(function(e) {
    "function" === typeof define && define.amd ? define(["jquery"], e) : e("undefined" != typeof jQuery ? jQuery : window.Zepto)
})(function(e) {
    function p(d) {
        var l = d.data;
        d.isDefaultPrevented() || (d.preventDefault(), e(d.target).ajaxSubmit(l))
    }

    function q(d) {
        var l = d.target,
            j = e(l);
        if (!j.is("[type=submit],[type=image]")) {
            l = j.closest("[type=submit]");
            if (0 === l.length) return;
            l = l[0]
        }
        var m = this;
        m.clk = l;
        "image" == l.type && (void 0 !== d.offsetX ? (m.clk_x = d.offsetX, m.clk_y = d.offsetY) : "function" == typeof e.fn.offset ? (j = j.offset(), m.clk_x = d.pageX - j.left, m.clk_y = d.pageY - j.top) : (m.clk_x = d.pageX - l.offsetLeft, m.clk_y = d.pageY - l.offsetTop));
        setTimeout(function() {
            m.clk = m.clk_x = m.clk_y = null
        }, 100)
    }

    function g() {
        if (e.fn.ajaxSubmit.debug) {
            var d = "[jquery.form] " + Array.prototype.join.call(arguments, "");
            window.console && window.console.log ? window.console.log(d) : window.opera && window.opera.postError && window.opera.postError(d)
        }
    }
    var c, a;
    c = void 0 !== e("<input type='file'/>").get(0).files;
    a = void 0 !== window.FormData;
    var b = !!e.fn.prop;
    e.fn.attr2 = function() {
        if (!b) return this.attr.apply(this, arguments);
        var d = this.prop.apply(this, arguments);
        return d && d.jquery || "string" === typeof d ? d : this.attr.apply(this, arguments)
    };
    e.fn.ajaxSubmit = function(d) {
        function l(E) {
            E = e.param(E, d.traditional).split("&");
            var J = E.length,
                C = [],
                H, F;
            for (H = 0; H < J; H++) {
                E[H] = E[H].replace(/\+/g, " ");
                F = E[H].split("=");
                C.push([decodeURIComponent(F[0]), decodeURIComponent(F[1])])
            }
            return C
        }

        function j(E) {
            for (var J = new FormData, C = 0; C < E.length; C++) J.append(E[C].name, E[C].value);
            if (d.extraData) {
                E = l(d.extraData);
                for (C = 0; C < E.length; C++) E[C] && J.append(E[C][0], E[C][1])
            }
            d.data = null;
            C = e.extend(true, {}, e.ajaxSettings, d, {
                contentType: false,
                processData: false,
                cache: false,
                type: h || "POST"
            });
            d.uploadProgress && (C.xhr = function() {
                var F = e.ajaxSettings.xhr();
                F.upload && F.upload.addEventListener("progress", function(I) {
                    var A = 0,
                        w = I.loaded || I.position,
                        x = I.total;
                    I.lengthComputable && (A = Math.ceil(w / x * 100));
                    d.uploadProgress(I, w, x, A)
                }, false);
                return F
            });
            C.data = null;
            var H = C.beforeSend;
            C.beforeSend = function(F, I) {
                I.data = d.formData ? d.formData : J;
                H && H.call(this, F, I)
            };
            return e.ajax(C)
        }

        function m(E) {
            function J(G) {
                var K = null;
                try {
                    G.contentWindow && (K = G.contentWindow.document)
                } catch (Q) {
                    g("cannot get iframe.contentWindow document: " + Q)
                }
                if (K) return K;
                try {
                    K = G.contentDocument ? G.contentDocument : G.document
                } catch (R) {
                    g("cannot get iframe.contentDocument: " + R);
                    K = G.document
                }
                return K
            }

            function C() {
                function G() {
                    try {
                        var V = J(v).readyState;
                        g("state = " + V);
                        V && "uninitialized" == V.toLowerCase() && setTimeout(G, 50)
                    } catch (Y) {
                        g("Server abort: ", Y, " (", Y.name, ")");
                        H(P);
                        T && clearTimeout(T);
                        T = void 0
                    }
                }
                var K = f.attr2("target"),
                    Q = f.attr2("action"),
                    R = f.attr("enctype") || f.attr("encoding") || "multipart/form-data";
                F.setAttribute("target", x);
                h && !/post/i.test(h) || F.setAttribute("method", "POST");
                Q != A.url && F.setAttribute("action", A.url);
                A.skipEncodingOverride || h && !/post/i.test(h) || f.attr({
                    encoding: "multipart/form-data",
                    enctype: "multipart/form-data"
                });
                A.timeout && (T = setTimeout(function() {
                    M = true;
                    H(y)
                }, A.timeout));
                var U = [];
                try {
                    if (A.extraData)
                        for (var S in A.extraData) A.extraData.hasOwnProperty(S) && (e.isPlainObject(A.extraData[S]) && A.extraData[S].hasOwnProperty("name") && A.extraData[S].hasOwnProperty("value") ? U.push(e('<input type="hidden" name="' + A.extraData[S].name + '">').val(A.extraData[S].value).appendTo(F)[0]) : U.push(e('<input type="hidden" name="' + S + '">').val(A.extraData[S]).appendTo(F)[0]));
                    A.iframeTarget || u.appendTo("body");
                    v.attachEvent ? v.attachEvent("onload", H) : v.addEventListener("load", H, false);
                    setTimeout(G, 15);
                    try {
                        F.submit()
                    } catch (Z) {
                        document.createElement("form").submit.apply(F)
                    }
                } finally {
                    F.setAttribute("action", Q);
                    F.setAttribute("enctype", R);
                    K ? F.setAttribute("target", K) : f.removeAttr("target");
                    e(U).remove()
                }
            }

            function H(G) {
                if (!D.aborted && !aa)
                    if (O = J(v), O || (g("cannot access response document"), G = P), G === y && D) {
                        D.abort("timeout");
                        N.reject(D, "timeout")
                    } else if (G == P && D) {
                    D.abort("server abort");
                    N.reject(D, "error", "server abort")
                } else if (O && O.location.href != A.iframeSrc || M) {
                    v.detachEvent ? v.detachEvent("onload", H) : v.removeEventListener("load", H, false);
                    G = "success";
                    var K;
                    try {
                        if (M) throw "timeout";
                        var Q = "xml" == A.dataType || O.XMLDocument || e.isXMLDoc(O);
                        g("isXml=" + Q);
                        if (!Q && window.opera && (null === O.body || !O.body.innerHTML) && --ba) {
                            g("requeing onLoad callback, DOM not available");
                            setTimeout(H, 250);
                            return
                        }
                        var R = O.body ? O.body : O.documentElement;
                        D.responseText = R ? R.innerHTML : null;
                        D.responseXML = O.XMLDocument ? O.XMLDocument : O;
                        Q && (A.dataType = "xml");
                        D.getResponseHeader = function(da) {
                            return {
                                "content-type": A.dataType
                            }[da.toLowerCase()]
                        };
                        R && (D.status = Number(R.getAttribute("status")) || D.status, D.statusText = R.getAttribute("statusText") || D.statusText);
                        var U = (A.dataType || "").toLowerCase(),
                            S = /(json|script|text)/.test(U);
                        if (S || A.textarea) {
                            var Z = O.getElementsByTagName("textarea")[0];
                            if (Z) {
                                D.responseText = Z.value;
                                D.status = Number(Z.getAttribute("status")) || D.status;
                                D.statusText = Z.getAttribute("statusText") || D.statusText
                            } else if (S) {
                                var V = O.getElementsByTagName("pre")[0],
                                    Y = O.getElementsByTagName("body")[0];
                                V ? D.responseText = V.textContent ? V.textContent : V.innerText : Y && (D.responseText = Y.textContent ? Y.textContent : Y.innerText)
                            }
                        } else "xml" == U && !D.responseXML && D.responseText && (D.responseXML = W(D.responseText));
                        try {
                            X = ea(D, U, A)
                        } catch (fa) {
                            G = "parsererror";
                            D.error = K = fa || G
                        }
                    } catch (ca) {
                        g("error caught: ", ca);
                        G = "error";
                        D.error = K = ca || G
                    }
                    D.aborted && (g("upload aborted"), G = null);
                    D.status && (G = 200 <= D.status && 300 > D.status || 304 === D.status ? "success" : "error");
                    "success" === G ? (A.success && A.success.call(A.context, X, "success", D), N.resolve(D.responseText, "success", D), w && e.event.trigger("ajaxSuccess", [D, A])) : G && (void 0 === K && (K = D.statusText), A.error && A.error.call(A.context, D, G, K), N.reject(D, "error", K), w && e.event.trigger("ajaxError", [D, A, K]));
                    w && e.event.trigger("ajaxComplete", [D, A]);
                    w && !--e.active && e.event.trigger("ajaxStop");
                    A.complete && A.complete.call(A.context, D, G);
                    aa = true;
                    A.timeout && clearTimeout(T);
                    setTimeout(function() {
                        A.iframeTarget ? u.attr("src", A.iframeSrc) : u.remove();
                        D.responseXML = null
                    }, 100)
                }
            }
            var F = f[0],
                I, A, w, x, u, v, D, M, T, N = e.Deferred();
            N.abort = function(G) {
                D.abort(G)
            };
            if (E)
                for (I = 0; I < n.length; I++) {
                    E = e(n[I]);
                    b ? E.prop("disabled", false) : E.removeAttr("disabled")
                }
            A = e.extend(true, {}, e.ajaxSettings, d);
            A.context = A.context || A;
            x = "jqFormIO" + (new Date).getTime();
            A.iframeTarget ? (u = e(A.iframeTarget), (I = u.attr2("name")) ? x = I : u.attr2("name", x)) : (u = e('<iframe name="' + x + '" src="' + A.iframeSrc + '" ></n>'), u.css({
                position: "absolute",
                top: "-1000px",
                left: "-1000px"
            }));
            v = u[0];
            D = {
                aborted: 0,
                responseText: null,
                responseXML: null,
                status: 0,
                statusText: "n/a",
                getAllResponseHeaders: function() {},
                getResponseHeader: function() {},
                setRequestHeader: function() {},
                abort: function(G) {
                    var K = "timeout" === G ? "timeout" : "aborted";
                    g("aborting upload... " + K);
                    this.aborted = 1;
                    try {
                        v.contentWindow.document.execCommand && v.contentWindow.document.execCommand("Stop")
                    } catch (Q) {}
                    u.attr("src", A.iframeSrc);
                    D.error = K;
                    A.error && A.error.call(A.context, D, K, G);
                    w && e.event.trigger("ajaxError", [D, A, K]);
                    A.complete && A.complete.call(A.context, D, K)
                }
            };
            (w = A.global) && 0 === e.active++ && e.event.trigger("ajaxStart");
            w && e.event.trigger("ajaxSend", [D, A]);
            if (A.beforeSend && false === A.beforeSend.call(A.context, D, A)) return A.global && e.active--, N.reject(), N;
            if (D.aborted) return N.reject(), N;
            (E = F.clk) && (I = E.name) && !E.disabled && (A.extraData = A.extraData || {}, A.extraData[I] = E.value, "image" == E.type && (A.extraData[I + ".x"] = F.clk_x, A.extraData[I + ".y"] = F.clk_y));
            var y = 1,
                P = 2;
            E = e("meta[name=csrf-token]").attr("content");
            (I = e("meta[name=csrf-param]").attr("content")) && E && (A.extraData = A.extraData || {}, A.extraData[I] = E);
            A.forceSync ? C() : setTimeout(C, 10);
            var X, O, ba = 50,
                aa, W = e.parseXML || function(G, K) {
                    window.ActiveXObject ? (K = new ActiveXObject("Microsoft.XMLDOM"), K.async = "false", K.loadXML(G)) : K = (new DOMParser).parseFromString(G, "text/xml");
                    return K && K.documentElement && "parsererror" != K.documentElement.nodeName ? K : null
                },
                ga = e.parseJSON || function(G) {
                    return window.eval("(" + G + ")")
                },
                ea = function(G, K, Q) {
                    var R = G.getResponseHeader("content-type") || "",
                        U = "xml" === K || !K && 0 <= R.indexOf("xml");
                    G = U ? G.responseXML : G.responseText;
                    U && "parsererror" === G.documentElement.nodeName && e.error && e.error("parsererror");
                    Q && Q.dataFilter && (G = Q.dataFilter(G, K));
                    "string" === typeof G && ("json" === K || !K && 0 <= R.indexOf("json") ? G = ga(G) : ("script" === K || !K && 0 <= R.indexOf("javascript")) && e.globalEval(G));
                    return G
                };
            return N
        }
        if (!this.length) return g("ajaxSubmit: skipping submit process - no element selected"), this;
        var h, k, f = this;
        "function" == typeof d ? d = {
            success: d
        } : void 0 === d && (d = {});
        h = d.type || this.attr2("method");
        k = d.url || this.attr2("action");
        (k = (k = "string" === typeof k ? e.trim(k) : "") || window.location.href || "") && (k = (k.match(/^([^#]+)/) || [])[1]);
        d = e.extend(true, {
            url: k,
            success: e.ajaxSettings.success,
            type: h || e.ajaxSettings.type,
            iframeSrc: /^https/i.test(window.location.href || "") ? "javascript:false" : "about:blank"
        }, d);
        k = {};
        this.trigger("form-pre-serialize", [this, d, k]);
        if (k.veto) return g("ajaxSubmit: submit vetoed via form-pre-serialize trigger"), this;
        if (d.beforeSerialize && false === d.beforeSerialize(this, d)) return g("ajaxSubmit: submit aborted via beforeSerialize callback"), this;
        var i = d.traditional;
        void 0 === i && (i = e.ajaxSettings.traditional);
        var n = [],
            o, r = this.formToArray(d.semantic, n);
        d.data && (d.extraData = d.data, o = e.param(d.data, i));
        if (d.beforeSubmit && false === d.beforeSubmit(r, this, d)) return g("ajaxSubmit: submit aborted via beforeSubmit callback"), this;
        this.trigger("form-submit-validate", [r, this, d, k]);
        if (k.veto) return g("ajaxSubmit: submit vetoed via form-submit-validate trigger"), this;
        k = e.param(r, i);
        o && (k = k ? k + "&" + o : o);
        "GET" == d.type.toUpperCase() ? (d.url += (0 <= d.url.indexOf("?") ? "&" : "?") + k, d.data = null) : d.data = k;
        var t = [];
        d.resetForm && t.push(function() {
            f.resetForm()
        });
        d.clearForm && t.push(function() {
            f.clearForm(d.includeHidden)
        });
        if (!d.dataType && d.target) {
            var s = d.success || function() {};
            t.push(function(E) {
                var J = d.replaceTarget ? "replaceWith" : "html";
                e(d.target)[J](E).each(s, arguments)
            })
        } else d.success && t.push(d.success);
        d.success = function(E, J, C) {
            for (var H = d.context || this, F = 0, I = t.length; F < I; F++) t[F].apply(H, [E, J, C || f, f])
        };
        if (d.error) {
            var B = d.error;
            d.error = function(E, J, C) {
                B.apply(d.context || this, [E, J, C, f])
            }
        }
        if (d.complete) {
            var z = d.complete;
            d.complete = function(E, J) {
                z.apply(d.context || this, [E, J, f])
            }
        }
        o = 0 < e("input[type=file]:enabled", this).filter(function() {
            return "" !== e(this).val()
        }).length;
        k = "multipart/form-data" == f.attr("enctype") || "multipart/form-data" == f.attr("encoding");
        i = c && a;
        g("fileAPI :" + i);
        var L;
        false !== d.iframe && (d.iframe || (o || k) && !i) ? d.closeKeepAlive ? e.get(d.closeKeepAlive, function() {
            L = m(r)
        }) : L = m(r) : L = (o || k) && i ? j(r) : e.ajax(d);
        f.removeData("jqxhr").data("jqxhr", L);
        for (o = 0; o < n.length; o++) n[o] = null;
        this.trigger("form-submit-notify", [this, d]);
        return this
    };
    e.fn.ajaxForm = function(d) {
        d = d || {};
        d.delegation = d.delegation && e.isFunction(e.fn.on);
        if (!d.delegation && 0 === this.length) {
            var l = this.selector,
                j = this.context;
            if (!e.isReady && l) return g("DOM not ready, queuing ajaxForm"), e(function() {
                e(l, j).ajaxForm(d)
            }), this;
            g("terminating; zero elements found by selector" + (e.isReady ? "" : " (DOM not ready)"));
            return this
        }
        return d.delegation ? (e(document).off("submit.form-plugin", this.selector, p).off("click.form-plugin", this.selector, q).on("submit.form-plugin", this.selector, d, p).on("click.form-plugin", this.selector, d, q), this) : this.ajaxFormUnbind().bind("submit.form-plugin", d, p).bind("click.form-plugin", d, q)
    };
    e.fn.ajaxFormUnbind = function() {
        return this.unbind("submit.form-plugin click.form-plugin")
    };
    e.fn.formToArray = function(d, l) {
        var j = [];
        if (0 === this.length) return j;
        var m = this[0],
            h = this.attr("id"),
            k = d ? m.getElementsByTagName("*") : m.elements;
        k && !/MSIE [678]/.test(navigator.userAgent) && (k = e(k).get());
        h && (h = e(":input[form=" + h + "]").get(), h.length && (k = (k || []).concat(h)));
        if (!k || !k.length) return j;
        var f, i, n, o, r;
        f = 0;
        for (r = k.length; f < r; f++)
            if (o = k[f], (h = o.name) && !o.disabled)
                if (d && m.clk && "image" == o.type) m.clk == o && (j.push({
                    name: h,
                    value: e(o).val(),
                    type: o.type
                }), j.push({
                    name: h + ".x",
                    value: m.clk_x
                }, {
                    name: h +
                        ".y",
                    value: m.clk_y
                }));
                else if ((n = e.fieldValue(o, true)) && n.constructor == Array) {
            l && l.push(o);
            i = 0;
            for (o = n.length; i < o; i++) j.push({
                name: h,
                value: n[i]
            })
        } else if (c && "file" == o.type)
            if (l && l.push(o), n = o.files, n.length)
                for (i = 0; i < n.length; i++) j.push({
                    name: h,
                    value: n[i],
                    type: o.type
                });
            else j.push({
                name: h,
                value: "",
                type: o.type
            });
        else null !== n && "undefined" != typeof n && (l && l.push(o), j.push({
            name: h,
            value: n,
            type: o.type,
            required: o.required
        }));
        !d && m.clk && (k = e(m.clk), f = k[0], (h = f.name) && !f.disabled && "image" == f.type && (j.push({
            name: h,
            value: k.val()
        }), j.push({
            name: h + ".x",
            value: m.clk_x
        }, {
            name: h + ".y",
            value: m.clk_y
        })));
        return j
    };
    e.fn.formSerialize = function(d) {
        return e.param(this.formToArray(d))
    };
    e.fn.fieldSerialize = function(d) {
        var l = [];
        this.each(function() {
            var j = this.name;
            if (j) {
                var m = e.fieldValue(this, d);
                if (m && m.constructor == Array)
                    for (var h = 0, k = m.length; h < k; h++) l.push({
                        name: j,
                        value: m[h]
                    });
                else null !== m && "undefined" != typeof m && l.push({
                    name: this.name,
                    value: m
                })
            }
        });
        return e.param(l)
    };
    e.fn.fieldValue = function(d) {
        for (var l = [], j = 0, m = this.length; j < m; j++) {
            var h = e.fieldValue(this[j], d);
            null === h || "undefined" == typeof h || h.constructor == Array && !h.length || (h.constructor == Array ? e.merge(l, h) : l.push(h))
        }
        return l
    };
    e.fieldValue = function(d, l) {
        var j = d.name,
            m = d.type,
            h = d.tagName.toLowerCase();
        void 0 === l && (l = true);
        if (l && (!j || d.disabled || "reset" == m || "button" == m || ("checkbox" == m || "radio" == m) && !d.checked || ("submit" == m || "image" == m) && d.form && d.form.clk != d || "select" == h && -1 == d.selectedIndex)) return null;
        if ("select" == h) {
            var k = d.selectedIndex;
            if (0 > k) return null;
            j = [];
            h = d.options;
            var f = (m = "select-one" == m) ? k + 1 : h.length;
            for (k = m ? k : 0; k < f; k++) {
                var i = h[k];
                if (i.selected) {
                    var n = i.value;
                    n || (n = i.attributes && i.attributes.value && !i.attributes.value.specified ? i.text : i.value);
                    if (m) return n;
                    j.push(n)
                }
            }
            return j
        }
        return e(d).val()
    };
    e.fn.clearForm = function(d) {
        return this.each(function() {
            e("input,select,textarea", this).clearFields(d)
        })
    };
    e.fn.clearFields = e.fn.clearInputs = function(d) {
        var l = /^(?:color|date|datetime|email|month|number|password|range|search|tel|text|time|url|week)$/i;
        return this.each(function() {
            var j = this.type,
                m = this.tagName.toLowerCase();
            l.test(j) || "textarea" == m ? this.value = "" : "checkbox" == j || "radio" == j ? this.checked = false : "select" == m ? this.selectedIndex = -1 : "file" == j ? /MSIE/.test(navigator.userAgent) ? e(this).replaceWith(e(this).clone(true)) : e(this).val("") : d && (true === d && /hidden/.test(j) || "string" == typeof d && e(this).is(d)) && (this.value = "")
        })
    };
    e.fn.resetForm = function() {
        return this.each(function() {
            ("function" == typeof this.reset || "object" == typeof this.reset && !this.reset.nodeType) && this.reset()
        })
    };
    e.fn.enable = function(d) {
        void 0 === d && (d = true);
        return this.each(function() {
            this.disabled = !d
        })
    };
    e.fn.selected = function(d) {
        void 0 === d && (d = true);
        return this.each(function() {
            var l = this.type;
            "checkbox" == l || "radio" == l ? this.checked = d : "option" == this.tagName.toLowerCase() && (l = e(this).parent("select"), d && l[0] && "select-one" == l[0].type && l.find("option").selected(false), this.selected = d)
        })
    };
    e.fn.ajaxSubmit.debug = false
});
(function(e) {
    if (!e.ionSound) {
        var p = {},
            q, g, c, a, b = {},
            d = false,
            l = function(m) {
                var h, k; - 1 !== m.indexOf(":") ? (h = m.split(":")[0], k = m.split(":")[1]) : h = m;
                b[h] = new Audio;
                g = b[h].canPlayType("audio/mp3");
                c = "probably" === g || "maybe" === g ? p.path + h + ".mp3" : p.path + h + ".ogg";
                e(b[h]).prop("src", c);
                b[h].load();
                b[h].preload = "auto";
                b[h].volume = k || p.volume
            },
            j = function(m) {
                var h, k, f, i; - 1 !== m.indexOf(":") ? (k = m.split(":")[0], f = m.split(":")[1]) : k = m;
                h = b[k];
                if ("object" === typeof h && null !== h)
                    if (f && (h.volume = f), !p.multiPlay && !d) {
                        h.play();
                        d = true;
                        i = setInterval(function() {
                            h.ended && (clearInterval(i), d = false)
                        }, 250)
                    } else if (p.multiPlay) {
                    if (!h.ended) try {
                        h.currentTime = 0
                    } catch (n) {}
                    h.play()
                }
            };
        e.ionSound = function(m) {
            p = e.extend({
                sounds: ["water_droplet"],
                path: "static/sounds/",
                multiPlay: true,
                volume: "0.5"
            }, m);
            q = p.sounds.length;
            if ("function" === typeof Audio || "object" === typeof Audio)
                for (a = 0; a < q; a += 1) l(p.sounds[a]);
            e.ionSound.play = function(h) {
                j(h)
            };
            e.ionSound.stop = function(h) {
                h = b[h];
                if ("object" === typeof h && null !== h) {
                    h.pause();
                    try {
                        h.currentTime = 0
                    } catch (k) {}
                }
            };
            e.ionSound.kill = function(h) {
                var k = b[h];
                if ("object" === typeof k && null !== k) {
                    try {
                        b[h].src = ""
                    } catch (f) {}
                    b[h] = null
                }
            }
        };
        e.ionSound.destroy = function() {
            for (a = 0; a < q; a += 1) b[p.sounds[a]] = null;
            q = 0;
            e.ionSound.play = function() {};
            e.ionSound.stop = function() {};
            e.ionSound.kill = function() {}
        }
    }
})(jQuery);
(function(e, p, q) {
    "undefined" !== typeof module && module.exports ? module.exports = q() : "function" === typeof define && define.amd ? define(q) : p[e] = q()
})("Fingerprint", this, function() {
    var e = function(p) {
        var q, g;
        q = Array.prototype.forEach;
        g = Array.prototype.map;
        this.each = function(c, a, b) {
            if (null !== c)
                if (q && c.forEach === q) c.forEach(a, b);
                else if (c.length === +c.length)
                for (var d = 0, l = c.length; d < l && a.call(b, c[d], d, c) !== {}; d++);
            else
                for (d in c)
                    if (c.hasOwnProperty(d) && a.call(b, c[d], d, c) === {}) break
        };
        this.map = function(c, a, b) {
            var d = [];
            if (null == c) return d;
            if (g && c.map === g) return c.map(a, b);
            this.each(c, function(l, j, m) {
                d[d.length] = a.call(b, l, j, m)
            });
            return d
        };
        "object" == typeof p ? (this.hasher = p.hasher, this.screen_resolution = p.screen_resolution, this.screen_orientation = p.screen_orientation, this.canvas = p.canvas, this.ie_activex = p.ie_activex) : "function" == typeof p && (this.hasher = p)
    };
    e.prototype = {
        get: function() {
            var p = [];
            p.push(navigator.userAgent);
            p.push(navigator.language);
            p.push(screen.colorDepth);
            this.screen_resolution && "undefined" !== typeof this.getScreenResolution() && p.push(this.getScreenResolution().join("x"));
            p.push((new Date).getTimezoneOffset());
            p.push(this.hasSessionStorage());
            p.push(this.hasLocalStorage());
            p.push(!!window.indexedDB);
            document.body ? p.push(typeof document.body.addBehavior) : p.push("undefined");
            p.push(typeof window.openDatabase);
            p.push(navigator.cpuClass);
            p.push(navigator.platform);
            p.push(navigator.doNotTrack);
            p.push(this.getPluginsString());
            this.canvas && this.isCanvasSupported() && p.push(this.getCanvasFingerprint());
            return this.hasher ? this.hasher(p.join("###"), 31) : this.murmurhash3_32_gc(p.join("###"), 31)
        },
        murmurhash3_32_gc: function(p, q) {
            var g, c, a, b, d;
            g = p.length & 3;
            c = p.length - g;
            a = q;
            for (d = 0; d < c;) {
                b = p.charCodeAt(d) & 255 | (p.charCodeAt(++d) & 255) << 8 | (p.charCodeAt(++d) & 255) << 16 | (p.charCodeAt(++d) & 255) << 24;
                ++d;
                b = 3432918353 * (b & 65535) + ((3432918353 * (b >>> 16) & 65535) << 16) & 4294967295;
                b = b << 15 | b >>> 17;
                b = 461845907 * (b & 65535) + ((461845907 * (b >>> 16) & 65535) << 16) & 4294967295;
                a ^= b;
                a = a << 13 | a >>> 19;
                a = 5 * (a & 65535) + ((5 * (a >>> 16) & 65535) << 16) & 4294967295;
                a = (a & 65535) + 27492 + (((a >>> 16) + 58964 & 65535) << 16)
            }
            b = 0;
            switch (g) {
                case 3:
                    b ^= (p.charCodeAt(d + 2) & 255) << 16;
                case 2:
                    b ^= (p.charCodeAt(d + 1) & 255) << 8;
                case 1:
                    b ^= p.charCodeAt(d) & 255;
                    b = 3432918353 * (b & 65535) + ((3432918353 * (b >>> 16) & 65535) << 16) & 4294967295;
                    b = b << 15 | b >>> 17;
                    a ^= 461845907 * (b & 65535) + ((461845907 * (b >>> 16) & 65535) << 16) & 4294967295
            }
            a ^= p.length;
            a ^= a >>> 16;
            a = 2246822507 * (a & 65535) + ((2246822507 * (a >>> 16) & 65535) << 16) & 4294967295;
            a ^= a >>> 13;
            a = 3266489909 * (a & 65535) + ((3266489909 * (a >>> 16) & 65535) << 16) & 4294967295;
            return (a ^ a >>> 16) >>> 0
        },
        hasLocalStorage: function() {
            try {
                return !!window.localStorage
            } catch (p) {
                return true
            }
        },
        hasSessionStorage: function() {
            try {
                return !!window.sessionStorage
            } catch (p) {
                return true
            }
        },
        isCanvasSupported: function() {
            var p = document.createElement("canvas");
            return !(!p.getContext || !p.getContext("2d"))
        },
        isIE: function() {
            return "Microsoft Internet Explorer" === navigator.appName || "Netscape" === navigator.appName && /Trident/.test(navigator.userAgent) ? true : false
        },
        getPluginsString: function() {
            return this.isIE() && this.ie_activex ? this.getIEPluginsString() : this.getRegularPluginsString()
        },
        getRegularPluginsString: function() {
            return this.map(navigator.plugins, function(p) {
                var q = this.map(p, function(g) {
                    return [g.type, g.suffixes].join("~")
                }).join(",");
                return [p.name, p.description, q].join("::")
            }, this).join(";")
        },
        getIEPluginsString: function() {
            return window.ActiveXObject ? this.map("ShockwaveFlash.ShockwaveFlash;AcroPDF.PDF;PDF.PdfCtrl;QuickTime.QuickTime;rmocx.RealPlayer G2 Control;rmocx.RealPlayer G2 Control.1;RealPlayer.RealPlayer(tm) ActiveX Control (32-bit);RealVideo.RealVideo(tm) ActiveX Control (32-bit);RealPlayer;SWCtl.SWCtl;WMPlayer.OCX;AgControl.AgControl;Skype.Detection".split(";"), function(p) {
                try {
                    return new ActiveXObject(p), p
                } catch (q) {
                    return null
                }
            }).join(";") : ""
        },
        getScreenResolution: function() {
            return this.screen_orientation ? screen.height > screen.width ? [screen.height, screen.width] : [screen.width, screen.height] : [screen.height, screen.width]
        },
        getCanvasFingerprint: function() {
            var p = document.createElement("canvas"),
                q = p.getContext("2d");
            q.textBaseline = "top";
            q.font = "14px 'Arial'";
            q.textBaseline = "alphabetic";
            q.fillStyle = "#f60";
            q.fillRect(125, 1, 62, 20);
            q.fillStyle = "#069";
            q.fillText("http://valve.github.io", 2, 15);
            q.fillStyle = "rgba(102, 204, 0, 0.7)";
            q.fillText("http://valve.github.io", 4, 17);
            return p.toDataURL()
        }
    };
    return e
});
(function(e) {
    function p(g, c) {
        function a(n, o) {
            n && !d[n] && (d[n] = {});
            for (var r in o) {
                var t = o[r];
                if (t instanceof Array)
                    for (var s = 0; s < t.length; s++) b(n, r, t[s]);
                else switch (typeof t) {
                    case "number":
                    case "string":
                        b(n, r, t);
                        break;
                    case "object":
                        if (s = r.charAt(r.length - 1), !n || "_" !== s && "-" !== s) {
                            var B = n;
                            s = [];
                            var z = r.split(/\s*,\s*/);
                            B = B.split(/\s*,\s*/);
                            for (var L = 0; L < B.length; L++)
                                for (var E = B[L], J = 0; J < z.length; J++) {
                                    var C = z[J];
                                    "&" === C.charAt(0) ? s.push(E + C.substr(1)) : s.push(E ? E + " " + C : C)
                                }
                            s = s.join(", ");
                            a(s, t)
                        } else
                            for (var H in t) {
                                s = H.split(/\s*,\s*/);
                                for (z = 0; z < s.length; z++)
                                    if (B = t[H], B instanceof Array)
                                        for (L = 0; L < B.length; L++) b(n, r + s[z], B[L]);
                                    else b(n, r + s[z], t[H])
                            }
                }
            }
        }

        function b(n, o, r) {
            "number" !== typeof r || c.useRawValues || (r += "px");
            o = o.split(/\s*,\s*/);
            for (var t = 0; t < o.length; t++) {
                var s = o[t].replace(/_/g, "-");
                d[n][s] ? d[n][s].push(r) : d[n][s] = [r]
            }
        }
        var d = {};
        if ("string" === typeof g) try {
            eval("var jss = {" + g + "}")
        } catch (l) {
            return ""
        }
        a("", g);
        var j = "",
            m;
        for (m in d) {
            var h = d[m];
            j += m + " {\n";
            for (var k in h)
                for (var f = h[k], i = 0; i < f.length; i++) j += "\t" + k + ": " + f[i] + ";\n";
            j += "}\n"
        }
        return j
    }
    var q = {
        truncateFirst: false,
        container: null,
        containerName: "injectCSSContainer",
        useRawValues: false
    };
    e.injectCSS = function(g, c) {
        c = e.extend({}, q, c);
        c.media = c.media || "all";
        var a = c.container && e(c.container) || e("#" + c.containerName);
        a.length || (a = e("<style></style>").appendTo("head").attr({
            media: c.media,
            id: c.containerName,
            type: "text/css"
        }));
        var b = a[0],
            d = void 0 !== b.styleSheet && void 0 !== b.styleSheet.cssText,
            l = "";
        c.truncateFirst || (l += d ? b.styleSheet.cssText : a.text());
        l += p(g, c);
        d ? b.styleSheet.cssText = l : a.text(l);
        return a
    }
})(jQuery);
var CryptoJS = CryptoJS || function(e, p) {
    var q = {},
        g = q.lib = {},
        c = function() {},
        a = g.Base = {
            extend: function(f) {
                c.prototype = this;
                var i = new c;
                f && i.mixIn(f);
                i.hasOwnProperty("init") || (i.init = function() {
                    i.$super.init.apply(this, arguments)
                });
                i.init.prototype = i;
                i.$super = this;
                return i
            },
            create: function() {
                var f = this.extend();
                f.init.apply(f, arguments);
                return f
            },
            init: function() {},
            mixIn: function(f) {
                for (var i in f) f.hasOwnProperty(i) && (this[i] = f[i]);
                f.hasOwnProperty("toString") && (this.toString = f.toString)
            },
            clone: function() {
                return this.init.prototype.extend(this)
            }
        },
        b = g.WordArray = a.extend({
            init: function(f, i) {
                f = this.words = f || [];
                this.sigBytes = i != p ? i : 4 * f.length
            },
            toString: function(f) {
                return (f || l).stringify(this)
            },
            concat: function(f) {
                var i = this.words,
                    n = f.words,
                    o = this.sigBytes;
                f = f.sigBytes;
                this.clamp();
                if (o % 4)
                    for (var r = 0; r < f; r++) i[o + r >>> 2] |= (n[r >>> 2] >>> 24 - r % 4 * 8 & 255) << 24 - (o + r) % 4 * 8;
                else if (65535 < n.length)
                    for (r = 0; r < f; r += 4) i[o + r >>> 2] = n[r >>> 2];
                else i.push.apply(i, n);
                this.sigBytes += f;
                return this
            },
            clamp: function() {
                var f = this.words,
                    i = this.sigBytes;
                f[i >>> 2] &= 4294967295 << 32 -
                    i % 4 * 8;
                f.length = e.ceil(i / 4)
            },
            clone: function() {
                var f = a.clone.call(this);
                f.words = this.words.slice(0);
                return f
            },
            random: function(f) {
                for (var i = [], n = 0; n < f; n += 4) i.push(4294967296 * e.random() | 0);
                return new b.init(i, f)
            }
        }),
        d = q.enc = {},
        l = d.Hex = {
            stringify: function(f) {
                var i = f.words;
                f = f.sigBytes;
                for (var n = [], o = 0; o < f; o++) {
                    var r = i[o >>> 2] >>> 24 - o % 4 * 8 & 255;
                    n.push((r >>> 4).toString(16));
                    n.push((r & 15).toString(16))
                }
                return n.join("")
            },
            parse: function(f) {
                for (var i = f.length, n = [], o = 0; o < i; o += 2) n[o >>> 3] |= parseInt(f.substr(o, 2), 16) << 24 - o % 8 * 4;
                return new b.init(n, i / 2)
            }
        },
        j = d.Latin1 = {
            stringify: function(f) {
                var i = f.words;
                f = f.sigBytes;
                for (var n = [], o = 0; o < f; o++) n.push(String.fromCharCode(i[o >>> 2] >>> 24 - o % 4 * 8 & 255));
                return n.join("")
            },
            parse: function(f) {
                for (var i = f.length, n = [], o = 0; o < i; o++) n[o >>> 2] |= (f.charCodeAt(o) & 255) << 24 - o % 4 * 8;
                return new b.init(n, i)
            }
        },
        m = d.Utf8 = {
            stringify: function(f) {
                try {
                    return decodeURIComponent(escape(j.stringify(f)))
                } catch (i) {
                    throw Error("Malformed UTF-8 data");
                }
            },
            parse: function(f) {
                return j.parse(unescape(encodeURIComponent(f)))
            }
        },
        h = g.BufferedBlockAlgorithm = a.extend({
            reset: function() {
                this._data = new b.init;
                this._nDataBytes = 0
            },
            _append: function(f) {
                "string" == typeof f && (f = m.parse(f));
                this._data.concat(f);
                this._nDataBytes += f.sigBytes
            },
            _process: function(f) {
                var i = this._data,
                    n = i.words,
                    o = i.sigBytes,
                    r = this.blockSize,
                    t = o / (4 * r);
                t = f ? e.ceil(t) : e.max((t | 0) - this._minBufferSize, 0);
                f = t * r;
                o = e.min(4 * f, o);
                if (f) {
                    for (var s = 0; s < f; s += r) this._doProcessBlock(n, s);
                    s = n.splice(0, f);
                    i.sigBytes -= o
                }
                return new b.init(s, o)
            },
            clone: function() {
                var f = a.clone.call(this);
                f._data = this._data.clone();
                return f
            },
            _minBufferSize: 0
        });
    g.Hasher = h.extend({
        cfg: a.extend(),
        init: function(f) {
            this.cfg = this.cfg.extend(f);
            this.reset()
        },
        reset: function() {
            h.reset.call(this);
            this._doReset()
        },
        update: function(f) {
            this._append(f);
            this._process();
            return this
        },
        finalize: function(f) {
            f && this._append(f);
            return this._doFinalize()
        },
        blockSize: 16,
        _createHelper: function(f) {
            return function(i, n) {
                return (new f.init(n)).finalize(i)
            }
        },
        _createHmacHelper: function(f) {
            return function(i, n) {
                return (new k.HMAC.init(f, n)).finalize(i)
            }
        }
    });
    var k = q.algo = {};
    return q
}(Math);
(function(e) {
    var p = CryptoJS,
        q = p.lib,
        g = q.WordArray,
        c = q.Hasher;
    q = p.algo;
    for (var a = [], b = [], d = function(i) {
            return 4294967296 * (i - (i | 0)) | 0
        }, l = 2, j = 0; 64 > j;) {
        var m;
        a: {
            m = l;
            for (var h = e.sqrt(m), k = 2; k <= h; k++)
                if (!(m % k)) {
                    m = false;
                    break a
                }
            m = true
        }
        m && (8 > j && (a[j] = d(e.pow(l, 0.5))), b[j] = d(e.pow(l, 1 / 3)), j++);
        l++
    }
    var f = [];
    q = q.SHA256 = c.extend({
        _doReset: function() {
            this._hash = new g.init(a.slice(0))
        },
        _doProcessBlock: function(i, n) {
            for (var o = this._hash.words, r = o[0], t = o[1], s = o[2], B = o[3], z = o[4], L = o[5], E = o[6], J = o[7], C = 0; 64 > C; C++) {
                if (16 > C) f[C] = i[n + C] | 0;
                else {
                    var H = f[C - 15],
                        F = f[C - 2];
                    f[C] = ((H << 25 | H >>> 7) ^ (H << 14 | H >>> 18) ^ H >>> 3) + f[C - 7] + ((F << 15 | F >>> 17) ^ (F << 13 | F >>> 19) ^ F >>> 10) + f[C - 16]
                }
                H = J + ((z << 26 | z >>> 6) ^ (z << 21 | z >>> 11) ^ (z << 7 | z >>> 25)) + (z & L ^ ~z & E) + b[C] + f[C];
                F = ((r << 30 | r >>> 2) ^ (r << 19 | r >>> 13) ^ (r << 10 | r >>> 22)) + (r & t ^ r & s ^ t & s);
                J = E;
                E = L;
                L = z;
                z = B + H | 0;
                B = s;
                s = t;
                t = r;
                r = H + F | 0
            }
            o[0] = o[0] + r | 0;
            o[1] = o[1] + t | 0;
            o[2] = o[2] + s | 0;
            o[3] = o[3] + B | 0;
            o[4] = o[4] + z | 0;
            o[5] = o[5] + L | 0;
            o[6] = o[6] + E | 0;
            o[7] = o[7] + J | 0
        },
        _doFinalize: function() {
            var i = this._data,
                n = i.words,
                o = 8 * this._nDataBytes,
                r = 8 * i.sigBytes;
            n[r >>> 5] |= 128 << 24 - r % 32;
            n[(r + 64 >>> 9 << 4) + 14] = e.floor(o / 4294967296);
            n[(r + 64 >>> 9 << 4) + 15] = o;
            i.sigBytes = 4 * n.length;
            this._process();
            return this._hash
        },
        clone: function() {
            var i = c.clone.call(this);
            i._hash = this._hash.clone();
            return i
        }
    });
    p.SHA256 = c._createHelper(q);
    p.HmacSHA256 = c._createHmacHelper(q)
})(Math);
CryptoJS = CryptoJS || function(e, p) {
    var q = {},
        g = q.lib = {},
        c = function() {},
        a = g.Base = {
            extend: function(f) {
                c.prototype = this;
                var i = new c;
                f && i.mixIn(f);
                i.hasOwnProperty("init") || (i.init = function() {
                    i.$super.init.apply(this, arguments)
                });
                i.init.prototype = i;
                i.$super = this;
                return i
            },
            create: function() {
                var f = this.extend();
                f.init.apply(f, arguments);
                return f
            },
            init: function() {},
            mixIn: function(f) {
                for (var i in f) f.hasOwnProperty(i) && (this[i] = f[i]);
                f.hasOwnProperty("toString") && (this.toString = f.toString)
            },
            clone: function() {
                return this.init.prototype.extend(this)
            }
        },
        b = g.WordArray = a.extend({
            init: function(f, i) {
                f = this.words = f || [];
                this.sigBytes = i != p ? i : 4 * f.length
            },
            toString: function(f) {
                return (f || l).stringify(this)
            },
            concat: function(f) {
                var i = this.words,
                    n = f.words,
                    o = this.sigBytes;
                f = f.sigBytes;
                this.clamp();
                if (o % 4)
                    for (var r = 0; r < f; r++) i[o + r >>> 2] |= (n[r >>> 2] >>> 24 - r % 4 * 8 & 255) << 24 - (o + r) % 4 * 8;
                else if (65535 < n.length)
                    for (r = 0; r < f; r += 4) i[o + r >>> 2] = n[r >>> 2];
                else i.push.apply(i, n);
                this.sigBytes += f;
                return this
            },
            clamp: function() {
                var f = this.words,
                    i = this.sigBytes;
                f[i >>> 2] &= 4294967295 << 32 -
                    i % 4 * 8;
                f.length = e.ceil(i / 4)
            },
            clone: function() {
                var f = a.clone.call(this);
                f.words = this.words.slice(0);
                return f
            },
            random: function(f) {
                for (var i = [], n = 0; n < f; n += 4) i.push(4294967296 * e.random() | 0);
                return new b.init(i, f)
            }
        }),
        d = q.enc = {},
        l = d.Hex = {
            stringify: function(f) {
                var i = f.words;
                f = f.sigBytes;
                for (var n = [], o = 0; o < f; o++) {
                    var r = i[o >>> 2] >>> 24 - o % 4 * 8 & 255;
                    n.push((r >>> 4).toString(16));
                    n.push((r & 15).toString(16))
                }
                return n.join("")
            },
            parse: function(f) {
                for (var i = f.length, n = [], o = 0; o < i; o += 2) n[o >>> 3] |= parseInt(f.substr(o, 2), 16) << 24 - o % 8 * 4;
                return new b.init(n, i / 2)
            }
        },
        j = d.Latin1 = {
            stringify: function(f) {
                var i = f.words;
                f = f.sigBytes;
                for (var n = [], o = 0; o < f; o++) n.push(String.fromCharCode(i[o >>> 2] >>> 24 - o % 4 * 8 & 255));
                return n.join("")
            },
            parse: function(f) {
                for (var i = f.length, n = [], o = 0; o < i; o++) n[o >>> 2] |= (f.charCodeAt(o) & 255) << 24 - o % 4 * 8;
                return new b.init(n, i)
            }
        },
        m = d.Utf8 = {
            stringify: function(f) {
                try {
                    return decodeURIComponent(escape(j.stringify(f)))
                } catch (i) {
                    throw Error("Malformed UTF-8 data");
                }
            },
            parse: function(f) {
                return j.parse(unescape(encodeURIComponent(f)))
            }
        },
        h = g.BufferedBlockAlgorithm = a.extend({
            reset: function() {
                this._data = new b.init;
                this._nDataBytes = 0
            },
            _append: function(f) {
                "string" == typeof f && (f = m.parse(f));
                this._data.concat(f);
                this._nDataBytes += f.sigBytes
            },
            _process: function(f) {
                var i = this._data,
                    n = i.words,
                    o = i.sigBytes,
                    r = this.blockSize,
                    t = o / (4 * r);
                t = f ? e.ceil(t) : e.max((t | 0) - this._minBufferSize, 0);
                f = t * r;
                o = e.min(4 * f, o);
                if (f) {
                    for (var s = 0; s < f; s += r) this._doProcessBlock(n, s);
                    s = n.splice(0, f);
                    i.sigBytes -= o
                }
                return new b.init(s, o)
            },
            clone: function() {
                var f = a.clone.call(this);
                f._data = this._data.clone();
                return f
            },
            _minBufferSize: 0
        });
    g.Hasher = h.extend({
        cfg: a.extend(),
        init: function(f) {
            this.cfg = this.cfg.extend(f);
            this.reset()
        },
        reset: function() {
            h.reset.call(this);
            this._doReset()
        },
        update: function(f) {
            this._append(f);
            this._process();
            return this
        },
        finalize: function(f) {
            f && this._append(f);
            return this._doFinalize()
        },
        blockSize: 16,
        _createHelper: function(f) {
            return function(i, n) {
                return (new f.init(n)).finalize(i)
            }
        },
        _createHmacHelper: function(f) {
            return function(i, n) {
                return (new k.HMAC.init(f, n)).finalize(i)
            }
        }
    });
    var k = q.algo = {};
    return q
}(Math);
(function(e) {
    function p(h, k, f, i, n, o, r) {
        h = h + (k & f | ~k & i) + n + r;
        return (h << o | h >>> 32 - o) + k
    }

    function q(h, k, f, i, n, o, r) {
        h = h + (k & i | f & ~i) + n + r;
        return (h << o | h >>> 32 - o) + k
    }

    function g(h, k, f, i, n, o, r) {
        h = h + (k ^ f ^ i) + n + r;
        return (h << o | h >>> 32 - o) + k
    }

    function c(h, k, f, i, n, o, r) {
        h = h + (f ^ (k | ~i)) + n + r;
        return (h << o | h >>> 32 - o) + k
    }
    var a = CryptoJS,
        b = a.lib,
        d = b.WordArray,
        l = b.Hasher;
    b = a.algo;
    for (var j = [], m = 0; 64 > m; m++) j[m] = 4294967296 * e.abs(e.sin(m + 1)) | 0;
    b = b.MD5 = l.extend({
        _doReset: function() {
            this._hash = new d.init([1732584193, 4023233417, 2562383102, 271733878])
        },
        _doProcessBlock: function(h, k) {
            for (var f = 0; 16 > f; f++) {
                var i = k + f,
                    n = h[i];
                h[i] = (n << 8 | n >>> 24) & 16711935 | (n << 24 | n >>> 8) & 4278255360
            }
            f = this._hash.words;
            i = h[k + 0];
            n = h[k + 1];
            var o = h[k + 2],
                r = h[k + 3],
                t = h[k + 4],
                s = h[k + 5],
                B = h[k + 6],
                z = h[k + 7],
                L = h[k + 8],
                E = h[k + 9],
                J = h[k + 10],
                C = h[k + 11],
                H = h[k + 12],
                F = h[k + 13],
                I = h[k + 14],
                A = h[k + 15],
                w = f[0],
                x = f[1],
                u = f[2],
                v = f[3];
            w = p(w, x, u, v, i, 7, j[0]);
            v = p(v, w, x, u, n, 12, j[1]);
            u = p(u, v, w, x, o, 17, j[2]);
            x = p(x, u, v, w, r, 22, j[3]);
            w = p(w, x, u, v, t, 7, j[4]);
            v = p(v, w, x, u, s, 12, j[5]);
            u = p(u, v, w, x, B, 17, j[6]);
            x = p(x, u, v, w, z, 22, j[7]);
            w = p(w, x, u, v, L, 7, j[8]);
            v = p(v, w, x, u, E, 12, j[9]);
            u = p(u, v, w, x, J, 17, j[10]);
            x = p(x, u, v, w, C, 22, j[11]);
            w = p(w, x, u, v, H, 7, j[12]);
            v = p(v, w, x, u, F, 12, j[13]);
            u = p(u, v, w, x, I, 17, j[14]);
            x = p(x, u, v, w, A, 22, j[15]);
            w = q(w, x, u, v, n, 5, j[16]);
            v = q(v, w, x, u, B, 9, j[17]);
            u = q(u, v, w, x, C, 14, j[18]);
            x = q(x, u, v, w, i, 20, j[19]);
            w = q(w, x, u, v, s, 5, j[20]);
            v = q(v, w, x, u, J, 9, j[21]);
            u = q(u, v, w, x, A, 14, j[22]);
            x = q(x, u, v, w, t, 20, j[23]);
            w = q(w, x, u, v, E, 5, j[24]);
            v = q(v, w, x, u, I, 9, j[25]);
            u = q(u, v, w, x, r, 14, j[26]);
            x = q(x, u, v, w, L, 20, j[27]);
            w = q(w, x, u, v, F, 5, j[28]);
            v = q(v, w, x, u, o, 9, j[29]);
            u = q(u, v, w, x, z, 14, j[30]);
            x = q(x, u, v, w, H, 20, j[31]);
            w = g(w, x, u, v, s, 4, j[32]);
            v = g(v, w, x, u, L, 11, j[33]);
            u = g(u, v, w, x, C, 16, j[34]);
            x = g(x, u, v, w, I, 23, j[35]);
            w = g(w, x, u, v, n, 4, j[36]);
            v = g(v, w, x, u, t, 11, j[37]);
            u = g(u, v, w, x, z, 16, j[38]);
            x = g(x, u, v, w, J, 23, j[39]);
            w = g(w, x, u, v, F, 4, j[40]);
            v = g(v, w, x, u, i, 11, j[41]);
            u = g(u, v, w, x, r, 16, j[42]);
            x = g(x, u, v, w, B, 23, j[43]);
            w = g(w, x, u, v, E, 4, j[44]);
            v = g(v, w, x, u, H, 11, j[45]);
            u = g(u, v, w, x, A, 16, j[46]);
            x = g(x, u, v, w, o, 23, j[47]);
            w = c(w, x, u, v, i, 6, j[48]);
            v = c(v, w, x, u, z, 10, j[49]);
            u = c(u, v, w, x, I, 15, j[50]);
            x = c(x, u, v, w, s, 21, j[51]);
            w = c(w, x, u, v, H, 6, j[52]);
            v = c(v, w, x, u, r, 10, j[53]);
            u = c(u, v, w, x, J, 15, j[54]);
            x = c(x, u, v, w, n, 21, j[55]);
            w = c(w, x, u, v, L, 6, j[56]);
            v = c(v, w, x, u, A, 10, j[57]);
            u = c(u, v, w, x, B, 15, j[58]);
            x = c(x, u, v, w, F, 21, j[59]);
            w = c(w, x, u, v, t, 6, j[60]);
            v = c(v, w, x, u, C, 10, j[61]);
            u = c(u, v, w, x, o, 15, j[62]);
            x = c(x, u, v, w, E, 21, j[63]);
            f[0] = f[0] + w | 0;
            f[1] = f[1] + x | 0;
            f[2] = f[2] + u | 0;
            f[3] = f[3] + v | 0
        },
        _doFinalize: function() {
            var h = this._data,
                k = h.words,
                f = 8 * this._nDataBytes,
                i = 8 * h.sigBytes;
            k[i >>> 5] |= 128 << 24 - i % 32;
            var n = e.floor(f / 4294967296);
            k[(i + 64 >>> 9 << 4) + 15] = (n << 8 | n >>> 24) & 16711935 | (n << 24 | n >>> 8) & 4278255360;
            k[(i + 64 >>> 9 << 4) + 14] = (f << 8 | f >>> 24) & 16711935 | (f << 24 | f >>> 8) & 4278255360;
            h.sigBytes = 4 * (k.length + 1);
            this._process();
            h = this._hash;
            k = h.words;
            for (f = 0; 4 > f; f++) {
                i = k[f];
                k[f] = (i << 8 | i >>> 24) & 16711935 | (i << 24 | i >>> 8) & 4278255360
            }
            return h
        },
        clone: function() {
            var h = l.clone.call(this);
            h._hash = this._hash.clone();
            return h
        }
    });
    a.MD5 = l._createHelper(b);
    a.HmacMD5 = l._createHmacHelper(b)
})(Math);
CryptoJS = CryptoJS || function(e, p) {
    var q = {},
        g = q.lib = {},
        c = function() {},
        a = g.Base = {
            extend: function(f) {
                c.prototype = this;
                var i = new c;
                f && i.mixIn(f);
                i.hasOwnProperty("init") || (i.init = function() {
                    i.$super.init.apply(this, arguments)
                });
                i.init.prototype = i;
                i.$super = this;
                return i
            },
            create: function() {
                var f = this.extend();
                f.init.apply(f, arguments);
                return f
            },
            init: function() {},
            mixIn: function(f) {
                for (var i in f) f.hasOwnProperty(i) && (this[i] = f[i]);
                f.hasOwnProperty("toString") && (this.toString = f.toString)
            },
            clone: function() {
                return this.init.prototype.extend(this)
            }
        },
        b = g.WordArray = a.extend({
            init: function(f, i) {
                f = this.words = f || [];
                this.sigBytes = i != p ? i : 4 * f.length
            },
            toString: function(f) {
                return (f || l).stringify(this)
            },
            concat: function(f) {
                var i = this.words,
                    n = f.words,
                    o = this.sigBytes;
                f = f.sigBytes;
                this.clamp();
                if (o % 4)
                    for (var r = 0; r < f; r++) i[o + r >>> 2] |= (n[r >>> 2] >>> 24 - r % 4 * 8 & 255) << 24 - (o + r) % 4 * 8;
                else if (65535 < n.length)
                    for (r = 0; r < f; r += 4) i[o + r >>> 2] = n[r >>> 2];
                else i.push.apply(i, n);
                this.sigBytes += f;
                return this
            },
            clamp: function() {
                var f = this.words,
                    i = this.sigBytes;
                f[i >>> 2] &= 4294967295 << 32 -
                    i % 4 * 8;
                f.length = e.ceil(i / 4)
            },
            clone: function() {
                var f = a.clone.call(this);
                f.words = this.words.slice(0);
                return f
            },
            random: function(f) {
                for (var i = [], n = 0; n < f; n += 4) i.push(4294967296 * e.random() | 0);
                return new b.init(i, f)
            }
        }),
        d = q.enc = {},
        l = d.Hex = {
            stringify: function(f) {
                var i = f.words;
                f = f.sigBytes;
                for (var n = [], o = 0; o < f; o++) {
                    var r = i[o >>> 2] >>> 24 - o % 4 * 8 & 255;
                    n.push((r >>> 4).toString(16));
                    n.push((r & 15).toString(16))
                }
                return n.join("")
            },
            parse: function(f) {
                for (var i = f.length, n = [], o = 0; o < i; o += 2) n[o >>> 3] |= parseInt(f.substr(o, 2), 16) << 24 - o % 8 * 4;
                return new b.init(n, i / 2)
            }
        },
        j = d.Latin1 = {
            stringify: function(f) {
                var i = f.words;
                f = f.sigBytes;
                for (var n = [], o = 0; o < f; o++) n.push(String.fromCharCode(i[o >>> 2] >>> 24 - o % 4 * 8 & 255));
                return n.join("")
            },
            parse: function(f) {
                for (var i = f.length, n = [], o = 0; o < i; o++) n[o >>> 2] |= (f.charCodeAt(o) & 255) << 24 - o % 4 * 8;
                return new b.init(n, i)
            }
        },
        m = d.Utf8 = {
            stringify: function(f) {
                try {
                    return decodeURIComponent(escape(j.stringify(f)))
                } catch (i) {
                    throw Error("Malformed UTF-8 data");
                }
            },
            parse: function(f) {
                return j.parse(unescape(encodeURIComponent(f)))
            }
        },
        h = g.BufferedBlockAlgorithm = a.extend({
            reset: function() {
                this._data = new b.init;
                this._nDataBytes = 0
            },
            _append: function(f) {
                "string" == typeof f && (f = m.parse(f));
                this._data.concat(f);
                this._nDataBytes += f.sigBytes
            },
            _process: function(f) {
                var i = this._data,
                    n = i.words,
                    o = i.sigBytes,
                    r = this.blockSize,
                    t = o / (4 * r);
                t = f ? e.ceil(t) : e.max((t | 0) - this._minBufferSize, 0);
                f = t * r;
                o = e.min(4 * f, o);
                if (f) {
                    for (var s = 0; s < f; s += r) this._doProcessBlock(n, s);
                    s = n.splice(0, f);
                    i.sigBytes -= o
                }
                return new b.init(s, o)
            },
            clone: function() {
                var f = a.clone.call(this);
                f._data = this._data.clone();
                return f
            },
            _minBufferSize: 0
        });
    g.Hasher = h.extend({
        cfg: a.extend(),
        init: function(f) {
            this.cfg = this.cfg.extend(f);
            this.reset()
        },
        reset: function() {
            h.reset.call(this);
            this._doReset()
        },
        update: function(f) {
            this._append(f);
            this._process();
            return this
        },
        finalize: function(f) {
            f && this._append(f);
            return this._doFinalize()
        },
        blockSize: 16,
        _createHelper: function(f) {
            return function(i, n) {
                return (new f.init(n)).finalize(i)
            }
        },
        _createHmacHelper: function(f) {
            return function(i, n) {
                return (new k.HMAC.init(f, n)).finalize(i)
            }
        }
    });
    var k = q.algo = {};
    return q
}(Math);
(function() {
    var e = CryptoJS,
        p = e.lib,
        q = p.WordArray,
        g = p.Hasher,
        c = [];
    p = e.algo.SHA1 = g.extend({
        _doReset: function() {
            this._hash = new q.init([1732584193, 4023233417, 2562383102, 271733878, 3285377520])
        },
        _doProcessBlock: function(a, b) {
            for (var d = this._hash.words, l = d[0], j = d[1], m = d[2], h = d[3], k = d[4], f = 0; 80 > f; f++) {
                if (16 > f) c[f] = a[b + f] | 0;
                else {
                    var i = c[f - 3] ^ c[f - 8] ^ c[f - 14] ^ c[f - 16];
                    c[f] = i << 1 | i >>> 31
                }
                i = (l << 5 | l >>> 27) + k + c[f];
                i = 20 > f ? i + ((j & m | ~j & h) + 1518500249) : 40 > f ? i + ((j ^ m ^ h) + 1859775393) : 60 > f ? i + ((j & m | j & h | m & h) - 1894007588) : i + ((j ^ m ^ h) - 899497514);
                k = h;
                h = m;
                m = j << 30 | j >>> 2;
                j = l;
                l = i
            }
            d[0] = d[0] + l | 0;
            d[1] = d[1] + j | 0;
            d[2] = d[2] + m | 0;
            d[3] = d[3] + h | 0;
            d[4] = d[4] + k | 0
        },
        _doFinalize: function() {
            var a = this._data,
                b = a.words,
                d = 8 * this._nDataBytes,
                l = 8 * a.sigBytes;
            b[l >>> 5] |= 128 << 24 - l % 32;
            b[(l + 64 >>> 9 << 4) + 14] = Math.floor(d / 4294967296);
            b[(l + 64 >>> 9 << 4) + 15] = d;
            a.sigBytes = 4 * b.length;
            this._process();
            return this._hash
        },
        clone: function() {
            var a = g.clone.call(this);
            a._hash = this._hash.clone();
            return a
        }
    });
    e.SHA1 = g._createHelper(p);
    e.HmacSHA1 = g._createHmacHelper(p)
})();
(function() {
    var e = CryptoJS,
        p = e.lib.WordArray;
    e.enc.Base64 = {
        stringify: function(q) {
            var g = q.words,
                c = q.sigBytes,
                a = this._map;
            q.clamp();
            q = [];
            for (var b = 0; b < c; b += 3)
                for (var d = (g[b >>> 2] >>> 24 - b % 4 * 8 & 255) << 16 | (g[b + 1 >>> 2] >>> 24 - (b + 1) % 4 * 8 & 255) << 8 | g[b + 2 >>> 2] >>> 24 - (b + 2) % 4 * 8 & 255, l = 0; 4 > l && b + 0.75 * l < c; l++) q.push(a.charAt(d >>> 6 * (3 - l) & 63));
            if (g = a.charAt(64))
                for (; q.length % 4;) q.push(g);
            return q.join("")
        },
        parse: function(q) {
            var g = q.length,
                c = this._map,
                a = c.charAt(64);
            a && (a = q.indexOf(a), -1 != a && (g = a));
            a = [];
            for (var b = 0, d = 0; d < g; d++)
                if (d % 4) {
                    var l = c.indexOf(q.charAt(d - 1)) << d % 4 * 2,
                        j = c.indexOf(q.charAt(d)) >>> 6 - d % 4 * 2;
                    a[b >>> 2] |= (l | j) << 24 - b % 4 * 8;
                    b++
                }
            return p.create(a, b)
        },
        _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
    }
})();
var libFuncName = null;
if ("undefined" === typeof jQuery && "undefined" === typeof Zepto && "function" === typeof $) libFuncName = $;
else if ("function" === typeof jQuery) libFuncName = jQuery;
else if ("function" === typeof Zepto) libFuncName = Zepto;
else throw new TypeError;
(function(e, p, q, g) {
    e("head").append('<meta class="foundation-mq-small">');
    e("head").append('<meta class="foundation-mq-medium">');
    e("head").append('<meta class="foundation-mq-large">');
    p.matchMedia = p.matchMedia || function(c) {
        var a, b = c.documentElement,
            d = b.firstElementChild || b.firstChild,
            l = c.createElement("body"),
            j = c.createElement("div");
        j.id = "mq-test-1";
        j.style.cssText = "position:absolute;top:-100em";
        l.style.background = "none";
        l.appendChild(j);
        return function(m) {
            j.innerHTML = '\u00ad<style media="' + m + '"> #mq-test-1 { width: 42px; }</style>';
            b.insertBefore(l, d);
            a = 42 === j.offsetWidth;
            b.removeChild(l);
            return {
                matches: a,
                media: m
            }
        }
    }(q);
    Array.prototype.filter || (Array.prototype.filter = function(c, a) {
        if (null == this) throw new TypeError;
        var b = Object(this),
            d = b.length >>> 0;
        if ("function" === typeof c) {
            for (var l = [], j = 0; j < d; j++)
                if (j in b) {
                    var m = b[j];
                    c && c.call(a, m, j, b) && l.push(m)
                }
            return l
        }
    });
    Function.prototype.bind || (Function.prototype.bind = function(c) {
        if ("function" !== typeof this) throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");
        var a = Array.prototype.slice.call(arguments, 1),
            b = this,
            d = function() {},
            l = function() {
                return b.apply(this instanceof d && c ? this : c, a.concat(Array.prototype.slice.call(arguments)))
            };
        d.prototype = this.prototype;
        l.prototype = new d;
        return l
    });
    Array.prototype.indexOf || (Array.prototype.indexOf = function(c) {
        if (null == this) throw new TypeError;
        var a = Object(this),
            b = a.length >>> 0;
        if (0 === b) return -1;
        var d = 0;
        1 < arguments.length && (d = Number(arguments[1]), d != d ? d = 0 : 0 != d && Infinity != d && -Infinity != d && (d = (0 < d || -1) * Math.floor(Math.abs(d))));
        if (d >= b) return -1;
        for (d = 0 <= d ? d : Math.max(b - Math.abs(d), 0); d < b; d++)
            if (d in a && a[d] === c) return d;
        return -1
    });
    e.fn.stop = e.fn.stop || function() {
        return this
    };
    p.Foundation = {
        name: "Foundation",
        version: "4.3.2",
        cache: {},
        media_queries: {
            small: e(".foundation-mq-small").css("font-family").replace(/\'/g, ""),
            medium: e(".foundation-mq-medium").css("font-family").replace(/\'/g, ""),
            large: e(".foundation-mq-large").css("font-family").replace(/\'/g, "")
        },
        stylesheet: e("<style></style>").appendTo("head")[0].sheet,
        init: function(c, a, b, d, l, j) {
            b = [c, b, d, l];
            d = [];
            if (j = j || false) this.nc = j;
            this.rtl = /rtl/i.test(e("html").attr("dir"));
            this.scope = c || this.scope;
            if (a && "string" === typeof a && !/reflow/i.test(a)) {
                if (/off/i.test(a)) return this.off();
                c = a.split(" ");
                if (0 < c.length)
                    for (j = c.length - 1; 0 <= j; j--) d.push(this.init_lib(c[j], b))
            } else {
                /reflow/i.test(a) && (b[1] = "reflow");
                for (var m in this.libs) d.push(this.init_lib(m, b))
            }
            "function" === typeof a && b.unshift(a);
            return this.response_obj(d, b)
        },
        response_obj: function(c, a) {
            for (var b = 0, d = a.length; b < d; b++)
                if ("function" === typeof a[b]) return a[b]({
                    errors: c.filter(function(l) {
                        if ("string" === typeof l) return l
                    })
                });
            return c
        },
        init_lib: function(c, a) {
            return this.trap(function() {
                return this.libs.hasOwnProperty(c) ? (this.patch(this.libs[c]), this.libs[c].init.apply(this.libs[c], a)) : function() {}
            }.bind(this), c)
        },
        trap: function(c, a) {
            if (!this.nc) try {
                return c()
            } catch (b) {
                return this.error({
                    name: a,
                    message: "could not be initialized",
                    more: b.name + " " + b.message
                })
            }
            return c()
        },
        patch: function(c) {
            this.fix_outer(c);
            c.scope = this.scope;
            c.rtl = this.rtl
        },
        inherit: function(c, a) {
            for (var b = a.split(" "), d = b.length - 1; 0 <= d; d--) this.lib_methods.hasOwnProperty(b[d]) && (this.libs[c.name][b[d]] = this.lib_methods[b[d]])
        },
        random_str: function(c) {
            var a = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
            c || (c = Math.floor(Math.random() * a.length));
            for (var b = "", d = 0; d < c; d++) b += a[Math.floor(Math.random() * a.length)];
            return b
        },
        libs: {},
        lib_methods: {
            set_data: function(c, a) {
                var b = [this.name, +new Date, Foundation.random_str(5)].join("-");
                Foundation.cache[b] = a;
                c.attr("data-" + this.name + "-id", b);
                return a
            },
            get_data: function(c) {
                return Foundation.cache[c.attr("data-" + this.name + "-id")]
            },
            remove_data: function(c) {
                c ? (delete Foundation.cache[c.attr("data-" + this.name + "-id")], c.attr("data-" + this.name + "-id", "")) : e("[data-" + this.name + "-id]").each(function() {
                    delete Foundation.cache[e(this).attr("data-" + this.name + "-id")];
                    e(this).attr("data-" + this.name + "-id", "")
                })
            },
            throttle: function(c, a) {
                var b = null;
                return function() {
                    var d = this,
                        l = arguments;
                    clearTimeout(b);
                    b = setTimeout(function() {
                        c.apply(d, l)
                    }, a)
                }
            },
            data_options: function(c) {
                var a = {},
                    b, d = (c.attr("data-options") || ":").split(";");
                for (c = d.length - 1; 0 <= c; c--) {
                    b = d[c].split(":");
                    /true/i.test(b[1]) && (b[1] = true);
                    /false/i.test(b[1]) && (b[1] = false);
                    isNaN(b[1] - 0) || null === b[1] || "" === b[1] || false === b[1] || true === b[1] || (b[1] = parseInt(b[1], 10));
                    2 === b.length && 0 < b[0].length && (a["string" === typeof b[0] ? e.trim(b[0]) : b[0]] = "string" === typeof b[1] ? e.trim(b[1]) : b[1])
                }
                return a
            },
            delay: function(c, a) {
                return setTimeout(c, a)
            },
            scrollTo: function(c, a, b) {
                if (!(0 > b)) {
                    var d = (a - e(p).scrollTop()) / b * 10;
                    this.scrollToTimerCache = setTimeout(function() {
                        isNaN(parseInt(d, 10)) || (p.scrollTo(0, e(p).scrollTop() + d), this.scrollTo(c, a, b - 10))
                    }.bind(this), 10)
                }
            },
            scrollLeft: function(c) {
                if (c.length) return "scrollLeft" in c[0] ? c[0].scrollLeft : c[0].pageXOffset
            },
            empty: function(c) {
                if (c.length && 0 < c.length) return false;
                if (c.length && 0 === c.length) return true;
                for (var a in c)
                    if (hasOwnProperty.call(c, a)) return false;
                return true
            },
            addCustomRule: function(c, a) {
                a === g ? Foundation.stylesheet.insertRule(c, Foundation.stylesheet.cssRules.length) : Foundation.media_queries[a] !== g && Foundation.stylesheet.insertRule("@media " + Foundation.media_queries[a] + "{ " + c + " }")
            }
        },
        fix_outer: function(c) {
            c.outerHeight = function(a, b) {
                return "function" === typeof Zepto ? a.height() : "undefined" !== typeof b ? a.outerHeight(b) : a.outerHeight()
            };
            c.outerWidth = function(a, b) {
                return "function" === typeof Zepto ? a.width() : "undefined" !== typeof b ? a.outerWidth(b) : a.outerWidth()
            }
        },
        error: function(c) {
            return c.name + " " + c.message + "; " + c.more
        },
        off: function() {
            e(this.scope).off(".fndtn");
            e(p).off(".fndtn");
            return true
        },
        zj: e
    };
    e.fn.foundation = function() {
        var c = Array.prototype.slice.call(arguments, 0);
        return this.each(function() {
            Foundation.init.apply(Foundation, [this].concat(c));
            return this
        })
    }
})(libFuncName, this, this.document);
(function(e) {
    Foundation.libs.alerts = {
        name: "alerts",
        version: "4.3.2",
        settings: {
            animation: "fadeOut",
            speed: 300,
            callback: function() {}
        },
        init: function(p, q, g) {
            this.scope = p || this.scope;
            Foundation.inherit(this, "data_options");
            "object" === typeof q && e.extend(true, this.settings, q);
            return "string" !== typeof q ? (this.settings.init || this.events(), this.settings.init) : this[q].call(this, g)
        },
        events: function() {
            var p = this;
            e(this.scope).on("click.fndtn.alerts", "[data-alert] a.close", function(q) {
                var g = e(this).closest("[data-alert]"),
                    c = e.extend({}, p.settings, p.data_options(g));
                q.preventDefault();
                g[c.animation](c.speed, function() {
                    e(this).remove();
                    c.callback()
                })
            });
            this.settings.init = true
        },
        off: function() {
            e(this.scope).off(".fndtn.alerts")
        },
        reflow: function() {}
    }
})(Foundation.zj, this, this.document);
(function(e, p, q, g) {
    Foundation.libs.clearing = {
        name: "clearing",
        version: "4.3.2",
        settings: {
            templates: {
                viewing: '<a href="https://static1.freebitco.in/min/combined_bottom1383555676.js#" class="clearing-close">\u00d7</a><div class="visible-img" style="display: none"><img src="https://:0"><p class="clearing-caption"></p><a href="https://static1.freebitco.in/min/combined_bottom1383555676.js#" class="clearing-main-prev"><span></span></a><a href="https://static1.freebitco.in/min/combined_bottom1383555676.js#" class="clearing-main-next"><span></span></a></div>'
            },
            close_selectors: ".clearing-close",
            init: false,
            locked: false
        },
        init: function(c, a, b) {
            var d = this;
            Foundation.inherit(this, "set_data get_data remove_data throttle data_options");
            "object" === typeof a && (b = e.extend(true, this.settings, a));
            return "string" !== typeof a ? (e(this.scope).find("ul[data-clearing]").each(function() {
                var l = e(this),
                    j = j || {},
                    m = l.find("li");
                !d.get_data(l) && 0 < m.length && (j.$parent = l.parent(), d.set_data(l, e.extend({}, d.settings, j, d.data_options(l))), d.assemble(l.find("li")), d.settings.init || d.events().swipe_events())
            }), this.settings.init) : this[a].call(this, b)
        },
        events: function() {
            var c = this;
            e(this.scope).on("click.fndtn.clearing", "ul[data-clearing] li", function(a, b, d) {
                b = b || e(this);
                d = d || b;
                var l = b.next("li"),
                    j = c.get_data(b.parent()),
                    m = e(a.target);
                a.preventDefault();
                j || c.init();
                d.hasClass("visible") && b[0] === d[0] && 0 < l.length && c.is_open(b) && (d = l, m = d.find("img"));
                c.open(m, b, d);
                c.update_paddles(d)
            }).on("click.fndtn.clearing", ".clearing-main-next", function(a) {
                this.nav(a, "next")
            }.bind(this)).on("click.fndtn.clearing", ".clearing-main-prev", function(a) {
                this.nav(a, "prev")
            }.bind(this)).on("click.fndtn.clearing", this.settings.close_selectors, function(a) {
                Foundation.libs.clearing.close(a, this)
            }).on("keydown.fndtn.clearing", function(a) {
                this.keydown(a)
            }.bind(this));
            e(p).on("resize.fndtn.clearing", function() {
                this.resize()
            }.bind(this));
            this.settings.init = true;
            return this
        },
        swipe_events: function() {
            var c = this;
            e(this.scope).on("touchstart.fndtn.clearing", ".visible-img", function(a) {
                a.touches || (a = a.originalEvent);
                var b = {
                    start_page_x: a.touches[0].pageX,
                    start_page_y: a.touches[0].pageY,
                    start_time: (new Date).getTime(),
                    delta_x: 0,
                    is_scrolling: g
                };
                e(this).data("swipe-transition", b);
                a.stopPropagation()
            }).on("touchmove.fndtn.clearing", ".visible-img", function(a) {
                a.touches || (a = a.originalEvent);
                if (!(1 < a.touches.length || a.scale && 1 !== a.scale)) {
                    var b = e(this).data("swipe-transition");
                    "undefined" === typeof b && (b = {});
                    b.delta_x = a.touches[0].pageX - b.start_page_x;
                    "undefined" === typeof b.is_scrolling && (b.is_scrolling = !!(b.is_scrolling || Math.abs(b.delta_x) < Math.abs(a.touches[0].pageY - b.start_page_y)));
                    if (!b.is_scrolling && !b.active) {
                        a.preventDefault();
                        var d = 0 > b.delta_x ? "next" : "prev";
                        b.active = true;
                        c.nav(a, d)
                    }
                }
            }).on("touchend.fndtn.clearing", ".visible-img", function(a) {
                e(this).data("swipe-transition", {});
                a.stopPropagation()
            })
        },
        assemble: function(c) {
            var a = c.parent();
            a.after('<div id="foundationClearingHolder"></div>');
            c = e("#foundationClearingHolder");
            var b = this.get_data(a);
            a = a.detach();
            a = '<div class="carousel">' + this.outerHTML(a[0]) + "</div>";
            return c.after('<div class="clearing-assembled"><div>' + b.templates.viewing +
                a + "</div></div>").remove()
        },
        open: function(c, a, b) {
            var d = b.closest(".clearing-assembled"),
                l = d.find("div").first(),
                j = l.find(".visible-img"),
                m = j.find("img").not(c);
            this.locked() || (m.attr("src", this.load(c)).css("visibility", "hidden"), this.loaded(m, function() {
                m.css("visibility", "visible");
                d.addClass("clearing-blackout");
                l.addClass("clearing-container");
                j.show();
                this.fix_height(b).caption(j.find(".clearing-caption"), c).center(m).shift(a, b, function() {
                    b.siblings().removeClass("visible");
                    b.addClass("visible")
                })
            }.bind(this)))
        },
        close: function(c, a) {
            c.preventDefault();
            var b;
            b = e(a);
            b = /blackout/.test(b.selector) ? b : b.closest(".clearing-blackout");
            var d, l;
            a === c.target && b && (d = b.find("div").first(), l = d.find(".visible-img"), this.settings.prev_index = 0, b.find("ul[data-clearing]").attr("style", "").closest(".clearing-blackout").removeClass("clearing-blackout"), d.removeClass("clearing-container"), l.hide());
            return false
        },
        is_open: function(c) {
            return 0 < c.parent().prop("style").length
        },
        keydown: function(c) {
            var a = e(".clearing-blackout").find("ul[data-clearing]");
            39 === c.which && this.go(a, "next");
            37 === c.which && this.go(a, "prev");
            27 === c.which && e("a.clearing-close").trigger("click")
        },
        nav: function(c, a) {
            var b = e(".clearing-blackout").find("ul[data-clearing]");
            c.preventDefault();
            this.go(b, a)
        },
        resize: function() {
            var c = e(".clearing-blackout .visible-img").find("img");
            c.length && this.center(c)
        },
        fix_height: function(c) {
            c = c.parent().children();
            var a = this;
            c.each(function() {
                var b = e(this),
                    d = b.find("img");
                b.height() > a.outerHeight(d) && b.addClass("fix-height")
            }).closest("ul").width(100 * c.length + "%");
            return this
        },
        update_paddles: function(c) {
            var a = c.closest(".carousel").siblings(".visible-img");
            0 < c.next().length ? a.find(".clearing-main-next").removeClass("disabled") : a.find(".clearing-main-next").addClass("disabled");
            0 < c.prev().length ? a.find(".clearing-main-prev").removeClass("disabled") : a.find(".clearing-main-prev").addClass("disabled")
        },
        center: function(c) {
            this.rtl ? c.css({
                marginRight: -(this.outerWidth(c) / 2),
                marginTop: -(this.outerHeight(c) / 2)
            }) : c.css({
                marginLeft: -(this.outerWidth(c) / 2),
                marginTop: -(this.outerHeight(c) / 2)
            });
            return this
        },
        load: function(c) {
            var a = "A" === c[0].nodeName ? c.attr("href") : c.parent().attr("href");
            this.preload(c);
            return a ? a : c.attr("src")
        },
        preload: function(c) {
            this.img(c.closest("li").next()).img(c.closest("li").prev())
        },
        loaded: function(c, a) {
            function b() {
                a()
            }

            function d() {
                this.one("load", b);
                if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) {
                    var l = this.attr("src"),
                        j = l.match(/\?/) ? "&" : "?";
                    j += "random=" + (new Date).getTime();
                    this.attr("src", l + j)
                }
            }
            c.attr("src") ? c[0].complete || 4 === c[0].readyState ? a() : d.call(c) : a()
        },
        img: function(c) {
            if (c.length) {
                var a = new Image,
                    b = c.find("a");
                a.src = b.length ? b.attr("href") : c.find("img").attr("src")
            }
            return this
        },
        caption: function(c, a) {
            var b = a.data("caption");
            b ? c.html(b).show() : c.text("").hide();
            return this
        },
        go: function(c, a) {
            var b = c.find(".visible"),
                d = b[a]();
            d.length && d.find("img").trigger("click", [b, d])
        },
        shift: function(c, a, b) {
            var d = a.parent(),
                l = this.settings.prev_index || a.index(),
                j = this.direction(d, c, a),
                m = parseInt(d.css("left"), 10);
            c = this.outerWidth(a);
            a.index() === l || /skip/.test(j) ? /skip/.test(j) && (a = a.index() - this.settings.up_count, this.lock(), 0 < a ? d.animate({
                left: -(a * c)
            }, 300, this.unlock()) : d.animate({
                left: 0
            }, 300, this.unlock())) : /left/.test(j) ? (this.lock(), d.animate({
                left: m + c
            }, 300, this.unlock())) : /right/.test(j) && (this.lock(), d.animate({
                left: m - c
            }, 300, this.unlock()));
            b()
        },
        direction: function(c, a, b) {
            c = c.find("li");
            a = this.outerWidth(c) + this.outerWidth(c) / 4;
            a = Math.floor(this.outerWidth(e(".clearing-container")) / a) - 1;
            b = c.index(b);
            this.settings.up_count = a;
            c = this.adjacent(this.settings.prev_index, b) ? b > a && b > this.settings.prev_index ? "right" : b > a - 1 && b <= this.settings.prev_index ? "left" : false : "skip";
            this.settings.prev_index = b;
            return c
        },
        adjacent: function(c, a) {
            for (var b = a + 1; b >= a - 1; b--)
                if (b === c) return true;
            return false
        },
        lock: function() {
            this.settings.locked = true
        },
        unlock: function() {
            this.settings.locked = false
        },
        locked: function() {
            return this.settings.locked
        },
        outerHTML: function(c) {
            return c.outerHTML || (new XMLSerializer).serializeToString(c)
        },
        off: function() {
            e(this.scope).off(".fndtn.clearing");
            e(p).off(".fndtn.clearing");
            this.remove_data();
            this.settings.init = false
        },
        reflow: function() {
            this.init()
        }
    }
})(Foundation.zj, this, this.document);
(function(e, p, q) {
    function g(d) {
        return d
    }

    function c(d) {
        return decodeURIComponent(d.replace(a, " "))
    }
    var a = /\+/g,
        b = e.cookie = function(d, l, j) {
            if (l !== q) {
                j = e.extend({}, b.defaults, j);
                null === l && (j.expires = -1);
                if ("number" === typeof j.expires) {
                    var m = j.expires,
                        h = j.expires = new Date;
                    h.setDate(h.getDate() + m)
                }
                l = b.json ? JSON.stringify(l) : String(l);
                return p.cookie = [encodeURIComponent(d), "=", b.raw ? l : encodeURIComponent(l), j.expires ? "; expires=" + j.expires.toUTCString() : "", j.path ? "; path=" + j.path : "", j.domain ? "; domain=" +
                    j.domain : "", j.secure ? "; secure" : ""
                ].join("")
            }
            l = b.raw ? g : c;
            j = p.cookie.split("; ");
            m = 0;
            for (h = j.length; m < h; m++) {
                var k = j[m].split("=");
                if (l(k.shift()) === d) return d = l(k.join("=")), b.json ? JSON.parse(d) : d
            }
            return null
        };
    b.defaults = {};
    e.removeCookie = function(d, l) {
        return null !== e.cookie(d) ? (e.cookie(d, null, l), true) : false
    }
})(Foundation.zj, document);
(function(e, p, q) {
    Foundation.libs.dropdown = {
        name: "dropdown",
        version: "4.3.2",
        settings: {
            activeClass: "open",
            is_hover: false,
            opened: function() {},
            closed: function() {}
        },
        init: function(g, c, a) {
            this.scope = g || this.scope;
            Foundation.inherit(this, "throttle scrollLeft data_options");
            "object" === typeof c && e.extend(true, this.settings, c);
            return "string" !== typeof c ? (this.settings.init || this.events(), this.settings.init) : this[c].call(this, a)
        },
        events: function() {
            var g = this;
            e(this.scope).on("click.fndtn.dropdown", "[data-dropdown]", function(c) {
                var a = e.extend({}, g.settings, g.data_options(e(this)));
                c.preventDefault();
                a.is_hover || g.toggle(e(this))
            }).on("mouseenter", "[data-dropdown]", function() {
                e.extend({}, g.settings, g.data_options(e(this))).is_hover && g.toggle(e(this))
            }).on("mouseleave", "[data-dropdown-content]", function(c) {
                c = e('[data-dropdown="' + e(this).attr("id") + '"]');
                e.extend({}, g.settings, g.data_options(c)).is_hover && g.close.call(g, e(this))
            }).on("opened.fndtn.dropdown", "[data-dropdown-content]", this.settings.opened).on("closed.fndtn.dropdown", "[data-dropdown-content]", this.settings.closed);
            e(q).on("click.fndtn.dropdown", function(c) {
                var a = e(c.target).closest("[data-dropdown-content]");
                e(c.target).data("dropdown") || e(c.target).parent().data("dropdown") || (!e(c.target).data("revealId") && 0 < a.length && (e(c.target).is("[data-dropdown-content]") || e.contains(a.first()[0], c.target)) ? c.stopPropagation() : g.close.call(g, e("[data-dropdown-content]")))
            });
            e(p).on("resize.fndtn.dropdown", g.throttle(function() {
                g.resize.call(g)
            }, 50)).trigger("resize");
            this.settings.init = true
        },
        close: function(g) {
            var c = this;
            g.each(function() {
                e(this).hasClass(c.settings.activeClass) && (e(this).css(Foundation.rtl ? "right" : "left", "-99999px").removeClass(c.settings.activeClass), e(this).trigger("closed"))
            })
        },
        open: function(g, c) {
            this.css(g.addClass(this.settings.activeClass), c);
            g.trigger("opened")
        },
        toggle: function(g) {
            var c = e("#" + g.data("dropdown"));
            0 !== c.length && (this.close.call(this, e("[data-dropdown-content]").not(c)), c.hasClass(this.settings.activeClass) ? this.close.call(this, c) : (this.close.call(this, e("[data-dropdown-content]")), this.open.call(this, c, g)))
        },
        resize: function() {
            var g = e("[data-dropdown-content].open"),
                c = e("[data-dropdown='" + g.attr("id") + "']");
            g.length && c.length && this.css(g, c)
        },
        css: function(g, c) {
            var a = g.offsetParent(),
                b = c.offset();
            b.top -= a.offset().top;
            b.left -= a.offset().left;
            this.small() ? (g.css({
                position: "absolute",
                width: "95%",
                "max-width": "none",
                top: b.top + this.outerHeight(c)
            }), g.css(Foundation.rtl ? "right" : "left", "2.5%")) : (!Foundation.rtl && e(p).width() > this.outerWidth(g) + c.offset().left && !this.data_options(c).align_right ? g.hasClass("right") && g.removeClass("right") : (g.hasClass("right") || g.addClass("right"), a = b.left - (this.outerWidth(g) - this.outerWidth(c))), g.attr("style", "").css({
                position: "absolute",
                top: b.top + this.outerHeight(c),
                left: a
            }));
            return g
        },
        small: function() {
            return 768 > e(p).width() || e("html").hasClass("lt-ie9")
        },
        off: function() {
            e(this.scope).off(".fndtn.dropdown");
            e("html, body").off(".fndtn.dropdown");
            e(p).off(".fndtn.dropdown");
            e("[data-dropdown-content]").off(".fndtn.dropdown");
            this.settings.init = false
        },
        reflow: function() {}
    }
})(Foundation.zj, this, this.document);
(function(e, p, q, g) {
    Foundation.libs.forms = {
        name: "forms",
        version: "4.3.2",
        cache: {},
        settings: {
            disable_class: "no-custom",
            last_combo: null
        },
        init: function(a, b, d) {
            "object" === typeof b && e.extend(true, this.settings, b);
            return "string" !== typeof b ? (this.settings.init || this.events(), this.assemble(), this.settings.init) : this[b].call(this, d)
        },
        assemble: function() {
            var a = this;
            e('form.custom input[type="radio"],[type="checkbox"]', e(this.scope)).not('[data-customforms="disabled"]').not("." + this.settings.disable_class).each(function(b, d) {
                a.set_custom_markup(d)
            }).change(function() {
                a.set_custom_markup(this)
            });
            e("form.custom select", e(this.scope)).not('[data-customforms="disabled"]').not("." + this.settings.disable_class).not("[multiple=multiple]").each(this.append_custom_select)
        },
        events: function() {
            var a = this;
            e(this.scope).on("click.fndtn.forms", "form.custom span.custom.checkbox", function(b) {
                b.preventDefault();
                b.stopPropagation();
                a.toggle_checkbox(e(this))
            }).on("click.fndtn.forms", "form.custom span.custom.radio", function(b) {
                b.preventDefault();
                b.stopPropagation();
                a.toggle_radio(e(this))
            }).on("change.fndtn.forms", "form.custom select", function(b, d) {
                e(this).is('[data-customforms="disabled"]') || a.refresh_custom_select(e(this), d)
            }).on("click.fndtn.forms", "form.custom label", function(b) {
                if (e(b.target).is("label")) {
                    var d = e("#" + a.escape(e(this).attr("for"))).not('[data-customforms="disabled"]');
                    0 !== d.length && ("checkbox" === d.attr("type") ? (b.preventDefault(), b = e(this).find("span.custom.checkbox"), 0 === b.length && (b = d.add(this).siblings("span.custom.checkbox").first()), a.toggle_checkbox(b)) : "radio" === d.attr("type") && (b.preventDefault(), b = e(this).find("span.custom.radio"), 0 === b.length && (b = d.add(this).siblings("span.custom.radio").first()), a.toggle_radio(b)))
                }
            }).on("mousedown.fndtn.forms", "form.custom div.custom.dropdown", function() {
                return false
            }).on("click.fndtn.forms", "form.custom div.custom.dropdown a.current, form.custom div.custom.dropdown a.selector", function(b) {
                var d = e(this).closest("div.custom.dropdown"),
                    l = c(d, "select");
                d.hasClass("open") || e(a.scope).trigger("click");
                b.preventDefault();
                if (false === l.is(":disabled")) {
                    d.toggleClass("open");
                    if (d.hasClass("open")) e(a.scope).on("click.fndtn.forms.customdropdown", function() {
                        d.removeClass("open");
                        e(a.scope).off(".fndtn.forms.customdropdown")
                    });
                    else e(a.scope).on(".fndtn.forms.customdropdown");
                    return false
                }
            }).on("click.fndtn.forms touchend.fndtn.forms", "form.custom div.custom.dropdown li", function(b) {
                var d = e(this),
                    l = d.closest("div.custom.dropdown"),
                    j = c(l, "select"),
                    m = 0;
                b.preventDefault();
                b.stopPropagation();
                e(this).hasClass("disabled") || (e("div.dropdown").not(l).removeClass("open"), b = d.closest("ul").find("li.selected"), b.removeClass("selected"), d.addClass("selected"), l.removeClass("open").find("a.current").text(d.text()), d.closest("ul").find("li").each(function(h) {
                    d[0] === this && (m = h)
                }), j[0].selectedIndex = m, j.data("prevalue", b.html()), "undefined" != typeof q.createEvent ? (l = q.createEvent("HTMLEvents"), l.initEvent("change", true, true), j[0].dispatchEvent(l)) : j[0].fireEvent("onchange"))
            });
            e(p).on("keydown", function(b) {
                var d = Foundation.libs.forms,
                    l = e(".custom.dropdown"),
                    j = c(l, "select"),
                    m = e("input,select,textarea,button");
                0 < l.length && l.hasClass("open") && (b.preventDefault(), 9 === b.which && (e(m[e(m).index(j) + 1]).focus(), l.removeClass("open")), 13 === b.which && l.find("li.selected").trigger("click"), 27 === b.which && l.removeClass("open"), 65 <= b.which && 90 >= b.which && (m = d.go_to(l, b.which), j = l.find("li.selected"), m && (j.removeClass("selected"), d.scrollTo(m.addClass("selected"), 300))), 38 === b.which ? (j = l.find("li.selected"), b = j.prev(":not(.disabled)"), 0 < b.length && (b.parent()[0].scrollTop = b.parent().scrollTop() - d.outerHeight(b), j.removeClass("selected"), b.addClass("selected"))) : 40 === b.which && (j = l.find("li.selected"), m = j.next(":not(.disabled)"), 0 < m.length && (m.parent()[0].scrollTop = m.parent().scrollTop() + d.outerHeight(m), j.removeClass("selected"), m.addClass("selected"))))
            });
            e(p).on("keyup", function(b) {
                b = q.activeElement;
                var d = e(".custom.dropdown");
                b === d.find(".current")[0] && d.find(".selector").focus().click()
            });
            this.settings.init = true
        },
        go_to: function(a, b) {
            var d = a.find("li"),
                l = d.length;
            if (0 < l)
                for (var j = 0; j < l; j++)
                    if (d.eq(j).text().charAt(0).toLowerCase() === String.fromCharCode(b).toLowerCase()) return d.eq(j)
        },
        scrollTo: function(a, b) {
            if (!(0 > b)) {
                var d = a.parent(),
                    l = (this.outerHeight(a) * a.index() - d.scrollTop()) / b * 10;
                this.scrollToTimerCache = setTimeout(function() {
                    isNaN(parseInt(l, 10)) || (d[0].scrollTop = d.scrollTop() + l, this.scrollTo(a, b - 10))
                }.bind(this), 10)
            }
        },
        set_custom_markup: function(a) {
            a = e(a);
            var b = a.attr("type"),
                d = a.next("span.custom." + b);
            a.parent().hasClass("switch") || a.addClass("hidden-field");
            0 === d.length && (d = e('<span class="custom ' + b + '"></span>').insertAfter(a));
            d.toggleClass("checked", a.is(":checked"));
            d.toggleClass("disabled", a.is(":disabled"))
        },
        append_custom_select: function(a, b) {
            var d = Foundation.libs.forms,
                l = e(b),
                j = l.next("div.custom.dropdown"),
                m = j.find("ul");
            j.find(".current");
            j.find(".selector");
            var h = l.find("option"),
                k = h.filter(":selected"),
                f = l.attr("class") ? l.attr("class").split(" ") : [],
                i = 0,
                n = "",
                o, r = false;
            0 === j.length ? (j = l.hasClass("small") ? "small" : l.hasClass("medium") ? "medium" : l.hasClass("large") ? "large" : l.hasClass("expand") ? "expand" : "", j = e('<div class="' + ["custom", "dropdown", j].concat(f).filter(function(t, s, B) {
                return "" === t ? false : B.indexOf(t) === s
            }).join(" ") + '"><a href="https://static1.freebitco.in/min/combined_bottom1383555676.js#" class="selector"></a><ul ></ul></div>'), j.find(".selector"), m = j.find("ul"), n = h.map(function() {
                return "<li class='" + (e(this).attr("class") ? e(this).attr("class") : "") + "'>" + e(this).html() + "</li>"
            }).get().join(""), m.append(n), r = j.prepend('<a href="https://static1.freebitco.in/min/combined_bottom1383555676.js#" class="current">' + (k.html() || "") + "</a>").find(".current"), l.after(j).addClass("hidden-field")) : (n = h.map(function() {
                return "<li>" + e(this).html() + "</li>"
            }).get().join(""), m.html("").append(n));
            d.assign_id(l, j);
            j.toggleClass("disabled", l.is(":disabled"));
            o = m.find("li");
            d.cache[j.data("id")] = o.length;
            h.each(function(t) {
                this.selected && (o.eq(t).addClass("selected"), r && r.html(e(this).html()));
                e(this).is(":disabled") && o.eq(t).addClass("disabled")
            });
            j.is(".small, .medium, .large, .expand") || (j.addClass("open"), d = Foundation.libs.forms, d.hidden_fix.adjust(m), i = d.outerWidth(o) > i ? d.outerWidth(o) : i, Foundation.libs.forms.hidden_fix.reset(), j.removeClass("open"))
        },
        assign_id: function(a, b) {
            var d = [+new Date, Foundation.random_str(5)].join("-");
            a.attr("data-id", d);
            b.attr("data-id", d)
        },
        refresh_custom_select: function(a, b) {
            var d = this,
                l = 0,
                j = a.next(),
                m = a.find("option"),
                h = j.find("ul"),
                k = j.find("li");
            if (m.length !== this.cache[j.data("id")] || b) {
                h.html("");
                var f = "";
                m.each(function() {
                    var i = e(this),
                        n = i.html(),
                        o = this.selected;
                    f += '<li class="' + (o ? " selected " : "") + (i.is(":disabled") ? " disabled " : "") + '">' + n + "</li>";
                    o && j.find(".current").html(n)
                });
                h.html(f);
                j.removeAttr("style");
                h.removeAttr("style");
                j.find("li").each(function() {
                    j.addClass("open");
                    d.outerWidth(e(this)) > l && (l = d.outerWidth(e(this)));
                    j.removeClass("open")
                });
                k = j.find("li");
                this.cache[j.data("id")] = k.length
            }
        },
        refresh_custom_selection: function(a) {
            var b = e("option:selected", a).text();
            e("a.current", a.next()).text(b)
        },
        toggle_checkbox: function(a) {
            var b = a.prev(),
                d = b[0];
            false === b.is(":disabled") && (d.checked = d.checked ? false : true, a.toggleClass("checked"), b.trigger("change"))
        },
        toggle_radio: function(a) {
            var b = a.prev(),
                d = b.closest("form.custom"),
                l = b[0];
            false === b.is(":disabled") && (d.find('input[type="radio"][name="' + this.escape(b.attr("name")) + '"]').next().not(a).removeClass("checked"), a.hasClass("checked") || a.toggleClass("checked"), l.checked = a.hasClass("checked"), b.trigger("change"))
        },
        escape: function(a) {
            return a ? a.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&") : ""
        },
        hidden_fix: {
            tmp: [],
            hidden: null,
            adjust: function(a) {
                var b = this;
                b.hidden = a.parents();
                b.hidden = b.hidden.add(a).filter(":hidden");
                b.hidden.each(function() {
                    var d = e(this);
                    b.tmp.push(d.attr("style"));
                    d.css({
                        visibility: "hidden",
                        display: "block"
                    })
                })
            },
            reset: function() {
                var a = this;
                a.hidden.each(function(b) {
                    var d = e(this);
                    b = a.tmp[b];
                    b === g ? d.removeAttr("style") : d.attr("style", b)
                });
                a.tmp = [];
                a.hidden = null
            }
        },
        off: function() {
            e(this.scope).off(".fndtn.forms")
        },
        reflow: function() {}
    };
    var c = function(a, b) {
        for (a = a.prev(); a.length;) {
            if (a.is(b)) return a;
            a = a.prev()
        }
        return e()
    }
})(Foundation.zj, this, this.document);
(function(e, p, q, g) {
    var c = c || false;
    Foundation.libs.joyride = {
        name: "joyride",
        version: "4.3.2",
        defaults: {
            expose: false,
            modal: false,
            tipLocation: "bottom",
            nubPosition: "auto",
            scrollSpeed: 300,
            timer: 0,
            startTimerOnClick: true,
            startOffset: 0,
            nextButton: true,
            tipAnimation: "fade",
            pauseAfter: [],
            exposed: [],
            tipAnimationFadeSpeed: 300,
            cookieMonster: false,
            cookieName: "joyride",
            cookieDomain: false,
            cookieExpires: 365,
            tipContainer: "body",
            postRideCallback: function() {},
            postStepCallback: function() {},
            preStepCallback: function() {},
            preRideCallback: function() {},
            postExposeCallback: function() {},
            template: {
                link: '<a href="https://static1.freebitco.in/min/combined_bottom1383555676.js#close" class="joyride-close-tip">\u00d7</a>',
                timer: '<div class="joyride-timer-indicator-wrap"><span class="joyride-timer-indicator"></span></div>',
                tip: '<div class="joyride-tip-guide"><span class="joyride-nub"></span></div>',
                wrapper: '<div class="joyride-content-wrapper"></div>',
                button: '<a href="https://static1.freebitco.in/min/combined_bottom1383555676.js#" class="small button joyride-next-tip"></a>',
                modal: '<div class="joyride-modal-bg"></div>',
                expose: '<div class="joyride-expose-wrapper"></div>',
                exposeCover: '<div class="joyride-expose-cover"></div>'
            },
            exposeAddClass: ""
        },
        settings: {},
        init: function(a, b, d) {
            this.scope = a || this.scope;
            Foundation.inherit(this, "throttle data_options scrollTo scrollLeft delay");
            "object" === typeof b ? e.extend(true, this.settings, this.defaults, b) : e.extend(true, this.settings, this.defaults, d);
            return "string" !== typeof b ? (this.settings.init || this.events(), this.settings.init) : this[b].call(this, d)
        },
        events: function() {
            var a = this;
            e(this.scope).on("click.joyride", ".joyride-next-tip, .joyride-modal-bg", function(b) {
                b.preventDefault();
                1 > this.settings.$li.next().length ? this.end() : 0 < this.settings.timer ? (clearTimeout(this.settings.automate), this.hide(), this.show(), this.startTimer()) : (this.hide(), this.show())
            }.bind(this)).on("click.joyride", ".joyride-close-tip", function(b) {
                b.preventDefault();
                this.end()
            }.bind(this));
            e(p).on("resize.fndtn.joyride", a.throttle(function() {
                0 < e("[data-joyride]").length && a.settings.$next_tip && (0 < a.settings.exposed.length && e(a.settings.exposed).each(function() {
                    var b = e(this);
                    a.un_expose(b);
                    a.expose(b)
                }), a.is_phone() ? a.pos_phone() : a.pos_default(false, true))
            }, 100));
            this.settings.init = true
        },
        start: function() {
            var a = this,
                b = e(this.scope).find("[data-joyride]"),
                d = ["timer", "scrollSpeed", "startOffset", "tipAnimationFadeSpeed", "cookieExpires"],
                l = d.length;
            this.settings.init || this.events();
            this.settings.$content_el = b;
            this.settings.$body = e(this.settings.tipContainer);
            this.settings.body_offset = e(this.settings.tipContainer).position();
            this.settings.$tip_content = this.settings.$content_el.find("> li");
            this.settings.paused = false;
            this.settings.attempts = 0;
            this.settings.tipLocationPatterns = {
                top: ["bottom"],
                bottom: [],
                left: ["right", "top", "bottom"],
                right: ["left", "top", "bottom"]
            };
            "function" !== typeof e.cookie && (this.settings.cookieMonster = false);
            if (!this.settings.cookieMonster || this.settings.cookieMonster && null === e.cookie(this.settings.cookieName)) {
                this.settings.$tip_content.each(function(j) {
                    var m = e(this);
                    e.extend(true, a.settings, a.data_options(m));
                    for (var h = l - 1; 0 <= h; h--) a.settings[d[h]] = parseInt(a.settings[d[h]], 10);
                    a.create({
                        $li: m,
                        index: j
                    })
                });
                !this.settings.startTimerOnClick && 0 < this.settings.timer ? (this.show("init"), this.startTimer()) : this.show("init")
            }
        },
        resume: function() {
            this.set_li();
            this.show()
        },
        tip_template: function(a) {
            var b, d;
            a.tip_class = a.tip_class || "";
            b = e(this.settings.template.tip).addClass(a.tip_class);
            d = e.trim(e(a.li).html()) + this.button_text(a.button_text) + this.settings.template.link +
                this.timer_instance(a.index);
            b.append(e(this.settings.template.wrapper));
            b.first().attr("data-index", a.index);
            e(".joyride-content-wrapper", b).append(d);
            return b[0]
        },
        timer_instance: function(a) {
            return 0 === a && this.settings.startTimerOnClick && 0 < this.settings.timer || 0 === this.settings.timer ? "" : this.outerHTML(e(this.settings.template.timer)[0])
        },
        button_text: function(a) {
            this.settings.nextButton ? (a = e.trim(a) || "Next", a = this.outerHTML(e(this.settings.template.button).append(a)[0])) : a = "";
            return a
        },
        create: function(a) {
            var b = a.$li.attr("data-button") || a.$li.attr("data-text"),
                d = a.$li.attr("class");
            a = e(this.tip_template({
                tip_class: d,
                index: a.index,
                button_text: b,
                li: a.$li
            }));
            e(this.settings.tipContainer).append(a)
        },
        show: function(a) {
            var b = null;
            this.settings.$li === g || -1 === e.inArray(this.settings.$li.index(), this.settings.pauseAfter) ? (this.settings.paused ? this.settings.paused = false : this.set_li(a), this.settings.attempts = 0, this.settings.$li.length && 0 < this.settings.$target.length ? (a && (this.settings.preRideCallback(this.settings.$li.index(), this.settings.$next_tip), this.settings.modal && this.show_modal()), this.settings.preStepCallback(this.settings.$li.index(), this.settings.$next_tip), this.settings.modal && this.settings.expose && this.expose(), this.settings.tipSettings = e.extend(this.settings, this.data_options(this.settings.$li)), this.settings.timer = parseInt(this.settings.timer, 10), this.settings.tipSettings.tipLocationPattern = this.settings.tipLocationPatterns[this.settings.tipSettings.tipLocation], /body/i.test(this.settings.$target.selector) || this.scroll_to(), this.is_phone() ? this.pos_phone(true) : this.pos_default(true), b = this.settings.$next_tip.find(".joyride-timer-indicator"), /pop/i.test(this.settings.tipAnimation) ? (b.width(0), 0 < this.settings.timer ? (this.settings.$next_tip.show(), this.delay(function() {
                b.animate({
                    width: b.parent().width()
                }, this.settings.timer, "linear")
            }.bind(this), this.settings.tipAnimationFadeSpeed)) : this.settings.$next_tip.show()) : /fade/i.test(this.settings.tipAnimation) && (b.width(0), 0 < this.settings.timer ? (this.settings.$next_tip.fadeIn(this.settings.tipAnimationFadeSpeed).show(), this.delay(function() {
                b.animate({
                    width: b.parent().width()
                }, this.settings.timer, "linear")
            }.bind(this), this.settings.tipAnimationFadeSpeed)) : this.settings.$next_tip.fadeIn(this.settings.tipAnimationFadeSpeed)), this.settings.$current_tip = this.settings.$next_tip) : this.settings.$li && 1 > this.settings.$target.length ? this.show() : this.end()) : this.settings.paused = true
        },
        is_phone: function() {
            return c ? c.mq("only screen and (max-width: 767px)") || 0 < e(".lt-ie9").length : 767 > e(p).width()
        },
        hide: function() {
            this.settings.modal && this.settings.expose && this.un_expose();
            this.settings.modal || e(".joyride-modal-bg").hide();
            this.settings.$current_tip.css("visibility", "hidden");
            setTimeout(e.proxy(function() {
                this.hide();
                this.css("visibility", "visible")
            }, this.settings.$current_tip), 0);
            this.settings.postStepCallback(this.settings.$li.index(), this.settings.$current_tip)
        },
        set_li: function(a) {
            a ? (this.settings.$li = this.settings.$tip_content.eq(this.settings.startOffset), this.set_next_tip(), this.settings.$current_tip = this.settings.$next_tip) : (this.settings.$li = this.settings.$li.next(), this.set_next_tip());
            this.set_target()
        },
        set_next_tip: function() {
            this.settings.$next_tip = e(".joyride-tip-guide[data-index='" + this.settings.$li.index() + "']");
            this.settings.$next_tip.data("closed", "")
        },
        set_target: function() {
            var a = this.settings.$li.attr("data-class"),
                b = this.settings.$li.attr("data-id");
            this.settings.$target = b ? e(q.getElementById(b)) : a ? e("." + a).first() : e("body")
        },
        scroll_to: function() {
            var a;
            a = e(p).height() / 2;
            a = Math.ceil(this.settings.$target.offset().top -
                a + this.outerHeight(this.settings.$next_tip));
            0 < a && this.scrollTo(e("html, body"), a, this.settings.scrollSpeed)
        },
        paused: function() {
            return -1 === e.inArray(this.settings.$li.index() + 1, this.settings.pauseAfter)
        },
        restart: function() {
            this.hide();
            this.settings.$li = g;
            this.show("init")
        },
        pos_default: function(a) {
            e(p).height();
            this.settings.$next_tip.offset();
            var b = this.settings.$next_tip.find(".joyride-nub"),
                d = Math.ceil(this.outerWidth(b) / 2),
                l = Math.ceil(this.outerHeight(b) / 2);
            (a = a || false) && (this.settings.$next_tip.css("visibility", "hidden"), this.settings.$next_tip.show());
            /body/i.test(this.settings.$target.selector) ? this.settings.$li.length && this.pos_modal(b) : (this.bottom() ? (d = this.settings.$target.offset().left, Foundation.rtl && (d = this.settings.$target.offset().width - this.settings.$next_tip.width() + d), this.settings.$next_tip.css({
                top: this.settings.$target.offset().top + l + this.outerHeight(this.settings.$target),
                left: d
            }), this.nub_position(b, this.settings.tipSettings.nubPosition, "top")) : this.top() ? (d = this.settings.$target.offset().left, Foundation.rtl && (d = this.settings.$target.offset().width - this.settings.$next_tip.width() + d), this.settings.$next_tip.css({
                top: this.settings.$target.offset().top - this.outerHeight(this.settings.$next_tip) - l,
                left: d
            }), this.nub_position(b, this.settings.tipSettings.nubPosition, "bottom")) : this.right() ? (this.settings.$next_tip.css({
                top: this.settings.$target.offset().top,
                left: this.outerWidth(this.settings.$target) + this.settings.$target.offset().left + d
            }), this.nub_position(b, this.settings.tipSettings.nubPosition, "left")) : this.left() && (this.settings.$next_tip.css({
                top: this.settings.$target.offset().top,
                left: this.settings.$target.offset().left - this.outerWidth(this.settings.$next_tip) - d
            }), this.nub_position(b, this.settings.tipSettings.nubPosition, "right")), !this.visible(this.corners(this.settings.$next_tip)) && this.settings.attempts < this.settings.tipSettings.tipLocationPattern.length && (b.removeClass("bottom").removeClass("top").removeClass("right").removeClass("left"), this.settings.tipSettings.tipLocation = this.settings.tipSettings.tipLocationPattern[this.settings.attempts], this.settings.attempts++, this.pos_default()));
            a && (this.settings.$next_tip.hide(), this.settings.$next_tip.css("visibility", "visible"))
        },
        pos_phone: function(a) {
            var b = this.outerHeight(this.settings.$next_tip);
            this.settings.$next_tip.offset();
            var d = this.outerHeight(this.settings.$target),
                l = e(".joyride-nub", this.settings.$next_tip),
                j = Math.ceil(this.outerHeight(l) / 2);
            a = a || false;
            l.removeClass("bottom").removeClass("top").removeClass("right").removeClass("left");
            a && (this.settings.$next_tip.css("visibility", "hidden"), this.settings.$next_tip.show());
            /body/i.test(this.settings.$target.selector) ? this.settings.$li.length && this.pos_modal(l) : this.top() ? (this.settings.$next_tip.offset({
                top: this.settings.$target.offset().top - b - j
            }), l.addClass("bottom")) : (this.settings.$next_tip.offset({
                top: this.settings.$target.offset().top + d + j
            }), l.addClass("top"));
            a && (this.settings.$next_tip.hide(), this.settings.$next_tip.css("visibility", "visible"))
        },
        pos_modal: function(a) {
            this.center();
            a.hide();
            this.show_modal()
        },
        show_modal: function() {
            if (!this.settings.$next_tip.data("closed")) {
                var a = e(".joyride-modal-bg");
                1 > a.length && e("body").append(this.settings.template.modal).show();
                /pop/i.test(this.settings.tipAnimation) ? a.show() : a.fadeIn(this.settings.tipAnimationFadeSpeed)
            }
        },
        expose: function() {
            var a, b, d, l, j, m = "expose-" + Math.floor(1E4 * Math.random());
            if (0 < arguments.length && arguments[0] instanceof e) d = arguments[0];
            else if (this.settings.$target && !/body/i.test(this.settings.$target.selector)) d = this.settings.$target;
            else return false;
            if (1 > d.length) return p.console && console.error("element not valid", d), false;
            a = e(this.settings.template.expose);
            this.settings.$body.append(a);
            a.css({
                top: d.offset().top,
                left: d.offset().left,
                width: this.outerWidth(d, true),
                height: this.outerHeight(d, true)
            });
            b = e(this.settings.template.exposeCover);
            l = {
                zIndex: d.css("z-index"),
                position: d.css("position")
            };
            j = null == d.attr("class") ? "" : d.attr("class");
            d.css("z-index", parseInt(a.css("z-index")) + 1);
            "static" == l.position && d.css("position", "relative");
            d.data("expose-css", l);
            d.data("orig-class", j);
            d.attr("class", j + " " + this.settings.exposeAddClass);
            b.css({
                top: d.offset().top,
                left: d.offset().left,
                width: this.outerWidth(d, true),
                height: this.outerHeight(d, true)
            });
            this.settings.$body.append(b);
            a.addClass(m);
            b.addClass(m);
            d.data("expose", m);
            this.settings.postExposeCallback(this.settings.$li.index(), this.settings.$next_tip, d);
            this.add_exposed(d)
        },
        un_expose: function() {
            var a, b, d;
            d = false;
            if (0 < arguments.length && arguments[0] instanceof e) b = arguments[0];
            else if (this.settings.$target && !/body/i.test(this.settings.$target.selector)) b = this.settings.$target;
            else return false;
            if (1 > b.length) return p.console && console.error("element not valid", b), false;
            a = b.data("expose");
            a = e("." + a);
            1 < arguments.length && (d = arguments[1]);
            true === d ? e(".joyride-expose-wrapper,.joyride-expose-cover").remove() : a.remove();
            d = b.data("expose-css");
            "auto" == d.zIndex ? b.css("z-index", "") : b.css("z-index", d.zIndex);
            d.position != b.css("position") && ("static" == d.position ? b.css("position", "") : b.css("position", d.position));
            d = b.data("orig-class");
            b.attr("class", d);
            b.removeData("orig-classes");
            b.removeData("expose");
            b.removeData("expose-z-index");
            this.remove_exposed(b)
        },
        add_exposed: function(a) {
            this.settings.exposed = this.settings.exposed || [];
            a instanceof e || "object" === typeof a ? this.settings.exposed.push(a[0]) : "string" == typeof a && this.settings.exposed.push(a)
        },
        remove_exposed: function(a) {
            var b;
            a instanceof e ? b = a[0] : "string" == typeof a && (b = a);
            this.settings.exposed = this.settings.exposed || [];
            a = this.settings.exposed.length;
            for (var d = 0; d < a; d++)
                if (this.settings.exposed[d] == b) {
                    this.settings.exposed.splice(d, 1);
                    break
                }
        },
        center: function() {
            var a = e(p);
            this.settings.$next_tip.css({
                top: (a.height() - this.outerHeight(this.settings.$next_tip)) / 2 + a.scrollTop(),
                left: (a.width() - this.outerWidth(this.settings.$next_tip)) / 2 + this.scrollLeft(a)
            });
            return true
        },
        bottom: function() {
            return /bottom/i.test(this.settings.tipSettings.tipLocation)
        },
        top: function() {
            return /top/i.test(this.settings.tipSettings.tipLocation)
        },
        right: function() {
            return /right/i.test(this.settings.tipSettings.tipLocation)
        },
        left: function() {
            return /left/i.test(this.settings.tipSettings.tipLocation)
        },
        corners: function(a) {
            var b = e(p),
                d = b.height() / 2;
            d = Math.ceil(this.settings.$target.offset().top - d + this.settings.$next_tip.outerHeight());
            var l = b.width() + this.scrollLeft(b),
                j = b.height() + d,
                m = b.height() + b.scrollTop(),
                h = b.scrollTop();
            d < h && (h = 0 > d ? 0 : d);
            j > m && (m = j);
            return [a.offset().top < h, l < a.offset().left + a.outerWidth(), m < a.offset().top + a.outerHeight(), this.scrollLeft(b) > a.offset().left]
        },
        visible: function(a) {
            for (var b = a.length; b--;)
                if (a[b]) return false;
            return true
        },
        nub_position: function(a, b, d) {
            "auto" === b ? a.addClass(d) : a.addClass(b)
        },
        startTimer: function() {
            this.settings.$li.length ? this.settings.automate = setTimeout(function() {
                this.hide();
                this.show();
                this.startTimer()
            }.bind(this), this.settings.timer) : clearTimeout(this.settings.automate)
        },
        end: function() {
            this.settings.cookieMonster && e.cookie(this.settings.cookieName, "ridden", {
                expires: this.settings.cookieExpires,
                domain: this.settings.cookieDomain
            });
            0 < this.settings.timer && clearTimeout(this.settings.automate);
            this.settings.modal && this.settings.expose && this.un_expose();
            this.settings.$next_tip.data("closed", true);
            e(".joyride-modal-bg").hide();
            this.settings.$current_tip.hide();
            this.settings.postStepCallback(this.settings.$li.index(), this.settings.$current_tip);
            this.settings.postRideCallback(this.settings.$li.index(), this.settings.$current_tip);
            e(".joyride-tip-guide").remove()
        },
        outerHTML: function(a) {
            return a.outerHTML || (new XMLSerializer).serializeToString(a)
        },
        off: function() {
            e(this.scope).off(".joyride");
            e(p).off(".joyride");
            e(".joyride-close-tip, .joyride-next-tip, .joyride-modal-bg").off(".joyride");
            e(".joyride-tip-guide, .joyride-modal-bg").remove();
            clearTimeout(this.settings.automate);
            this.settings = {}
        },
        reflow: function() {}
    }
})(Foundation.zj, this, this.document);
(function(e, p) {
    Foundation.libs.magellan = {
        name: "magellan",
        version: "4.3.2",
        settings: {
            activeClass: "active",
            threshold: 0
        },
        init: function(q, g, c) {
            this.scope = q || this.scope;
            Foundation.inherit(this, "data_options");
            "object" === typeof g && e.extend(true, this.settings, g);
            return "string" !== typeof g ? (this.settings.init || (this.fixed_magellan = e("[data-magellan-expedition]"), this.set_threshold(), this.last_destination = e("[data-magellan-destination]").last(), this.events()), this.settings.init) : this[g].call(this, c)
        },
        events: function() {
            var q = this;
            e(this.scope).on("arrival.fndtn.magellan", "[data-magellan-arrival]", function(g) {
                g = e(this);
                var c = g.closest("[data-magellan-expedition]").attr("data-magellan-active-class") || q.settings.activeClass;
                g.closest("[data-magellan-expedition]").find("[data-magellan-arrival]").not(g).removeClass(c);
                g.addClass(c)
            });
            this.fixed_magellan.on("update-position.fndtn.magellan", function() {
                e(this)
            }).trigger("update-position");
            e(p).on("resize.fndtn.magellan", function() {
                this.fixed_magellan.trigger("update-position")
            }.bind(this)).on("scroll.fndtn.magellan", function() {
                var g = e(p).scrollTop();
                q.fixed_magellan.each(function() {
                    var c = e(this);
                    "undefined" === typeof c.data("magellan-top-offset") && c.data("magellan-top-offset", c.offset().top);
                    "undefined" === typeof c.data("magellan-fixed-position") && c.data("magellan-fixed-position", false);
                    var a = g + q.settings.threshold > c.data("magellan-top-offset"),
                        b = c.attr("data-magellan-top-offset");
                    c.data("magellan-fixed-position") != a && (c.data("magellan-fixed-position", a), a ? (c.addClass("fixed"), c.css({
                        position: "fixed",
                        top: 0
                    })) : (c.removeClass("fixed"), c.css({
                        position: "",
                        top: ""
                    })), a && "undefined" != typeof b && false != b && c.css({
                        position: "fixed",
                        top: b + "px"
                    }))
                })
            });
            if (0 < this.last_destination.length) e(p).on("scroll.fndtn.magellan", function() {
                var g = e(p).scrollTop(),
                    c = g + e(p).height(),
                    a = Math.ceil(q.last_destination.offset().top);
                e("[data-magellan-destination]").each(function() {
                    var b = e(this),
                        d = b.attr("data-magellan-destination");
                    b.offset().top - g <= q.settings.threshold && e("[data-magellan-arrival='" + d + "']").trigger("arrival");
                    c >= e(q.scope).height() && a > g && a < c && e("[data-magellan-arrival]").last().trigger("arrival")
                })
            });
            this.settings.init = true
        },
        set_threshold: function() {
            "number" !== typeof this.settings.threshold && (this.settings.threshold = 0 < this.fixed_magellan.length ? this.outerHeight(this.fixed_magellan, true) : 0)
        },
        off: function() {
            e(this.scope).off(".fndtn.magellan");
            e(p).off(".fndtn.magellan")
        },
        reflow: function() {}
    }
})(Foundation.zj, this, this.document);
(function(e, p, q, g) {
    var c = function() {},
        a = function(j, m) {
            if (j.hasClass(m.slides_container_class)) return this;
            var h = this,
                k, f, i, n, o = 0,
                r, t;
            j.children().first().addClass(m.active_slide_class);
            h.update_slide_number = function(s) {
                m.slide_number && (f.find("span:first").text(parseInt(s) + 1), f.find("span:last").text(j.children().length));
                m.bullets && (i.children().removeClass(m.bullets_active_class), e(i.children().get(s)).addClass(m.bullets_active_class))
            };
            h.update_active_link = function(s) {
                s = e('a[data-orbit-link="' +
                    j.children().eq(s).attr("data-orbit-slide") + '"]');
                s.parents("ul").find("[data-orbit-link]").removeClass(m.bullets_active_class);
                s.addClass(m.bullets_active_class)
            };
            h.build_markup = function() {
                j.wrap('<div class="' + m.container_class + '"></div>');
                k = j.parent();
                j.addClass(m.slides_container_class);
                m.navigation_arrows && (k.append(e('<a href="https://static1.freebitco.in/min/combined_bottom1383555676.js#"><span></span></a>').addClass(m.prev_class)), k.append(e('<a href="https://static1.freebitco.in/min/combined_bottom1383555676.js#"><span></span></a>').addClass(m.next_class)));
                m.timer && (n = e("<div>").addClass(m.timer_container_class), n.append("<span>"), n.append(e("<div>").addClass(m.timer_progress_class)), n.addClass(m.timer_paused_class), k.append(n));
                m.slide_number && (f = e("<div>").addClass(m.slide_number_class), f.append("<span></span> " + m.slide_number_text + " <span></span>"), k.append(f));
                m.bullets && (i = e("<ol>").addClass(m.bullets_container_class), k.append(i), j.children().each(function(s) {
                    s = e("<li>").attr("data-orbit-slide", s);
                    i.append(s)
                }));
                m.stack_on_small && k.addClass(m.stack_on_small_class);
                h.update_slide_number(0);
                h.update_active_link(0)
            };
            h._goto = function(s, B) {
                if (s === o) return false;
                "object" === typeof t && t.restart();
                var z = j.children(),
                    L = "next";
                s < o && (L = "prev");
                s >= z.length ? s = 0 : 0 > s && (s = z.length - 1);
                var E = e(z.get(o)),
                    J = e(z.get(s));
                E.css("zIndex", 2);
                E.removeClass(m.active_slide_class);
                J.css("zIndex", 4).addClass(m.active_slide_class);
                j.trigger("orbit:before-slide-change");
                m.before_slide_change();
                h.update_active_link(s);
                var C = function() {
                    var F = function() {
                        o = s;
                        true === B && (t = h.create_timer(), t.start());
                        h.update_slide_number(o);
                        j.trigger("orbit:after-slide-change", [{
                            slide_number: o,
                            total_slides: z.length
                        }]);
                        m.after_slide_change(o, z.length)
                    };
                    j.height() != J.height() && m.variable_height ? j.animate({
                        height: J.height()
                    }, 250, "linear", F) : F()
                };
                if (1 === z.length) return C(), false;
                var H = function() {
                    "next" === L && r.next(E, J, C);
                    "prev" === L && r.prev(E, J, C)
                };
                J.height() > j.height() && m.variable_height ? j.animate({
                    height: J.height()
                }, 250, "linear", H) : H()
            };
            h.next = function(s) {
                s.stopImmediatePropagation();
                s.preventDefault();
                h._goto(o +
                    1)
            };
            h.prev = function(s) {
                s.stopImmediatePropagation();
                s.preventDefault();
                h._goto(o - 1)
            };
            h.link_custom = function(s) {
                s.preventDefault();
                s = e(this).attr("data-orbit-link");
                "string" === typeof s && "" != (s = e.trim(s)) && (s = k.find("[data-orbit-slide=" + s + "]"), -1 != s.index() && h._goto(s.index()))
            };
            h.link_bullet = function(s) {
                s = e(this).attr("data-orbit-slide");
                "string" === typeof s && "" != (s = e.trim(s)) && h._goto(parseInt(s))
            };
            h.timer_callback = function() {
                h._goto(o + 1, true)
            };
            h.compute_dimensions = function() {
                var s = e(j.children().get(o)).height();
                m.variable_height || j.children().each(function() {
                    e(this).height() > s && (s = e(this).height())
                });
                j.height(s)
            };
            h.create_timer = function() {
                return new b(k.find("." + m.timer_container_class), m, h.timer_callback)
            };
            h.stop_timer = function() {
                "object" === typeof t && t.stop()
            };
            h.toggle_timer = function() {
                k.find("." + m.timer_container_class).hasClass(m.timer_paused_class) ? ("undefined" === typeof t && (t = h.create_timer()), t.start()) : "object" === typeof t && t.stop()
            };
            h.init = function() {
                h.build_markup();
                m.timer && (t = h.create_timer(), t.start());
                r = new l(m, j);
                "slide" === m.animation && (r = new d(m, j));
                k.on("click", "." + m.next_class, h.next);
                k.on("click", "." + m.prev_class, h.prev);
                k.on("click", "[data-orbit-slide]", h.link_bullet);
                k.on("click", h.toggle_timer);
                if (m.swipe) k.on("touchstart.fndtn.orbit", function(s) {
                    s.touches || (s = s.originalEvent);
                    var B = {
                        start_page_x: s.touches[0].pageX,
                        start_page_y: s.touches[0].pageY,
                        start_time: (new Date).getTime(),
                        delta_x: 0,
                        is_scrolling: g
                    };
                    k.data("swipe-transition", B);
                    s.stopPropagation()
                }).on("touchmove.fndtn.orbit", function(s) {
                    s.touches || (s = s.originalEvent);
                    if (!(1 < s.touches.length || s.scale && 1 !== s.scale)) {
                        var B = k.data("swipe-transition");
                        "undefined" === typeof B && (B = {});
                        B.delta_x = s.touches[0].pageX - B.start_page_x;
                        "undefined" === typeof B.is_scrolling && (B.is_scrolling = !!(B.is_scrolling || Math.abs(B.delta_x) < Math.abs(s.touches[0].pageY - B.start_page_y)));
                        B.is_scrolling || B.active || (s.preventDefault(), s = 0 > B.delta_x ? o + 1 : o - 1, B.active = true, h._goto(s))
                    }
                }).on("touchend.fndtn.orbit", function(s) {
                    k.data("swipe-transition", {});
                    s.stopPropagation()
                });
                k.on("mouseenter.fndtn.orbit", function() {
                    m.timer && m.pause_on_hover && h.stop_timer()
                }).on("mouseleave.fndtn.orbit", function() {
                    m.timer && m.resume_on_mouseout && t.start()
                });
                e(q).on("click", "[data-orbit-link]", h.link_custom);
                e(p).on("resize", h.compute_dimensions);
                e(p).on("load", h.compute_dimensions);
                e(p).on("load", function() {
                    k.prev(".preloader").css("display", "none")
                });
                j.trigger("orbit:ready")
            };
            h.init()
        },
        b = function(j, m, h) {
            var k = this,
                f = m.timer_speed,
                i = j.find("." + m.timer_progress_class),
                n, o, r = -1;
            this.update_progress = function(t) {
                var s = i.clone();
                s.attr("style", "");
                s.css("width", t + "%");
                i.replaceWith(s);
                i = s
            };
            this.restart = function() {
                clearTimeout(o);
                j.addClass(m.timer_paused_class);
                r = -1;
                k.update_progress(0)
            };
            this.start = function() {
                if (!j.hasClass(m.timer_paused_class)) return true;
                r = -1 === r ? f : r;
                j.removeClass(m.timer_paused_class);
                n = (new Date).getTime();
                i.animate({
                    width: "100%"
                }, r, "linear");
                o = setTimeout(function() {
                    k.restart();
                    h()
                }, r);
                j.trigger("orbit:timer-started")
            };
            this.stop = function() {
                if (j.hasClass(m.timer_paused_class)) return true;
                clearTimeout(o);
                j.addClass(m.timer_paused_class);
                var t = (new Date).getTime();
                r -= t - n;
                k.update_progress(100 - r / f * 100);
                j.trigger("orbit:timer-stopped")
            }
        },
        d = function(j) {
            var m = j.animation_speed,
                h = 1 === e("html[dir=rtl]").length ? "marginRight" : "marginLeft",
                k = {};
            k[h] = "0%";
            this.next = function(f, i, n) {
                i.animate(k, m, "linear", function() {
                    f.css(h, "100%");
                    n()
                })
            };
            this.prev = function(f, i, n) {
                i.css(h, "-100%");
                i.animate(k, m, "linear", function() {
                    f.css(h, "100%");
                    n()
                })
            }
        },
        l = function(j) {
            var m = j.animation_speed;
            e("html[dir=rtl]");
            this.next = function(h, k, f) {
                k.css({
                    margin: "0%",
                    opacity: "0.01"
                });
                k.animate({
                    opacity: "1"
                }, m, "linear", function() {
                    h.css("margin", "100%");
                    f()
                })
            };
            this.prev = function(h, k, f) {
                k.css({
                    margin: "0%",
                    opacity: "0.01"
                });
                k.animate({
                    opacity: "1"
                }, m, "linear", function() {
                    h.css("margin", "100%");
                    f()
                })
            }
        };
    Foundation.libs = Foundation.libs || {};
    Foundation.libs.orbit = {
        name: "orbit",
        version: "4.3.2",
        settings: {
            animation: "slide",
            timer_speed: 1E4,
            pause_on_hover: true,
            resume_on_mouseout: false,
            animation_speed: 500,
            stack_on_small: false,
            navigation_arrows: true,
            slide_number: true,
            slide_number_text: "of",
            container_class: "orbit-container",
            stack_on_small_class: "orbit-stack-on-small",
            next_class: "orbit-next",
            prev_class: "orbit-prev",
            timer_container_class: "orbit-timer",
            timer_paused_class: "paused",
            timer_progress_class: "orbit-progress",
            slides_container_class: "orbit-slides-container",
            bullets_container_class: "orbit-bullets",
            bullets_active_class: "active",
            slide_number_class: "orbit-slide-number",
            caption_class: "orbit-caption",
            active_slide_class: "active",
            orbit_transition_class: "orbit-transitioning",
            bullets: true,
            timer: true,
            variable_height: false,
            swipe: true,
            before_slide_change: c,
            after_slide_change: c
        },
        init: function(j, m, h) {
            var k = this;
            Foundation.inherit(k, "data_options");
            "object" === typeof m && e.extend(true, k.settings, m);
            e(j).is("[data-orbit]") && (m = e(j), h = k.data_options(m), new a(m, e.extend({}, k.settings, h)));
            e("[data-orbit]", j).each(function(f, i) {
                var n = e(i),
                    o = k.data_options(n);
                new a(n, e.extend({}, k.settings, o))
            })
        }
    }
})(Foundation.zj, this, this.document);
(function(e, p, q, g) {
    Foundation.libs.reveal = {
        name: "reveal",
        version: "4.3.2",
        locked: false,
        settings: {
            animation: "fadeAndPop",
            animationSpeed: 250,
            closeOnBackgroundClick: true,
            closeOnEsc: true,
            dismissModalClass: "close-reveal-modal",
            bgClass: "reveal-modal-bg",
            open: function() {},
            opened: function() {},
            close: function() {},
            closed: function() {},
            bg: e(".reveal-modal-bg"),
            css: {
                open: {
                    opacity: 0,
                    visibility: "visible",
                    display: "block"
                },
                close: {
                    opacity: 1,
                    visibility: "hidden",
                    display: "none"
                }
            }
        },
        init: function(c, a, b) {
            Foundation.inherit(this, "data_options delay");
            "object" === typeof a ? e.extend(true, this.settings, a) : "undefined" !== typeof b && e.extend(true, this.settings, b);
            return "string" !== typeof a ? (this.events(), this.settings.init) : this[a].call(this, b)
        },
        events: function() {
            var c = this;
            e(this.scope).off(".fndtn.reveal").on("click.fndtn.reveal", "[data-reveal-id]", function(a) {
                a.preventDefault();
                if (!c.locked) {
                    a = e(this);
                    var b = a.data("reveal-ajax");
                    c.locked = true;
                    "undefined" === typeof b ? c.open.call(c, a) : (b = true === b ? a.attr("href") : b, c.open.call(c, a, {
                        url: b
                    }))
                }
            }).on("click.fndtn.reveal touchend", this.close_targets(), function(a) {
                a.preventDefault();
                if (!c.locked) {
                    var b = e.extend({}, c.settings, c.data_options(e(".reveal-modal.open")));
                    a = e(a.target)[0] === e("." + b.bgClass)[0];
                    if (!a || b.closeOnBackgroundClick) {
                        c.locked = true;
                        c.close.call(c, a ? e(".reveal-modal.open") : e(this).closest(".reveal-modal"))
                    }
                }
            });
            if (e(this.scope).hasClass("reveal-modal")) e(this.scope).on("open.fndtn.reveal", this.settings.open).on("opened.fndtn.reveal", this.settings.opened).on("opened.fndtn.reveal", this.open_video).on("close.fndtn.reveal", this.settings.close).on("closed.fndtn.reveal", this.settings.closed).on("closed.fndtn.reveal", this.close_video);
            else e(this.scope).on("open.fndtn.reveal", ".reveal-modal", this.settings.open).on("opened.fndtn.reveal", ".reveal-modal", this.settings.opened).on("opened.fndtn.reveal", ".reveal-modal", this.open_video).on("close.fndtn.reveal", ".reveal-modal", this.settings.close).on("closed.fndtn.reveal", ".reveal-modal", this.settings.closed).on("closed.fndtn.reveal", ".reveal-modal", this.close_video);
            e("body").bind("keyup.reveal", function(a) {
                var b = e(".reveal-modal.open"),
                    d = e.extend({}, c.settings, c.data_options(b));
                27 === a.which && d.closeOnEsc && b.foundation("reveal", "close")
            });
            return true
        },
        open: function(c, a) {
            if (c)
                if ("undefined" !== typeof c.selector) var b = e("#" + c.data("reveal-id"));
                else {
                    b = e(this.scope);
                    a = c
                }
            else b = e(this.scope);
            if (!b.hasClass("open")) {
                var d = e(".reveal-modal.open");
                "undefined" === typeof b.data("css-top") && b.data("css-top", parseInt(b.css("top"), 10)).data("offset", this.cache_offset(b));
                b.trigger("open");
                1 > d.length && this.toggle_bg();
                if ("undefined" !== typeof a && a.url) {
                    var l = this,
                        j = "undefined" !== typeof a.success ? a.success : null;
                    e.extend(a, {
                        success: function(m, h, k) {
                            e.isFunction(j) && j(m, h, k);
                            b.html(m);
                            e(b).foundation("section", "reflow");
                            l.hide(d, l.settings.css.close);
                            l.show(b, l.settings.css.open)
                        }
                    });
                    e.ajax(a)
                } else {
                    this.hide(d, this.settings.css.close);
                    this.show(b, this.settings.css.open)
                }
            }
        },
        close: function(c) {
            c = c && c.length ? c : e(this.scope);
            var a = e(".reveal-modal.open");
            0 < a.length && (this.locked = true, c.trigger("close"), this.toggle_bg(), this.hide(a, this.settings.css.close))
        },
        close_targets: function() {
            var c = "." + this.settings.dismissModalClass;
            return this.settings.closeOnBackgroundClick ? c + ", ." + this.settings.bgClass : c
        },
        toggle_bg: function() {
            0 === e("." + this.settings.bgClass).length && (this.settings.bg = e("<div ></a>", {
                "class": this.settings.bgClass
            }).appendTo("body"));
            0 < this.settings.bg.filter(":visible").length ? this.hide(this.settings.bg) : this.show(this.settings.bg)
        },
        show: function(c, a) {
            if (a) {
                if (0 === c.parent("body").length) {
                    var b = c.wrap('<div style="display: none;" ></this>').parent();
                    c.on("closed.fndtn.reveal.wrapped", function() {
                        c.detach().appendTo(b);
                        c.unwrap().unbind("closed.fndtn.reveal.wrapped")
                    });
                    c.detach().appendTo("body")
                }
                if (/pop/i.test(this.settings.animation)) {
                    a.top = e(p).scrollTop() - c.data("offset") + "px";
                    var d = {
                        top: e(p).scrollTop() + c.data("css-top") + "px",
                        opacity: 1
                    };
                    return this.delay(function() {
                        return c.css(a).animate(d, this.settings.animationSpeed, "linear", function() {
                            this.locked = false;
                            c.trigger("opened")
                        }.bind(this)).addClass("open")
                    }.bind(this), this.settings.animationSpeed / 2)
                }
                return /fade/i.test(this.settings.animation) ? (d = {
                    opacity: 1
                }, this.delay(function() {
                    return c.css(a).animate(d, this.settings.animationSpeed, "linear", function() {
                        this.locked = false;
                        c.trigger("opened")
                    }.bind(this)).addClass("open")
                }.bind(this), this.settings.animationSpeed / 2)) : c.css(a).show().css({
                    opacity: 1
                }).addClass("open").trigger("opened")
            }
            return /fade/i.test(this.settings.animation) ? c.fadeIn(this.settings.animationSpeed / 2) : c.show()
        },
        hide: function(c, a) {
            if (a) {
                if (/pop/i.test(this.settings.animation)) {
                    var b = {
                        top: -e(p).scrollTop() - c.data("offset") + "px",
                        opacity: 0
                    };
                    return this.delay(function() {
                        return c.animate(b, this.settings.animationSpeed, "linear", function() {
                            this.locked = false;
                            c.css(a).trigger("closed")
                        }.bind(this)).removeClass("open")
                    }.bind(this), this.settings.animationSpeed / 2)
                }
                return /fade/i.test(this.settings.animation) ? (b = {
                    opacity: 0
                }, this.delay(function() {
                    return c.animate(b, this.settings.animationSpeed, "linear", function() {
                        this.locked = false;
                        c.css(a).trigger("closed")
                    }.bind(this)).removeClass("open")
                }.bind(this), this.settings.animationSpeed / 2)) : c.hide().css(a).removeClass("open").trigger("closed")
            }
            return /fade/i.test(this.settings.animation) ? c.fadeOut(this.settings.animationSpeed / 2) : c.hide()
        },
        close_video: function(c) {
            c = e(this).find(".flex-video");
            var a = c.find("iframe");
            0 < a.length && (a.attr("data-src", a[0].src), a.attr("src", "about:blank"), c.hide())
        },
        open_video: function(c) {
            c = e(this).find(".flex-video");
            var a = c.find("iframe");
            if (0 < a.length) {
                if ("string" === typeof a.attr("data-src")) a[0].src = a.attr("data-src");
                else {
                    var b = a[0].src;
                    a[0].src = g;
                    a[0].src = b
                }
                c.show()
            }
        },
        cache_offset: function(c) {
            var a = c.show().height() + parseInt(c.css("top"), 10);
            c.hide();
            return a
        },
        off: function() {
            e(this.scope).off(".fndtn.reveal")
        },
        reflow: function() {}
    }
})(Foundation.zj, this, this.document);
(function(e, p, q) {
    Foundation.libs.section = {
        name: "section",
        version: "4.3.2",
        settings: {
            deep_linking: false,
            small_breakpoint: 768,
            one_up: true,
            multi_expand: false,
            section_selector: "[data-section]",
            region_selector: "section, .section, [data-section-region]",
            title_selector: ".title, [data-section-title]",
            resized_data_attr: "data-section-resized",
            small_style_data_attr: "data-section-small-style",
            content_selector: ".content, [data-section-content]",
            nav_selector: '[data-section="vertical-nav"], [data-section="horizontal-nav"]',
            active_class: "active",
            callback: function() {}
        },
        init: function(g, c, a) {
            Foundation.inherit(this, "throttle data_options position_right offset_right");
            "object" === typeof c && e.extend(true, this.settings, c);
            return "string" !== typeof c ? (this.events(), true) : this[c].call(this, a)
        },
        events: function() {
            for (var g = this, c = [], a = g.settings.section_selector, b = g.settings.region_selector.split(","), d = g.settings.title_selector.split(","), l = 0, j = b.length; l < j; l++)
                for (var m = b[l], h = 0, k = d.length; h < k; h++) {
                    var f = a + ">" + m + ">" + d[h];
                    c.push(f +
                        " a");
                    c.push(f)
                }
            e(g.scope).on("click.fndtn.section", c.join(","), function(i) {
                var n = e(this).closest(g.settings.title_selector);
                g.close_navs(n);
                0 < n.siblings(g.settings.content_selector).length && g.toggle_active.call(n[0], i)
            });
            e(p).on("resize.fndtn.section", g.throttle(function() {
                g.resize()
            }, 30)).on("hashchange.fndtn.section", g.set_active_from_hash);
            e(q).on("click.fndtn.section", function(i) {
                i.isPropagationStopped && i.isPropagationStopped() || i.target !== q && g.close_navs(e(i.target).closest(g.settings.title_selector))
            });
            e(p).triggerHandler("resize.fndtn.section");
            e(p).triggerHandler("hashchange.fndtn.section")
        },
        close_navs: function(g) {
            var c = Foundation.libs.section,
                a = e(c.settings.nav_selector).filter(function() {
                    return !e.extend({}, c.settings, c.data_options(e(this))).one_up
                });
            if (0 < g.length) {
                var b = g.parent().parent();
                if (c.is_horizontal_nav(b) || c.is_vertical_nav(b)) a = a.filter(function() {
                    return this !== b[0]
                })
            }
            a.children(c.settings.region_selector).removeClass(c.settings.active_class)
        },
        toggle_active: function(g) {
            var c = e(this),
                a = Foundation.libs.section,
                b = c.parent();
            c = c.siblings(a.settings.content_selector);
            var d = b.parent(),
                l = e.extend({}, a.settings, a.data_options(d)),
                j = d.children(a.settings.region_selector).filter("." + a.settings.active_class);
            !l.deep_linking && 0 < c.length && g.preventDefault();
            g.stopPropagation();
            if (b.hasClass(a.settings.active_class)) {
                if (b.hasClass(a.settings.active_class) && a.is_accordion(d) || !l.one_up && (a.small(d) || a.is_vertical_nav(d) || a.is_horizontal_nav(d) || a.is_accordion(d))) {
                    b.removeClass(a.settings.active_class);
                    b.trigger("closed.fndtn.section")
                }
            } else {
                if (!a.is_accordion(d) || a.is_accordion(d) && !a.settings.multi_expand) {
                    j.removeClass(a.settings.active_class);
                    j.trigger("closed.fndtn.section")
                }
                b.addClass(a.settings.active_class);
                a.resize(b.find(a.settings.section_selector).not("[" + a.settings.resized_data_attr + "]"), true);
                b.trigger("opened.fndtn.section")
            }
            l.callback(d)
        },
        check_resize_timer: null,
        resize: function(g, c) {
            var a = Foundation.libs.section,
                b = e(a.settings.section_selector),
                d = a.small(b),
                l = function(j, m) {
                    return !a.is_accordion(j) && !j.is("[" + a.settings.resized_data_attr + "]") && (!d || a.is_horizontal_tabs(j)) && m === ("none" === j.css("display") || !j.parent().is(":visible"))
                };
            g = g || e(a.settings.section_selector);
            clearTimeout(a.check_resize_timer);
            d || g.removeAttr(a.settings.small_style_data_attr);
            g.filter(function() {
                return l(e(this), false)
            }).each(function() {
                var j = e(this),
                    m = j.children(a.settings.region_selector),
                    h = m.children(a.settings.title_selector),
                    k = m.children(a.settings.content_selector),
                    f = 0;
                if (c && 0 == j.children(a.settings.region_selector).filter("." +
                        a.settings.active_class).length) {
                    var i = e.extend({}, a.settings, a.data_options(j));
                    i.deep_linking || !i.one_up && (a.is_horizontal_nav(j) || a.is_vertical_nav(j) || a.is_accordion(j)) || m.filter(":visible").first().addClass(a.settings.active_class)
                }
                if (a.is_horizontal_tabs(j) || a.is_auto(j)) {
                    var n = 0;
                    h.each(function() {
                        var B = e(this);
                        if (B.is(":visible")) {
                            B.css(a.rtl ? "right" : "left", n);
                            var z = parseInt(B.css("border-" + (a.rtl ? "left" : "right") + "-width"), 10);
                            "Nan" === z.toString() && (z = 0);
                            n += a.outerWidth(B) - z;
                            f = Math.max(f, a.outerHeight(B))
                        }
                    });
                    h.css("height", f);
                    m.each(function() {
                        var B = e(this),
                            z = B.children(a.settings.content_selector);
                        z = parseInt(z.css("border-top-width"), 10);
                        "Nan" === z.toString() && (z = 0);
                        B.css("padding-top", f - z)
                    });
                    j.css("min-height", f)
                } else if (a.is_horizontal_nav(j)) {
                    var o = true;
                    h.each(function() {
                        f = Math.max(f, a.outerHeight(e(this)))
                    });
                    m.each(function() {
                        var B = e(this);
                        B.css("margin-left", "-" + (o ? j : B.children(a.settings.title_selector)).css("border-left-width"));
                        o = false
                    });
                    m.css("margin-top", "-" + j.css("border-top-width"));
                    h.css("height", f);
                    k.css("top", f);
                    j.css("min-height", f)
                } else if (a.is_vertical_tabs(j)) {
                    var r = 0;
                    h.each(function() {
                        var B = e(this);
                        if (B.is(":visible")) {
                            B.css("top", r);
                            var z = parseInt(B.css("border-top-width"), 10);
                            "Nan" === z.toString() && (z = 0);
                            r += a.outerHeight(B) - z
                        }
                    });
                    k.css("min-height", r + 1)
                } else if (a.is_vertical_nav(j)) {
                    var t = 0,
                        s = true;
                    h.each(function() {
                        t = Math.max(t, a.outerWidth(e(this)))
                    });
                    m.each(function() {
                        var B = e(this);
                        B.css("margin-top", "-" + (s ? j : B.children(a.settings.title_selector)).css("border-top-width"));
                        s = false
                    });
                    h.css("width", t);
                    k.css(a.rtl ? "right" : "left", t);
                    j.css("width", t)
                }
                j.attr(a.settings.resized_data_attr, true)
            });
            0 < e(a.settings.section_selector).filter(function() {
                return l(e(this), true)
            }).length && (a.check_resize_timer = setTimeout(function() {
                a.resize(g.filter(function() {
                    return l(e(this), false)
                }), true)
            }, 700));
            d && g.attr(a.settings.small_style_data_attr, true)
        },
        is_vertical_nav: function(g) {
            return /vertical-nav/i.test(g.data("section"))
        },
        is_horizontal_nav: function(g) {
            return /horizontal-nav/i.test(g.data("section"))
        },
        is_accordion: function(g) {
            return /accordion/i.test(g.data("section"))
        },
        is_horizontal_tabs: function(g) {
            return /^tabs$/i.test(g.data("section"))
        },
        is_vertical_tabs: function(g) {
            return /vertical-tabs/i.test(g.data("section"))
        },
        is_auto: function(g) {
            g = g.data("section");
            return "" === g || /auto/i.test(g)
        },
        set_active_from_hash: function() {
            var g = Foundation.libs.section,
                c = p.location.hash.substring(1),
                a = e(g.settings.section_selector),
                b;
            a.each(function() {
                var d = e(this);
                d.children(g.settings.region_selector).each(function() {
                    var l = e(this).children(g.settings.content_selector).data("slug");
                    if (RegExp(l, "i").test(c)) return b = d, false
                });
                if (null != b) return false
            });
            null != b && a.each(function() {
                if (b == e(this)) {
                    var d = e(this),
                        l = e.extend({}, g.settings, g.data_options(d)),
                        j = d.children(g.settings.region_selector),
                        m = l.deep_linking && 0 < c.length,
                        h = false;
                    j.each(function() {
                        var k = e(this);
                        if (h) k.removeClass(g.settings.active_class);
                        else if (m) {
                            var f = k.children(g.settings.content_selector).data("slug");
                            f && RegExp(f, "i").test(c) ? (k.hasClass(g.settings.active_class) || k.addClass(g.settings.active_class), h = true) : k.removeClass(g.settings.active_class)
                        } else k.hasClass(g.settings.active_class) && (h = true)
                    });
                    h || !l.one_up && (g.is_horizontal_nav(d) || g.is_vertical_nav(d) || g.is_accordion(d)) || j.filter(":visible").first().addClass(g.settings.active_class)
                }
            })
        },
        reflow: function() {
            var g = Foundation.libs.section;
            e(g.settings.section_selector).removeAttr(g.settings.resized_data_attr);
            g.throttle(function() {
                g.resize()
            }, 30)()
        },
        small: function(g) {
            var c = e.extend({}, this.settings, this.data_options(g));
            return this.is_horizontal_tabs(g) ? false : g && this.is_accordion(g) || e("html").hasClass("lt-ie9") || e("html").hasClass("ie8compat") ? true : e(this.scope).width() < c.small_breakpoint
        },
        off: function() {
            e(this.scope).off(".fndtn.section");
            e(p).off(".fndtn.section");
            e(q).off(".fndtn.section")
        }
    };
    e.fn.reflow_section = function(g) {
        var c = this,
            a = Foundation.libs.section;
        c.removeAttr(a.settings.resized_data_attr);
        a.throttle(function() {
            a.resize(c, g)
        }, 30)();
        return this
    }
})(Foundation.zj, window, document);
(function(e, p) {
    Foundation.libs.tooltips = {
        name: "tooltips",
        version: "4.3.2",
        settings: {
            selector: ".has-tip",
            additionalInheritableClasses: [],
            tooltipClass: ".tooltip",
            touchCloseText: "tap to close",
            appendTo: "body",
            "disable-for-touch": false,
            tipTemplate: function(q, g) {
                return '<span data-selector="' + q + '" class="' + Foundation.libs.tooltips.settings.tooltipClass.substring(1) + '">' + g + '<span class="nub"></span></span>'
            }
        },
        cache: {},
        init: function(q, g, c) {
            Foundation.inherit(this, "data_options");
            var a = this;
            "object" === typeof g ? e.extend(true, this.settings, g) : "undefined" !== typeof c && e.extend(true, this.settings, c);
            if ("string" !== typeof g)
                if (Modernizr.touch) e(this.scope).on("click.fndtn.tooltip touchstart.fndtn.tooltip touchend.fndtn.tooltip", "[data-tooltip]", function(b) {
                    var d = e.extend({}, a.settings, a.data_options(e(this)));
                    d["disable-for-touch"] || (b.preventDefault(), e(d.tooltipClass).hide(), a.showOrCreateTip(e(this)))
                }).on("click.fndtn.tooltip touchstart.fndtn.tooltip touchend.fndtn.tooltip", this.settings.tooltipClass, function(b) {
                    b.preventDefault();
                    e(this).fadeOut(150)
                });
                else e(this.scope).on("mouseenter.fndtn.tooltip mouseleave.fndtn.tooltip", "[data-tooltip]", function(b) {
                    var d = e(this);
                    /enter|over/i.test(b.type) ? a.showOrCreateTip(d) : "mouseout" !== b.type && "mouseleave" !== b.type || a.hide(d)
                });
            else return this[g].call(this, c)
        },
        showOrCreateTip: function(q) {
            var g = this.getTip(q);
            return g && 0 < g.length ? this.show(q) : this.create(q)
        },
        getTip: function(q) {
            q = this.selector(q);
            var g = null;
            q && (g = e('span[data-selector="' + q + '"]' + this.settings.tooltipClass));
            return "object" === typeof g ? g : false
        },
        selector: function(q) {
            var g = q.attr("id"),
                c = q.attr("data-tooltip") || q.attr("data-selector");
            (g && 1 > g.length || !g) && "string" != typeof c && (c = "tooltip" + Math.random().toString(36).substring(7), q.attr("data-selector", c));
            return g && 0 < g.length ? g : c
        },
        create: function(q) {
            var g = e(this.settings.tipTemplate(this.selector(q), e("<div></div>").html(q.attr("title")).html())),
                c = this.inheritable_classes(q);
            g.addClass(c).appendTo(this.settings.appendTo);
            Modernizr.touch && g.append('<span class="tap-to-close">' +
                this.settings.touchCloseText + "</span>");
            q.removeAttr("title").attr("title", "");
            this.show(q)
        },
        reposition: function(q, g, c) {
            var a, b, d, l;
            g.css("visibility", "hidden").show();
            a = q.data("width");
            b = g.children(".nub");
            d = this.outerHeight(b);
            this.outerHeight(b);
            l = function(j, m, h, k, f, i) {
                return j.css({
                    top: m ? m : "auto",
                    bottom: k ? k : "auto",
                    left: f ? f : "auto",
                    right: h ? h : "auto",
                    width: i ? i : "auto"
                }).end()
            };
            l(g, q.offset().top + this.outerHeight(q) + 10, "auto", "auto", q.offset().left, a);
            767 > e(p).width() ? (l(g, q.offset().top + this.outerHeight(q) +
                10, "auto", "auto", 12.5, e(this.scope).width()), g.addClass("tip-override"), l(b, -d, "auto", "auto", q.offset().left)) : (b = q.offset().left, Foundation.rtl && (b = q.offset().left + q.offset().width - this.outerWidth(g)), l(g, q.offset().top + this.outerHeight(q) + 10, "auto", "auto", b, a), g.removeClass("tip-override"), c && -1 < c.indexOf("tip-top") ? l(g, q.offset().top - this.outerHeight(g), "auto", "auto", b, a).removeClass("tip-override") : c && -1 < c.indexOf("tip-left") ? l(g, q.offset().top + this.outerHeight(q) / 2 - 2.5 * d, "auto", "auto", q.offset().left -
                this.outerWidth(g) - d, a).removeClass("tip-override") : c && -1 < c.indexOf("tip-right") && l(g, q.offset().top + this.outerHeight(q) / 2 - 2.5 * d, "auto", "auto", q.offset().left + this.outerWidth(q) + d, a).removeClass("tip-override"));
            g.css("visibility", "visible").hide()
        },
        inheritable_classes: function(q) {
            var g = ["tip-top", "tip-left", "tip-bottom", "tip-right", "noradius"].concat(this.settings.additionalInheritableClasses);
            q = (q = q.attr("class")) ? e.map(q.split(" "), function(c) {
                if (-1 !== e.inArray(c, g)) return c
            }).join(" ") : "";
            return e.trim(q)
        },
        show: function(q) {
            var g = this.getTip(q);
            this.reposition(q, g, q.attr("class"));
            g.fadeIn(150)
        },
        hide: function(q) {
            this.getTip(q).fadeOut(150)
        },
        reload: function() {
            var q = e(this);
            return q.data("fndtn-tooltips") ? q.foundationTooltips("destroy").foundationTooltips("init") : q.foundationTooltips("init")
        },
        off: function() {
            e(this.scope).off(".fndtn.tooltip");
            e(this.settings.tooltipClass).each(function(q) {
                e("[data-tooltip]").get(q).attr("title", e(this).text())
            }).remove()
        },
        reflow: function() {}
    }
})(Foundation.zj, this, this.document);
(function(e, p, q) {
    Foundation.libs.topbar = {
        name: "topbar",
        version: "4.3.2",
        settings: {
            index: 0,
            stickyClass: "sticky",
            custom_back_text: true,
            back_text: "Back",
            is_hover: true,
            mobile_show_parent_link: false,
            scrolltop: true,
            init: false
        },
        init: function(g, c, a) {
            Foundation.inherit(this, "data_options addCustomRule");
            var b = this;
            "object" === typeof c ? e.extend(true, this.settings, c) : "undefined" !== typeof a && e.extend(true, this.settings, a);
            return "string" !== typeof c ? (e(".top-bar, [data-topbar]").each(function() {
                e.extend(true, b.settings, b.data_options(e(this)));
                b.settings.$w = e(p);
                b.settings.$topbar = e(this);
                b.settings.$section = b.settings.$topbar.find("section");
                b.settings.$titlebar = b.settings.$topbar.children("ul").first();
                b.settings.$topbar.data("index", 0);
                var d = b.settings.$topbar.parent();
                d.hasClass("fixed") || d.hasClass(b.settings.stickyClass) ? (b.settings.$topbar.data("height", b.outerHeight(d)), b.settings.$topbar.data("stickyoffset", d.offset().top)) : b.settings.$topbar.data("height", b.outerHeight(b.settings.$topbar));
                d = e("<div class='top-bar-js-breakpoint'></c>").insertAfter(b.settings.$topbar);
                b.settings.breakPoint = d.width();
                d.remove();
                b.assemble();
                b.settings.is_hover && b.settings.$topbar.find(".has-dropdown").addClass("not-click");
                b.addCustomRule(".f-topbar-fixed { padding-top: " + b.settings.$topbar.data("height") + "px }");
                b.settings.$topbar.parent().hasClass("fixed") && e("body").addClass("f-topbar-fixed")
            }), b.settings.init || this.events(), this.settings.init) : this[c].call(this, a)
        },
        toggle: function() {
            var g = e(".top-bar, [data-topbar]"),
                c = g.find("section, .section");
            this.breakpoint() && (this.rtl ? (c.css({
                right: "0%"
            }), c.find(">.name").css({
                right: "100%"
            })) : (c.css({
                left: "0%"
            }), c.find(">.name").css({
                left: "100%"
            })), c.find("li.moved").removeClass("moved"), g.data("index", 0), g.toggleClass("expanded").css("height", ""));
            this.settings.scrolltop ? g.hasClass("expanded") ? g.parent().hasClass("fixed") && (this.settings.scrolltop ? (g.parent().removeClass("fixed"), g.addClass("fixed"), e("body").removeClass("f-topbar-fixed"), p.scrollTo(0, 0)) : g.parent().removeClass("expanded")) : g.hasClass("fixed") && (g.parent().addClass("fixed"), g.removeClass("fixed"), e("body").addClass("f-topbar-fixed")) : (g.parent().hasClass(this.settings.stickyClass) && g.parent().addClass("fixed"), g.parent().hasClass("fixed") && (g.hasClass("expanded") ? (g.addClass("fixed"), g.parent().addClass("expanded")) : (g.removeClass("fixed"), g.parent().removeClass("expanded"), this.updateStickyPositioning())))
        },
        timer: null,
        events: function() {
            var g = this;
            e(this.scope).off(".fndtn.topbar").on("click.fndtn.topbar", ".top-bar .toggle-topbar, [data-topbar] .toggle-topbar", function(c) {
                c.preventDefault();
                g.toggle()
            }).on("click.fndtn.topbar", ".top-bar li.has-dropdown", function(c) {
                var a = e(this),
                    b = e(c.target);
                a.closest("[data-topbar], .top-bar").data("topbar");
                b.data("revealId") ? g.toggle() : g.breakpoint() || g.settings.is_hover && !Modernizr.touch || (c.stopImmediatePropagation(), "A" === b[0].nodeName && b.parent().hasClass("has-dropdown") && c.preventDefault(), a.hasClass("hover") ? (a.removeClass("hover").find("li").removeClass("hover"), a.parents("li.hover").removeClass("hover")) : a.addClass("hover"))
            }).on("click.fndtn.topbar", ".top-bar .has-dropdown>a, [data-topbar] .has-dropdown>a", function(c) {
                if (g.breakpoint() && e(p).width() != g.settings.breakPoint) {
                    c.preventDefault();
                    c = e(this);
                    var a = c.closest(".top-bar, [data-topbar]"),
                        b = a.find("section, .section");
                    c.next(".dropdown").outerHeight();
                    var d = c.closest("li");
                    a.data("index", a.data("index") + 1);
                    d.addClass("moved");
                    g.rtl ? (b.css({
                        right: -(100 * a.data("index")) + "%"
                    }), b.find(">.name").css({
                        right: 100 * a.data("index") + "%"
                    })) : (b.css({
                        left: -(100 * a.data("index")) + "%"
                    }), b.find(">.name").css({
                        left: 100 * a.data("index") + "%"
                    }));
                    a.css("height", g.outerHeight(c.siblings("ul"), true) + g.settings.$topbar.data("height"))
                }
            });
            e(p).on("resize.fndtn.topbar", function() {
                if ("undefined" !== typeof g.settings.$topbar) {
                    var c = g.settings.$topbar.parent("." + this.settings.stickyClass),
                        a;
                    g.breakpoint() || (a = g.settings.$topbar.hasClass("expanded"), e(".top-bar, [data-topbar]").css("height", "").removeClass("expanded").find("li").removeClass("hover"), a && g.toggle());
                    0 < c.length && (c.hasClass("fixed") ? (c.removeClass("fixed"), a = c.offset().top, e(q.body).hasClass("f-topbar-fixed") && (a -= g.settings.$topbar.data("height")), g.settings.$topbar.data("stickyoffset", a), c.addClass("fixed")) : (a = c.offset().top, g.settings.$topbar.data("stickyoffset", a)))
                }
            }.bind(this));
            e("body").on("click.fndtn.topbar", function(c) {
                0 < e(c.target).closest("li").closest("li.hover").length || e(".top-bar li, [data-topbar] li").removeClass("hover")
            });
            e(this.scope).on("click.fndtn", ".top-bar .has-dropdown .back, [data-topbar] .has-dropdown .back", function(c) {
                c.preventDefault();
                var a = e(this);
                c = a.closest(".top-bar, [data-topbar]");
                var b = c.find("section, .section"),
                    d = a.closest("li.moved");
                a = d.parent();
                c.data("index", c.data("index") - 1);
                g.rtl ? (b.css({
                    right: -(100 * c.data("index")) + "%"
                }), b.find(">.name").css({
                    right: 100 * c.data("index") + "%"
                })) : (b.css({
                    left: -(100 * c.data("index")) + "%"
                }), b.find(">.name").css({
                    left: 100 * c.data("index") + "%"
                }));
                0 === c.data("index") ? c.css("height", "") : c.css("height", g.outerHeight(a, true) + g.settings.$topbar.data("height"));
                setTimeout(function() {
                    d.removeClass("moved")
                }, 300)
            })
        },
        breakpoint: function() {
            return e(q).width() <= this.settings.breakPoint || e("html").hasClass("lt-ie9")
        },
        assemble: function() {
            var g = this;
            this.settings.$section.detach();
            this.settings.$section.find(".has-dropdown>a").each(function() {
                var c = e(this),
                    a = c.siblings(".dropdown"),
                    b = c.attr("href");
                b = g.settings.mobile_show_parent_link && b && 1 < b.length ? e('<li class="title back js-generated"><h5><a href="https://static1.freebitco.in/min/combined_bottom1383555676.js#"></a></h5></li><li><a class="parent-link js-generated" href="https://static1.freebitco.in/min/' +
                    b + '">' + c.text() + "</a></li>") : e('<li class="title back js-generated"><h5><a href="https://static1.freebitco.in/min/combined_bottom1383555676.js#"></a></h5></li>');
                true == g.settings.custom_back_text ? b.find("h5>a").html(g.settings.back_text) : b.find("h5>a").html("\u00ab " + c.html());
                a.prepend(b)
            });
            this.settings.$section.appendTo(this.settings.$topbar);
            this.sticky()
        },
        height: function(g) {
            var c = 0,
                a = this;
            g.find("> li").each(function() {
                c += a.outerHeight(e(this), true)
            });
            return c
        },
        sticky: function() {
            var g = this;
            e(p).scroll(function() {
                g.updateStickyPositioning()
            })
        },
        updateStickyPositioning: function() {
            var g = "." + this.settings.stickyClass,
                c = e(p);
            if (0 < e(g).length) {
                var a = this.settings.$topbar.data("stickyoffset");
                e(g).hasClass("expanded") || (c.scrollTop() > a ? e(g).hasClass("fixed") || (e(g).addClass("fixed"), e("body").addClass("f-topbar-fixed")) : c.scrollTop() <= a && e(g).hasClass("fixed") && (e(g).removeClass("fixed"), e("body").removeClass("f-topbar-fixed")))
            }
        },
        off: function() {
            e(this.scope).off(".fndtn.topbar");
            e(p).off(".fndtn.topbar")
        },
        reflow: function() {}
    }
})(Foundation.zj, this, this.document);
(function(e, p, q) {
    Foundation.libs.interchange = {
        name: "interchange",
        version: "4.2.4",
        cache: {},
        images_loaded: false,
        settings: {
            load_attr: "interchange",
            named_queries: {
                "default": "only screen and (min-width: 1px)",
                small: "only screen and (min-width: 768px)",
                medium: "only screen and (min-width: 1280px)",
                large: "only screen and (min-width: 1440px)",
                landscape: "only screen and (orientation: landscape)",
                portrait: "only screen and (orientation: portrait)",
                retina: "only screen and (-webkit-min-device-pixel-ratio: 2),only screen and (min--moz-device-pixel-ratio: 2),only screen and (-o-min-device-pixel-ratio: 2/1),only screen and (min-device-pixel-ratio: 2),only screen and (min-resolution: 192dpi),only screen and (min-resolution: 2dppx)"
            },
            directives: {
                replace: function(g, c) {
                    if (/IMG/.test(g[0].nodeName)) {
                        var a = g[0].src;
                        if (!RegExp(c, "i").test(a)) return g[0].src = c, g.trigger("replace", [g[0].src, a])
                    }
                }
            }
        },
        init: function(g, c, a) {
            Foundation.inherit(this, "throttle");
            "object" === typeof c && e.extend(true, this.settings, c);
            this.events();
            this.images();
            return "string" !== typeof c ? this.settings.init : this[c].call(this, a)
        },
        events: function() {
            var g = this;
            e(p).on("resize.fndtn.interchange", g.throttle(function() {
                g.resize.call(g)
            }, 50))
        },
        resize: function() {
            var g = this.cache;
            if (this.images_loaded)
                for (var c in g) {
                    if (g.hasOwnProperty(c)) {
                        var a = this.results(c, g[c]);
                        if (a) this.settings.directives[a.scenario[1]](a.el, a.scenario[0])
                    }
                } else setTimeout(e.proxy(this.resize, this), 50)
        },
        results: function(g, c) {
            var a = c.length;
            if (0 < a) {
                var b = e('[data-uuid="' + g + '"]');
                for (a -= 1; 0 <= a; a--) {
                    var d = c[a][2];
                    if ((this.settings.named_queries.hasOwnProperty(d) ? matchMedia(this.settings.named_queries[d]) : matchMedia(d)).matches) return {
                        el: b,
                        scenario: c[a]
                    }
                }
            }
            return false
        },
        images: function(g) {
            return "undefined" === typeof this.cached_images || g ? this.update_images() : this.cached_images
        },
        update_images: function() {
            var g = q.getElementsByTagName("img"),
                c = g.length,
                a = 0,
                b = "data-" + this.settings.load_attr;
            this.cached_images = [];
            this.images_loaded = false;
            for (var d = c - 1; 0 <= d; d--) this.loaded(e(g[d]), function(l) {
                a++;
                l && 0 < (l.getAttribute(b) || "").length && this.cached_images.push(l);
                a === c && (this.images_loaded = true, this.enhance())
            }.bind(this));
            return "deferred"
        },
        loaded: function(g, c) {
            function a() {
                c(g[0])
            }

            function b() {
                this.one("load", a);
                if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) {
                    var d = this.attr("src"),
                        l = d.match(/\?/) ? "&" : "?";
                    l += "random=" + (new Date).getTime();
                    this.attr("src", d + l)
                }
            }
            g.attr("src") ? g[0].complete || 4 === g[0].readyState ? a() : b.call(g) : a()
        },
        enhance: function() {
            for (var g = this.images().length - 1; 0 <= g; g--) this._object(e(this.images()[g]));
            return e(p).trigger("resize")
        },
        parse_params: function(g, c, a) {
            return [this.trim(g), this.convert_directive(c), this.trim(a)]
        },
        convert_directive: function(g) {
            g = this.trim(g);
            return 0 < g.length ? g : "replace"
        },
        _object: function(g) {
            var c = this.parse_data_attr(g),
                a = [],
                b = c.length;
            if (0 < b)
                for (b -= 1; 0 <= b; b--) {
                    var d = c[b].split(/\((.*?)(\))$/);
                    if (1 < d.length) {
                        var l = d[0].split(",");
                        d = this.parse_params(l[0], l[1], d[1]);
                        a.push(d)
                    }
                }
            return this.store(g, a)
        },
        uuid: function(g) {
            function c() {
                return (65536 * (1 + Math.random()) | 0).toString(16).substring(1)
            }
            g = g || "-";
            return c() + c() + g + c() + g + c() + g + c() + g + c() + c() + c()
        },
        store: function(g, c) {
            var a = this.uuid(),
                b = g.data("uuid");
            if (b) return this.cache[b];
            g.attr("data-uuid", a);
            return this.cache[a] = c
        },
        trim: function(g) {
            return "string" === typeof g ? e.trim(g) : g
        },
        parse_data_attr: function(g) {
            g = g.data(this.settings.load_attr).split(/\[(.*?)\]/);
            for (var c = [], a = g.length - 1; 0 <= a; a--) 4 < g[a].replace(/[\W\d]+/, "").length && c.push(g[a]);
            return c
        },
        reflow: function() {
            this.images(true)
        }
    }
})(Foundation.zj, this, this.document);
(function(e) {
    e.Placeholders = {
        Utils: {
            addEventListener: function(p, q, g) {
                if (p.addEventListener) return p.addEventListener(q, g, false);
                if (p.attachEvent) return p.attachEvent("on" + q, g)
            },
            inArray: function(p, q) {
                var g, c;
                g = 0;
                for (c = p.length; g < c; g++)
                    if (p[g] === q) return true;
                return false
            },
            moveCaret: function(p, q) {
                var g;
                p.createTextRange ? (g = p.createTextRange(), g.move("character", q), g.select()) : p.selectionStart && (p.focus(), p.setSelectionRange(q, q))
            },
            changeType: function(p, q) {
                try {
                    return p.type = q, true
                } catch (g) {
                    return false
                }
            }
        }
    }
})(this);
(function(e) {
    function p() {}

    function q(y) {
        var P;
        if (y.value === y.getAttribute(B) && "true" === y.getAttribute(z)) {
            y.setAttribute(z, "false");
            y.value = "";
            y.className = y.className.replace(r, "");
            if (P = y.getAttribute(L)) y.type = P;
            return true
        }
        return false
    }

    function g(y) {
        var P;
        P = y.getAttribute(B);
        return "" === y.value && P ? (y.setAttribute(z, "true"), y.value = P, y.className += " " + o, y.getAttribute(L) ? y.type = "text" : "password" === y.type && I.changeType(y, "text") && y.setAttribute(L, "password"), true) : false
    }

    function c(y, P) {
        var X, O, ba, aa, W;
        if (y && y.getAttribute(B)) P(y);
        else {
            X = y ? y.getElementsByTagName("input") : t;
            O = y ? y.getElementsByTagName("textarea") : s;
            W = 0;
            for (aa = X.length + O.length; W < aa; W++) {
                ba = W < X.length ? X[W] : O[W - X.length];
                P(ba)
            }
        }
    }

    function a(y) {
        c(y, q)
    }

    function b(y) {
        c(y, g)
    }

    function d(y) {
        return function() {
            A && y.value === y.getAttribute(B) && "true" === y.getAttribute(z) ? I.moveCaret(y, 0) : q(y)
        }
    }

    function l(y) {
        return function() {
            g(y)
        }
    }

    function j(y) {
        return function(P) {
            x = y.value;
            if ("true" === y.getAttribute(z) && x === y.getAttribute(B) && I.inArray(n, P.keyCode)) return P.preventDefault && P.preventDefault(), false
        }
    }

    function m(y) {
        return function() {
            var P;
            "true" === y.getAttribute(z) && y.value !== x && (y.className = y.className.replace(r, ""), y.value = y.value.replace(y.getAttribute(B), ""), y.setAttribute(z, false), P = y.getAttribute(L)) && (y.type = P);
            "" === y.value && (y.blur(), I.moveCaret(y, 0))
        }
    }

    function h(y) {
        return function() {
            y === document.activeElement && y.value === y.getAttribute(B) && "true" === y.getAttribute(z) && I.moveCaret(y, 0)
        }
    }

    function k(y) {
        return function() {
            a(y)
        }
    }

    function f(y) {
        y.form && (D = y.form, D.getAttribute(E) || (I.addEventListener(D, "submit", k(D)), D.setAttribute(E, "true")));
        I.addEventListener(y, "focus", d(y));
        I.addEventListener(y, "blur", l(y));
        A && (I.addEventListener(y, "keydown", j(y)), I.addEventListener(y, "keyup", m(y)), I.addEventListener(y, "click", h(y)));
        y.setAttribute(J, "true");
        y.setAttribute(B, u);
        g(y)
    }
    var i = "text search url tel email password number textarea".split(" "),
        n = [27, 33, 34, 35, 36, 37, 38, 39, 40, 8, 46],
        o = "placeholdersjs",
        r = RegExp("(?:^|\\s)" + o + "(?!\\S)"),
        t, s, B = "data-placeholder-value",
        z = "data-placeholder-active",
        L = "data-placeholder-type",
        E = "data-placeholder-submit",
        J = "data-placeholder-bound",
        C = document.createElement("input"),
        H = document.getElementsByTagName("head")[0],
        F = document.documentElement;
    e = e.Placeholders;
    var I = e.Utils,
        A, w, x, u, v, D, M, T, N;
    e.nativeSupport = void 0 !== C.placeholder;
    if (!e.nativeSupport) {
        t = document.getElementsByTagName("input");
        s = document.getElementsByTagName("textarea");
        A = "false" === F.getAttribute("data-placeholder-focus");
        w = "false" !== F.getAttribute("data-placeholder-live");
        C = document.createElement("style");
        C.type = "text/css";
        F = document.createTextNode("." + o + " { color:#ccc; }");
        C.styleSheet ? C.styleSheet.cssText = F.nodeValue : C.appendChild(F);
        H.insertBefore(C, H.firstChild);
        N = 0;
        for (T = t.length + s.length; N < T; N++) {
            M = N < t.length ? t[N] : s[N - t.length];
            (u = M.attributes.placeholder) && (u = u.nodeValue) && I.inArray(i, M.type) && f(M)
        }
        v = setInterval(function() {
            N = 0;
            for (T = t.length + s.length; N < T; N++)
                if (M = N < t.length ? t[N] : s[N - t.length], (u = M.attributes.placeholder) && (u = u.nodeValue) && I.inArray(i, M.type) && (M.getAttribute(J) || f(M), u !== M.getAttribute(B) || "password" === M.type && !M.getAttribute(L))) {
                    "password" === M.type && !M.getAttribute(L) && I.changeType(M, "text") && M.setAttribute(L, "password");
                    M.value === M.getAttribute(B) && (M.value = u);
                    M.setAttribute(B, u)
                }
            w || clearInterval(v)
        }, 100)
    }
    e.disable = e.nativeSupport ? p : a;
    e.enable = e.nativeSupport ? p : b
})(this);
(function(e, p, q) {
    Foundation.libs.abide = {
        name: "abide",
        version: "4.3.2",
        settings: {
            live_validate: true,
            focus_on_invalid: true,
            timeout: 1E3,
            patterns: {
                alpha: /[a-zA-Z]+/,
                alpha_numeric: /[a-zA-Z0-9]+/,
                integer: /-?\d+/,
                number: /-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?/,
                password: /(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/,
                card: /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$/,
                cvv: /^([0-9]){3,4}$/,
                email: /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
                url: /(https?|ftp|file|ssh):\/\/(((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-zA-Z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-zA-Z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-zA-Z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-zA-Z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-zA-Z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?/,
                domain: /^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}$/,
                datetime: /([0-2][0-9]{3})\-([0-1][0-9])\-([0-3][0-9])T([0-5][0-9])\:([0-5][0-9])\:([0-5][0-9])(Z|([\-\+]([0-1][0-9])\:00))/,
                date: /(?:19|20)[0-9]{2}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-9])|(?:(?!02)(?:0[1-9]|1[0-2])-(?:30))|(?:(?:0[13578]|1[02])-31))/,
                time: /(0[0-9]|1[0-9]|2[0-3])(:[0-5][0-9]){2}/,
                dateISO: /\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}/,
                month_day_year: /(0[1-9]|1[012])[- \/.](0[1-9]|[12][0-9]|3[01])[- \/.](19|20)\d\d/,
                color: /^#?([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$/
            }
        },
        timer: null,
        init: function(g, c, a) {
            "object" === typeof c && e.extend(true, this.settings, c);
            if ("string" !== typeof c) this.settings.init || this.events();
            else return this[c].call(this, a)
        },
        events: function() {
            var g = this,
                c = e("form[data-abide]", this.scope).attr("novalidate", "novalidate");
            c.on("submit validate", function(a) {
                return g.validate(e(this).find("input, textarea, select").get(), a)
            });
            this.settings.init = true;
            if (this.settings.live_validate) c.find("input, textarea, select").on("blur change", function(a) {
                g.validate([this], a)
            }).on("keydown", function(a) {
                clearTimeout(g.timer);
                g.timer = setTimeout(function() {
                    g.validate([this], a)
                }.bind(this), g.settings.timeout)
            })
        },
        validate: function(g, c) {
            for (var a = this.parse_patterns(g), b = a.length, d = e(g[0]).closest("form"), l = 0; l < b; l++)
                if (!a[l] && /submit/.test(c.type)) return this.settings.focus_on_invalid && g[l].focus(), d.trigger("invalid"), e(g[l]).closest("form").attr("data-invalid", ""), false;
            /submit/.test(c.type) && d.trigger("valid");
            d.removeAttr("data-invalid");
            return true
        },
        parse_patterns: function(g) {
            for (var c = [], a = g.length - 1; 0 <= a; a--) c.push(this.pattern(g[a]));
            return this.check_validation_and_apply_styles(c)
        },
        pattern: function(g) {
            var c = g.getAttribute("type"),
                a = "string" === typeof g.getAttribute("required");
            if (this.settings.patterns.hasOwnProperty(c)) return [g, this.settings.patterns[c], a];
            c = g.getAttribute("pattern") || "";
            if (this.settings.patterns.hasOwnProperty(c) && 0 < c.length) return [g, this.settings.patterns[c], a];
            if (0 < c.length) return [g, RegExp(c), a];
            c = /.*/;
            return [g, c, a]
        },
        check_validation_and_apply_styles: function(g) {
            for (var c = [], a = g.length - 1; 0 <= a; a--) {
                var b = g[a][0],
                    d = g[a][2],
                    l = b.value,
                    j = d ? 0 < b.value.length : true;
                "radio" === b.type && d ? c.push(this.valid_radio(b, d)) : g[a][1].test(l) && j || !d && 1 > b.value.length ? (e(b).removeAttr("data-invalid").parent().removeClass("error"), c.push(true)) : (e(b).attr("data-invalid", "").parent().addClass("error"), c.push(false))
            }
            return c
        },
        valid_radio: function(g) {
            g = g.getAttribute("name");
            g = q.getElementsByName(g);
            for (var c = g.length, a = false, b = 0; b < c; b++) g[b].checked && (a = true);
            for (b = 0; b < c; b++) a ? e(g[b]).removeAttr("data-invalid").parent().removeClass("error") : e(g[b]).attr("data-invalid", "").parent().addClass("error");
            return a
        }
    }
})(Foundation.zj, this, this.document);
(function(e) {
    e.fn.qrcode = function(p) {
        function q(h) {
            this.mode = d;
            this.data = h
        }

        function g(h, k) {
            this.typeNumber = h;
            this.errorCorrectLevel = k;
            this.modules = null;
            this.moduleCount = 0;
            this.dataCache = null;
            this.dataList = []
        }

        function c(h, k) {
            if (void 0 == h.length) throw Error(h.length + "/" + k);
            for (var f = 0; f < h.length && 0 == h[f];) f++;
            this.num = Array(h.length - f + k);
            for (var i = 0; i < h.length - f; i++) this.num[i] = h[i + f]
        }

        function a(h, k) {
            this.totalCount = h;
            this.dataCount = k
        }

        function b() {
            this.buffer = [];
            this.length = 0
        }
        var d;
        q.prototype = {
            getLength: function() {
                return this.data.length
            },
            write: function(h) {
                for (var k = 0; k < this.data.length; k++) h.put(this.data.charCodeAt(k), 8)
            }
        };
        g.prototype = {
            addData: function(h) {
                this.dataList.push(new q(h));
                this.dataCache = null
            },
            isDark: function(h, k) {
                if (0 > h || this.moduleCount <= h || 0 > k || this.moduleCount <= k) throw Error(h + "," + k);
                return this.modules[h][k]
            },
            getModuleCount: function() {
                return this.moduleCount
            },
            make: function() {
                if (1 > this.typeNumber) {
                    var h = 1;
                    for (h = 1; 40 > h; h++) {
                        for (var k = a.getRSBlocks(h, this.errorCorrectLevel), f = new b, i = 0, n = 0; n < k.length; n++) i += k[n].dataCount;
                        for (n = 0; n < this.dataList.length; n++) {
                            k = this.dataList[n];
                            f.put(k.mode, 4);
                            f.put(k.getLength(), l.getLengthInBits(k.mode, h));
                            k.write(f)
                        }
                        if (f.getLengthInBits() <= 8 * i) break
                    }
                    this.typeNumber = h
                }
                this.makeImpl(false, this.getBestMaskPattern())
            },
            makeImpl: function(h, k) {
                this.moduleCount = 4 * this.typeNumber + 17;
                this.modules = Array(this.moduleCount);
                for (var f = 0; f < this.moduleCount; f++) {
                    this.modules[f] = Array(this.moduleCount);
                    for (var i = 0; i < this.moduleCount; i++) this.modules[f][i] = null
                }
                this.setupPositionProbePattern(0, 0);
                this.setupPositionProbePattern(this.moduleCount -
                    7, 0);
                this.setupPositionProbePattern(0, this.moduleCount - 7);
                this.setupPositionAdjustPattern();
                this.setupTimingPattern();
                this.setupTypeInfo(h, k);
                7 <= this.typeNumber && this.setupTypeNumber(h);
                null == this.dataCache && (this.dataCache = g.createData(this.typeNumber, this.errorCorrectLevel, this.dataList));
                this.mapData(this.dataCache, k)
            },
            setupPositionProbePattern: function(h, k) {
                for (var f = -1; 7 >= f; f++)
                    if (!(-1 >= h + f || this.moduleCount <= h + f))
                        for (var i = -1; 7 >= i; i++) - 1 >= k + i || this.moduleCount <= k + i || (this.modules[h + f][k + i] = 0 <= f && 6 >= f && (0 == i || 6 == i) || 0 <= i && 6 >= i && (0 == f || 6 == f) || 2 <= f && 4 >= f && 2 <= i && 4 >= i ? true : false)
            },
            getBestMaskPattern: function() {
                for (var h = 0, k = 0, f = 0; 8 > f; f++) {
                    this.makeImpl(true, f);
                    var i = l.getLostPoint(this);
                    if (0 == f || h > i) {
                        h = i;
                        k = f
                    }
                }
                return k
            },
            createMovieClip: function(h, k, f) {
                h = h.createEmptyMovieClip(k, f);
                this.make();
                for (k = 0; k < this.modules.length; k++) {
                    f = 1 * k;
                    for (var i = 0; i < this.modules[k].length; i++) {
                        var n = 1 * i;
                        this.modules[k][i] && (h.beginFill(0, 100), h.moveTo(n, f), h.lineTo(n + 1, f), h.lineTo(n + 1, f + 1), h.lineTo(n, f + 1), h.endFill())
                    }
                }
                return h
            },
            setupTimingPattern: function() {
                for (var h = 8; h < this.moduleCount - 8; h++) null == this.modules[h][6] && (this.modules[h][6] = 0 == h % 2);
                for (h = 8; h < this.moduleCount - 8; h++) null == this.modules[6][h] && (this.modules[6][h] = 0 == h % 2)
            },
            setupPositionAdjustPattern: function() {
                for (var h = l.getPatternPosition(this.typeNumber), k = 0; k < h.length; k++)
                    for (var f = 0; f < h.length; f++) {
                        var i = h[k],
                            n = h[f];
                        if (null == this.modules[i][n])
                            for (var o = -2; 2 >= o; o++)
                                for (var r = -2; 2 >= r; r++) this.modules[i + o][n + r] = -2 == o || 2 == o || -2 == r || 2 == r || 0 == o && 0 == r ? true : false
                    }
            },
            setupTypeNumber: function(h) {
                for (var k = l.getBCHTypeNumber(this.typeNumber), f = 0; 18 > f; f++) {
                    var i = !h && 1 == (k >> f & 1);
                    this.modules[Math.floor(f / 3)][f % 3 + this.moduleCount - 8 - 3] = i
                }
                for (f = 0; 18 > f; f++) {
                    i = !h && 1 == (k >> f & 1);
                    this.modules[f % 3 + this.moduleCount - 8 - 3][Math.floor(f / 3)] = i
                }
            },
            setupTypeInfo: function(h, k) {
                for (var f = l.getBCHTypeInfo(this.errorCorrectLevel << 3 | k), i = 0; 15 > i; i++) {
                    var n = !h && 1 == (f >> i & 1);
                    6 > i ? this.modules[i][8] = n : 8 > i ? this.modules[i + 1][8] = n : this.modules[this.moduleCount - 15 + i][8] = n
                }
                for (i = 0; 15 > i; i++) {
                    n = !h && 1 == (f >> i & 1);
                    8 > i ? this.modules[8][this.moduleCount - i - 1] = n : 9 > i ? this.modules[8][15 - i - 1 + 1] = n : this.modules[8][15 - i - 1] = n
                }
                this.modules[this.moduleCount - 8][8] = !h
            },
            mapData: function(h, k) {
                for (var f = -1, i = this.moduleCount - 1, n = 7, o = 0, r = this.moduleCount - 1; 0 < r; r -= 2)
                    for (6 == r && r--;;) {
                        for (var t = 0; 2 > t; t++)
                            if (null == this.modules[i][r - t]) {
                                var s = false;
                                o < h.length && (s = 1 == (h[o] >>> n & 1));
                                l.getMask(k, i, r - t) && (s = !s);
                                this.modules[i][r - t] = s;
                                n--; - 1 == n && (o++, n = 7)
                            }
                        i += f;
                        if (0 > i || this.moduleCount <= i) {
                            i -= f;
                            f = -f;
                            break
                        }
                    }
            }
        };
        g.PAD0 = 236;
        g.PAD1 = 17;
        g.createData = function(h, k, f) {
            k = a.getRSBlocks(h, k);
            for (var i = new b, n = 0; n < f.length; n++) {
                var o = f[n];
                i.put(o.mode, 4);
                i.put(o.getLength(), l.getLengthInBits(o.mode, h));
                o.write(i)
            }
            for (n = h = 0; n < k.length; n++) h += k[n].dataCount;
            if (i.getLengthInBits() > 8 * h) throw Error("code length overflow. (" + i.getLengthInBits() + ">" + 8 * h + ")");
            for (i.getLengthInBits() + 4 <= 8 * h && i.put(0, 4); 0 != i.getLengthInBits() % 8;) i.putBit(false);
            for (; !(i.getLengthInBits() >= 8 * h);) {
                i.put(g.PAD0, 8);
                if (i.getLengthInBits() >= 8 * h) break;
                i.put(g.PAD1, 8)
            }
            return g.createBytes(i, k)
        };
        g.createBytes = function(h, k) {
            for (var f = 0, i = 0, n = 0, o = Array(k.length), r = Array(k.length), t = 0; t < k.length; t++) {
                var s = k[t].dataCount,
                    B = k[t].totalCount - s;
                i = Math.max(i, s);
                n = Math.max(n, B);
                o[t] = Array(s);
                for (var z = 0; z < o[t].length; z++) o[t][z] = 255 & h.buffer[z + f];
                f += s;
                z = l.getErrorCorrectPolynomial(B);
                s = (new c(o[t], z.getLength() - 1)).mod(z);
                r[t] = Array(z.getLength() - 1);
                for (z = 0; z < r[t].length; z++) {
                    B = z + s.getLength() - r[t].length;
                    r[t][z] = 0 <= B ? s.get(B) : 0
                }
            }
            for (z = t = 0; z < k.length; z++) t += k[z].totalCount;
            f = Array(t);
            for (z = s = 0; z < i; z++)
                for (t = 0; t < k.length; t++) z < o[t].length && (f[s++] = o[t][z]);
            for (z = 0; z < n; z++)
                for (t = 0; t < k.length; t++) z < r[t].length && (f[s++] = r[t][z]);
            return f
        };
        d = 4;
        for (var l = {
                PATTERN_POSITION_TABLE: [
                    [],
                    [6, 18],
                    [6, 22],
                    [6, 26],
                    [6, 30],
                    [6, 34],
                    [6, 22, 38],
                    [6, 24, 42],
                    [6, 26, 46],
                    [6, 28, 50],
                    [6, 30, 54],
                    [6, 32, 58],
                    [6, 34, 62],
                    [6, 26, 46, 66],
                    [6, 26, 48, 70],
                    [6, 26, 50, 74],
                    [6, 30, 54, 78],
                    [6, 30, 56, 82],
                    [6, 30, 58, 86],
                    [6, 34, 62, 90],
                    [6, 28, 50, 72, 94],
                    [6, 26, 50, 74, 98],
                    [6, 30, 54, 78, 102],
                    [6, 28, 54, 80, 106],
                    [6, 32, 58, 84, 110],
                    [6, 30, 58, 86, 114],
                    [6, 34, 62, 90, 118],
                    [6, 26, 50, 74, 98, 122],
                    [6, 30, 54, 78, 102, 126],
                    [6, 26, 52, 78, 104, 130],
                    [6, 30, 56, 82, 108, 134],
                    [6, 34, 60, 86, 112, 138],
                    [6, 30, 58, 86, 114, 142],
                    [6, 34, 62, 90, 118, 146],
                    [6, 30, 54, 78, 102, 126, 150],
                    [6, 24, 50, 76, 102, 128, 154],
                    [6, 28, 54, 80, 106, 132, 158],
                    [6, 32, 58, 84, 110, 136, 162],
                    [6, 26, 54, 82, 110, 138, 166],
                    [6, 30, 58, 86, 114, 142, 170]
                ],
                G15: 1335,
                G18: 7973,
                G15_MASK: 21522,
                getBCHTypeInfo: function(h) {
                    for (var k = h << 10; 0 <= l.getBCHDigit(k) - l.getBCHDigit(l.G15);) k ^= l.G15 << l.getBCHDigit(k) - l.getBCHDigit(l.G15);
                    return (h << 10 | k) ^ l.G15_MASK
                },
                getBCHTypeNumber: function(h) {
                    for (var k = h << 12; 0 <= l.getBCHDigit(k) - l.getBCHDigit(l.G18);) k ^= l.G18 << l.getBCHDigit(k) - l.getBCHDigit(l.G18);
                    return h << 12 | k
                },
                getBCHDigit: function(h) {
                    for (var k = 0; 0 != h;) {
                        k++;
                        h >>>= 1
                    }
                    return k
                },
                getPatternPosition: function(h) {
                    return l.PATTERN_POSITION_TABLE[h - 1]
                },
                getMask: function(h, k, f) {
                    switch (h) {
                        case 0:
                            return 0 == (k + f) % 2;
                        case 1:
                            return 0 == k % 2;
                        case 2:
                            return 0 == f % 3;
                        case 3:
                            return 0 == (k + f) % 3;
                        case 4:
                            return 0 == (Math.floor(k / 2) + Math.floor(f / 3)) % 2;
                        case 5:
                            return 0 == k * f % 2 + k * f % 3;
                        case 6:
                            return 0 == (k * f % 2 + k * f % 3) % 2;
                        case 7:
                            return 0 == (k * f % 3 + (k + f) % 2) % 2;
                        default:
                            throw Error("bad maskPattern:" + h);
                    }
                },
                getErrorCorrectPolynomial: function(h) {
                    for (var k = new c([1], 0), f = 0; f < h; f++) k = k.multiply(new c([1, j.gexp(f)], 0));
                    return k
                },
                getLengthInBits: function(h, k) {
                    if (1 <= k && 10 > k) switch (h) {
                        case 1:
                            return 10;
                        case 2:
                            return 9;
                        case d:
                            return 8;
                        case 8:
                            return 8;
                        default:
                            throw Error("mode:" + h);
                    } else if (27 > k) switch (h) {
                        case 1:
                            return 12;
                        case 2:
                            return 11;
                        case d:
                            return 16;
                        case 8:
                            return 10;
                        default:
                            throw Error("mode:" + h);
                    } else if (41 > k) switch (h) {
                        case 1:
                            return 14;
                        case 2:
                            return 13;
                        case d:
                            return 16;
                        case 8:
                            return 12;
                        default:
                            throw Error("mode:" + h);
                    } else throw Error("type:" + k);
                },
                getLostPoint: function(h) {
                    for (var k = h.getModuleCount(), f = 0, i = 0; i < k; i++)
                        for (var n = 0; n < k; n++) {
                            for (var o = 0, r = h.isDark(i, n), t = -1; 1 >= t; t++)
                                if (!(0 > i + t || k <= i + t))
                                    for (var s = -1; 1 >= s; s++) 0 > n + s || k <= n + s || 0 == t && 0 == s || r == h.isDark(i + t, n + s) && o++;
                            5 < o && (f += 3 + o - 5)
                        }
                    for (i = 0; i < k - 1; i++)
                        for (n = 0; n < k - 1; n++)
                            if (o = 0, h.isDark(i, n) && o++, h.isDark(i + 1, n) && o++, h.isDark(i, n + 1) && o++, h.isDark(i + 1, n + 1) && o++, 0 == o || 4 == o) f += 3;
                    for (i = 0; i < k; i++)
                        for (n = 0; n < k - 6; n++) h.isDark(i, n) && !h.isDark(i, n + 1) && h.isDark(i, n + 2) && h.isDark(i, n + 3) && h.isDark(i, n + 4) && !h.isDark(i, n + 5) && h.isDark(i, n + 6) && (f += 40);
                    for (n = 0; n < k; n++)
                        for (i = 0; i < k - 6; i++) h.isDark(i, n) && !h.isDark(i + 1, n) && h.isDark(i + 2, n) && h.isDark(i + 3, n) && h.isDark(i + 4, n) && !h.isDark(i + 5, n) && h.isDark(i + 6, n) && (f += 40);
                    for (n = o = 0; n < k; n++)
                        for (i = 0; i < k; i++) h.isDark(i, n) && o++;
                    h = Math.abs(100 * o / k / k - 50) / 5;
                    return f + 10 * h
                }
            }, j = {
                glog: function(h) {
                    if (1 > h) throw Error("glog(" + h + ")");
                    return j.LOG_TABLE[h]
                },
                gexp: function(h) {
                    for (; 0 > h;) h += 255;
                    for (; 256 <= h;) h -= 255;
                    return j.EXP_TABLE[h]
                },
                EXP_TABLE: Array(256),
                LOG_TABLE: Array(256)
            }, m = 0; 8 > m; m++) j.EXP_TABLE[m] = 1 << m;
        for (m = 8; 256 > m; m++) j.EXP_TABLE[m] = j.EXP_TABLE[m - 4] ^ j.EXP_TABLE[m - 5] ^ j.EXP_TABLE[m - 6] ^ j.EXP_TABLE[m - 8];
        for (m = 0; 255 > m; m++) j.LOG_TABLE[j.EXP_TABLE[m]] = m;
        c.prototype = {
            get: function(h) {
                return this.num[h]
            },
            getLength: function() {
                return this.num.length
            },
            multiply: function(h) {
                for (var k = Array(this.getLength() + h.getLength() - 1), f = 0; f < this.getLength(); f++)
                    for (var i = 0; i < h.getLength(); i++) k[f + i] ^= j.gexp(j.glog(this.get(f)) + j.glog(h.get(i)));
                return new c(k, 0)
            },
            mod: function(h) {
                if (0 > this.getLength() - h.getLength()) return this;
                for (var k = j.glog(this.get(0)) - j.glog(h.get(0)), f = Array(this.getLength()), i = 0; i < this.getLength(); i++) f[i] = this.get(i);
                for (i = 0; i < h.getLength(); i++) f[i] ^= j.gexp(j.glog(h.get(i)) + k);
                return (new c(f, 0)).mod(h)
            }
        };
        a.RS_BLOCK_TABLE = [
            [1, 26, 19],
            [1, 26, 16],
            [1, 26, 13],
            [1, 26, 9],
            [1, 44, 34],
            [1, 44, 28],
            [1, 44, 22],
            [1, 44, 16],
            [1, 70, 55],
            [1, 70, 44],
            [2, 35, 17],
            [2, 35, 13],
            [1, 100, 80],
            [2, 50, 32],
            [2, 50, 24],
            [4, 25, 9],
            [1, 134, 108],
            [2, 67, 43],
            [2, 33, 15, 2, 34, 16],
            [2, 33, 11, 2, 34, 12],
            [2, 86, 68],
            [4, 43, 27],
            [4, 43, 19],
            [4, 43, 15],
            [2, 98, 78],
            [4, 49, 31],
            [2, 32, 14, 4, 33, 15],
            [4, 39, 13, 1, 40, 14],
            [2, 121, 97],
            [2, 60, 38, 2, 61, 39],
            [4, 40, 18, 2, 41, 19],
            [4, 40, 14, 2, 41, 15],
            [2, 146, 116],
            [3, 58, 36, 2, 59, 37],
            [4, 36, 16, 4, 37, 17],
            [4, 36, 12, 4, 37, 13],
            [2, 86, 68, 2, 87, 69],
            [4, 69, 43, 1, 70, 44],
            [6, 43, 19, 2, 44, 20],
            [6, 43, 15, 2, 44, 16],
            [4, 101, 81],
            [1, 80, 50, 4, 81, 51],
            [4, 50, 22, 4, 51, 23],
            [3, 36, 12, 8, 37, 13],
            [2, 116, 92, 2, 117, 93],
            [6, 58, 36, 2, 59, 37],
            [4, 46, 20, 6, 47, 21],
            [7, 42, 14, 4, 43, 15],
            [4, 133, 107],
            [8, 59, 37, 1, 60, 38],
            [8, 44, 20, 4, 45, 21],
            [12, 33, 11, 4, 34, 12],
            [3, 145, 115, 1, 146, 116],
            [4, 64, 40, 5, 65, 41],
            [11, 36, 16, 5, 37, 17],
            [11, 36, 12, 5, 37, 13],
            [5, 109, 87, 1, 110, 88],
            [5, 65, 41, 5, 66, 42],
            [5, 54, 24, 7, 55, 25],
            [11, 36, 12],
            [5, 122, 98, 1, 123, 99],
            [7, 73, 45, 3, 74, 46],
            [15, 43, 19, 2, 44, 20],
            [3, 45, 15, 13, 46, 16],
            [1, 135, 107, 5, 136, 108],
            [10, 74, 46, 1, 75, 47],
            [1, 50, 22, 15, 51, 23],
            [2, 42, 14, 17, 43, 15],
            [5, 150, 120, 1, 151, 121],
            [9, 69, 43, 4, 70, 44],
            [17, 50, 22, 1, 51, 23],
            [2, 42, 14, 19, 43, 15],
            [3, 141, 113, 4, 142, 114],
            [3, 70, 44, 11, 71, 45],
            [17, 47, 21, 4, 48, 22],
            [9, 39, 13, 16, 40, 14],
            [3, 135, 107, 5, 136, 108],
            [3, 67, 41, 13, 68, 42],
            [15, 54, 24, 5, 55, 25],
            [15, 43, 15, 10, 44, 16],
            [4, 144, 116, 4, 145, 117],
            [17, 68, 42],
            [17, 50, 22, 6, 51, 23],
            [19, 46, 16, 6, 47, 17],
            [2, 139, 111, 7, 140, 112],
            [17, 74, 46],
            [7, 54, 24, 16, 55, 25],
            [34, 37, 13],
            [4, 151, 121, 5, 152, 122],
            [4, 75, 47, 14, 76, 48],
            [11, 54, 24, 14, 55, 25],
            [16, 45, 15, 14, 46, 16],
            [6, 147, 117, 4, 148, 118],
            [6, 73, 45, 14, 74, 46],
            [11, 54, 24, 16, 55, 25],
            [30, 46, 16, 2, 47, 17],
            [8, 132, 106, 4, 133, 107],
            [8, 75, 47, 13, 76, 48],
            [7, 54, 24, 22, 55, 25],
            [22, 45, 15, 13, 46, 16],
            [10, 142, 114, 2, 143, 115],
            [19, 74, 46, 4, 75, 47],
            [28, 50, 22, 6, 51, 23],
            [33, 46, 16, 4, 47, 17],
            [8, 152, 122, 4, 153, 123],
            [22, 73, 45, 3, 74, 46],
            [8, 53, 23, 26, 54, 24],
            [12, 45, 15, 28, 46, 16],
            [3, 147, 117, 10, 148, 118],
            [3, 73, 45, 23, 74, 46],
            [4, 54, 24, 31, 55, 25],
            [11, 45, 15, 31, 46, 16],
            [7, 146, 116, 7, 147, 117],
            [21, 73, 45, 7, 74, 46],
            [1, 53, 23, 37, 54, 24],
            [19, 45, 15, 26, 46, 16],
            [5, 145, 115, 10, 146, 116],
            [19, 75, 47, 10, 76, 48],
            [15, 54, 24, 25, 55, 25],
            [23, 45, 15, 25, 46, 16],
            [13, 145, 115, 3, 146, 116],
            [2, 74, 46, 29, 75, 47],
            [42, 54, 24, 1, 55, 25],
            [23, 45, 15, 28, 46, 16],
            [17, 145, 115],
            [10, 74, 46, 23, 75, 47],
            [10, 54, 24, 35, 55, 25],
            [19, 45, 15, 35, 46, 16],
            [17, 145, 115, 1, 146, 116],
            [14, 74, 46, 21, 75, 47],
            [29, 54, 24, 19, 55, 25],
            [11, 45, 15, 46, 46, 16],
            [13, 145, 115, 6, 146, 116],
            [14, 74, 46, 23, 75, 47],
            [44, 54, 24, 7, 55, 25],
            [59, 46, 16, 1, 47, 17],
            [12, 151, 121, 7, 152, 122],
            [12, 75, 47, 26, 76, 48],
            [39, 54, 24, 14, 55, 25],
            [22, 45, 15, 41, 46, 16],
            [6, 151, 121, 14, 152, 122],
            [6, 75, 47, 34, 76, 48],
            [46, 54, 24, 10, 55, 25],
            [2, 45, 15, 64, 46, 16],
            [17, 152, 122, 4, 153, 123],
            [29, 74, 46, 14, 75, 47],
            [49, 54, 24, 10, 55, 25],
            [24, 45, 15, 46, 46, 16],
            [4, 152, 122, 18, 153, 123],
            [13, 74, 46, 32, 75, 47],
            [48, 54, 24, 14, 55, 25],
            [42, 45, 15, 32, 46, 16],
            [20, 147, 117, 4, 148, 118],
            [40, 75, 47, 7, 76, 48],
            [43, 54, 24, 22, 55, 25],
            [10, 45, 15, 67, 46, 16],
            [19, 148, 118, 6, 149, 119],
            [18, 75, 47, 31, 76, 48],
            [34, 54, 24, 34, 55, 25],
            [20, 45, 15, 61, 46, 16]
        ];
        a.getRSBlocks = function(h, k) {
            var f = a.getRsBlockTable(h, k);
            if (void 0 == f) throw Error("bad rs block @ typeNumber:" + h + "/errorCorrectLevel:" + k);
            for (var i = f.length / 3, n = [], o = 0; o < i; o++)
                for (var r = f[3 * o + 0], t = f[3 * o + 1], s = f[3 * o + 2], B = 0; B < r; B++) n.push(new a(t, s));
            return n
        };
        a.getRsBlockTable = function(h, k) {
            switch (k) {
                case 1:
                    return a.RS_BLOCK_TABLE[4 * (h - 1) + 0];
                case 0:
                    return a.RS_BLOCK_TABLE[4 * (h - 1) + 1];
                case 3:
                    return a.RS_BLOCK_TABLE[4 * (h - 1) + 2];
                case 2:
                    return a.RS_BLOCK_TABLE[4 * (h - 1) + 3]
            }
        };
        b.prototype = {
            get: function(h) {
                return 1 == (this.buffer[Math.floor(h / 8)] >>> 7 - h % 8 & 1)
            },
            put: function(h, k) {
                for (var f = 0; f < k; f++) this.putBit(1 == (h >>> k - f - 1 & 1))
            },
            getLengthInBits: function() {
                return this.length
            },
            putBit: function(h) {
                var k = Math.floor(this.length / 8);
                this.buffer.length <= k && this.buffer.push(0);
                h && (this.buffer[k] |= 128 >>> this.length % 8);
                this.length++
            }
        };
        "string" === typeof p && (p = {
            text: p
        });
        p = e.extend({}, {
            render: "canvas",
            width: 256,
            height: 256,
            typeNumber: -1,
            correctLevel: 2,
            background: "#ffffff",
            foreground: "#000000"
        }, p);
        return this.each(function() {
            var h;
            if ("canvas" == p.render) {
                h = new g(p.typeNumber, p.correctLevel);
                h.addData(p.text);
                h.make();
                var k = document.createElement("canvas");
                k.width = p.width;
                k.height = p.height;
                for (var f = k.getContext("2d"), i = p.width / h.getModuleCount(), n = p.height / h.getModuleCount(), o = 0; o < h.getModuleCount(); o++)
                    for (var r = 0; r < h.getModuleCount(); r++) {
                        f.fillStyle = h.isDark(o, r) ? p.foreground : p.background;
                        f.fillRect(Math.round(r * i), Math.round(o * n), Math.ceil((r + 1) * i) - Math.floor(r * i), Math.ceil((o + 1) * i) - Math.floor(o * i))
                    }
            } else {
                h = new g(p.typeNumber, p.correctLevel);
                h.addData(p.text);
                h.make();
                k = e("<table></table>").css("width", p.width + "px").css("height", p.height + "px").css("border", "0px").css("border-collapse", "collapse").css("background-color", p.background);
                f = p.width / h.getModuleCount();
                i = p.height / h.getModuleCount();
                for (n = 0; n < h.getModuleCount(); n++) {
                    o = e("<tr></tr>").css("height", i + "px").appendTo(k);
                    for (r = 0; r < h.getModuleCount(); r++) e("<td></td>").css("width", f + "px").css("background-color", h.isDark(n, r) ? p.foreground : p.background).appendTo(o)
                }
            }
            jQuery(k).appendTo(this)
        })
    }
})(jQuery);
(function() {
    if (!window.hasCookieConsent) {
        window.hasCookieConsent = true;
        if (!(document.cookie.indexOf("cookieconsent_dismissed") > -1)) {
            "function" != typeof String.prototype.trim && (String.prototype.trim = function() {
                return this.replace(/^\s+|\s+$/g, "")
            });
            var e, p = {
                    isArray: function(a) {
                        return "[object Array]" == Object.prototype.toString.call(a)
                    },
                    isObject: function(a) {
                        return "[object Object]" == Object.prototype.toString.call(a)
                    },
                    each: function(a, b, d, l) {
                        if (p.isObject(a) && !l)
                            for (var j in a) a.hasOwnProperty(j) && b.call(d, a[j], j, a);
                        else {
                            l = 0;
                            for (j = a.length; j > l; l++) b.call(d, a[l], l, a)
                        }
                    },
                    merge: function(a, b) {
                        a && p.each(b, function(d, l) {
                            p.isObject(d) && p.isObject(a[l]) ? p.merge(a[l], d) : a[l] = d
                        })
                    },
                    bind: function(a, b) {
                        return function() {
                            return a.apply(b, arguments)
                        }
                    },
                    queryObject: function(a, b) {
                        var d, l = 0,
                            j = a;
                        for (b = b.split(".");
                            (d = b[l++]) && j.hasOwnProperty(d) && (j = j[d]);)
                            if (l === b.length) return j;
                        return null
                    },
                    setCookie: function(a, b, d, l, j) {
                        var m = new Date;
                        m.setDate(m.getDate() + (d || 365));
                        a = [a + "=" + b, "expires=" + m.toUTCString(), "path=" + j || "/"];
                        l && a.push("domain=" + l);
                        document.cookie = a.join(";")
                    },
                    addEventListener: function(a, b, d) {
                        a.addEventListener ? a.addEventListener(b, d) : a.attachEvent("on" + b, d)
                    }
                },
                q = function() {
                    var a = function(m, h, k) {
                            return p.isArray(h) ? p.each(h, function(f) {
                                a(m, f, k)
                            }) : void(m.addEventListener ? m.addEventListener(h, k) : m.attachEvent("on" + h, k))
                        },
                        b = function(m, h) {
                            return m.replace(/\{\{(.*?)\}\}/g, function(k, f) {
                                for (var i, n = f.split("||"); i = n.shift();) {
                                    if (i = i.trim(), '"' === i[0]) return i.slice(1, i.length - 1);
                                    if (i = p.queryObject(h, i)) return i
                                }
                                return ""
                            })
                        },
                        d = function(m, h, k) {
                            m = m.parentNode.querySelectorAll("[" + h + "]");
                            p.each(m, function(f) {
                                var i = f.getAttribute(h);
                                k(f, i)
                            }, window, true)
                        },
                        l = function(m, h) {
                            d(m, "data-cc-event", function(k, f) {
                                var i = f.split(":"),
                                    n = p.queryObject(h, i[1]);
                                a(k, i[0], p.bind(n, h))
                            })
                        },
                        j = function(m, h) {
                            d(m, "data-cc-if", function(k, f) {
                                p.queryObject(h, f) || k.parentNode.removeChild(k)
                            })
                        };
                    return {
                        build: function(m, h) {
                            p.isArray(m) && (m = m.join(""));
                            m = b(m, h);
                            var k;
                            k = m;
                            var f = document.createElement("div");
                            k = (f.innerHTML = k, f.children[0]);
                            return l(k, h), j(k, h), k
                        }
                    }
                }(),
                g = {
                    options: {
                        message: "This website uses cookies to ensure you get the best experience on our website. ",
                        dismiss: "Got it!",
                        learnMore: "More info",
                        link: null,
                        target: "_self",
                        container: null,
                        theme: "light-floating",
                        domain: null,
                        path: "/",
                        expiryDays: 365,
                        markup: ['<div class="cc_banner-wrapper {{containerClasses}}">', '<div class="cc_banner cc_container cc_container--open">', '<a href="#null" data-cc-event="click:dismiss" target="_blank" class="cc_btn cc_btn_accept_all">{{options.dismiss}}</a>', '<p class="cc_message">{{options.message}} <a data-cc-if="options.link" target="{{ options.target }}" class="cc_more_info" href="{{options.link || "#null"}}">{{options.learnMore}}</a></p>', '<a class="cc_logo" target="_blank" href="http://silktide.com/cookieconsent">Cookie Consent plugin for the EU cookie law</a>', "</div>", "</div>"]
                    },
                    init: function() {
                        var a = window.cookieconsent_options;
                        a && this.setOptions(a);
                        this.setContainer();
                        this.options.theme ? this.loadTheme(this.render) : this.render()
                    },
                    setOptionsOnTheFly: function(a) {
                        this.setOptions(a);
                        this.render()
                    },
                    setOptions: function(a) {
                        p.merge(this.options, a)
                    },
                    setContainer: function() {
                        this.options.container ? this.container = document.querySelector(this.options.container) : this.container = document.body;
                        this.containerClasses = "";
                        navigator.appVersion.indexOf("MSIE 8") > -1 && (this.containerClasses += " cc_ie8")
                    },
                    loadTheme: function(a) {
                        var b = this.options.theme; - 1 === b.indexOf(".css") && (b = "//cdnjs.cloudflare.com/ajax/libs/cookieconsent2/1.0.9/" + b + ".css");
                        var d = document.createElement("link");
                        d.rel = "stylesheet";
                        d.type = "text/css";
                        d.href = b;
                        var l = false;
                        d.onload = p.bind(function() {
                            !l && a && (a.call(this), l = true)
                        }, this);
                        document.getElementsByTagName("head")[0].appendChild(d)
                    },
                    render: function() {
                        this.element && this.element.parentNode && (this.element.parentNode.removeChild(this.element), delete this.element);
                        this.element = q.build(this.options.markup, this);
                        this.container.firstChild ? this.container.insertBefore(this.element, this.container.firstChild) : this.container.appendChild(this.element)
                    },
                    dismiss: function(a) {
                        a.preventDefault && a.preventDefault();
                        a.returnValue = false;
                        this.setDismissedCookie();
                        this.container.removeChild(this.element)
                    },
                    setDismissedCookie: function() {
                        p.setCookie("cookieconsent_dismissed", "yes", this.options.expiryDays, this.options.domain, this.options.path)
                    }
                },
                c = false;
            (e = function() {
                c || "complete" != document.readyState || (g.init(), c = true, window.update_cookieconsent_options = p.bind(g.setOptionsOnTheFly, g))
            })();
            p.addEventListener(document, "readystatechange", e)
        }
    }
})();