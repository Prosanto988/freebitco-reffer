importScripts('https://pushpad.xyz/service-worker.js');
self.addEventListener('fetch', function(event) {});