var gvjs_vN = ".enableInteractivity",
    gvjs_wN = "percentage",
    gvjs_xN = "pieSliceBorderColor",
    gvjs_yN = "pieSliceText",
    gvjs_zN = "value-and-percentage";

function gvjs_Fia(a, b, c) {
    var d = b.ca,
        e = {
            entries: []
        };
    gvjs_v(c, function(f) {
        f = d.series[f];
        var g = f.hc;
        g.sk ? gvjs_dI(a, e, g.sk, g.content, !0, a.showColorCode, f, !0) : gvjs_dI(a, e, null, g.content, !1, a.showColorCode, f)
    });
    a.kr(e, b.Rh);
    return e
}

function gvjs_Gia(a, b) {
    return Math.abs(a - b)
}

function gvjs_AN(a, b, c) {
    if (!a || !b) return !0;
    c = c || gvjs_Gia;
    return Object.entries(a).every(function(d) {
        var e = gvjs_q(d);
        d = e.next().value;
        e = e.next().value;
        var f = b[d];
        return void 0 === b[d] || .05 >= c(e, f)
    })
}

function gvjs_BN(a, b, c, d) {
    for (var e = {}, f = gvjs_q(Object.entries(a)), g = f.next(); !g.done; g = f.next()) {
        var h = gvjs_q(g.value);
        g = h.next().value;
        h = h.next().value;
        for (var k = 0; k < b.length; k++) {
            var l = (0, b[k])(a, g, d);
            h = c(h, l)
        }
        e[g] = h
    }
    return e
}

function gvjs_Hia(a, b, c, d) {
    for (var e = 1, f = 0; 1E3 > f; f++) {
        var g = gvjs_BN(a, b, c, e),
            h = gvjs_BN(a, b, c, 0),
            k = gvjs_AN(a, g, d);
        h = gvjs_AN(a, h, d);
        if (k && h) break;
        a = g;
        e *= .99
    }
    return a
}
var gvjs_Iia = {
        NONE: gvjs_e,
        yoa: gvjs_qd,
        E_: gvjs_o,
        paa: gvjs_wN,
        Cpa: gvjs_zN
    },
    gvjs_CN = {
        NONE: gvjs_e,
        VG: gvjs_Sr,
        E_: gvjs_o,
        paa: gvjs_wN
    };

function gvjs_DN(a) {
    return new gvjs_Ij(Math.round(a.x), Math.round(a.y))
}

function gvjs_Jia(a) {
    return Array.prototype.reduce.call(arguments, gvjs_jy, new gvjs_Ij(0, 0))
}

function gvjs_Kia(a) {
    return Array.prototype.reduce.call(arguments, function(b, c) {
        return new gvjs_B(b.width + c.width, b.height + c.height)
    }, new gvjs_B(0, 0))
}

function gvjs_Lia(a) {
    return new gvjs_Ij(a[0], a[1])
}

function gvjs_EN(a, b) {
    return [
        [a.x - b.width / 2, a.y - b.height / 2],
        [a.x + b.width / 2, a.y - b.height / 2],
        [a.x + b.width / 2, a.y + b.height / 2],
        [a.x - b.width / 2, a.y + b.height / 2]
    ].map(gvjs_Lia)
}

function gvjs_Mia(a, b, c, d, e) {
    var f = d.map(function(k) {
            return {
                anchor: k.mt,
                top: k.mt - (k.oB * b + k.tH),
                bottom: k.mt + (k.MB * c + k.LH)
            }
        }),
        g = [];
    g.push(function(k, l) {
        var m = k[l].top;
        if (0 == l) return {
            top: Math.max(a.top - m, 0)
        };
        l = gvjs_Kx(l) - 1;
        return {
            top: Math.max(k[l].bottom - m, 0) / 2
        }
    });
    g.push(function(k, l) {
        var m = k[l].bottom;
        if (l == d.length - 1) return {
            bottom: Math.min(a.bottom - m, 0)
        };
        l = gvjs_Kx(l) + 1;
        return {
            bottom: Math.min(k[l].top - m, 0) / 2
        }
    });
    g.push(function(k, l, m) {
        k = k[l].anchor - k[l].top;
        var n = Math;
        l = d[l];
        m = (Math.max(-k, 0) + n.max.call(n,
            l.oB * b + l.tH - Math.max(k, 0), 0) * (e ? 1 : m)) / 2;
        return {
            anchor: m,
            top: -m
        }
    });
    g.push(function(k, l, m) {
        k = k[l].bottom - k[l].anchor;
        var n = Math;
        l = d[l];
        m = (Math.max(-k, 0) + n.max.call(n, l.MB * c + l.LH - Math.max(k, 0), 0) * (e ? 1 : m)) / 2;
        return {
            anchor: -m,
            bottom: m
        }
    });
    g.push(function(k, l) {
        k = k[l].anchor;
        l = d[l];
        return {
            anchor: gvjs_7h(k, l.S_.start, l.S_.end) - k
        }
    });
    e && g.push(function(k, l, m) {
        return {
            anchor: (d[l].TU - k[l].anchor) * m
        }
    });
    var h = gvjs_Hia(f, g, function(k, l) {
        return {
            anchor: k.anchor + (l.anchor || 0),
            top: k.top + (l.top || 0),
            bottom: k.bottom + (l.bottom ||
                0)
        }
    }, function(k, l) {
        return Math.max(Math.abs(k.anchor - l.anchor), Math.abs(k.top - l.top), Math.abs(k.bottom - l.bottom))
    });
    return d.map(function(k, l) {
        k = h[String(l)];
        return {
            anchor: k.anchor,
            top: k.top,
            bottom: k.bottom
        }
    })
}

function gvjs_FN(a, b, c, d, e, f) {
    0 < e.length && (e[0].tH = 0, gvjs_nf(e).LH = 0);
    for (var g = 0; g < e.length; g++) {
        var h = e[g],
            k = e[g - 1],
            l = e[g + 1];
        h.S_ = new gvjs_Lk(Math.min(h.TU, k ? d[k.SC].pL.start + 5 : a.top), Math.max(h.TU, l ? d[l.SC].pL.end - 5 : a.bottom))
    }
    a = gvjs_Mia(a, b, c, e, f);
    d = !1;
    f = {};
    for (g = 0; g < e.length; g++) {
        h = e[g];
        k = a[g];
        l = (k.anchor - k.top - h.tH) / b;
        var m = (k.bottom - k.anchor - h.LH) / c;
        l = Math.floor(l + .1);
        m = Math.floor(m + .1);
        var n = l < h.oB || m < h.MB;
        d = d || n;
        f[h.SC] = {
            y: k.anchor,
            oB: l,
            MB: m,
            qG: n
        }
    }
    return {
        layout: f,
        qG: d
    }
}

function gvjs_Nia(a, b, c, d, e, f, g) {
    var h = d.fontSize + f,
        k = e.fontSize + f,
        l = g.map(function(r, t) {
            var u = gvjs_rF(c, r.Tw, d, b, Infinity),
                v = gvjs_rF(c, r.ix, e, b, Infinity);
            return {
                SC: t,
                TU: r.u7,
                mt: r.u7,
                oB: u.lines.length,
                MB: v.lines.length,
                tH: f,
                LH: f
            }
        });
    l.sort(function(r, t) {
        return r.mt - t.mt
    });
    l = gvjs_wf(l);
    l.sort(function(r, t) {
        return g[r.SC].I4 - g[t.SC].I4
    });
    var m = [];
    0 < l.length && m.push(l.pop());
    for (var n = null, p = 0, q; q = gvjs_FN(a, h, k, g, m, !1), !(0 === l.length || q.qG && 15 < p);) q.qG ? (p++, n && gvjs_uf(m, n)) : p = 0, n = l.pop(), m.push(n), m.sort(function(r,
        t) {
        return r.mt - t.mt
    });
    q.qG && n && (gvjs_uf(m, n), q = gvjs_FN(a, h, k, g, m, !1));
    a = gvjs_FN(a, h, k, g, m, !0);
    a.qG || (q = a);
    return q.layout
}

function gvjs_GN(a, b, c, d, e) {
    var f = a.right - a.left,
        g = gvjs_z(d),
        h = gvjs_z(d);
    h.color = "9e9e9e";
    d = d.fontSize / 3.236;
    var k = g.fontSize + d,
        l = h.fontSize + d,
        m = gvjs_Nia(a, f, b, g, h, d, e),
        n = [];
    if (2 == c) {
        c = a.right;
        a = a.left;
        var p = gvjs_Y
    } else c = a.left, a = a.right, p = gvjs_l;
    for (var q = {}, r = 0; r < e.length; q = {
            sw: q.sw,
            FA: q.FA
        }, ++r) {
        var t = e[r],
            u = m[r];
        if (null != u) {
            q.sw = gvjs_rF(b, t.Tw, g, f, u.oB);
            q.FA = gvjs_rF(b, t.ix, h, f, u.MB);
            var v = gvjs_DN(new gvjs_Ij(c, u.y));
            n.push({
                Z8: 2,
                Kl: gvjs_DN(t.d7(gvjs_7h(u.y, t.pL.start, t.pL.end))),
                o1: a,
                PC: v,
                Vla: new gvjs__({
                    fill: "636363",
                    fillOpacity: .7
                }),
                Lb: new gvjs__({
                    stroke: "636363",
                    strokeWidth: 1,
                    strokeOpacity: .7
                }),
                yta: d,
                Tw: {
                    text: t.Tw,
                    textStyle: g,
                    anchor: new gvjs_vF(v.x, v.y),
                    lines: q.sw.lines.map(function(w) {
                        return function(x, y) {
                            return {
                                x: 0,
                                y: (y - w.sw.lines.length) * k,
                                length: w.sw.Bp,
                                text: x
                            }
                        }
                    }(q)),
                    Yb: p,
                    Mb: gvjs_l,
                    tooltip: q.sw.tc ? t.Tw : "",
                    angle: 0
                },
                Qpa: g,
                ix: {
                    text: t.ix,
                    textStyle: h,
                    anchor: new gvjs_vF(v.x, v.y),
                    lines: q.FA.lines.map(function(w) {
                        return function(x, y) {
                            return {
                                x: 0,
                                y: (y + 1) * l,
                                length: w.FA.Bp,
                                text: x
                            }
                        }
                    }(q)),
                    Yb: p,
                    Mb: gvjs_Y,
                    tooltip: q.FA.tc ?
                        t.ix : "",
                    angle: 0
                },
                rqa: h,
                alignment: p,
                index: t.index
            })
        }
    }
    return n
}

function gvjs_Oia(a, b) {
    a = a.findIndex(function(d) {
        return d.index == b
    });
    if (0 > a) return {};
    var c = {};
    c[a] = {
        Z8: 4,
        Lb: new gvjs__({
            stroke: "636363",
            strokeWidth: 2,
            strokeOpacity: .7
        })
    };
    return c
}

function gvjs_HN(a, b) {
    gvjs_zF.call(this, a, b);
    this.zK = this.Nj = null
}
gvjs_r(gvjs_HN, gvjs_zF);
gvjs_ = gvjs_HN.prototype;
gvjs_.d2 = function(a, b) {
    var c = this.renderer;
    if (1 > a.series.length) return !1;
    this.Nj = b;
    b = a.pie.cc;
    for (var d = a.series.length / b.length, e = 0; e < b.length; ++e) {
        for (var f = b[e].radiusX, g = b[e].radiusY, h = b[e].rL, k = e * d, l = k + d; k < l && 180 > a.series[k].fc;) gvjs_IN(this, a.series[k], f, g), k += 1;
        h && gvjs_IN(this, h, f, g);
        for (h = l - 1; h >= k; --h) gvjs_IN(this, a.series[h], f, g)
    }
    a.Vm && (this.zK = c.ta(), gvjs_JN(this, a.Vm), c.appendChild(this.Nj, this.zK));
    return !0
};
gvjs_.VQ = function(a, b) {
    if (this.ca.eX) {
        var c = a.square.coordinates.height,
            d = a.square.coordinates.left + a.square.coordinates.width / 2,
            e = a.square.coordinates.top + c / 2;
        a = a.square.brush.clone();
        a.Qd(1);
        gvjs_DF(this, d, e, c / 2, a, {
            type: gvjs_es
        }, b)
    } else gvjs_zF.prototype.VQ.call(this, a, b)
};

function gvjs_IN(a, b, c, d) {
    if (b.isVisible) {
        var e = a.renderer.ta(),
            f = a.ca,
            g = f.pie.center,
            h = b.offset;
        if (b.kb) {
            var k = f.pie.yz;
            var l = b.kb,
                m = new gvjs_uz;
            m.move(h.x + l.Kd.x, h.y + l.Kd.y);
            m.na(h.x + l.Kd.x, h.y + l.Kd.y + k);
            m.ke(h.x + g.x, h.y + g.y + k, c, d, l.Bc, l.fc, !0);
            m.na(h.x + l.dg.x, h.y + l.dg.y);
            m.ke(h.x + g.x, h.y + g.y, c, d, l.fc, l.Bc, !1);
            a.renderer.Ba(m, l.brush, e)
        }
        if (b.gr || b.Wt) k = f.pie.yz, l = new gvjs_uz, l.move(h.x + g.x, h.y + g.y), l.na(h.x + g.x, h.y + g.y + k), b.Wt && (l.na(h.x + b.dg.x, h.y + b.dg.y + k), l.na(h.x + b.dg.x, h.y + b.dg.y)), b.gr && (l.na(h.x +
            b.Kd.x, h.y + b.Kd.y + k), l.na(h.x + b.Kd.x, h.y + b.Kd.y)), a.renderer.Ba(l, b.jK, e);
        l = b.brush;
        b.sp ? 0 == b.PD && 0 == b.Iy ? a.renderer.No(g.x, g.y, c, d, l, e) : (m = new gvjs_uz, m.move(g.x, g.y - d), m.ke(g.x, g.y, c, d, 0, 180, !0), m.ke(g.x, g.y, c, d, 180, 360, !0), m.move(g.x, g.y - b.Iy), m.ke(g.x, g.y, b.PD, b.Iy, 360, 180, !1), m.ke(g.x, g.y, b.PD, b.Iy, 180, 0, !1), m.close(), a.renderer.Ba(m, l, e)) : (m = new gvjs_uz, m.move(h.x + b.Hy.x, h.y + b.Hy.y), m.na(h.x + b.Kd.x, h.y + b.Kd.y), m.ke(h.x + g.x, h.y + g.y, c, d, b.Bc, b.fc, !0), m.na(h.x + b.Jr.x, h.y + b.Jr.y), m.ke(h.x + g.x, h.y +
            g.y, b.PD, b.Iy, b.fc, b.Bc, !1), a.renderer.Ba(m, l, e));
        b.Fh && f.B8 && gvjs_KN(a, b.Fh, e);
        if (c = b.Mm) {
            c.kb && (d = new gvjs_uz, d.move(c.kb.Kd.x, c.kb.Kd.y), d.na(c.kb.Kd.x, c.kb.Kd.y + k), d.ke(c.kb.cg.x, c.kb.cg.y + k, c.kb.radiusX, c.kb.radiusY, c.kb.Bc, c.kb.fc, !0), d.na(c.kb.dg.x, c.kb.dg.y), d.ke(c.kb.cg.x, c.kb.cg.y, c.kb.radiusX, c.kb.radiusY, c.kb.fc, c.kb.Bc, !1), a.renderer.Ba(d, c.kb.brush, e));
            if (c.gr || c.Wt) d = new gvjs_uz, d.move(c.Gy.x, c.Gy.y), d.na(c.kK.x, c.kK.y), d.na(c.kK.x, c.kK.y + k), d.na(c.Gy.x, c.Gy.y + k), d.na(c.Gy.x, c.Gy.y),
                a.renderer.Ba(d, c.jK, e);
            gvjs_KN(a, c, e)
        }
        b.WS && a.renderer.Oc(b.text, b.AW.x + h.x, b.AW.y + h.y, b.mN.width, gvjs_l, gvjs_l, b.textStyle, e);
        h = gvjs_rD([gvjs_Ap, b.index]);
        e = e.j();
        a.Ed(a.Nj, h, e);
        b.tooltip && (e = gvjs_rD([gvjs_de, b.index]), a.VE(b.tooltip, e))
    }
}

function gvjs_KN(a, b, c) {
    if (b.sp) a.renderer.No(b.cg.x, b.cg.y, b.radiusX, b.radiusY, b.brush, c);
    else {
        var d = new gvjs_uz;
        d.move(b.Kd.x, b.Kd.y);
        d.ke(b.cg.x, b.cg.y, b.radiusX, b.radiusY, b.Bc, b.fc, !0);
        a.renderer.Ba(d, b.brush, c)
    }
}

function gvjs_JN(a, b) {
    var c = a.jr.bind(a),
        d = a.registerElement.bind(a),
        e = a.renderer;
    a = a.zK;
    for (var f = 0; f < b.length; ++f) {
        var g = b[f],
            h = e.ta(),
            k = e.ta(),
            l = new gvjs_uz;
        l.move(g.Kl.x + .5, g.Kl.y + .5);
        l.na(g.o1 + .5, g.Kl.y + .5);
        l.na(g.o1 + .5, g.PC.y + .5);
        l.na(g.PC.x + .5, g.PC.y + .5);
        e.Ba(l, g.Lb, k);
        e.ei(g.Kl.x + .5, g.Kl.y + .5, g.Z8, g.Vla, k);
        c(g.Tw, h);
        c(g.ix, h);
        e.appendChild(a, h);
        e.appendChild(a, k);
        g = gvjs_rD([gvjs_5t, g.index]);
        d(h.j(), g)
    }
}
gvjs_.G7 = function(a, b) {
    if (!gvjs_ox(b.Vm, this.Po.Vm)) {
        this.renderer.xb(this.zK);
        var c = new gvjs_tD(2);
        c.ed(0, a.Vm || {});
        c.ed(1, b.Vm || {});
        c = c.compact();
        gvjs_JN(this, c)
    }
    this.bM(a);
    this.XO(a, b)
};
gvjs_.bM = function(a) {
    var b = this.Po;
    if (b)
        for (var c in b.series) {
            var d = Number(c);
            if (b.series[d].tooltip) {
                var e = gvjs_rD([gvjs_de, Number(d)]);
                gvjs_FF(this, e)
            }
            e = a.pie.cc[d < a.series.length / a.pie.cc.length ? 0 : 1];
            gvjs_IN(this, a.series[d], e.radiusX, e.radiusY)
        }
};
gvjs_.XO = function(a, b) {
    for (var c in b.series) {
        var d = Number(c),
            e = a.series[d],
            f = new gvjs_tD(2);
        f.ed(0, e);
        f.ed(1, b.series[d]);
        e = a.pie.cc[d < a.series.length / a.pie.cc.length ? 0 : 1];
        d = e.radiusX;
        e = e.radiusY;
        gvjs_IN(this, f.compact(), d, e)
    }
};

function gvjs_LN(a, b) {
    switch (b) {
        case gvjs_wN:
            return a.xz;
        case gvjs_o:
            return a.qe;
        case gvjs_Sr:
            return a.qe + " (" + a.xz + ")"
    }
    return ""
}

function gvjs_MN(a, b, c, d, e) {
    gvjs_5G.call(this, a, b, c, d, e);
    this.wc = b.R(gvjs_ls, gvjs_IE);
    this.V8 = gvjs_E(b, "pieStartAngle", 0);
    this.Gka = 0 > gvjs_E(b, gvjs_Cs, 1);
    this.Fka = gvjs_D(b, gvjs_6u, !1);
    a = b.La("pieSlicePercentFormat");
    gvjs_wx(a) && (a = {
        pattern: "#.#%"
    });
    this.Vja = new gvjs_Aj(a);
    b = b.La("pieSliceValueFormat");
    gvjs_wx(b) && (b = {
        pattern: gvjs_3b
    });
    this.T9 = new gvjs_Aj(b)
}
gvjs_r(gvjs_MN, gvjs_5G);
gvjs_MN.prototype.Cu = function() {
    var a = this;
    return [function() {
        a.L.focusTarget = new Set([gvjs_iv]);
        a.L.Xb = gvjs_D(a.options, "isDiff");
        var b;
        (b = a.L).is3D && (b.is3D = !a.L.Xb);
        a.L.Xb && (b = a.L.Uk || {}, a.L.Uk = b, b.pie = {
            i5: a.options.R("diff.oldData.inCenter", !0),
            ES: a.options.R("diff.innerCircle.radiusFactor", .6)
        });
        for (b = 0; b < a.Ia.getNumberOfRows(); b++) {
            var c = a.Ia.getValue(b, 1);
            if (typeof c === gvjs_f && 0 > c) throw Error("Negative values are invalid for a pie chart.");
        }
    }, gvjs_5G.prototype.Cu.bind(this)]
};
gvjs_MN.prototype.r3 = function() {
    return gvjs_i
};
gvjs_MN.prototype.q3 = function() {
    return null
};
gvjs_MN.prototype.PH = function() {
    var a = this;
    return [function() {
        var b = a.Si();
        if (a.Ia.getColumnType(0) != gvjs_m) throw Error("Pie chart should have a first column of type string");
        var c = a.L,
            d = c.chartArea,
            e = a.Pc.getPosition();
        var f = null;
        var g = Math.round(1.618 * c.rh),
            h = Math.round(d.width * (1 - 1 / 1.618) - g);
        if (e == gvjs_sd) {
            f = new gvjs_H(d.top, d.left + h, d.bottom, d.left);
            var k = new gvjs_H(d.top, d.right, d.bottom, f.right + g)
        } else e == gvjs_i ? (f = new gvjs_H(d.top, d.right, d.bottom, d.right - h), k = new gvjs_H(d.top, f.left - g, d.bottom,
            d.left)) : e == gvjs_Vr ? (k = new gvjs_H(d.top, d.right, d.top + 1 / 1.618 * (d.bottom - d.top - g), d.left), f = new gvjs_H(k.bottom + g, d.right, d.bottom, d.left)) : k = new gvjs_H(d.top, d.right, d.bottom, d.left);
        d = 0;
        h = e = Math.floor(Math.min(k.right - k.left, k.bottom - k.top) / 2);
        g = Math.round((k.right + k.left) / 2);
        k = Math.round((k.bottom + k.top) / 2);
        c.is3D && (h *= .8, d = e / 5, k -= d / 2);
        if (c.Xb) {
            c = c.Uk;
            var l = {
                radiusX: e * c.pie.ES,
                radiusY: h * c.pie.ES
            };
            e = {
                radiusX: e,
                radiusY: h
            };
            f = {
                pie: {
                    center: new gvjs_Ij(g, k),
                    radiusX: e.radiusX,
                    radiusY: e.radiusY,
                    yz: d,
                    cc: c.pie.i5 ? [l, e] : [e, l]
                },
                legend: f
            }
        } else f = {
            pie: {
                center: new gvjs_Ij(g, k),
                radiusX: e,
                radiusY: h,
                yz: d,
                cc: [{
                    radiusX: e,
                    radiusY: h
                }]
            },
            legend: f
        };
        gvjs_Pia(a, f);
        c = a.Pc.getPosition();
        f.legend ? a.Pc.wn(f.legend) : c == gvjs_Tr ? (b = a.Pc, f = b.wn, c = a.L, e = c.height - c.chartArea.bottom, d = a.Pc.Ea.fontSize, h = [], h.push({
            min: 2,
            extra: [Infinity]
        }), g = h.length, h.push({
            min: d + 2,
            extra: [Infinity]
        }), e = gvjs_ry(h, e), e.length > g ? (g = c.chartArea.bottom + e[g], c = new gvjs_H(g - d, c.chartArea.right, g, c.chartArea.left)) : c = null, f.call(b, c)) : c == gvjs_Yt && gvjs_Qia(a,
            b.chartArea, f, a.Pc.Ea)
    }]
};

function gvjs_NN(a, b, c) {
    var d = a.L,
        e = {},
        f = gvjs_Mw(a.options, gvjs_xN, "");
    a = b.color;
    var g = b.dark;
    b = b.light;
    if (d.is3D) {
        d = a;
        var h = g;
        f = b
    } else h = d = f;
    e.jc = new gvjs__({
        stroke: d,
        strokeWidth: 1,
        fill: a,
        fillOpacity: null != c ? c : 1
    });
    e.dark = new gvjs__({
        stroke: h,
        strokeWidth: 1,
        fill: g,
        fillOpacity: null != c ? c : 1
    });
    e.light = new gvjs__({
        stroke: f,
        strokeWidth: 1,
        fill: b,
        fillOpacity: null != c ? c : 1
    });
    return e
}

function gvjs_Pia(a, b) {
    function c(W, ba, aa, za, oa) {
        f.Xb ? f.pl.push({
            id: W,
            text: ba,
            brush: new gvjs__({
                gradient: {
                    color1: aa,
                    color2: aa,
                    ik: z[0],
                    jk: z[1],
                    x1: gvjs_yq,
                    y1: gvjs_wq,
                    x2: gvjs_wq,
                    y2: gvjs_wq,
                    useObjectBoundingBoxUnits: !0,
                    Hl: !0
                }
            }),
            index: za,
            isVisible: oa
        }) : f.pl.push({
            id: W,
            text: ba,
            brush: new gvjs__({
                fill: aa
            }),
            index: za,
            isVisible: oa
        })
    }

    function d(W) {
        var ba = f.pie.cc[W - 1].rL,
            aa = f.pie.cc[0].rL;
        1 == W && ba ? gvjs_ON(ba, r, ba) : 1 < W && (ba && aa ? (gvjs_ON(ba, r, ba, aa), gvjs_ON(aa, r, ba, aa)) : ba ? (aa = {
                xz: "0",
                qe: "0"
            }, gvjs_ON(ba, r, ba, aa)) :
            aa && (ba = {
                xz: "0",
                qe: "0"
            }, gvjs_ON(aa, r, ba, aa)))
    }

    function e(W, ba, aa, za) {
        var oa = f.series[W];
        1 == ba ? null != aa ? oa.hc = {
            Qf: !!za,
            ng: !0,
            content: aa
        } : gvjs_ON(oa, r, oa) : (W = f.series[W - l], gvjs_ON(oa, r, oa, W), gvjs_ON(W, r, oa, W))
    }
    var f = a.L,
        g = a.Ia,
        h = b.pie.center,
        k = b.pie.yz,
        l = g.getNumberOfRows(),
        m = gvjs_ZD(gvjs_Mw(a.options, "pieResidueSliceColor", "")),
        n = gvjs_NN(a, m, 1),
        p = gvjs_Pw(a.options, "pieSliceTextStyle", {
            fontName: f.Kf,
            fontSize: f.rh
        }),
        q = gvjs_C(a.options, gvjs_yN, f.Xb ? gvjs_e : gvjs_wN, gvjs_Iia),
        r = gvjs_C(a.options, "tooltip.text",
            gvjs_Sr, gvjs_CN),
        t = gvjs_Lw(a.options, "sliceVisibilityThreshold", 1 / 720),
        u = gvjs_D(a.options, "displayTinySlicesInLegend"),
        v = gvjs_C(a.options, "pieResidueSliceLabel", "Other"),
        w = gvjs_Lw(a.options, "pieHole", 0);
    f.series = [];
    f.pl = [];
    if (f.Xb) {
        var x = f.Uk;
        var y = a.options.R("diff.innerCircle.borderFactor", .01);
        y = x.pie.ES * (1 + y);
        x = x.pie.i5 ? [0, y] : [y, 0];
        y = [!1, !0];
        var z = [a.options.R(gvjs_Bs, .5), a.options.R(gvjs_As, 1)]
    } else x = [0], y = [!0], z = [1];
    f.pie = {
        center: h,
        yz: k,
        radiusX: b.pie.radiusX,
        radiusY: b.pie.radiusY,
        cc: []
    };
    k =
        f.pie.cc;
    b = b.pie.cc;
    for (var A = b.length, B = 0, D = 0; D < A; ++D) {
        var F = b[D],
            G = null,
            H = F.radiusX;
        F = F.radiusY;
        for (var I = x[D], P = y[D], K = 0, N = 0, Q = 0, U = 0; U < l; U++) Q += Number(g.getValue(U, D + 1) || 0);
        for (U = 0; U < l; ++U) {
            var O = a.Fka ? l - U - 1 : U,
                J = 1 === A && g.getNumberOfColumns() > D + 2 && g.getColumnRole(D + 2) === gvjs_de && g.getColumnType(D + 2) === gvjs_m,
                C = f.md && J && !(!g.getProperty(O, D + 2, gvjs_It) && !g.getColumnProperty(D + 2, gvjs_It)),
                E = Number(g.getValue(O, D + 1) || 0),
                L = g.getFormattedValue(O, D + 1, a.T9),
                M = g.getValue(O, 0),
                R = g.getFormattedValue(O, 0),
                S = 0 === Q ? 0 : N / Q,
                T = 0 === Q ? 0 : S + E / Q,
                ca = T - S >= t;
            J = J && g.getStringValue(O, D + 2) || null;
            ca ? N += E : K += E;
            var V = "slices." + B,
                ia = a.options.R(V + ".color", a.wc[U % a.wc.length]);
            ia = gvjs_ZD(ia);
            var sa = gvjs_NN(a, ia, z[D]),
                ma = gvjs_E(a.options, V + ".offset", 0),
                ka = gvjs_Lw(a.options, V + ".hole", w) + I,
                ya = gvjs_Pw(a.options, V + ".textStyle", p),
                Y = gvjs_D(a.options, [V + gvjs_vN, gvjs_Ms], !0);
            O = gvjs_PN(a, B, O, S, T, E, L, R, ca, h, H, F, ka, ma, q, ya, ia, sa, Y);
            f.series.push(O);
            ca = gvjs_D(a.options, V + ".visibleInLegend", P && (ca || u));
            c(M, R, ia.color, B, ca);
            D == A - 1 &&
                e(B, A, J, C);
            B += 1
        }
        0 < K && (G = 1 - (0 === Q ? 0 : K / Q), N = K, Q = a.T9.formatValue(Number(K)), K = v, G = gvjs_PN(a, -1, -1, G, 1, N, Q, K, !0, h, H, F, w + I, 0, q, p, m, n, !1), P && !u && c("", K, m.color, -1, !0));
        k.push({
            radiusX: H,
            radiusY: F,
            rL: G
        });
        D == A - 1 && d(A)
    }
}

function gvjs_PN(a, b, c, d, e, f, g, h, k, l, m, n, p, q, r, t, u, v, w) {
    var x = a.L;
    if (x.is3D || 1 <= p) p = 0;
    var y = {},
        z = e - d;
    y.value = f;
    y.qe = g;
    y.color = u;
    y.ab = v;
    y.brush = y.ab.jc;
    y.title = h;
    y.index = b;
    y.enableInteractivity = w;
    y.Fo = 0 <= c ? a.Ia.getTableRowIndex(c) : null;
    y.isVisible = k;
    b = m * p;
    p *= n;
    y.PD = b;
    y.Iy = p;
    y.Bc = 360 * d + a.V8;
    y.fc = 360 * e + a.V8;
    a.Gka && (c = 360 - y.Bc, y.Bc = 360 - y.fc, y.fc = c);
    c = Math.PI * (y.Bc - 90) / 180;
    f = Math.PI * (y.fc - 90) / 180;
    y.xz = a.Vja.formatValue(z);
    h = "";
    switch (r) {
        case gvjs_wN:
            h = y.xz;
            break;
        case gvjs_qd:
            h = y.title;
            break;
        case gvjs_o:
            h =
                g;
            break;
        case gvjs_zN:
            h = g + " (" + y.xz + ")"
    }
    y.text = h;
    if (!k) return y;
    y.textStyle = t;
    a = a.Va(y.text, t).width;
    t = t.fontSize;
    y.mN = new gvjs_B(a, t);
    y.sp = 1 == z;
    if (y.text)
        if (y.sp) y.AW = gvjs_ky(l, new gvjs_Ij(a / 2, t / 2)), y.WS = !0;
        else {
            z = m - t;
            t = n - t;
            a = y.mN;
            a = new gvjs_B(a.width / z, a.height / t);
            g = new gvjs_B(2 / z, 2 / t);
            k = gvjs_hH((c + f) / 2 + Math.PI, 1, 1);
            r = gvjs_EN(new gvjs_Ij(0, 0), a);
            b: {
                h = 1;u = Math.min;
                for (v = 0; v < r.length; ++v) {
                    var A = r[v];
                    w = k.x * A.x + k.y * A.y;
                    A = w * w + 1 - (A.x * A.x + A.y * A.y);
                    0 > A ? w = null : (A = Math.sqrt(A), w = [w - A, w + A]);
                    if (null === w || 0 >
                        w[1]) {
                        r = null;
                        break b
                    }
                    h = u(h, w[1])
                }
                r = h
            }
            if (null == r || .4 > r) a = null;
            else {
                k = k.clone();
                k.scale(-r);
                a = gvjs_Kia(a, g, g);
                b: {
                    a = gvjs_EN(k, a);g = gvjs_Mx(f - c, 2 * Math.PI);r = 0;h = g;
                    for (u = 0; u < a.length; ++u) {
                        v = gvjs_Mx(Math.atan2(a[u].y, a[u].x) - c, 2 * Math.PI);
                        if (v >= g || 0 == v) {
                            a = !1;
                            break b
                        }
                        h = Math.min(v, h);
                        r = Math.max(v, r)
                    }
                    a = r - h < Math.PI
                }
                a = a ? k : null
            }
            z = a && new gvjs_Ij(a.x * z, a.y * t);
            null !== z && (y.WS = !0, y.AW = gvjs_Jia(l, z, new gvjs_Ij(-y.mN.width / 2, -y.mN.height / 2)))
        }
    else y.WS = !1;
    y.offset = gvjs_hH((c + f) / 2, m, n).scale(q);
    q = gvjs_hH(f, m, n);
    y.Kd =
        gvjs_jy(l, gvjs_hH(c, m, n));
    y.dg = gvjs_jy(l, q);
    n = gvjs_hH(f, b, p);
    y.Hy = gvjs_jy(l, gvjs_hH(c, b, p));
    y.Jr = gvjs_jy(l, n);
    x.is3D && 270 >= y.Bc && 90 <= y.fc && (n = {}, 90 > y.Bc ? (n.Bc = 90, n.Kd = new gvjs_Ij(l.x + m, l.y)) : (n.Bc = y.Bc, n.Kd = y.Kd), 270 < y.fc ? (n.fc = 270, n.dg = new gvjs_Ij(l.x - m, l.y)) : (n.fc = y.fc, n.dg = y.dg), n.brush = y.ab.dark, y.kb = n);
    y.gr = x.is3D && .5 < d;
    y.Wt = x.is3D && .5 > e;
    if (y.gr || y.Wt) y.jK = y.ab.dark;
    return y
}

function gvjs_ON(a, b, c, d) {
    c = gvjs_LN(c, b);
    d && (c += "\n" + gvjs_LN(d, b));
    a.hc = {
        sk: a.title,
        content: c
    }
}

function gvjs_Qia(a, b, c, d) {
    var e = a.L,
        f = e.pie.radiusX,
        g = e.pie.radiusY,
        h = c.pie.center,
        k = gvjs_C(a.options, "legend.labeledValueText", gvjs_wN, gvjs_CN),
        l = Math.PI * (3 * (f + g) - Math.sqrt((3 * f + g) * (f + 3 * g))),
        m = [];
    c = [];
    for (var n = {}, p = 0; p < e.pl.length; n = {
            NG: n.NG,
            LA: n.LA,
            MA: n.MA,
            OG: n.OG
        }, ++p) {
        var q = e.pl[p];
        if (q.isVisible) {
            var r = void 0;
            if (0 <= q.index) r = e.series[q.index];
            else {
                var t = e.pie.cc;
                r = t[t.length - 1].rL
            }
            n.NG = Math.max((f + r.PD) / 2, .75 * f);
            n.LA = Math.max((g + r.Iy) / 2, .75 * g);
            var u = (r.fc + r.Bc) / 2;
            t = gvjs_Mx(u, 360);
            var v = gvjs_Ux(f -
                    n.NG, g - n.LA) / l * 360,
                w = void 0,
                x = void 0;
            2 * v < r.fc - r.Bc ? (w = r.Bc + v, x = r.fc - v, 180 > t ? x = Math.min(x, 180) : w = Math.max(w, 180)) : x = w = u;
            n.MA = function(A) {
                return function(B) {
                    return gvjs_jy(h, gvjs_hH(B, A.NG, A.LA))
                }
            }(n);
            var y = function(A) {
                return function(B) {
                    return A.MA(gvjs_Ox(B - 90))
                }
            }(n);
            n.OG = function(A) {
                return function(B) {
                    return Math.asin(gvjs_7h((B - h.y) / A.LA, -1, 1))
                }
            }(n);
            v = function(A) {
                return function(B) {
                    return A.MA(A.OG(B))
                }
            }(n);
            var z = function(A) {
                return function(B) {
                    return A.MA(Math.PI - A.OG(B))
                }
            }(n);
            q = {
                u7: y(u).y,
                pL: new gvjs_Lk(y(w).y,
                    y(x).y),
                Tw: q.text,
                ix: gvjs_LN(r, k),
                I4: r.value,
                index: r.index
            };
            180 > t ? (q.d7 = v, m.push(q)) : (q.d7 = z, c.push(q))
        }
    }
    f = b.width / 2 - f - d.fontSize;
    e = gvjs_GN(new gvjs_H(b.top, b.right, b.bottom, b.right - f), a.Va, 2, d, m);
    b = gvjs_GN(new gvjs_H(b.top, b.left + f, b.bottom, b.left), a.Va, 1, d, c);
    d = [];
    gvjs_xf(d, e, b);
    a.L.Vm = d
}

function gvjs_QN(a, b, c) {
    gvjs_2H.call(this, a, b, c, gvjs_Ru)
}
gvjs_r(gvjs_QN, gvjs_2H);
gvjs_QN.prototype.Io = function(a) {
    return this.renderer.sr(a.target)
};
gvjs_QN.prototype.Y1 = function(a, b) {
    b = b.split("#");
    b[0] === gvjs_Ap && (b = Number(b[1]), 0 > b || this.dispatchEvent("serie" + a, {
        yb: b,
        bi: null
    }))
};

function gvjs_RN(a, b, c, d, e, f, g) {
    gvjs_sI.call(this, a, b, c, d, e, g);
    var h = gvjs_D(a, gvjs_Ms, !0);
    this.Ada = gvjs_py(f, function(k) {
        return gvjs_D(a, "slices." + k + gvjs_vN, h)
    });
    this.xla = gvjs_D(a, "shouldHighlightHover", !0)
}
gvjs_r(gvjs_RN, gvjs_sI);
gvjs_RN.prototype.Uo = function(a, b, c) {
    this.HQ(a, b, c)
};
gvjs_RN.prototype.z2 = function(a, b) {
    return a.equals(b, !0)
};

function gvjs_SN(a, b) {
    a.series = a.series || {};
    a = a.series;
    a[b] = a[b] || {};
    return a[b]
}
gvjs_RN.prototype.HQ = function(a, b, c) {
    function d(q, r) {
        if (null != q) {
            if (a.Xb) {
                var t = a.series.length;
                t = [q, (q + t / a.pie.cc.length) % t]
            } else t = [q];
            for (var u = !1, v = 0; v < t.length; ++v) {
                var w = t[v];
                null != w && e.Ada[w] && (u = u || !0, a.Xb || e.xla && gvjs_Ria(a, w, c), a.Vm && (c.Vm = gvjs_Oia(a.Vm, w)))
            }
            r && k && u && gvjs_TN(e, f, q)
        }
    }
    var e = this,
        f = {
            ca: a,
            Rh: this.Tc.getEntries(),
            Nr: c,
            Sh: b.fg
        },
        g = b.fg.focused.Zt;
    null != g && (b.fg.focused.action = this.Tc.getAction(g).action);
    var h = this.Ol.UW;
    g = h == gvjs_fv || h == gvjs_Sr;
    var k = h == gvjs_1s || h == gvjs_Sr,
        l =
        this.Tc && 0 < f.Rh.length;
    h = gvjs_Io(b.selected);
    l = 1 < h.length && l;
    for (var m = 0; m < h.length; ++m) {
        var n = h[m],
            p = a.pie.cc.length;
        n += a.series.length / p * (p - 1);
        gvjs_Sia(a, n, c);
        g && !l && gvjs_TN(this, f, n)
    }
    g && l && gvjs_Tia(this, f, h, h[h.length - 1]);
    if (g = b.cf) c.cf = g;
    d(b.focused.Ua, !0);
    d(b.legend.focused.Ob, !1)
};

function gvjs_Ria(a, b, c) {
    var d = a.pie,
        e = a.series[b];
    if (null != e.offset) {
        c = gvjs_SN(c, b);
        b = {};
        c.Mm = b;
        b.brush = new gvjs__({
            stroke: e.brush.fill,
            strokeWidth: 6.5,
            strokeOpacity: .3
        });
        b.cg = new gvjs_A(d.center.x + e.offset.x, d.center.y + e.offset.y);
        b.Bc = e.Bc;
        b.fc = e.fc;
        b.sp = e.sp;
        (c = c.Fh) && a.B8 ? (a = c.radiusX + c.brush.strokeWidth / 2, c = c.radiusY + c.brush.strokeWidth / 2) : (c = e.brush.strokeWidth / 2, a = d.radiusX + c, c = d.radiusY + c);
        d = b.brush.strokeWidth / 2;
        b.radiusX = a + d;
        b.radiusY = c + d;
        a = gvjs_Ox(b.Bc - 90);
        c = gvjs_Ox(b.fc - 90);
        b.Kd = gvjs_3x(b.cg,
            gvjs_hH(a, b.radiusX, b.radiusY));
        b.dg = gvjs_3x(b.cg, gvjs_hH(c, b.radiusX, b.radiusY));
        var f = e.kb;
        f && (b.kb = b.kb || {}, b.kb.brush = gvjs_cy(f.brush.fill, .3), b.kb.cg = b.cg.clone(), b.kb.Bc = f.Bc, b.kb.fc = f.fc, b.kb.radiusX = b.radiusX + d, b.kb.radiusY = b.radiusY + d, a = gvjs_Ox(b.kb.Bc - 90), c = gvjs_Ox(b.kb.fc - 90), b.kb.Kd = gvjs_3x(b.kb.cg, gvjs_hH(a, b.kb.radiusX, b.kb.radiusY)), b.kb.dg = gvjs_3x(b.kb.cg, gvjs_hH(c, b.kb.radiusX, b.kb.radiusY)));
        b.gr = e.gr;
        b.Wt = e.Wt;
        if (b.gr || b.Wt) b.jK = gvjs_cy(e.jK.fill, .3), b.lka = b.gr ? a : c, e = function(g,
            h) {
            return gvjs_3x(g.cg, gvjs_hH(g.lka, g.radiusX + h * g.brush.strokeWidth / 2, g.radiusY + h * g.brush.strokeWidth / 2))
        }, b.Gy = e(b, -1), b.kK = e(b, 1)
    }
}

function gvjs_Sia(a, b, c) {
    var d = a.pie;
    if (!(0 < d.yz)) {
        var e = a.series[b];
        null != e.offset && (a = {}, gvjs_SN(c, b).Fh = a, a.brush = gvjs_dy(e.brush.fill, 2), a.cg = new gvjs_A(d.center.x + e.offset.x, d.center.y + e.offset.y), a.Bc = e.Bc, a.fc = e.fc, a.sp = e.sp, b = e.brush.strokeWidth / 2 + 2.5 + a.brush.strokeWidth / 2, a.radiusX = d.radiusX + b, a.radiusY = d.radiusY + b, d = gvjs_Ox(a.fc - 90), a.Kd = gvjs_3x(a.cg, gvjs_hH(gvjs_Ox(a.Bc - 90), a.radiusX, a.radiusY)), a.dg = gvjs_3x(a.cg, gvjs_hH(d, a.radiusX, a.radiusY)))
    }
}

function gvjs_TN(a, b, c) {
    var d = gvjs_SN(b.Nr, c);
    if (c = gvjs_qI(a.Ol, b, c, null, null)) d.tooltip = c, b.Sh && a.Tc.Uo(c, b.Sh, d.tooltip)
}

function gvjs_Tia(a, b, c, d) {
    var e = gvjs_SN(b.Nr, d);
    var f = a.Ol;
    var g = b.ca,
        h = g.series[d];
    d = gvjs_iI(g, h);
    h = gvjs_nI(g, h);
    c = gvjs_Fia(f.oo, b, c);
    f = gvjs_ED(c, g.Va, !0, d, f.le, h, void 0, g.md, g.Pr, g.Es);
    e.tooltip = f;
    b.Sh && a.Tc.Uo(f, b.Sh, e.tooltip)
}

function gvjs_UN(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_c, gvjs_xv, gvjs_R)
}
gvjs_r(gvjs_UN, gvjs_fJ);

function gvjs_VN(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_c, gvjs_e, gvjs_R, "sparkline")
}
gvjs_r(gvjs_VN, gvjs_fJ);

function gvjs_WN(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_Wr)
}
gvjs_r(gvjs_WN, gvjs_fJ);

function gvjs_XN(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_c, gvjs_Hr, gvjs_S)
}
gvjs_r(gvjs_XN, gvjs_fJ);
gvjs_XN.prototype.computeDiff = function(a, b) {
    return gvjs_kJ(a, b)
};

function gvjs_YN(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_c, gvjs_2r, gvjs_R)
}
gvjs_r(gvjs_YN, gvjs_fJ);

function gvjs_ZN(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_c, gvjs_Hr, gvjs_R)
}
gvjs_r(gvjs_ZN, gvjs_fJ);
gvjs_ZN.prototype.computeDiff = function(a, b) {
    return gvjs_kJ(a, b)
};

function gvjs__N(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_Bt, gvjs_Hr, gvjs_R)
}
gvjs_r(gvjs__N, gvjs_fJ);

function gvjs_0N(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_Ru)
}
gvjs_r(gvjs_0N, gvjs_fJ);
gvjs_ = gvjs_0N.prototype;
gvjs_.iI = function(a, b, c, d, e, f) {
    a = new gvjs_MN(a, b, c, d, e);
    a.init(this.mf, f);
    return a
};
gvjs_.e1 = function(a, b, c, d, e, f, g) {
    return new gvjs_RN(a, b, c, d, e, f, g)
};
gvjs_.d1 = function(a, b, c) {
    return new gvjs_QN(a, b, c)
};
gvjs_.dQ = function(a, b) {
    return new gvjs_HN(a, b)
};
gvjs_.computeDiff = function(a, b) {
    return gvjs_kJ(a, b)
};
gvjs_t(gvjs_wc, gvjs_fJ);
gvjs_fJ.prototype.draw = gvjs_fJ.prototype.draw;
gvjs_fJ.prototype.clearChart = gvjs_fJ.prototype.clearChart;
gvjs_fJ.prototype.getImageURI = gvjs_fJ.prototype.getImageURI;
gvjs_fJ.prototype.getSelection = gvjs_fJ.prototype.getSelection;
gvjs_fJ.prototype.setSelection = gvjs_fJ.prototype.setSelection;
gvjs_fJ.prototype.dump = gvjs_fJ.prototype.dump;
gvjs_fJ.prototype.getChartLayoutInterface = gvjs_fJ.prototype.getChartLayoutInterface;
gvjs_fJ.prototype.getContainer = gvjs_fJ.prototype.getContainer;
gvjs_fJ.prototype.setAction = gvjs_fJ.prototype.setAction;
gvjs_fJ.prototype.getAction = gvjs_fJ.prototype.getAction;
gvjs_fJ.prototype.removeAction = gvjs_fJ.prototype.removeAction;
gvjs_t(gvjs_kc, gvjs_qJ);
gvjs_qJ.prototype.draw = gvjs_qJ.prototype.draw;
gvjs_qJ.prototype.clearChart = gvjs_qJ.prototype.clearChart;
gvjs_qJ.prototype.getImageURI = gvjs_qJ.prototype.getImageURI;
gvjs_qJ.prototype.getSelection = gvjs_qJ.prototype.getSelection;
gvjs_qJ.prototype.setSelection = gvjs_qJ.prototype.setSelection;
gvjs_qJ.prototype.setAction = gvjs_qJ.prototype.setAction;
gvjs_qJ.prototype.getAction = gvjs_qJ.prototype.getAction;
gvjs_qJ.prototype.removeAction = gvjs_qJ.prototype.removeAction;
gvjs_t(gvjs_lc, gvjs_XN);
gvjs_XN.prototype.computeDiff = gvjs_XN.prototype.computeDiff;
gvjs_XN.prototype.draw = gvjs_XN.prototype.draw;
gvjs_XN.prototype.clearChart = gvjs_XN.prototype.clearChart;
gvjs_XN.prototype.getImageURI = gvjs_XN.prototype.getImageURI;
gvjs_XN.prototype.getSelection = gvjs_XN.prototype.getSelection;
gvjs_XN.prototype.setSelection = gvjs_XN.prototype.setSelection;
gvjs_XN.prototype.setAction = gvjs_XN.prototype.setAction;
gvjs_XN.prototype.getAction = gvjs_XN.prototype.getAction;
gvjs_XN.prototype.removeAction = gvjs_XN.prototype.removeAction;
gvjs_t(gvjs_mc, gvjs_WN);
gvjs_WN.prototype.draw = gvjs_WN.prototype.draw;
gvjs_WN.prototype.clearChart = gvjs_WN.prototype.clearChart;
gvjs_WN.prototype.getImageURI = gvjs_WN.prototype.getImageURI;
gvjs_WN.prototype.getSelection = gvjs_WN.prototype.getSelection;
gvjs_WN.prototype.setSelection = gvjs_WN.prototype.setSelection;
gvjs_WN.prototype.setAction = gvjs_WN.prototype.setAction;
gvjs_WN.prototype.getAction = gvjs_WN.prototype.getAction;
gvjs_WN.prototype.removeAction = gvjs_WN.prototype.removeAction;
gvjs_t(gvjs_oc, gvjs_YN);
gvjs_YN.prototype.draw = gvjs_YN.prototype.draw;
gvjs_YN.prototype.clearChart = gvjs_YN.prototype.clearChart;
gvjs_YN.prototype.getImageURI = gvjs_YN.prototype.getImageURI;
gvjs_YN.prototype.getSelection = gvjs_YN.prototype.getSelection;
gvjs_YN.prototype.setSelection = gvjs_YN.prototype.setSelection;
gvjs_YN.prototype.setAction = gvjs_YN.prototype.setAction;
gvjs_YN.prototype.getAction = gvjs_YN.prototype.getAction;
gvjs_YN.prototype.removeAction = gvjs_YN.prototype.removeAction;
gvjs_t(gvjs_Ic, gvjs__N);
gvjs__N.prototype.draw = gvjs__N.prototype.draw;
gvjs__N.prototype.clearChart = gvjs__N.prototype.clearChart;
gvjs__N.prototype.getImageURI = gvjs__N.prototype.getImageURI;
gvjs__N.prototype.getSelection = gvjs__N.prototype.getSelection;
gvjs__N.prototype.setSelection = gvjs__N.prototype.setSelection;
gvjs__N.prototype.setAction = gvjs__N.prototype.setAction;
gvjs__N.prototype.getAction = gvjs__N.prototype.getAction;
gvjs__N.prototype.removeAction = gvjs__N.prototype.removeAction;
gvjs_t(gvjs_tc, gvjs_ZN);
gvjs_ZN.prototype.computeDiff = gvjs_ZN.prototype.computeDiff;
gvjs_ZN.prototype.draw = gvjs_ZN.prototype.draw;
gvjs_ZN.prototype.clearChart = gvjs_ZN.prototype.clearChart;
gvjs_ZN.prototype.getImageURI = gvjs_ZN.prototype.getImageURI;
gvjs_ZN.prototype.getSelection = gvjs_ZN.prototype.getSelection;
gvjs_ZN.prototype.setSelection = gvjs_ZN.prototype.setSelection;
gvjs_ZN.prototype.setAction = gvjs_ZN.prototype.setAction;
gvjs_ZN.prototype.getAction = gvjs_ZN.prototype.getAction;
gvjs_ZN.prototype.removeAction = gvjs_ZN.prototype.removeAction;
gvjs_t(gvjs_vc, gvjs_tJ);
gvjs_tJ.prototype.draw = gvjs_tJ.prototype.draw;
gvjs_tJ.prototype.clearChart = gvjs_tJ.prototype.clearChart;
gvjs_tJ.prototype.getImageURI = gvjs_tJ.prototype.getImageURI;
gvjs_tJ.prototype.getSelection = gvjs_tJ.prototype.getSelection;
gvjs_tJ.prototype.setSelection = gvjs_tJ.prototype.setSelection;
gvjs_tJ.prototype.setAction = gvjs_tJ.prototype.setAction;
gvjs_tJ.prototype.getAction = gvjs_tJ.prototype.getAction;
gvjs_tJ.prototype.removeAction = gvjs_tJ.prototype.removeAction;
gvjs_t(gvjs_Qc, gvjs_rJ);
gvjs_rJ.prototype.draw = gvjs_rJ.prototype.draw;
gvjs_rJ.prototype.clearChart = gvjs_rJ.prototype.clearChart;
gvjs_rJ.prototype.getImageURI = gvjs_rJ.prototype.getImageURI;
gvjs_rJ.prototype.getSelection = gvjs_rJ.prototype.getSelection;
gvjs_rJ.prototype.setSelection = gvjs_rJ.prototype.setSelection;
gvjs_rJ.prototype.setAction = gvjs_rJ.prototype.setAction;
gvjs_rJ.prototype.getAction = gvjs_rJ.prototype.getAction;
gvjs_rJ.prototype.removeAction = gvjs_rJ.prototype.removeAction;
gvjs_t(gvjs__c, gvjs_0N);
gvjs_0N.prototype.computeDiff = gvjs_0N.prototype.computeDiff;
gvjs_0N.prototype.draw = gvjs_0N.prototype.draw;
gvjs_0N.prototype.clearChart = gvjs_0N.prototype.clearChart;
gvjs_0N.prototype.getImageURI = gvjs_0N.prototype.getImageURI;
gvjs_0N.prototype.getSelection = gvjs_0N.prototype.getSelection;
gvjs_0N.prototype.setSelection = gvjs_0N.prototype.setSelection;
gvjs_0N.prototype.setAction = gvjs_0N.prototype.setAction;
gvjs_0N.prototype.getAction = gvjs_0N.prototype.getAction;
gvjs_0N.prototype.removeAction = gvjs_0N.prototype.removeAction;
gvjs_t(gvjs_3c, gvjs_sJ);
gvjs_sJ.prototype.computeDiff = gvjs_sJ.prototype.computeDiff;
gvjs_sJ.prototype.draw = gvjs_sJ.prototype.draw;
gvjs_sJ.prototype.clearChart = gvjs_sJ.prototype.clearChart;
gvjs_sJ.prototype.getImageURI = gvjs_sJ.prototype.getImageURI;
gvjs_sJ.prototype.getSelection = gvjs_sJ.prototype.getSelection;
gvjs_sJ.prototype.setSelection = gvjs_sJ.prototype.setSelection;
gvjs_sJ.prototype.setAction = gvjs_sJ.prototype.setAction;
gvjs_sJ.prototype.getAction = gvjs_sJ.prototype.getAction;
gvjs_sJ.prototype.removeAction = gvjs_sJ.prototype.removeAction;
gvjs_t(gvjs_5c, gvjs_VN);
gvjs_VN.prototype.draw = gvjs_VN.prototype.draw;
gvjs_VN.prototype.clearChart = gvjs_VN.prototype.clearChart;
gvjs_VN.prototype.getImageURI = gvjs_VN.prototype.getImageURI;
gvjs_VN.prototype.getSelection = gvjs_VN.prototype.getSelection;
gvjs_VN.prototype.setSelection = gvjs_VN.prototype.setSelection;
gvjs_VN.prototype.setAction = gvjs_VN.prototype.setAction;
gvjs_VN.prototype.getAction = gvjs_VN.prototype.getAction;
gvjs_VN.prototype.removeAction = gvjs_VN.prototype.removeAction;
gvjs_t(gvjs_6c, gvjs_UN);
gvjs_UN.prototype.draw = gvjs_UN.prototype.draw;
gvjs_UN.prototype.clearChart = gvjs_UN.prototype.clearChart;
gvjs_UN.prototype.getImageURI = gvjs_UN.prototype.getImageURI;
gvjs_UN.prototype.getSelection = gvjs_UN.prototype.getSelection;
gvjs_UN.prototype.setSelection = gvjs_UN.prototype.setSelection;
gvjs_UN.prototype.setAction = gvjs_UN.prototype.setAction;
gvjs_UN.prototype.getAction = gvjs_UN.prototype.getAction;
gvjs_UN.prototype.removeAction = gvjs_UN.prototype.removeAction;