/*

Copyright (c) 2015-2018, University of Washington Interactive Data Lab
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
  may be used to endorse or promote products derived from this software
  without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
var gvjs_kp = "BUTTON",
    gvjs_lp = "TEXTAREA",
    gvjs_mp = "Uneven number of arguments",
    gvjs_np = "background",
    gvjs_op = "chartArea.bottom",
    gvjs_pp = "chartArea.height",
    gvjs_qp = "chartArea.left",
    gvjs_rp = "chartArea.right",
    gvjs_sp = "chartArea.top",
    gvjs_tp = "chartArea.width",
    gvjs_up = "datatable",
    gvjs_vp = "datum",
    gvjs_wp = "group",
    gvjs_R = "horizontal",
    gvjs_xp = "point",
    gvjs_yp = "pointShape",
    gvjs_zp = "rect",
    gvjs_Ap = "slice",
    gvjs_Bp = "strokeWidth",
    gvjs_Cp = "svg",
    gvjs_S = "vertical";

function gvjs_T(a, b) {
    return gvjs_qe[a] = b
}
gvjs_Ln.prototype.Dx = gvjs_T(28, function(a) {
    var b = this.Wb();
    return gvjs_tf(b, a)
});
gvjs_dn.prototype.De = gvjs_T(27, function() {
    return this.Xf.size
});
gvjs_Ln.prototype.De = gvjs_T(26, function() {
    gvjs_On(this);
    return this.Cg
});
gvjs_vm.prototype.gG = gvjs_T(25, function() {
    return new gvjs_xm(this.FR())
});
gvjs_wm.prototype.gG = gvjs_T(24, function() {
    return new gvjs_xm(this.dE)
});
gvjs_H.prototype.pb = gvjs_T(16, function() {
    return this.right - this.left
});
gvjs_cn.prototype.pb = gvjs_T(15, function(a, b) {
    return a.Dy(gvjs_le) || gvjs_ok(this.container).width || b || 400
});

function gvjs_Dp(a, b, c) {
    b = b.reduceRight(function(d, e) {
        var f = {};
        return f[e] = d, f
    }, c);
    gvjs_Bg(a, b)
}

function gvjs_Ep(a, b, c) {
    if (a.KH) {
        var d = {};
        gvjs_Dp(d, a.KH[0].split("."), c);
        c = d
    }
    for (var e = d = 0; e < b; e++) e === a.mE.length && a.mE.push(0), d += a.mE[e];
    a.mE[b]++;
    a.cc.splice(d, 0, c)
}

function gvjs_Fp(a, b) {
    for (var c = gvjs_q(Object.keys(b)), d = c.next(); !d.done; d = c.next()) {
        d = d.value;
        var e = b[d];
        null != e && e instanceof Object && !Array.isArray(e) ? (a[d] = a[d] || {}, gvjs_Fp(a[d], e)) : null != e && (a[d] = e)
    }
}

function gvjs_Gp(a) {
    var b = void 0 === b ? {} : b;
    for (var c = a.cc.length - 1; 0 <= c; c--) gvjs_Fp(b, a.cc[c]);
    return b
}

function gvjs_Hp(a) {
    var b = 0,
        c;
    for (c in a) b++;
    return b
}

function gvjs_Ip(a) {
    var b = arguments.length;
    if (1 == b && Array.isArray(arguments[0])) return gvjs_Ip.apply(null, arguments[0]);
    for (var c = {}, d = 0; d < b; d++) c[arguments[d]] = !0;
    return c
}

function gvjs_xda(a, b) {
    return new gvjs_sm(a, b)
}

function gvjs_Jp(a) {
    return {
        value: a,
        done: !1
    }
}

function gvjs_Kp(a) {
    if (a instanceof gvjs_vm || a instanceof gvjs_wm || a instanceof gvjs_xm) return a;
    if (typeof a.next == gvjs_c) return new gvjs_vm(function() {
        return a
    });
    if (typeof a[Symbol.iterator] == gvjs_c) return new gvjs_vm(function() {
        return a[Symbol.iterator]()
    });
    if (typeof a.Di == gvjs_c) return new gvjs_vm(function() {
        return a.Di()
    });
    throw Error("Not an iterator or iterable.");
}

function gvjs_Lp(a, b) {
    return Object.prototype.hasOwnProperty.call(a, b)
}

function gvjs_yda(a, b) {
    return a === b
}

function gvjs_Mp(a, b) {
    this.ma = {};
    this.Rb = [];
    this.AG = this.size = 0;
    var c = arguments.length;
    if (1 < c) {
        if (c % 2) throw Error(gvjs_mp);
        for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1])
    } else a && this.addAll(a)
}
gvjs_ = gvjs_Mp.prototype;
gvjs_.De = function() {
    return this.size
};
gvjs_.Wb = function() {
    gvjs_Np(this);
    for (var a = [], b = 0; b < this.Rb.length; b++) a.push(this.ma[this.Rb[b]]);
    return a
};
gvjs_.Km = function() {
    gvjs_Np(this);
    return this.Rb.concat()
};
gvjs_.sm = function(a) {
    return this.has(a)
};
gvjs_.has = function(a) {
    return gvjs_Lp(this.ma, a)
};
gvjs_.Dx = function(a) {
    for (var b = 0; b < this.Rb.length; b++) {
        var c = this.Rb[b];
        if (gvjs_Lp(this.ma, c) && this.ma[c] == a) return !0
    }
    return !1
};
gvjs_.equals = function(a, b) {
    if (this === a) return !0;
    if (this.size != a.De()) return !1;
    b = b || gvjs_yda;
    gvjs_Np(this);
    for (var c, d = 0; c = this.Rb[d]; d++)
        if (!b(this.get(c), a.get(c))) return !1;
    return !0
};
gvjs_.isEmpty = function() {
    return 0 == this.size
};
gvjs_.clear = function() {
    this.ma = {};
    this.Rb.length = 0;
    this.cq(0);
    this.AG = 0
};
gvjs_.remove = function(a) {
    return this.delete(a)
};
gvjs_.delete = function(a) {
    return gvjs_Lp(this.ma, a) ? (delete this.ma[a], this.cq(this.size - 1), this.AG++, this.Rb.length > 2 * this.size && gvjs_Np(this), !0) : !1
};

function gvjs_Np(a) {
    if (a.size != a.Rb.length) {
        for (var b = 0, c = 0; b < a.Rb.length;) {
            var d = a.Rb[b];
            gvjs_Lp(a.ma, d) && (a.Rb[c++] = d);
            b++
        }
        a.Rb.length = c
    }
    if (a.size != a.Rb.length) {
        var e = {};
        for (c = b = 0; b < a.Rb.length;) d = a.Rb[b], gvjs_Lp(e, d) || (a.Rb[c++] = d, e[d] = 1), b++;
        a.Rb.length = c
    }
}
gvjs_.get = function(a, b) {
    return gvjs_Lp(this.ma, a) ? this.ma[a] : b
};
gvjs_.set = function(a, b) {
    gvjs_Lp(this.ma, a) || (this.cq(this.size + 1), this.Rb.push(a), this.AG++);
    this.ma[a] = b
};
gvjs_.addAll = function(a) {
    if (a instanceof gvjs_Mp)
        for (var b = a.Km(), c = 0; c < b.length; c++) this.set(b[c], a.get(b[c]));
    else
        for (b in a) this.set(b, a[b])
};
gvjs_.forEach = function(a, b) {
    for (var c = this.Km(), d = 0; d < c.length; d++) {
        var e = c[d],
            f = this.get(e);
        a.call(b, f, e, this)
    }
};
gvjs_.clone = function() {
    return new gvjs_Mp(this)
};
gvjs_.transpose = function() {
    for (var a = new gvjs_Mp, b = 0; b < this.Rb.length; b++) {
        var c = this.Rb[b];
        a.set(this.ma[c], c)
    }
    return a
};
gvjs_.keys = function() {
    return gvjs_Kp(this.Di(!0)).gG()
};
gvjs_.values = function() {
    return gvjs_Kp(this.Di(!1)).gG()
};
gvjs_.entries = function() {
    var a = this;
    return gvjs_xda(this.keys(), function(b) {
        return [b, a.get(b)]
    })
};
gvjs_.Di = function(a) {
    gvjs_Np(this);
    var b = 0,
        c = this.AG,
        d = this,
        e = new gvjs_tm;
    e.next = function() {
        if (c != d.AG) throw Error("The map has changed since the iterator was created");
        if (b >= d.Rb.length) return gvjs_um;
        var f = d.Rb[b++];
        return gvjs_Jp(a ? f : d.ma[f])
    };
    return e
};
gvjs_.cq = function(a) {
    this.size = a
};

function gvjs_Op(a) {
    return a.De && typeof a.De == gvjs_c ? a.De() : gvjs_Ne(a) || typeof a === gvjs_m ? a.length : gvjs_Hp(a)
}

function gvjs_zda(a, b) {
    if (typeof a.every == gvjs_c) return a.every(b, void 0);
    if (gvjs_Ne(a) || typeof a === gvjs_m) return Array.prototype.every.call(a, b, void 0);
    for (var c = gvjs_wn(a), d = gvjs_vn(a), e = d.length, f = 0; f < e; f++)
        if (!b.call(void 0, d[f], c && c[f], a)) return !1;
    return !0
};
var gvjs_Pp = Symbol("referencepoint");
var gvjs_Ada = function() {
    if (gvjs_Kf) {
        var a = /Windows NT ([0-9.]+)/;
        return (a = a.exec(gvjs_8e())) ? a[1] : "0"
    }
    return gvjs_Jf ? (a = /1[0|1][_.][0-9_.]+/, (a = a.exec(gvjs_8e())) ? a[0].replace(/_/g, ".") : "10") : gvjs_saa ? (a = /Android\s+([^\);]+)(\)|;)/, (a = a.exec(gvjs_8e())) ? a[1] : "") : gvjs_taa || gvjs_uaa || gvjs_vaa ? (a = /(?:iPhone|CPU)\s+OS\s+(\S+)/, (a = a.exec(gvjs_8e())) ? a[1].replace(/_/g, ".") : "") : ""
}();

function gvjs_Qp(a) {
    return (a = a.exec(gvjs_8e())) ? a[1] : ""
}
var gvjs_Rp = function() {
    if (gvjs_yaa) return gvjs_Qp(/Firefox\/([0-9.]+)/);
    if (gvjs_x || gvjs_Gf || gvjs_Ff) return gvjs_Sf;
    if (gvjs_Wf) {
        if (gvjs_lf() || gvjs_mf()) {
            var a = gvjs_Qp(/CriOS\/([0-9.]+)/);
            if (a) return a
        }
        return gvjs_Qp(/Chrome\/([0-9.]+)/)
    }
    if (gvjs_Xf && !gvjs_lf()) return gvjs_Qp(/Version\/([0-9.]+)/);
    if (gvjs_zaa || gvjs_Aaa) {
        if (a = /Version\/(\S+).*Mobile\/(\S+)/.exec(gvjs_8e())) return a[1] + "." + a[2]
    } else if (gvjs_Baa) return (a = gvjs_Qp(/Android\s+([0-9.]+)/)) ? a : gvjs_Qp(/Version\/([0-9.]+)/);
    return ""
}();

function gvjs_Sp(a) {
    this.ma = new gvjs_Mp;
    this.size = 0;
    a && this.addAll(a)
}

function gvjs_Tp(a) {
    var b = typeof a;
    return b == gvjs_g && a || b == gvjs_c ? "o" + gvjs_Qe(a) : b.slice(0, 1) + a
}
gvjs_ = gvjs_Sp.prototype;
gvjs_.De = function() {
    return this.ma.size
};
gvjs_.add = function(a) {
    this.ma.set(gvjs_Tp(a), a);
    this.cq(this.ma.size)
};
gvjs_.addAll = function(a) {
    a = gvjs_vn(a);
    for (var b = a.length, c = 0; c < b; c++) this.add(a[c]);
    this.cq(this.ma.size)
};
gvjs_.removeAll = function(a) {
    a = gvjs_vn(a);
    for (var b = a.length, c = 0; c < b; c++) this.remove(a[c]);
    this.cq(this.ma.size)
};
gvjs_.delete = function(a) {
    a = this.ma.remove(gvjs_Tp(a));
    this.cq(this.ma.size);
    return a
};
gvjs_.remove = function(a) {
    return this.delete(a)
};
gvjs_.clear = function() {
    this.ma.clear();
    this.cq(0)
};
gvjs_.isEmpty = function() {
    return 0 === this.ma.size
};
gvjs_.has = function(a) {
    return this.ma.sm(gvjs_Tp(a))
};
gvjs_.contains = function(a) {
    return this.ma.sm(gvjs_Tp(a))
};
gvjs_.IS = gvjs_p(29);
gvjs_.Wb = function() {
    return this.ma.Wb()
};
gvjs_.values = function() {
    return this.ma.values()
};
gvjs_.clone = function() {
    return new gvjs_Sp(this)
};
gvjs_.equals = function(a) {
    return this.De() == gvjs_Op(a) && this.VS(a)
};
gvjs_.VS = function(a) {
    var b = gvjs_Op(a);
    if (this.De() > b) return !1;
    !(a instanceof gvjs_Sp) && 5 < b && (a = new gvjs_Sp(a));
    return gvjs_zda(this, function(c) {
        var d = a;
        return d.contains && typeof d.contains == gvjs_c ? d.contains(c) : d.Dx && typeof d.Dx == gvjs_c ? d.Dx(c) : gvjs_Ne(d) || typeof d === gvjs_m ? gvjs_tf(d, c) : gvjs_Ug(d, c)
    })
};
gvjs_.Di = function() {
    return this.ma.Di(!1)
};
gvjs_Sp.prototype[Symbol.iterator] = function() {
    return this.values()
};
gvjs_Sp.prototype.cq = function(a) {
    this.size = a
};
var gvjs_Up = {};

function gvjs_Vp() {
    throw Error("Do not instantiate directly");
}
gvjs_Vp.prototype.fQ = null;
gvjs_Vp.prototype.getContent = function() {
    return this.content
};
gvjs_Vp.prototype.toString = function() {
    return this.content
};
gvjs_Vp.prototype.lA = gvjs_p(30);

function gvjs_Wp() {
    gvjs_Vp.call(this)
}
gvjs_u(gvjs_Wp, gvjs_Vp);
gvjs_Wp.prototype.tm = gvjs_Up;
var gvjs_U = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            void 0 !== d && (c.fQ = d);
            return c
        }
    }(gvjs_Wp),
    gvjs_Xp = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = String(c);
            if (!c) return "";
            c = new b(c);
            void 0 !== d && (c.fQ = d);
            return c
        }
    }(gvjs_Wp);
var gvjs_Yp = {
    s: function(a, b, c) {
        return isNaN(c) || "" == c || a.length >= Number(c) ? a : a = -1 < b.indexOf("-", 0) ? a + gvjs_Jh(" ", Number(c) - a.length) : gvjs_Jh(" ", Number(c) - a.length) + a
    },
    f: function(a, b, c, d, e) {
        d = a.toString();
        isNaN(e) || "" == e || (d = parseFloat(a).toFixed(e));
        var f = 0 > Number(a) ? "-" : 0 <= b.indexOf("+") ? "+" : 0 <= b.indexOf(" ") ? " " : "";
        0 <= Number(a) && (d = f + d);
        if (isNaN(c) || d.length >= Number(c)) return d;
        d = isNaN(e) ? Math.abs(Number(a)).toString() : Math.abs(Number(a)).toFixed(e);
        a = Number(c) - d.length - f.length;
        0 <= b.indexOf("-",
            0) ? d = f + d + gvjs_Jh(" ", a) : (b = 0 <= b.indexOf("0", 0) ? "0" : " ", d = f + gvjs_Jh(b, a) + d);
        return d
    },
    d: function(a, b, c, d, e, f, g, h) {
        return gvjs_Yp.f(parseInt(a, 10), b, c, d, 0, f, g, h)
    }
};
gvjs_Yp.i = gvjs_Yp.d;
gvjs_Yp.u = gvjs_Yp.d;
gvjs_Ip(["A", "AREA", gvjs_kp, "HEAD", gvjs_Oa, "LINK", "MENU", "META", "OPTGROUP", "OPTION", "PROGRESS", gvjs_bb, gvjs_9a, gvjs_$a, gvjs_lp, "TITLE", "TRACK"]);
var gvjs_Bda = gvjs_s.requestAnimationFrame || gvjs_s.mozRequestAnimationFrame || gvjs_s.webkitRequestAnimationFrame || gvjs_s.msRequestAnimationFrame || function(a) {
    return gvjs_s.setTimeout(function() {
        return a.call(this, Date.now())
    }, 1E3 / 60)
};

function gvjs_Zp(a) {
    gvjs_L.call(this);
    this.XI = a
}
gvjs_r(gvjs_Zp, gvjs_L);
gvjs_Zp.prototype.ar = gvjs_p(31);
gvjs_Zp.prototype.dispatchEvent = function(a, b) {
    gvjs_N(this.XI, a, void 0 === b ? null : b)
};
gvjs_Zp.prototype.J = function() {
    this.XI = null;
    gvjs_L.prototype.J.call(this)
};

function gvjs__p(a, b, c, d, e) {
    if (null == a || null == b) null == c && (c = e), c = Math.max(0, d - c), null == a && null == b ? a = b = c / 2 : null == a ? a = Math.max(0, c - b) : b = Math.max(0, c - a);
    c = Math.max(0, Math.round(d - (a + b)));
    a = Math.round(a);
    d = Math.min(d, a + c);
    c = d - a;
    return {
        before: a,
        after: d,
        size: c
    }
}

function gvjs_0p(a, b, c) {
    var d = a / 1.618,
        e = a - b * (1.618 - 1),
        f = b / 1.618,
        g = b - a * (1.618 - 1);
    a = gvjs__p(c.left, c.right, c.width, a, Math.round(d > e ? d : (d + 2 * e) / 3));
    b = gvjs__p(c.top, c.bottom, c.height, b, Math.round(f > g ? f : (f + 2 * g) / 3));
    return {
        left: a.before,
        right: a.after,
        width: a.size,
        top: b.before,
        bottom: b.after,
        height: b.size
    }
};