/*

 Copyright 2021 Google LLC
 This code is released under the MIT license.
 SPDX-License-Identifier: MIT

*/
/*

 SPDX-License-Identifier: Apache-2.0
*/
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
/*

 Copyright 2021 Google LLC
 This code is released under the MIT license.
 SPDX-License-Identifier: MIT
*/
var gvjs_aa = " does not match type ",
    gvjs_ba = ' id="',
    gvjs_ca = " must be of type '",
    gvjs_da = ' nonce="',
    gvjs_ea = "#000000",
    gvjs_fa = "#808080",
    gvjs_ga = "#ffffff",
    gvjs_ha = "&lt;",
    gvjs_ia = "&quot;",
    gvjs_ja = ", ",
    gvjs_ka = ', for column "',
    gvjs_la = ".format",
    gvjs_ma = "0000000000000000",
    gvjs_a = "</div>",
    gvjs_na = "Android",
    gvjs_oa = "AnnotatedTimeLine",
    gvjs_pa = "AreaChart",
    gvjs_qa = "AreaChart-stacked",
    gvjs_ra = "August",
    gvjs_sa = "BarChart",
    gvjs_ta = "BubbleChart",
    gvjs_ua = "CSSStyleDeclaration",
    gvjs_va = "CandlestickChart",
    gvjs_wa =
    "Clobbering detected",
    gvjs_xa = "Column ",
    gvjs_ya = "ColumnChart",
    gvjs_za = "ComboChart",
    gvjs_Aa = "Container is not defined",
    gvjs_Ba = "Custom response handler must be a function.",
    gvjs_b = "DIV",
    gvjs_Ca = "December",
    gvjs_Da = "Edge",
    gvjs_Ea = "Element",
    gvjs_Fa = "February",
    gvjs_Ga = "Friday",
    gvjs_Ha = "Gauge",
    gvjs_Ia = "GeoChart",
    gvjs_Ja = "HH:mm",
    gvjs_Ka = "HH:mm:ss",
    gvjs_La = "HH:mm:ss.SSS",
    gvjs_Ma = "Histogram",
    gvjs_Na = "IFRAME",
    gvjs_Oa = "INPUT",
    gvjs_Pa = "ImageRadarChart",
    gvjs_Qa = "ImageSparkLine",
    gvjs_Ra = "Inconsistent use of percent/permill characters",
    gvjs_Sa = "Invalid DataView column type.",
    gvjs_Ta = "Invalid data table format: column #",
    gvjs_Ua = "Invalid value for numOrArray: ",
    gvjs_Va = "January",
    gvjs_Wa = "LineChart",
    gvjs_Xa = "Map",
    gvjs_Ya = "May",
    gvjs_Za = "Min value must be less than max value",
    gvjs__a = "Monday",
    gvjs_0a = "MotionChart",
    gvjs_1a = "Must be overridden",
    gvjs_2a = "Node",
    gvjs_3a = "November",
    gvjs_4a = "OBJECT",
    gvjs_5a = "October",
    gvjs_6a = "OrgChart",
    gvjs_7a = "PieChart",
    gvjs_8a = "Request timed out",
    gvjs_9a = "SELECT",
    gvjs_$a = "SOURCE",
    gvjs_ab = "SPAN",
    gvjs_bb =
    "STYLE",
    gvjs_cb = "Saturday",
    gvjs_db = "ScatterChart",
    gvjs_eb = "September",
    gvjs_fb = "SteppedAreaChart",
    gvjs_gb = "Sunday",
    gvjs_hb = "Symbol.asyncIterator",
    gvjs_ib = "Symbol.iterator",
    gvjs_jb = "TABLE",
    gvjs_kb = "TBODY",
    gvjs_lb = "TD",
    gvjs_mb = "Table",
    gvjs_nb = "Thursday",
    gvjs_ob = "Timeline",
    gvjs_pb = "Too many percent/permill",
    gvjs_qb = "TreeMap",
    gvjs_rb = "Tuesday",
    gvjs_sb = "Type mismatch. Value ",
    gvjs_tb = "Wednesday",
    gvjs_ub = "WordTree",
    gvjs_vb = "_bar_format_old_value",
    gvjs_wb = "about:invalid#zClosurez",
    gvjs_xb = "absolute",
    gvjs_yb =
    "addTrendLine",
    gvjs_zb = "annotatedtimeline",
    gvjs_Ab = "annotationchart",
    gvjs_Bb = "aria-hidden",
    gvjs_Cb = "aria-label",
    gvjs_Db = "array",
    gvjs_Eb = "async",
    gvjs_Fb = "attributes",
    gvjs_Gb = "auto",
    gvjs_Hb = "background-color:",
    gvjs_Ib = "bar",
    gvjs_Jb = "block",
    gvjs_Kb = "body",
    gvjs_Lb = "boolean",
    gvjs_Mb = "border",
    gvjs_Nb = "cancel",
    gvjs_Ob = "chart",
    gvjs_Pb = "checked",
    gvjs_Qb = "class",
    gvjs_Rb = "className",
    gvjs_Sb = "color",
    gvjs_Tb = "color:",
    gvjs_Ub = "colspan",
    gvjs_Vb = "column",
    gvjs_Wb = "columnFilters[",
    gvjs_Xb = "complete",
    gvjs_Yb = "controls",
    gvjs_Zb = "corechart",
    gvjs__b = "data-",
    gvjs_0b = "data-sanitizer-",
    gvjs_1b = "date",
    gvjs_2b = "datetime",
    gvjs_3b = "decimal",
    gvjs_4b = "disabled",
    gvjs_5b = "div",
    gvjs_6b = "domainAxis",
    gvjs_7b = "error",
    gvjs_8b = "false",
    gvjs_9b = "full",
    gvjs_c = "function",
    gvjs_$b = "geochart",
    gvjs_ac = "getAttribute",
    gvjs_bc = "getElementsByTagName",
    gvjs_cc = "getPropertyValue",
    gvjs_dc = "google.charts.",
    gvjs_ec = "google.charts.Bar",
    gvjs_fc = "google.charts.Line",
    gvjs_gc = "google.charts.Scatter",
    gvjs_hc = "google.visualization.",
    gvjs_ic = "google.visualization.AnnotatedTimeLine",
    gvjs_jc = "google.visualization.AnnotationChart",
    gvjs_kc = "google.visualization.AreaChart",
    gvjs_lc = "google.visualization.BarChart",
    gvjs_mc = "google.visualization.BubbleChart",
    gvjs_nc = "google.visualization.Bubbles",
    gvjs_oc = "google.visualization.CandlestickChart",
    gvjs_pc = "google.visualization.CategoryFilter",
    gvjs_qc = "google.visualization.ChartRangeFilter",
    gvjs_rc = "google.visualization.ChartRangeFilterUi",
    gvjs_sc = "google.visualization.ClusterChart",
    gvjs_tc = "google.visualization.ColumnChart",
    gvjs_uc = "google.visualization.ColumnSelector",
    gvjs_vc = "google.visualization.ComboChart",
    gvjs_wc = "google.visualization.CoreChart",
    gvjs_xc = "google.visualization.Dashboard",
    gvjs_yc = "google.visualization.DashboardWrapper",
    gvjs_zc = "google.visualization.DateRangeFilter",
    gvjs_Ac = "google.visualization.DateRangeFilterUi",
    gvjs_Bc = "google.visualization.Filter",
    gvjs_Cc = "google.visualization.Gantt",
    gvjs_Dc = "google.visualization.Gauge",
    gvjs_Ec = "google.visualization.GeoChart",
    gvjs_Fc = "google.visualization.GeoMap",
    gvjs_Gc = "google.visualization.HeadlessUi",
    gvjs_Hc =
    "google.visualization.HelloWorld",
    gvjs_Ic = "google.visualization.Histogram",
    gvjs_Jc = "google.visualization.ImageAreaChart",
    gvjs_Kc = "google.visualization.ImageBarChart",
    gvjs_Lc = "google.visualization.ImageCandlestickChart",
    gvjs_Mc = "google.visualization.ImageChart",
    gvjs_Nc = "google.visualization.ImageLineChart",
    gvjs_Oc = "google.visualization.ImagePieChart",
    gvjs_Pc = "google.visualization.ImageSparkLine",
    gvjs_Qc = "google.visualization.LineChart",
    gvjs_Rc = "google.visualization.Map",
    gvjs_Sc = "google.visualization.Matrix",
    gvjs_Tc = "google.visualization.MotionChart",
    gvjs_Uc = "google.visualization.NumberFormat",
    gvjs_Vc = "google.visualization.NumberRangeFilter",
    gvjs_Wc = "google.visualization.NumberRangeSetter",
    gvjs_Xc = "google.visualization.NumberRangeUi",
    gvjs_Yc = "google.visualization.Operator",
    gvjs_Zc = "google.visualization.OrgChart",
    gvjs__c = "google.visualization.PieChart",
    gvjs_0c = "google.visualization.Query",
    gvjs_1c = "google.visualization.RangeSelector",
    gvjs_2c = "google.visualization.Sankey",
    gvjs_3c = "google.visualization.ScatterChart",
    gvjs_4c = "google.visualization.SelectorUi",
    gvjs_5c = "google.visualization.SparklineChart",
    gvjs_6c = "google.visualization.SteppedAreaChart",
    gvjs_7c = "google.visualization.Streamgraph",
    gvjs_8c = "google.visualization.StringFilter",
    gvjs_9c = "google.visualization.StringFilterUi",
    gvjs_$c = "google.visualization.Sunburst",
    gvjs_ad = "google.visualization.Table",
    gvjs_bd = "google.visualization.Timeline",
    gvjs_cd = "google.visualization.TreeMap",
    gvjs_dd = "google.visualization.VegaChart",
    gvjs_ed = "google.visualization.Version",
    gvjs_fd = "google.visualization.WordTree",
    gvjs_gd = "google.visualization.WordcloudChart",
    gvjs_hd = "hasAttribute",
    gvjs_id = "hasLabelsColumn",
    gvjs_jd = "height",
    gvjs_kd = "hidden",
    gvjs_ld = "http://www.w3.org/1999/xhtml",
    gvjs_md = "https:",
    gvjs_nd = "id",
    gvjs_od = "imagechart",
    gvjs_pd = "keypress",
    gvjs_qd = "label",
    gvjs_rd = "latlng",
    gvjs_sd = "left",
    gvjs_d = "line",
    gvjs_td = "ltr",
    gvjs_ud = "makeRequest",
    gvjs_vd = "markers",
    gvjs_wd = "max",
    gvjs_xd = "maxValue",
    gvjs_yd = "medium",
    gvjs_zd = "min",
    gvjs_Ad = "minValue",
    gvjs_Bd = "motionchart",
    gvjs_Cd =
    "mouseout",
    gvjs_Dd = "mouseover",
    gvjs_Ed = "msMatchesSelector",
    gvjs_Fd = "multiple",
    gvjs_Gd = "namespaceURI",
    gvjs_Hd = "nodeName",
    gvjs_Id = "nodeType",
    gvjs_Jd = "nonce",
    gvjs_e = "none",
    gvjs_Kd = "null",
    gvjs_f = "number",
    gvjs_g = "object",
    gvjs_Ld = "orgchart",
    gvjs_Md = "pattern",
    gvjs_Nd = "percent",
    gvjs_Od = "placeholder",
    gvjs_Pd = "position",
    gvjs_Qd = "prefix",
    gvjs_h = "ready",
    gvjs_Rd = "regioncode",
    gvjs_Sd = "regions",
    gvjs_Td = "relative",
    gvjs_Ud = "removeAttribute",
    gvjs_i = "right",
    gvjs_Vd = "role",
    gvjs_Wd = "row",
    gvjs_Xd = "rows",
    gvjs_Yd = "rowspan",
    gvjs_Zd = "rtl",
    gvjs_j = "scatter",
    gvjs_k = "select",
    gvjs__d = "selected",
    gvjs_0d = "setAttribute",
    gvjs_1d = "short",
    gvjs_2d = "span",
    gvjs_l = "start",
    gvjs_3d = "statechange",
    gvjs_4d = "step",
    gvjs_m = "string",
    gvjs_5d = "stringify",
    gvjs_6d = "style",
    gvjs_7d = "suffix",
    gvjs_8d = "table",
    gvjs_9d = "target",
    gvjs_$d = "targetAxis",
    gvjs_n = "text",
    gvjs_ae = "timeline",
    gvjs_be = "timeofday",
    gvjs_ce = "title",
    gvjs_de = "tooltip",
    gvjs_ee = "transparent",
    gvjs_fe = "true",
    gvjs_ge = "type",
    gvjs_he = "unhandledrejection",
    gvjs_ie = "vAxis",
    gvjs_je = "valign",
    gvjs_o =
    "value",
    gvjs_ke = "warning",
    gvjs_le = "width",
    gvjs_me = "withCredentials",
    gvjs_ne = "wordtree",
    gvjs_oe = "{1} 'at' {0}",
    gvjs_pe = "{1}, {0}",
    gvjs_, gvjs_qe = [];

function gvjs_p(a) {
    return function() {
        return gvjs_qe[a].apply(this, arguments)
    }
}

function gvjs_re(a) {
    var b = 0;
    return function() {
        return b < a.length ? {
            done: !1,
            value: a[b++]
        } : {
            done: !0
        }
    }
}
var gvjs_se = typeof Object.defineProperties == gvjs_c ? Object.defineProperty : function(a, b, c) {
    if (a == Array.prototype || a == Object.prototype) return a;
    a[b] = c.value;
    return a
};

function gvjs_aaa(a) {
    a = [gvjs_g == typeof globalThis && globalThis, a, gvjs_g == typeof window && window, gvjs_g == typeof self && self, gvjs_g == typeof global && global];
    for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c
    }
    throw Error("Cannot find global object");
}
var gvjs_te = gvjs_aaa(this);

function gvjs_ue(a, b) {
    if (b) a: {
        var c = gvjs_te;a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
            var e = a[d];
            if (!(e in c)) break a;
            c = c[e]
        }
        a = a[a.length - 1];d = c[a];b = b(d);b != d && null != b && gvjs_se(c, a, {
            configurable: !0,
            writable: !0,
            value: b
        })
    }
}
gvjs_ue("Symbol", function(a) {
    function b(f) {
        if (this instanceof b) throw new TypeError("Symbol is not a constructor");
        return new c(d + (f || "") + "_" + e++, f)
    }

    function c(f, g) {
        this.i$ = f;
        gvjs_se(this, "description", {
            configurable: !0,
            writable: !0,
            value: g
        })
    }
    if (a) return a;
    c.prototype.toString = function() {
        return this.i$
    };
    var d = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
        e = 0;
    return b
});
gvjs_ue(gvjs_ib, function(a) {
    if (a) return a;
    a = Symbol(gvjs_ib);
    for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
        var d = gvjs_te[b[c]];
        typeof d === gvjs_c && typeof d.prototype[a] != gvjs_c && gvjs_se(d.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return gvjs_ve(gvjs_re(this))
            }
        })
    }
    return a
});
gvjs_ue(gvjs_hb, function(a) {
    return a ? a : Symbol(gvjs_hb)
});

function gvjs_ve(a) {
    a = {
        next: a
    };
    a[Symbol.iterator] = function() {
        return this
    };
    return a
}

function gvjs_q(a) {
    var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
    if (b) return b.call(a);
    if (typeof a.length == gvjs_f) return {
        next: gvjs_re(a)
    };
    throw Error(String(a) + " is not an iterable or ArrayLike");
}

function gvjs_we(a) {
    if (!(a instanceof Array)) {
        a = gvjs_q(a);
        for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
        a = c
    }
    return a
}

function gvjs_xe(a, b) {
    return Object.prototype.hasOwnProperty.call(a, b)
}
var gvjs_baa = typeof Object.assign == gvjs_c ? Object.assign : function(a, b) {
    for (var c = 1; c < arguments.length; c++) {
        var d = arguments[c];
        if (d)
            for (var e in d) gvjs_xe(d, e) && (a[e] = d[e])
    }
    return a
};
gvjs_ue("Object.assign", function(a) {
    return a || gvjs_baa
});
var gvjs_caa = typeof Object.create == gvjs_c ? Object.create : function(a) {
        function b() {}
        b.prototype = a;
        return new b
    },
    gvjs_ye;
if (typeof Object.setPrototypeOf == gvjs_c) gvjs_ye = Object.setPrototypeOf;
else {
    var gvjs_ze;
    a: {
        var gvjs_daa = {
                a: !0
            },
            gvjs_Ae = {};
        try {
            gvjs_Ae.__proto__ = gvjs_daa;
            gvjs_ze = gvjs_Ae.a;
            break a
        } catch (a) {}
        gvjs_ze = !1
    }
    gvjs_ye = gvjs_ze ? function(a, b) {
        a.__proto__ = b;
        if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
        return a
    } : null
}
var gvjs_Be = gvjs_ye;

function gvjs_r(a, b) {
    a.prototype = gvjs_caa(b.prototype);
    a.prototype.constructor = a;
    if (gvjs_Be) gvjs_Be(a, b);
    else
        for (var c in b)
            if ("prototype" != c)
                if (Object.defineProperties) {
                    var d = Object.getOwnPropertyDescriptor(b, c);
                    d && Object.defineProperty(a, c, d)
                } else a[c] = b[c];
    a.G = b.prototype
}

function gvjs_Ce() {
    for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
    return b
}
gvjs_ue("Promise", function(a) {
    function b(g) {
        this.V = 0;
        this.Eh = void 0;
        this.oz = [];
        this.k5 = !1;
        var h = this.nQ();
        try {
            g(h.resolve, h.reject)
        } catch (k) {
            h.reject(k)
        }
    }

    function c() {
        this.Jq = null
    }

    function d(g) {
        return g instanceof b ? g : new b(function(h) {
            h(g)
        })
    }
    if (a) return a;
    c.prototype.c0 = function(g) {
        if (null == this.Jq) {
            this.Jq = [];
            var h = this;
            this.d0(function() {
                h.Oda()
            })
        }
        this.Jq.push(g)
    };
    var e = gvjs_te.setTimeout;
    c.prototype.d0 = function(g) {
        e(g, 0)
    };
    c.prototype.Oda = function() {
        for (; this.Jq && this.Jq.length;) {
            var g = this.Jq;
            this.Jq = [];
            for (var h = 0; h < g.length; ++h) {
                var k = g[h];
                g[h] = null;
                try {
                    k()
                } catch (l) {
                    this.hba(l)
                }
            }
        }
        this.Jq = null
    };
    c.prototype.hba = function(g) {
        this.d0(function() {
            throw g;
        })
    };
    b.prototype.nQ = function() {
        function g(l) {
            return function(m) {
                k || (k = !0, l.call(h, m))
            }
        }
        var h = this,
            k = !1;
        return {
            resolve: g(this.Dka),
            reject: g(this.nV)
        }
    };
    b.prototype.Dka = function(g) {
        if (g === this) this.nV(new TypeError("A Promise cannot resolve to itself"));
        else if (g instanceof b) this.pla(g);
        else {
            a: switch (typeof g) {
                case gvjs_g:
                    var h = null != g;
                    break a;
                case gvjs_c:
                    h = !0;
                    break a;
                default:
                    h = !1
            }
            h ? this.Cka(g) : this.f3(g)
        }
    };
    b.prototype.Cka = function(g) {
        var h = void 0;
        try {
            h = g.then
        } catch (k) {
            this.nV(k);
            return
        }
        typeof h == gvjs_c ? this.qla(h, g) : this.f3(g)
    };
    b.prototype.nV = function(g) {
        this.z8(2, g)
    };
    b.prototype.f3 = function(g) {
        this.z8(1, g)
    };
    b.prototype.z8 = function(g, h) {
        if (0 != this.V) throw Error("Cannot settle(" + g + gvjs_ja + h + "): Promise already settled in state" + this.V);
        this.V = g;
        this.Eh = h;
        2 === this.V && this.Tka();
        this.Qda()
    };
    b.prototype.Tka = function() {
        var g = this;
        e(function() {
            if (g.eja()) {
                var h =
                    gvjs_te.console;
                "undefined" !== typeof h && h.error(g.Eh)
            }
        }, 1)
    };
    b.prototype.eja = function() {
        if (this.k5) return !1;
        var g = gvjs_te.CustomEvent,
            h = gvjs_te.Event,
            k = gvjs_te.dispatchEvent;
        if ("undefined" === typeof k) return !0;
        typeof g === gvjs_c ? g = new g(gvjs_he, {
            cancelable: !0
        }) : typeof h === gvjs_c ? g = new h(gvjs_he, {
            cancelable: !0
        }) : (g = gvjs_te.document.createEvent("CustomEvent"), g.initCustomEvent(gvjs_he, !1, !0, g));
        g.promise = this;
        g.reason = this.Eh;
        return k(g)
    };
    b.prototype.Qda = function() {
        if (null != this.oz) {
            for (var g = 0; g < this.oz.length; ++g) f.c0(this.oz[g]);
            this.oz = null
        }
    };
    var f = new c;
    b.prototype.pla = function(g) {
        var h = this.nQ();
        g.SH(h.resolve, h.reject)
    };
    b.prototype.qla = function(g, h) {
        var k = this.nQ();
        try {
            g.call(h, k.resolve, k.reject)
        } catch (l) {
            k.reject(l)
        }
    };
    b.prototype.then = function(g, h) {
        function k(p, q) {
            return typeof p == gvjs_c ? function(r) {
                try {
                    l(p(r))
                } catch (t) {
                    m(t)
                }
            } : q
        }
        var l, m, n = new b(function(p, q) {
            l = p;
            m = q
        });
        this.SH(k(g, l), k(h, m));
        return n
    };
    b.prototype.catch = function(g) {
        return this.then(void 0, g)
    };
    b.prototype.SH = function(g, h) {
        function k() {
            switch (l.V) {
                case 1:
                    g(l.Eh);
                    break;
                case 2:
                    h(l.Eh);
                    break;
                default:
                    throw Error("Unexpected state: " + l.V);
            }
        }
        var l = this;
        null == this.oz ? f.c0(k) : this.oz.push(k);
        this.k5 = !0
    };
    b.resolve = d;
    b.reject = function(g) {
        return new b(function(h, k) {
            k(g)
        })
    };
    b.race = function(g) {
        return new b(function(h, k) {
            for (var l = gvjs_q(g), m = l.next(); !m.done; m = l.next()) d(m.value).SH(h, k)
        })
    };
    b.all = function(g) {
        var h = gvjs_q(g),
            k = h.next();
        return k.done ? d([]) : new b(function(l, m) {
            function n(r) {
                return function(t) {
                    p[r] = t;
                    q--;
                    0 == q && l(p)
                }
            }
            var p = [],
                q = 0;
            do p.push(void 0), q++, d(k.value).SH(n(p.length -
                1), m), k = h.next(); while (!k.done)
        })
    };
    return b
});

function gvjs_De(a, b, c) {
    a instanceof String && (a = String(a));
    for (var d = a.length, e = 0; e < d; e++) {
        var f = a[e];
        if (b.call(c, f, e, a)) return {
            sc: e,
            v: f
        }
    }
    return {
        sc: -1,
        v: void 0
    }
}
gvjs_ue("Array.prototype.find", function(a) {
    return a ? a : function(b, c) {
        return gvjs_De(this, b, c).v
    }
});
gvjs_ue("WeakMap", function(a) {
    function b(k) {
        this.vd = (h += Math.random() + 1).toString();
        if (k) {
            k = gvjs_q(k);
            for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
        }
    }

    function c() {}

    function d(k) {
        var l = typeof k;
        return l === gvjs_g && null !== k || l === gvjs_c
    }

    function e(k) {
        if (!gvjs_xe(k, g)) {
            var l = new c;
            gvjs_se(k, g, {
                value: l
            })
        }
    }

    function f(k) {
        var l = Object[k];
        l && (Object[k] = function(m) {
            if (m instanceof c) return m;
            Object.isExtensible(m) && e(m);
            return l(m)
        })
    }
    if (function() {
            if (!a || !Object.seal) return !1;
            try {
                var k = Object.seal({}),
                    l = Object.seal({}),
                    m = new a([
                        [k, 2],
                        [l, 3]
                    ]);
                if (2 != m.get(k) || 3 != m.get(l)) return !1;
                m.delete(k);
                m.set(l, 4);
                return !m.has(k) && 4 == m.get(l)
            } catch (n) {
                return !1
            }
        }()) return a;
    var g = "$jscomp_hidden_" + Math.random();
    f("freeze");
    f("preventExtensions");
    f("seal");
    var h = 0;
    b.prototype.set = function(k, l) {
        if (!d(k)) throw Error("Invalid WeakMap key");
        e(k);
        if (!gvjs_xe(k, g)) throw Error("WeakMap key fail: " + k);
        k[g][this.vd] = l;
        return this
    };
    b.prototype.get = function(k) {
        return d(k) && gvjs_xe(k, g) ? k[g][this.vd] : void 0
    };
    b.prototype.has =
        function(k) {
            return d(k) && gvjs_xe(k, g) && gvjs_xe(k[g], this.vd)
        };
    b.prototype.delete = function(k) {
        return d(k) && gvjs_xe(k, g) && gvjs_xe(k[g], this.vd) ? delete k[g][this.vd] : !1
    };
    return b
});
gvjs_ue(gvjs_Xa, function(a) {
    function b() {
        var h = {};
        return h.ff = h.next = h.head = h
    }

    function c(h, k) {
        var l = h.vb;
        return gvjs_ve(function() {
            if (l) {
                for (; l.head != h.vb;) l = l.ff;
                for (; l.next != l.head;) return l = l.next, {
                    done: !1,
                    value: k(l)
                };
                l = null
            }
            return {
                done: !0,
                value: void 0
            }
        })
    }

    function d(h, k) {
        var l = k && typeof k;
        l == gvjs_g || l == gvjs_c ? f.has(k) ? l = f.get(k) : (l = "" + ++g, f.set(k, l)) : l = "p_" + k;
        var m = h.qa[l];
        if (m && gvjs_xe(h.qa, l))
            for (h = 0; h < m.length; h++) {
                var n = m[h];
                if (k !== k && n.key !== n.key || k === n.key) return {
                    id: l,
                    list: m,
                    index: h,
                    Ob: n
                }
            }
        return {
            id: l,
            list: m,
            index: -1,
            Ob: void 0
        }
    }

    function e(h) {
        this.qa = {};
        this.vb = b();
        this.size = 0;
        if (h) {
            h = gvjs_q(h);
            for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
        }
    }
    if (function() {
            if (!a || typeof a != gvjs_c || !a.prototype.entries || typeof Object.seal != gvjs_c) return !1;
            try {
                var h = Object.seal({
                        x: 4
                    }),
                    k = new a(gvjs_q([
                        [h, "s"]
                    ]));
                if ("s" != k.get(h) || 1 != k.size || k.get({
                        x: 4
                    }) || k.set({
                        x: 4
                    }, "t") != k || 2 != k.size) return !1;
                var l = k.entries(),
                    m = l.next();
                if (m.done || m.value[0] != h || "s" != m.value[1]) return !1;
                m = l.next();
                return m.done || 4 != m.value[0].x ||
                    "t" != m.value[1] || !l.next().done ? !1 : !0
            } catch (n) {
                return !1
            }
        }()) return a;
    var f = new WeakMap;
    e.prototype.set = function(h, k) {
        h = 0 === h ? 0 : h;
        var l = d(this, h);
        l.list || (l.list = this.qa[l.id] = []);
        l.Ob ? l.Ob.value = k : (l.Ob = {
            next: this.vb,
            ff: this.vb.ff,
            head: this.vb,
            key: h,
            value: k
        }, l.list.push(l.Ob), this.vb.ff.next = l.Ob, this.vb.ff = l.Ob, this.size++);
        return this
    };
    e.prototype.delete = function(h) {
        h = d(this, h);
        return h.Ob && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this.qa[h.id], h.Ob.ff.next = h.Ob.next, h.Ob.next.ff =
            h.Ob.ff, h.Ob.head = null, this.size--, !0) : !1
    };
    e.prototype.clear = function() {
        this.qa = {};
        this.vb = this.vb.ff = b();
        this.size = 0
    };
    e.prototype.has = function(h) {
        return !!d(this, h).Ob
    };
    e.prototype.get = function(h) {
        return (h = d(this, h).Ob) && h.value
    };
    e.prototype.entries = function() {
        return c(this, function(h) {
            return [h.key, h.value]
        })
    };
    e.prototype.keys = function() {
        return c(this, function(h) {
            return h.key
        })
    };
    e.prototype.values = function() {
        return c(this, function(h) {
            return h.value
        })
    };
    e.prototype.forEach = function(h, k) {
        for (var l = this.entries(),
                m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
    };
    e.prototype[Symbol.iterator] = e.prototype.entries;
    var g = 0;
    return e
});
gvjs_ue("Math.trunc", function(a) {
    return a ? a : function(b) {
        b = Number(b);
        if (isNaN(b) || Infinity === b || -Infinity === b || 0 === b) return b;
        var c = Math.floor(Math.abs(b));
        return 0 > b ? -c : c
    }
});
gvjs_ue("Number.isFinite", function(a) {
    return a ? a : function(b) {
        return typeof b !== gvjs_f ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
    }
});
gvjs_ue("Number.isNaN", function(a) {
    return a ? a : function(b) {
        return typeof b === gvjs_f && isNaN(b)
    }
});

function gvjs_Ee(a, b) {
    a instanceof String && (a += "");
    var c = 0,
        d = !1,
        e = {
            next: function() {
                if (!d && c < a.length) {
                    var f = c++;
                    return {
                        value: b(f, a[f]),
                        done: !1
                    }
                }
                d = !0;
                return {
                    done: !0,
                    value: void 0
                }
            }
        };
    e[Symbol.iterator] = function() {
        return e
    };
    return e
}
gvjs_ue("Array.prototype.entries", function(a) {
    return a ? a : function() {
        return gvjs_Ee(this, function(b, c) {
            return [b, c]
        })
    }
});
gvjs_ue("Array.prototype.keys", function(a) {
    return a ? a : function() {
        return gvjs_Ee(this, function(b) {
            return b
        })
    }
});
gvjs_ue("Array.from", function(a) {
    return a ? a : function(b, c, d) {
        c = null != c ? c : function(h) {
            return h
        };
        var e = [],
            f = "undefined" != typeof Symbol && Symbol.iterator && b[Symbol.iterator];
        if (typeof f == gvjs_c) {
            b = f.call(b);
            for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
        } else
            for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
        return e
    }
});
gvjs_ue("Number.isInteger", function(a) {
    return a ? a : function(b) {
        return Number.isFinite(b) ? b === Math.floor(b) : !1
    }
});
gvjs_ue("Array.prototype.values", function(a) {
    return a ? a : function() {
        return gvjs_Ee(this, function(b, c) {
            return c
        })
    }
});
gvjs_ue("Array.prototype.fill", function(a) {
    return a ? a : function(b, c, d) {
        var e = this.length || 0;
        0 > c && (c = Math.max(0, e + c));
        if (null == d || d > e) d = e;
        d = Number(d);
        0 > d && (d = Math.max(0, e + d));
        for (c = Number(c || 0); c < d; c++) this[c] = b;
        return this
    }
});

function gvjs_Fe(a) {
    return a ? a : Array.prototype.fill
}
gvjs_ue("Int8Array.prototype.fill", gvjs_Fe);
gvjs_ue("Uint8Array.prototype.fill", gvjs_Fe);
gvjs_ue("Uint8ClampedArray.prototype.fill", gvjs_Fe);
gvjs_ue("Int16Array.prototype.fill", gvjs_Fe);
gvjs_ue("Uint16Array.prototype.fill", gvjs_Fe);
gvjs_ue("Int32Array.prototype.fill", gvjs_Fe);
gvjs_ue("Uint32Array.prototype.fill", gvjs_Fe);
gvjs_ue("Float32Array.prototype.fill", gvjs_Fe);
gvjs_ue("Float64Array.prototype.fill", gvjs_Fe);
gvjs_ue("Set", function(a) {
    function b(c) {
        this.ma = new Map;
        if (c) {
            c = gvjs_q(c);
            for (var d; !(d = c.next()).done;) this.add(d.value)
        }
        this.size = this.ma.size
    }
    if (function() {
            if (!a || typeof a != gvjs_c || !a.prototype.entries || typeof Object.seal != gvjs_c) return !1;
            try {
                var c = Object.seal({
                        x: 4
                    }),
                    d = new a(gvjs_q([c]));
                if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                        x: 4
                    }) != d || 2 != d.size) return !1;
                var e = d.entries(),
                    f = e.next();
                if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                f = e.next();
                return f.done || f.value[0] == c || 4 != f.value[0].x ||
                    f.value[1] != f.value[0] ? !1 : e.next().done
            } catch (g) {
                return !1
            }
        }()) return a;
    b.prototype.add = function(c) {
        c = 0 === c ? 0 : c;
        this.ma.set(c, c);
        this.size = this.ma.size;
        return this
    };
    b.prototype.delete = function(c) {
        c = this.ma.delete(c);
        this.size = this.ma.size;
        return c
    };
    b.prototype.clear = function() {
        this.ma.clear();
        this.size = 0
    };
    b.prototype.has = function(c) {
        return this.ma.has(c)
    };
    b.prototype.entries = function() {
        return this.ma.entries()
    };
    b.prototype.values = function() {
        return this.ma.values()
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function(c, d) {
        var e = this;
        this.ma.forEach(function(f) {
            return c.call(d, f, f, e)
        })
    };
    return b
});
gvjs_ue("Object.entries", function(a) {
    return a ? a : function(b) {
        var c = [],
            d;
        for (d in b) gvjs_xe(b, d) && c.push([d, b[d]]);
        return c
    }
});

function gvjs_Ge(a, b, c) {
    if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
    if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
    return a + ""
}
gvjs_ue("String.prototype.endsWith", function(a) {
    return a ? a : function(b, c) {
        var d = gvjs_Ge(this, b, "endsWith");
        b += "";
        void 0 === c && (c = d.length);
        c = Math.max(0, Math.min(c | 0, d.length));
        for (var e = b.length; 0 < e && 0 < c;)
            if (d[--c] != b[--e]) return !1;
        return 0 >= e
    }
});
gvjs_ue("String.prototype.startsWith", function(a) {
    return a ? a : function(b, c) {
        var d = gvjs_Ge(this, b, "startsWith");
        b += "";
        var e = d.length,
            f = b.length;
        c = Math.max(0, Math.min(c | 0, d.length));
        for (var g = 0; g < f && c < e;)
            if (d[c++] != b[g++]) return !1;
        return g >= f
    }
});
gvjs_ue("String.prototype.repeat", function(a) {
    return a ? a : function(b) {
        var c = gvjs_Ge(this, null, "repeat");
        if (0 > b || 1342177279 < b) throw new RangeError("Invalid count value");
        b |= 0;
        for (var d = ""; b;)
            if (b & 1 && (d += c), b >>>= 1) c += c;
        return d
    }
});
gvjs_ue("Object.is", function(a) {
    return a ? a : function(b, c) {
        return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
    }
});
gvjs_ue("Array.prototype.includes", function(a) {
    return a ? a : function(b, c) {
        var d = this;
        d instanceof String && (d = String(d));
        var e = d.length;
        c = c || 0;
        for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0
        }
        return !1
    }
});
gvjs_ue("String.prototype.includes", function(a) {
    return a ? a : function(b, c) {
        return -1 !== gvjs_Ge(this, b, "includes").indexOf(b, c || 0)
    }
});
gvjs_ue("Object.values", function(a) {
    return a ? a : function(b) {
        var c = [],
            d;
        for (d in b) gvjs_xe(b, d) && c.push(b[d]);
        return c
    }
});
gvjs_ue("Math.hypot", function(a) {
    return a ? a : function(b) {
        if (2 > arguments.length) return arguments.length ? Math.abs(arguments[0]) : 0;
        var c, d, e;
        for (c = e = 0; c < arguments.length; c++) e = Math.max(e, Math.abs(arguments[c]));
        if (1E100 < e || 1E-100 > e) {
            if (!e) return e;
            for (c = d = 0; c < arguments.length; c++) {
                var f = Number(arguments[c]) / e;
                d += f * f
            }
            return Math.sqrt(d) * e
        }
        for (c = d = 0; c < arguments.length; c++) f = Number(arguments[c]), d += f * f;
        return Math.sqrt(d)
    }
});
gvjs_ue("Array.prototype.findIndex", function(a) {
    return a ? a : function(b, c) {
        return gvjs_De(this, b, c).sc
    }
});
gvjs_ue("Math.log10", function(a) {
    return a ? a : function(b) {
        return Math.log(b) / Math.LN10
    }
});

function gvjs_He(a) {
    a = Math.trunc(a) || 0;
    0 > a && (a += this.length);
    if (!(0 > a || a >= this.length)) return this[a]
}
gvjs_ue("Array.prototype.at", function(a) {
    return a ? a : gvjs_He
});

function gvjs_Ie(a) {
    return a ? a : gvjs_He
}
gvjs_ue("Int8Array.prototype.at", gvjs_Ie);
gvjs_ue("Uint8Array.prototype.at", gvjs_Ie);
gvjs_ue("Uint8ClampedArray.prototype.at", gvjs_Ie);
gvjs_ue("Int16Array.prototype.at", gvjs_Ie);
gvjs_ue("Uint16Array.prototype.at", gvjs_Ie);
gvjs_ue("Int32Array.prototype.at", gvjs_Ie);
gvjs_ue("Uint32Array.prototype.at", gvjs_Ie);
gvjs_ue("Float32Array.prototype.at", gvjs_Ie);
gvjs_ue("Float64Array.prototype.at", gvjs_Ie);
gvjs_ue("String.prototype.at", function(a) {
    return a ? a : gvjs_He
});
gvjs_ue("Math.cbrt", function(a) {
    return a ? a : function(b) {
        if (0 === b) return b;
        b = Number(b);
        var c = Math.pow(Math.abs(b), 1 / 3);
        return 0 > b ? -c : c
    }
});
gvjs_ue("Math.log2", function(a) {
    return a ? a : function(b) {
        return Math.log(b) / Math.LN2
    }
});
var gvjs_Je = gvjs_Je || {},
    gvjs_s = this || self;

function gvjs_t(a, b, c) {
    a = a.split(".");
    c = c || gvjs_s;
    a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
    for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = b
}

function gvjs_Ke(a, b) {
    a = a.split(".");
    b = b || gvjs_s;
    for (var c = 0; c < a.length; c++)
        if (b = b[a[c]], null == b) return null;
    return b
}

function gvjs_Le(a) {
    a.Fu = void 0;
    a.eb = function() {
        return a.Fu ? a.Fu : a.Fu = new a
    }
}

function gvjs_Me(a) {
    var b = typeof a;
    return b != gvjs_g ? b : a ? Array.isArray(a) ? gvjs_Db : b : gvjs_Kd
}

function gvjs_Ne(a) {
    var b = gvjs_Me(a);
    return b == gvjs_Db || b == gvjs_g && typeof a.length == gvjs_f
}

function gvjs_Oe(a) {
    return gvjs_Pe(a) && typeof a.getFullYear == gvjs_c
}

function gvjs_Pe(a) {
    var b = typeof a;
    return b == gvjs_g && null != a || b == gvjs_c
}

function gvjs_Qe(a) {
    return Object.prototype.hasOwnProperty.call(a, gvjs_Re) && a[gvjs_Re] || (a[gvjs_Re] = ++gvjs_eaa)
}
var gvjs_Re = "closure_uid_" + (1E9 * Math.random() >>> 0),
    gvjs_eaa = 0;

function gvjs_faa(a, b, c) {
    return a.call.apply(a.bind, arguments)
}

function gvjs_gaa(a, b, c) {
    if (!a) throw Error();
    if (2 < arguments.length) {
        var d = Array.prototype.slice.call(arguments, 2);
        return function() {
            var e = Array.prototype.slice.call(arguments);
            Array.prototype.unshift.apply(e, d);
            return a.apply(b, e)
        }
    }
    return function() {
        return a.apply(b, arguments)
    }
}

function gvjs_Se(a, b, c) {
    gvjs_Se = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? gvjs_faa : gvjs_gaa;
    return gvjs_Se.apply(null, arguments)
}

function gvjs_Te(a, b) {
    var c = Array.prototype.slice.call(arguments, 1);
    return function() {
        var d = c.slice();
        d.push.apply(d, arguments);
        return a.apply(this, d)
    }
}

function gvjs_Ue() {
    return Date.now()
}

function gvjs_Ve(a) {
    (0, eval)(a)
}

function gvjs_u(a, b) {
    function c() {}
    c.prototype = b.prototype;
    a.G = b.prototype;
    a.prototype = new c;
    a.prototype.constructor = a;
    a.base = function(d, e, f) {
        for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
        return b.prototype[e].apply(d, g)
    }
}

function gvjs_We(a) {
    return a
};

function gvjs_Xe(a, b) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, gvjs_Xe);
    else {
        var c = Error().stack;
        c && (this.stack = c)
    }
    a && (this.message = String(a));
    void 0 !== b && (this.cause = b)
}
gvjs_u(gvjs_Xe, Error);
gvjs_Xe.prototype.name = "CustomError";
var gvjs_Ye;

function gvjs_Ze(a, b) {
    a = a.split("%s");
    for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
    gvjs_Xe.call(this, c + a[d])
}
gvjs_u(gvjs_Ze, gvjs_Xe);
gvjs_Ze.prototype.name = "AssertionError";

function gvjs__e(a) {
    gvjs_s.setTimeout(function() {
        throw a;
    }, 0)
};

function gvjs_0e(a, b) {
    return 0 == a.lastIndexOf(b, 0)
}

function gvjs_1e(a) {
    return /^[\s\xa0]*$/.test(a)
}
var gvjs_2e = String.prototype.trim ? function(a) {
    return a.trim()
} : function(a) {
    return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
};

function gvjs_3e(a) {
    if (!gvjs_haa.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(gvjs_iaa, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(gvjs_jaa, gvjs_ha)); - 1 != a.indexOf(">") && (a = a.replace(gvjs_kaa, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(gvjs_laa, gvjs_ia)); - 1 != a.indexOf("'") && (a = a.replace(gvjs_maa, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(gvjs_naa, "&#0;"));
    return a
}
var gvjs_iaa = /&/g,
    gvjs_jaa = /</g,
    gvjs_kaa = />/g,
    gvjs_laa = /"/g,
    gvjs_maa = /'/g,
    gvjs_naa = /\x00/g,
    gvjs_haa = /[\x00&<>"']/;

function gvjs_4e(a, b) {
    return -1 != a.indexOf(b)
};
var gvjs_5e, gvjs_6e = gvjs_Ke("CLOSURE_FLAGS"),
    gvjs_7e = gvjs_6e && gvjs_6e[610401301];
gvjs_5e = null != gvjs_7e ? gvjs_7e : !1;

function gvjs_8e() {
    var a = gvjs_s.navigator;
    return a && (a = a.userAgent) ? a : ""
}
var gvjs_9e, gvjs_$e = gvjs_s.navigator;
gvjs_9e = gvjs_$e ? gvjs_$e.userAgentData || null : null;

function gvjs_af(a) {
    return gvjs_5e ? gvjs_9e ? gvjs_9e.brands.some(function(b) {
        return (b = b.brand) && gvjs_4e(b, a)
    }) : !1 : !1
}

function gvjs_bf(a) {
    return gvjs_4e(gvjs_8e(), a)
};

function gvjs_cf() {
    return gvjs_5e ? !!gvjs_9e && 0 < gvjs_9e.brands.length : !1
}

function gvjs_df() {
    return gvjs_cf() ? !1 : gvjs_bf("Opera")
}

function gvjs_ef() {
    return gvjs_cf() ? !1 : gvjs_bf("Trident") || gvjs_bf("MSIE")
}

function gvjs_ff() {
    return gvjs_bf("Firefox") || gvjs_bf("FxiOS")
}

function gvjs_gf() {
    return gvjs_bf("Safari") && !(gvjs_hf() || (gvjs_cf() ? 0 : gvjs_bf("Coast")) || gvjs_df() || (gvjs_cf() ? 0 : gvjs_bf(gvjs_Da)) || (gvjs_cf() ? gvjs_af("Microsoft Edge") : gvjs_bf("Edg/")) || (gvjs_cf() ? gvjs_af("Opera") : gvjs_bf("OPR")) || gvjs_ff() || gvjs_bf("Silk") || gvjs_bf(gvjs_na))
}

function gvjs_hf() {
    return gvjs_cf() ? gvjs_af("Chromium") : (gvjs_bf("Chrome") || gvjs_bf("CriOS")) && !(gvjs_cf() ? 0 : gvjs_bf(gvjs_Da)) || gvjs_bf("Silk")
}

function gvjs_if() {
    return gvjs_bf(gvjs_na) && !(gvjs_hf() || gvjs_ff() || gvjs_df() || gvjs_bf("Silk"))
};

function gvjs_jf() {
    return gvjs_5e ? !!gvjs_9e && !!gvjs_9e.platform : !1
}

function gvjs_kf() {
    return gvjs_bf("iPhone") && !gvjs_bf("iPod") && !gvjs_bf("iPad")
}

function gvjs_lf() {
    return gvjs_kf() || gvjs_bf("iPad") || gvjs_bf("iPod")
}

function gvjs_mf() {
    return gvjs_jf() ? "macOS" === gvjs_9e.platform : gvjs_bf("Macintosh")
};

function gvjs_nf(a) {
    return a[a.length - 1]
}
var gvjs_of = Array.prototype.indexOf ? function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if (typeof a === gvjs_m) return typeof b !== gvjs_m || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    },
    gvjs_oaa = Array.prototype.lastIndexOf ? function(a, b) {
        return Array.prototype.lastIndexOf.call(a, b, a.length - 1)
    } : function(a, b) {
        var c = a.length - 1;
        0 > c && (c = Math.max(0, a.length + c));
        if (typeof a === gvjs_m) return typeof b !== gvjs_m || 1 != b.length ? -1 : a.lastIndexOf(b,
            c);
        for (; 0 <= c; c--)
            if (c in a && a[c] === b) return c;
        return -1
    },
    gvjs_v = Array.prototype.forEach ? function(a, b, c) {
        Array.prototype.forEach.call(a, b, c)
    } : function(a, b, c) {
        for (var d = a.length, e = typeof a === gvjs_m ? a.split("") : a, f = 0; f < d; f++) f in e && b.call(c, e[f], f, a)
    },
    gvjs_pf = Array.prototype.filter ? function(a, b) {
        return Array.prototype.filter.call(a, b, void 0)
    } : function(a, b) {
        for (var c = a.length, d = [], e = 0, f = typeof a === gvjs_m ? a.split("") : a, g = 0; g < c; g++)
            if (g in f) {
                var h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    },
    gvjs_w =
    Array.prototype.map ? function(a, b, c) {
        return Array.prototype.map.call(a, b, c)
    } : function(a, b, c) {
        for (var d = a.length, e = Array(d), f = typeof a === gvjs_m ? a.split("") : a, g = 0; g < d; g++) g in f && (e[g] = b.call(c, f[g], g, a));
        return e
    },
    gvjs_qf = Array.prototype.reduce ? function(a, b, c, d) {
        d && (b = gvjs_Se(b, d));
        return Array.prototype.reduce.call(a, b, c)
    } : function(a, b, c, d) {
        var e = c;
        gvjs_v(a, function(f, g) {
            e = b.call(d, e, f, g, a)
        });
        return e
    },
    gvjs_rf = Array.prototype.some ? function(a, b, c) {
        return Array.prototype.some.call(a, b, c)
    } : function(a,
        b, c) {
        for (var d = a.length, e = typeof a === gvjs_m ? a.split("") : a, f = 0; f < d; f++)
            if (f in e && b.call(c, e[f], f, a)) return !0;
        return !1
    },
    gvjs_sf = Array.prototype.every ? function(a, b, c) {
        return Array.prototype.every.call(a, b, c)
    } : function(a, b, c) {
        for (var d = a.length, e = typeof a === gvjs_m ? a.split("") : a, f = 0; f < d; f++)
            if (f in e && !b.call(c, e[f], f, a)) return !1;
        return !0
    };

function gvjs_tf(a, b) {
    return 0 <= gvjs_of(a, b)
}

function gvjs_uf(a, b) {
    b = gvjs_of(a, b);
    var c;
    (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
    return c
}

function gvjs_vf(a) {
    return Array.prototype.concat.apply([], arguments)
}

function gvjs_wf(a) {
    var b = a.length;
    if (0 < b) {
        for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
        return c
    }
    return []
}

function gvjs_xf(a, b) {
    for (var c = 1; c < arguments.length; c++) {
        var d = arguments[c];
        if (gvjs_Ne(d)) {
            var e = a.length || 0,
                f = d.length || 0;
            a.length = e + f;
            for (var g = 0; g < f; g++) a[e + g] = d[g]
        } else a.push(d)
    }
}

function gvjs_yf(a, b, c) {
    return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
}

function gvjs_zf(a, b, c) {
    function d(l) {
        return gvjs_Pe(l) ? "o" + gvjs_Qe(l) : (typeof l).charAt(0) + l
    }
    b = b || a;
    c = c || d;
    for (var e = 0, f = 0, g = {}; f < a.length;) {
        var h = a[f++],
            k = c(h);
        Object.prototype.hasOwnProperty.call(g, k) || (g[k] = !0, b[e++] = h)
    }
    b.length = e
}

function gvjs_Af(a, b) {
    a.sort(b || gvjs_Bf)
}

function gvjs_Cf(a, b) {
    for (var c = Array(a.length), d = 0; d < a.length; d++) c[d] = {
        index: d,
        value: a[d]
    };
    var e = b || gvjs_Bf;
    gvjs_Af(c, function(f, g) {
        return e(f.value, g.value) || f.index - g.index
    });
    for (b = 0; b < a.length; b++) a[b] = c[b].value
}

function gvjs_Bf(a, b) {
    return a > b ? 1 : a < b ? -1 : 0
}

function gvjs_paa(a, b) {
    return gvjs_vf.apply([], gvjs_w(a, b))
};

function gvjs_Df(a) {
    gvjs_Df[" "](a);
    return a
}
gvjs_Df[" "] = function() {};

function gvjs_Ef(a, b) {
    try {
        return gvjs_Df(a[b]), !0
    } catch (c) {}
    return !1
};
var gvjs_Ff = gvjs_df(),
    gvjs_x = gvjs_ef(),
    gvjs_Gf = gvjs_bf(gvjs_Da),
    gvjs_qaa = gvjs_Gf || gvjs_x,
    gvjs_Hf = gvjs_bf("Gecko") && !(gvjs_4e(gvjs_8e().toLowerCase(), "webkit") && !gvjs_bf(gvjs_Da)) && !(gvjs_bf("Trident") || gvjs_bf("MSIE")) && !gvjs_bf(gvjs_Da),
    gvjs_If = gvjs_4e(gvjs_8e().toLowerCase(), "webkit") && !gvjs_bf(gvjs_Da),
    gvjs_raa = gvjs_If && gvjs_bf("Mobile"),
    gvjs_Jf = gvjs_mf(),
    gvjs_Kf = gvjs_jf() ? "Windows" === gvjs_9e.platform : gvjs_bf("Windows"),
    gvjs_Lf = (gvjs_jf() ? "Linux" === gvjs_9e.platform : gvjs_bf("Linux")) || (gvjs_jf() ?
        "Chrome OS" === gvjs_9e.platform : gvjs_bf("CrOS")),
    gvjs_Mf = gvjs_s.navigator || null;
gvjs_Mf && gvjs_4e(gvjs_Mf.appVersion || "", "X11");
var gvjs_saa = gvjs_jf() ? gvjs_9e.platform === gvjs_na : gvjs_bf(gvjs_na),
    gvjs_taa = gvjs_kf(),
    gvjs_uaa = gvjs_bf("iPad"),
    gvjs_vaa = gvjs_bf("iPod"),
    gvjs_waa = gvjs_lf();
gvjs_4e(gvjs_8e().toLowerCase(), "kaios");

function gvjs_Nf() {
    var a = gvjs_s.document;
    return a ? a.documentMode : void 0
}
var gvjs_Of;
a: {
    var gvjs_Pf = "",
        gvjs_Qf = function() {
            var a = gvjs_8e();
            if (gvjs_Hf) return /rv:([^\);]+)(\)|;)/.exec(a);
            if (gvjs_Gf) return /Edge\/([\d\.]+)/.exec(a);
            if (gvjs_x) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
            if (gvjs_If) return /WebKit\/(\S+)/.exec(a);
            if (gvjs_Ff) return /(?:Version)[ \/]?(\S+)/.exec(a)
        }();gvjs_Qf && (gvjs_Pf = gvjs_Qf ? gvjs_Qf[1] : "");
    if (gvjs_x) {
        var gvjs_Rf = gvjs_Nf();
        if (null != gvjs_Rf && gvjs_Rf > parseFloat(gvjs_Pf)) {
            gvjs_Of = String(gvjs_Rf);
            break a
        }
    }
    gvjs_Of = gvjs_Pf
}
var gvjs_Sf = gvjs_Of;

function gvjs_Tf(a) {
    return Number(gvjs_xaa) >= a
}
var gvjs_Uf;
if (gvjs_s.document && gvjs_x) {
    var gvjs_Vf = gvjs_Nf();
    gvjs_Uf = gvjs_Vf ? gvjs_Vf : parseInt(gvjs_Sf, 10) || void 0
} else gvjs_Uf = void 0;
var gvjs_xaa = gvjs_Uf;
var gvjs_yaa = gvjs_ff(),
    gvjs_zaa = gvjs_kf() || gvjs_bf("iPod"),
    gvjs_Aaa = gvjs_bf("iPad"),
    gvjs_Baa = gvjs_if(),
    gvjs_Wf = gvjs_hf(),
    gvjs_Xf = gvjs_gf() && !gvjs_lf();
var gvjs_Yf = {},
    gvjs_Zf = null;
var gvjs__f = "undefined" !== typeof Uint8Array,
    gvjs_Caa = !gvjs_x && typeof gvjs_s.btoa === gvjs_c;
var gvjs_0f = typeof Symbol === gvjs_c && "symbol" === typeof Symbol() ? Symbol() : void 0;

function gvjs_1f(a, b) {
    if (gvjs_0f) return a[gvjs_0f] |= b;
    if (void 0 !== a.Gu) return a.Gu |= b;
    Object.defineProperties(a, {
        Gu: {
            value: b,
            configurable: !0,
            writable: !0,
            enumerable: !1
        }
    });
    return b
}

function gvjs_2f(a, b) {
    var c = gvjs_3f(a);
    (c & b) !== b && (Object.isFrozen(a) && (a = Array.prototype.slice.call(a)), gvjs_4f(a, c | b));
    return a
}

function gvjs_3f(a) {
    a = gvjs_0f ? a[gvjs_0f] : a.Gu;
    return null == a ? 0 : a
}

function gvjs_4f(a, b) {
    gvjs_0f ? a[gvjs_0f] = b : void 0 !== a.Gu ? a.Gu = b : Object.defineProperties(a, {
        Gu: {
            value: b,
            configurable: !0,
            writable: !0,
            enumerable: !1
        }
    });
    return a
}

function gvjs_Daa(a, b) {
    gvjs_4f(b, (a | 0) & -51)
}

function gvjs_5f(a, b) {
    gvjs_4f(b, (a | 18) & -41)
};
var gvjs_6f = {};

function gvjs_7f(a) {
    return null !== a && typeof a === gvjs_g && !Array.isArray(a) && a.constructor === Object
}
var gvjs_8f, gvjs_9f = Object.freeze(gvjs_4f([], 23));

function gvjs_$f(a) {
    if (a & 2) throw Error();
}

function gvjs_ag(a) {
    var b = a.length;
    (b = b ? a[b - 1] : void 0) && gvjs_7f(b) ? b.g = 1 : (b = {}, a.push((b.g = 1, b)))
};

function gvjs_bg(a) {
    var b = a.zz + a.pt;
    return a.kl || (a.kl = a.rf[b] = {})
}

function gvjs_cg(a, b, c) {
    return -1 === b ? null : b >= a.zz ? a.kl ? a.kl[b] : void 0 : c && a.kl && (c = a.kl[b], null != c) ? c : a.rf[b + a.pt]
}

function gvjs_dg(a, b, c, d) {
    gvjs_$f(gvjs_3f(a.rf));
    return gvjs_eg(a, b, c, d)
}

function gvjs_eg(a, b, c, d) {
    a.W4 && (a.W4 = void 0);
    if (b >= a.zz || d) return gvjs_bg(a)[b] = c, a;
    a.rf[b + a.pt] = c;
    (c = a.kl) && b in c && delete c[b];
    return a
};
var gvjs_fg;

function gvjs_gg(a) {
    switch (typeof a) {
        case gvjs_f:
            return isFinite(a) ? a : String(a);
        case gvjs_g:
            if (a)
                if (Array.isArray(a)) {
                    if (0 !== (gvjs_3f(a) & 128)) return a = Array.prototype.slice.call(a), gvjs_ag(a), a
                } else if (gvjs__f && null != a && a instanceof Uint8Array) {
                if (gvjs_Caa) {
                    for (var b = ""; 10240 < a.length;) b += String.fromCharCode.apply(null, a.subarray(0, 10240)), a = a.subarray(10240);
                    b += String.fromCharCode.apply(null, a);
                    a = btoa(b)
                } else {
                    void 0 === b && (b = 0);
                    if (!gvjs_Zf) {
                        gvjs_Zf = {};
                        for (var c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                                d = ["+/=", "+/", "-_=", "-_.", "-_"], e = 0; 5 > e; e++) {
                            var f = c.concat(d[e].split(""));
                            gvjs_Yf[e] = f;
                            for (var g = 0; g < f.length; g++) {
                                var h = f[g];
                                void 0 === gvjs_Zf[h] && (gvjs_Zf[h] = g)
                            }
                        }
                    }
                    b = gvjs_Yf[b];
                    c = Array(Math.floor(a.length / 3));
                    d = b[64] || "";
                    for (e = f = 0; f < a.length - 2; f += 3) {
                        var k = a[f],
                            l = a[f + 1];
                        h = a[f + 2];
                        g = b[k >> 2];
                        k = b[(k & 3) << 4 | l >> 4];
                        l = b[(l & 15) << 2 | h >> 6];
                        h = b[h & 63];
                        c[e++] = "" + g + k + l + h
                    }
                    g = 0;
                    h = d;
                    switch (a.length - f) {
                        case 2:
                            g = a[f + 1], h = b[(g & 15) << 2] || d;
                        case 1:
                            a = a[f], c[e] = "" + b[a >> 2] + b[(a & 3) << 4 | g >> 4] + h + d
                    }
                    a = c.join("")
                }
                return a
            }
    }
    return a
};

function gvjs_hg(a, b, c, d) {
    if (null != a) {
        if (Array.isArray(a)) a = gvjs_ig(a, b, c, void 0 !== d);
        else if (gvjs_7f(a)) {
            var e = {},
                f;
            for (f in a) e[f] = gvjs_hg(a[f], b, c, d);
            a = e
        } else a = b(a, d);
        return a
    }
}

function gvjs_ig(a, b, c, d) {
    var e = gvjs_3f(a);
    d = d ? !!(e & 16) : void 0;
    a = Array.prototype.slice.call(a);
    for (var f = 0; f < a.length; f++) a[f] = gvjs_hg(a[f], b, c, d);
    c(e, a);
    return a
}

function gvjs_Eaa(a) {
    return a.JT === gvjs_6f ? a.toJSON() : gvjs_gg(a)
}

function gvjs_Faa(a, b) {
    a & 128 && gvjs_ag(b)
};

function gvjs_jg(a, b, c) {
    c = void 0 === c ? gvjs_5f : c;
    if (null != a) {
        if (gvjs__f && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
        if (Array.isArray(a)) {
            var d = gvjs_3f(a);
            if (d & 2) return a;
            if (b && !(d & 32) && (d & 16 || 0 === d)) return gvjs_4f(a, d | 18), a;
            a = gvjs_ig(a, gvjs_jg, d & 4 ? gvjs_5f : c, !0);
            b = gvjs_3f(a);
            b & 4 && b & 2 && Object.freeze(a);
            return a
        }
        return a.JT === gvjs_6f ? gvjs_kg(a) : a
    }
}

function gvjs_lg(a, b, c, d, e, f, g) {
    if (a = a.Iu && a.Iu[c]) {
        d = gvjs_3f(a);
        d & 2 ? d = a : (f = gvjs_w(a, gvjs_kg), gvjs_5f(d, f), Object.freeze(f), d = f);
        gvjs_$f(gvjs_3f(b.rf));
        null == d ? f = gvjs_9f : (f = [], gvjs_1f(f, 1));
        if (null != d) {
            g = !!d.length;
            for (a = 0; a < d.length; a++) {
                var h = d[a];
                g = g && !(gvjs_3f(h.rf) & 2);
                f[a] = h.rf
            }
            f = gvjs_2f(f, (g ? 8 : 0) | 1);
            b.Iu || (b.Iu = {});
            b.Iu[c] = d
        } else b.Iu && (b.Iu[c] = void 0);
        gvjs_eg(b, c, f, e)
    } else gvjs_dg(b, c, gvjs_jg(d, f, g), e)
}

function gvjs_kg(a) {
    if (gvjs_3f(a.rf) & 2) return a;
    a = gvjs_mg(a, !0);
    gvjs_1f(a.rf, 18);
    return a
}

function gvjs_mg(a, b) {
    var c = a.rf,
        d = [];
    gvjs_1f(d, 16);
    var e = a.constructor.yia;
    e && d.push(e);
    e = a.kl;
    if (e) {
        d.length = c.length;
        var f = {};
        d[d.length - 1] = f
    }
    0 !== (gvjs_3f(c) & 128) && gvjs_ag(d);
    b = b || gvjs_3f(a.rf) & 2 ? gvjs_5f : gvjs_Daa;
    f = a.constructor;
    gvjs_fg = d;
    d = new f(d);
    gvjs_fg = void 0;
    a.X4 && (d.X4 = a.X4.slice());
    f = !!(gvjs_3f(c) & 16);
    for (var g = e ? c.length - 1 : c.length, h = 0; h < g; h++) gvjs_lg(a, d, h - a.pt, c[h], !1, f, b);
    if (e)
        for (var k in e) gvjs_lg(a, d, +k, e[k], !0, f, b);
    return d
};

function gvjs_ng(a, b, c, d) {
    null == a && (a = gvjs_fg);
    gvjs_fg = void 0;
    var e = this.constructor.yia;
    if (null == a) {
        a = e ? [e] : [];
        var f = 48;
        var g = !0;
        d && (f |= 128);
        gvjs_4f(a, f)
    } else {
        if (!Array.isArray(a)) throw Error();
        if (e && e !== a[0]) throw Error();
        f = gvjs_1f(a, 0) | 32;
        g = 0 !== (16 & f);
        if (d) {
            if (f |= 128, 0 < a.length) {
                var h = a[a.length - 1];
                if (gvjs_7f(h) && "g" in h) {
                    delete h.g;
                    var k = !0,
                        l;
                    for (l in h) {
                        k = !1;
                        break
                    }
                    k && a.pop()
                }
            }
        } else if (128 & f) throw Error();
        gvjs_4f(a, f)
    }
    this.pt = e ? 0 : -1;
    this.Iu = void 0;
    this.rf = a;
    a: {
        f = this.rf.length;e = f - 1;
        if (f && (f =
                this.rf[e], gvjs_7f(f))) {
            this.kl = f;
            this.zz = e - this.pt;
            break a
        }
        void 0 !== b && -1 < b ? (this.zz = Math.max(b, e + 1 - this.pt), this.kl = void 0) : this.zz = Number.MAX_VALUE
    }
    if (!d && this.kl && "g" in this.kl) throw Error('Unexpected "g" flag in sparse object of message that is not a group type.');
    if (c) {
        b = g && !0;
        d = this.zz;
        var m;
        for (g = 0; g < c.length; g++) e = c[g], e < d ? (e += this.pt, (f = a[e]) ? gvjs_og(f, b) : a[e] = gvjs_9f) : (m || (m = gvjs_bg(this)), (f = m[e]) ? gvjs_og(f, b) : m[e] = gvjs_9f)
    }
}
gvjs_ = gvjs_ng.prototype;
gvjs_.toJSON = function() {
    var a = this.rf;
    return gvjs_8f ? a : gvjs_ig(a, gvjs_Eaa, gvjs_Faa)
};
gvjs_.Ic = function() {
    gvjs_8f = !0;
    try {
        return JSON.stringify(this.toJSON(), gvjs_Gaa)
    } finally {
        gvjs_8f = !1
    }
};
gvjs_.getExtension = function(a) {
    return a.rQ ? a.vJ(this, a.rQ, a.iJ, !0) : a.tsa ? a.vJ(this, a.iJ, !0) : a.vJ(this, a.iJ, a.defaultValue, !0)
};
gvjs_.hasExtension = function(a) {
    a = a.rQ ? a.vJ(this, a.rQ, a.iJ, !0) : a.vJ(this, a.iJ, null, !0);
    return void 0 !== (null === a ? void 0 : a)
};
gvjs_.clone = function() {
    return gvjs_mg(this, !1)
};

function gvjs_og(a, b) {
    if (Array.isArray(a)) {
        var c = gvjs_3f(a),
            d = 1;
        !b || c & 2 || (d |= 16);
        (c & d) !== d && gvjs_4f(a, c | d)
    }
}
gvjs_.JT = gvjs_6f;
gvjs_.toString = function() {
    return this.rf.toString()
};

function gvjs_Gaa(a, b) {
    return gvjs_gg(b)
};
var gvjs_pg;
gvjs_pg = function(a) {
    return !!a && (typeof a === gvjs_g || typeof a === gvjs_c)
};
var gvjs_qg = {
    Ona: gvjs_Lb,
    Qoa: gvjs_f,
    qpa: gvjs_m,
    goa: gvjs_1b,
    hoa: gvjs_2b,
    TIME: "time",
    wpa: gvjs_be,
    eZ: gvjs_c
};

function gvjs_rg() {
    this.Hi = null
}
gvjs_rg.prototype.getColumnIndex = function(a) {
    if (typeof a === gvjs_f) {
        var b = this.getNumberOfColumns();
        return 0 > a || a >= b ? -1 : a
    }
    if (!this.Hi) {
        this.Hi = {};
        b = this.getNumberOfColumns();
        for (var c = 0; c < b; c++) {
            var d = this.getColumnId(c);
            null == d || "" === d || d in this.Hi || (this.Hi[d] = c)
        }
        for (c = 0; c < b; c++) d = this.getColumnLabel(c), null == d || "" === d || d in this.Hi || (this.Hi[d] = c)
    }
    a = this.Hi[a];
    return null == a ? -1 : a
};
gvjs_rg.prototype.getStringValue = function(a, b) {
    var c = this.getColumnType(b);
    if (c !== gvjs_m) throw Error(gvjs_xa + b + " must be of type string, but is " + (c + "."));
    return this.getValue(a, b)
};

function gvjs_sg(a, b) {
    return (new gvjs_tg(b)).Ic(a)
}

function gvjs_tg(a) {
    this.WL = a
}
gvjs_tg.prototype.Ic = function(a) {
    var b = [];
    gvjs_ug(this, a, b);
    return b.join("")
};

function gvjs_ug(a, b, c) {
    if (null == b) c.push(gvjs_Kd);
    else {
        if (typeof b == gvjs_g) {
            if (Array.isArray(b)) {
                var d = b;
                b = d.length;
                c.push("[");
                for (var e = "", f = 0; f < b; f++) c.push(e), e = d[f], gvjs_ug(a, a.WL ? a.WL.call(d, String(f), e) : e, c), e = ",";
                c.push("]");
                return
            }
            if (b instanceof String || b instanceof Number || b instanceof Boolean) b = b.valueOf();
            else {
                c.push("{");
                f = "";
                for (d in b) Object.prototype.hasOwnProperty.call(b, d) && (e = b[d], typeof e != gvjs_c && (c.push(f), gvjs_vg(d, c), c.push(":"), gvjs_ug(a, a.WL ? a.WL.call(b, d, e) : e, c), f = ","));
                c.push("}");
                return
            }
        }
        switch (typeof b) {
            case gvjs_m:
                gvjs_vg(b, c);
                break;
            case gvjs_f:
                c.push(isFinite(b) && !isNaN(b) ? String(b) : gvjs_Kd);
                break;
            case gvjs_Lb:
                c.push(String(b));
                break;
            case gvjs_c:
                c.push(gvjs_Kd);
                break;
            default:
                throw Error("Unknown type: " + typeof b);
        }
    }
}
var gvjs_wg = {
        '"': '\\"',
        "\\": "\\\\",
        "/": "\\/",
        "\b": "\\b",
        "\f": "\\f",
        "\n": "\\n",
        "\r": "\\r",
        "\t": "\\t",
        "\v": "\\u000b"
    },
    gvjs_Haa = /\uffff/.test("\uffff") ? /[\\"\x00-\x1f\x7f-\uffff]/g : /[\\"\x00-\x1f\x7f-\xff]/g;

function gvjs_vg(a, b) {
    b.push('"', a.replace(gvjs_Haa, function(c) {
        var d = gvjs_wg[c];
        d || (d = "\\u" + (c.charCodeAt(0) | 65536).toString(16).slice(1), gvjs_wg[c] = d);
        return d
    }), '"')
};

function gvjs_xg(a) {
    return gvjs_pg(a) && typeof a.getFullYear === gvjs_c
}

function gvjs_yg(a) {
    if (gvjs_xg(a)) {
        var b = new Date;
        b.setTime(a.valueOf());
        return b
    }
    var c = gvjs_Me(a);
    if (c === gvjs_g || c === gvjs_Db) {
        if (a.clone) return a.clone();
        c = c === gvjs_Db ? [] : {};
        for (b in a) c[b] = gvjs_yg(a[b]);
        return c
    }
    return a
}

function gvjs_zg(a, b) {
    a = a.split(".");
    b = b || gvjs_s;
    for (var c = 0; c < a.length; c++) {
        var d = a[c];
        if (Array.isArray(b) && !d.match(/[0-9]+/)) a: {
            for (var e = 0; e < b.length; e++) {
                var f = b[e];
                if (f.name && f.name === d) {
                    b = f;
                    break a
                }
            }
            b = null
        }
        else if (null != b[d]) b = b[d];
        else return null
    }
    return b
}

function gvjs_Ag(a) {
    return gvjs_Me(a) !== gvjs_g || gvjs_xg(a) ? null : a
}

function gvjs_Bg(a) {
    a = gvjs_Ag(a) || {};
    if (2 === arguments.length) {
        var b = arguments[1];
        if (!gvjs_Ag(b)) return a;
        for (var c in b)
            if (Array.isArray(b[c])) a[c] = Array.from(b[c]);
            else if (gvjs_Ag(a[c])) a[c] = gvjs_Bg(a[c], b[c]);
        else if (gvjs_Ag(b[c])) a[c] = gvjs_Bg({}, b[c]);
        else if (null == a[c] || null != b[c]) a[c] = b[c]
    } else if (2 < arguments.length)
        for (b = 1, c = arguments.length; b < c; b++) a = gvjs_Bg(a, arguments[b]);
    return a
}

function gvjs_Cg(a) {
    var b = [];
    a = gvjs_q(a);
    for (var c = a.next(); !c.done; c = a.next()) b.push(c.value);
    return b
}

function gvjs_Dg(a, b) {
    var c = new Set;
    b = gvjs_Cg(b);
    for (var d = 0; d < b.length; d++) {
        var e = b[d];
        a.has(e) && c.add(e)
    }
    return c
};
var gvjs_Eg = JSON.parse,
    gvjs_Fg = gvjs_s.JSON && gvjs_s.JSON.stringify || gvjs_sg;

function gvjs_Gg(a) {
    return JSON.stringify(gvjs_Hg(a, gvjs_Ig))
}

function gvjs_Jg(a) {
    return gvjs_Kg(JSON.parse(a))
}

function gvjs_Hg(a, b) {
    a = b(a);
    var c = gvjs_Me(a);
    if (c === gvjs_g || c === gvjs_Db) {
        c = c === gvjs_Db ? [] : {};
        for (var d in a)
            if (-1 === d.indexOf("___clazz$") && a.hasOwnProperty(d)) {
                var e = gvjs_Hg(a[d], b);
                void 0 !== e && (c[d] = e)
            }
    } else c = a;
    return c
}

function gvjs_Kg(a) {
    if (typeof a === gvjs_m) {
        var b = a.match(/^Date\(\s*([\d,\s]*)\)$/);
        b && (a = b[1].split(/,\s*/), a = 1 === a.length ? new Date(Number(a[0]) || 0) : new Date(Number(a[0]) || 0, Number(a[1]) || 0, Number(a[2]) || 1, Number(a[3]) || 0, Number(a[4]) || 0, Number(a[5]) || 0, Number(a[6]) || 0));
        return a
    }
    if (Array.isArray(a)) return a.map(gvjs_Kg);
    if (gvjs_pg(a))
        for (b in a)
            if (a.hasOwnProperty(b)) {
                var c = a[b];
                Object.prototype.hasOwnProperty.call(a, b) && (a[b] = gvjs_Kg(c))
            }
    return a
}

function gvjs_Ig(a) {
    var b = a;
    gvjs_xg(b) && (b = "Date(" + (0 !== a.getMilliseconds() ? [a.getFullYear(), a.getMonth(), a.getDate(), a.getHours(), a.getMinutes(), a.getSeconds(), a.getMilliseconds()] : 0 !== a.getSeconds() || 0 !== a.getMinutes() || 0 !== a.getHours() ? [a.getFullYear(), a.getMonth(), a.getDate(), a.getHours(), a.getMinutes(), a.getSeconds()] : [a.getFullYear(), a.getMonth(), a.getDate()]).join(gvjs_ja) + ")");
    return b
};
var gvjs_Lg = {
        YY: ["BC", "AD"],
        XY: ["Before Christ", "Anno Domini"],
        HZ: "JFMAMJJASOND".split(""),
        o_: "JFMAMJJASOND".split(""),
        MONTHS: [gvjs_Va, gvjs_Fa, "March", "April", gvjs_Ya, "June", "July", gvjs_ra, gvjs_eb, gvjs_5a, gvjs_3a, gvjs_Ca],
        n_: [gvjs_Va, gvjs_Fa, "March", "April", gvjs_Ya, "June", "July", gvjs_ra, gvjs_eb, gvjs_5a, gvjs_3a, gvjs_Ca],
        Mw: ["Jan", "Feb", "Mar", "Apr", gvjs_Ya, "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        q_: ["Jan", "Feb", "Mar", "Apr", gvjs_Ya, "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        BO: [gvjs_gb, gvjs__a, gvjs_rb,
            gvjs_tb, gvjs_nb, gvjs_Ga, gvjs_cb
        ],
        s_: [gvjs_gb, gvjs__a, gvjs_rb, gvjs_tb, gvjs_nb, gvjs_Ga, gvjs_cb],
        m_: "Sun Mon Tue Wed Thu Fri Sat".split(" "),
        r_: "Sun Mon Tue Wed Thu Fri Sat".split(" "),
        iaa: "SMTWTFS".split(""),
        p_: "SMTWTFS".split(""),
        l_: ["Q1", "Q2", "Q3", "Q4"],
        MZ: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"],
        xX: ["AM", "PM"],
        YG: ["EEEE, MMMM d, y", "MMMM d, y", "MMM d, y", "M/d/yy"],
        yO: ["h:mm:ss\u202fa zzzz", "h:mm:ss\u202fa z", "h:mm:ss\u202fa", "h:mm\u202fa"],
        UY: [gvjs_oe, gvjs_oe, gvjs_pe, gvjs_pe],
        ZG: 6,
        Eaa: [5, 6],
        aH: 5
    },
    gvjs_Mg = gvjs_Lg;
gvjs_Mg = gvjs_Lg;

function gvjs_Ng() {
    return null
}

function gvjs_Og() {}

function gvjs_Pg(a) {
    var b = !1,
        c;
    return function() {
        b || (c = a(), b = !0);
        return c
    }
};

function gvjs_y(a, b, c) {
    for (var d in a) b.call(c, a[d], d, a)
}

function gvjs_Qg(a, b) {
    for (var c in a)
        if (b.call(void 0, a[c], c, a)) return !0;
    return !1
}

function gvjs_Rg(a, b, c) {
    for (var d in a)
        if (!b.call(c, a[d], d, a)) return !1;
    return !0
}

function gvjs_Sg(a) {
    var b = [],
        c = 0,
        d;
    for (d in a) b[c++] = a[d];
    return b
}

function gvjs_Tg(a) {
    var b = [],
        c = 0,
        d;
    for (d in a) b[c++] = d;
    return b
}

function gvjs_Ug(a, b) {
    for (var c in a)
        if (a[c] == b) return !0;
    return !1
}

function gvjs_z(a) {
    var b = {},
        c;
    for (c in a) b[c] = a[c];
    return b
}
var gvjs_Vg = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

function gvjs_Wg(a, b) {
    for (var c, d, e = 1; e < arguments.length; e++) {
        d = arguments[e];
        for (c in d) a[c] = d[c];
        for (var f = 0; f < gvjs_Vg.length; f++) c = gvjs_Vg[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
    }
};
var gvjs_Iaa = {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    command: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0
};
var gvjs_Xg;

function gvjs_Yg() {
    if (void 0 === gvjs_Xg) {
        var a = null,
            b = gvjs_s.trustedTypes;
        if (b && b.createPolicy) try {
            a = b.createPolicy("goog#html", {
                createHTML: gvjs_We,
                createScript: gvjs_We,
                createScriptURL: gvjs_We
            })
        } catch (c) {
            gvjs_s.console && gvjs_s.console.error(c.message)
        }
        gvjs_Xg = a
    }
    return gvjs_Xg
};

function gvjs_Zg(a, b) {
    this.c9 = a === gvjs__g && b || "";
    this.zaa = gvjs_0g
}
gvjs_Zg.prototype.jl = !0;
gvjs_Zg.prototype.Wi = function() {
    return this.c9
};

function gvjs_1g(a) {
    return a instanceof gvjs_Zg && a.constructor === gvjs_Zg && a.zaa === gvjs_0g ? a.c9 : "type_error:Const"
}

function gvjs_2g(a) {
    return new gvjs_Zg(gvjs__g, a)
}
var gvjs_0g = {},
    gvjs__g = {};
var gvjs_3g = {};

function gvjs_4g(a, b) {
    this.YU = b === gvjs_3g ? a : "";
    this.jl = !0
}
gvjs_4g.prototype.toString = function() {
    return this.YU.toString()
};
gvjs_4g.prototype.Wi = function() {
    return this.YU.toString()
};

function gvjs_5g(a) {
    if (a instanceof gvjs_4g && a.constructor === gvjs_4g) return a.YU;
    gvjs_Me(a);
    return "type_error:SafeScript"
}

function gvjs_6g(a) {
    var b = gvjs_Yg();
    a = b ? b.createScript(a) : a;
    return new gvjs_4g(a, gvjs_3g)
};

function gvjs_7g(a, b) {
    this.cV = b === gvjs_8g ? a : ""
}
gvjs_7g.prototype.toString = function() {
    return this.cV + ""
};
gvjs_7g.prototype.jl = !0;
gvjs_7g.prototype.Wi = function() {
    return this.cV.toString()
};

function gvjs_9g(a) {
    return gvjs_$g(a).toString()
}

function gvjs_$g(a) {
    if (a instanceof gvjs_7g && a.constructor === gvjs_7g) return a.cV;
    gvjs_Me(a);
    return "type_error:TrustedResourceUrl"
}
var gvjs_Jaa = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i"),
    gvjs_8g = {};

function gvjs_ah(a) {
    var b = gvjs_Yg();
    a = b ? b.createScriptURL(a) : a;
    return new gvjs_7g(a, gvjs_8g)
};

function gvjs_bh(a, b) {
    this.bV = b === gvjs_ch ? a : ""
}
gvjs_bh.prototype.toString = function() {
    return this.bV.toString()
};
gvjs_bh.prototype.jl = !0;
gvjs_bh.prototype.Wi = function() {
    return this.bV.toString()
};

function gvjs_dh(a) {
    if (a instanceof gvjs_bh && a.constructor === gvjs_bh) return a.bV;
    gvjs_Me(a);
    return "type_error:SafeUrl"
}
var gvjs_Kaa = /^data:(.*);base64,[a-z0-9+\/]+=*$/i;

function gvjs_eh(a) {
    a = String(a);
    a = a.replace(/(%0A|%0D)/g, "");
    return a.match(gvjs_Kaa) ? gvjs_fh(a) : null
}
var gvjs_Laa = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;

function gvjs_gh(a) {
    a instanceof gvjs_bh || (a = typeof a == gvjs_g && a.jl ? a.Wi() : String(a), a = gvjs_Laa.test(a) ? gvjs_fh(a) : gvjs_eh(a));
    return a || gvjs_hh
}
var gvjs_ih;
try {
    new URL("s://g"), gvjs_ih = !0
} catch (a) {
    gvjs_ih = !1
}
var gvjs_Maa = gvjs_ih,
    gvjs_ch = {};

function gvjs_fh(a) {
    return new gvjs_bh(a, gvjs_ch)
}
var gvjs_hh = gvjs_fh(gvjs_wb);
var gvjs_jh = {};

function gvjs_kh(a, b) {
    this.aV = b === gvjs_jh ? a : "";
    this.jl = !0
}
gvjs_kh.prototype.Wi = function() {
    return this.aV
};
gvjs_kh.prototype.toString = function() {
    return this.aV.toString()
};

function gvjs_lh(a) {
    if (a instanceof gvjs_kh && a.constructor === gvjs_kh) return a.aV;
    gvjs_Me(a);
    return "type_error:SafeStyle"
}

function gvjs_mh(a) {
    var b = "",
        c;
    for (c in a)
        if (Object.prototype.hasOwnProperty.call(a, c)) {
            if (!/^[-_a-zA-Z0-9]+$/.test(c)) throw Error("Name allows only [-_a-zA-Z0-9], got: " + c);
            var d = a[c];
            null != d && (d = Array.isArray(d) ? d.map(gvjs_nh).join(" ") : gvjs_nh(d), b += c + ":" + d + ";")
        }
    return b ? new gvjs_kh(b, gvjs_jh) : gvjs_oh
}
var gvjs_oh = new gvjs_kh("", gvjs_jh);

function gvjs_nh(a) {
    if (a instanceof gvjs_bh) return 'url("' + gvjs_dh(a).replace(/</g, "%3c").replace(/[\\"]/g, "\\$&") + '")';
    if (a instanceof gvjs_Zg) a = gvjs_1g(a);
    else {
        a = String(a);
        var b = a.replace(gvjs_ph, "$1").replace(gvjs_ph, "$1").replace(gvjs_qh, "url");
        if (gvjs_Naa.test(b)) {
            if (b = !gvjs_Oaa.test(a)) {
                for (var c = b = !0, d = 0; d < a.length; d++) {
                    var e = a.charAt(d);
                    "'" == e && c ? b = !b : '"' == e && b && (c = !c)
                }
                b = b && c && gvjs_Paa(a)
            }
            a = b ? gvjs_Qaa(a) : "zClosurez"
        } else a = "zClosurez"
    }
    if (/[{;}]/.test(a)) throw new gvjs_Ze("Value does not allow [{;}], got: %s.", [a]);
    return a
}

function gvjs_Paa(a) {
    for (var b = !0, c = /^[-_a-zA-Z0-9]$/, d = 0; d < a.length; d++) {
        var e = a.charAt(d);
        if ("]" == e) {
            if (b) return !1;
            b = !0
        } else if ("[" == e) {
            if (!b) return !1;
            b = !1
        } else if (!b && !c.test(e)) return !1
    }
    return b
}
var gvjs_Naa = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$"),
    gvjs_qh = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g"),
    gvjs_ph = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g"),
    gvjs_Oaa = /\/\*/;

function gvjs_Qaa(a) {
    return a.replace(gvjs_qh, function(b, c, d, e) {
        var f = "";
        d = d.replace(/^(['"])(.*)\1$/, function(g, h, k) {
            f = h;
            return k
        });
        b = gvjs_gh(d).Wi();
        return c + f + b + f + e
    })
};
var gvjs_rh = {};

function gvjs_sh(a, b) {
    this.ZU = b === gvjs_rh ? a : "";
    this.jl = !0
}
gvjs_sh.prototype.toString = function() {
    return this.ZU.toString()
};

function gvjs_Raa(a) {
    function b(d) {
        Array.isArray(d) ? d.forEach(b) : c += gvjs_th(d)
    }
    var c = "";
    Array.prototype.forEach.call(arguments, b);
    return new gvjs_sh(c, gvjs_rh)
}
gvjs_sh.prototype.Wi = function() {
    return this.ZU
};

function gvjs_th(a) {
    if (a instanceof gvjs_sh && a.constructor === gvjs_sh) return a.ZU;
    gvjs_Me(a);
    return "type_error:SafeStyleSheet"
}
var gvjs_Saa = new gvjs_sh("", gvjs_rh);
var gvjs_uh = {};

function gvjs_vh(a, b) {
    this.XU = b === gvjs_uh ? a : "";
    this.jl = !0
}
gvjs_vh.prototype.Wi = function() {
    return this.XU.toString()
};
gvjs_vh.prototype.toString = function() {
    return this.XU.toString()
};

function gvjs_wh(a) {
    return gvjs_xh(a).toString()
}

function gvjs_xh(a) {
    if (a instanceof gvjs_vh && a.constructor === gvjs_vh) return a.XU;
    gvjs_Me(a);
    return "type_error:SafeHtml"
}

function gvjs_yh(a) {
    return a instanceof gvjs_vh ? a : gvjs_zh(gvjs_3e(typeof a == gvjs_g && a.jl ? a.Wi() : String(a)))
}

function gvjs_Ah(a, b, c) {
    gvjs_Bh(String(a));
    a = String(a);
    b = "<" + a + gvjs_Ch(b);
    null == c ? c = [] : Array.isArray(c) || (c = [c]);
    !0 === gvjs_Iaa[a.toLowerCase()] ? b += ">" : (c = gvjs_Dh(c), b += ">" + gvjs_wh(c) + "</" + a + ">");
    return gvjs_zh(b)
}

function gvjs_Bh(a) {
    if (!gvjs_Eh.test(a)) throw Error("");
    if (a.toUpperCase() in gvjs_Taa) throw Error("");
}

function gvjs_Uaa(a) {
    function b(e) {
        Array.isArray(e) ? e.forEach(b) : (e = gvjs_yh(e), d.push(gvjs_wh(e)))
    }
    var c = gvjs_yh(gvjs_Fh),
        d = [];
    a.forEach(b);
    return gvjs_zh(d.join(gvjs_wh(c)))
}

function gvjs_Dh(a) {
    return gvjs_Uaa(Array.prototype.slice.call(arguments))
}

function gvjs_zh(a) {
    var b = gvjs_Yg();
    a = b ? b.createHTML(a) : a;
    return new gvjs_vh(a, gvjs_uh)
}

function gvjs_Ch(a) {
    var b = "";
    if (a)
        for (var c in a)
            if (Object.prototype.hasOwnProperty.call(a, c)) {
                if (!gvjs_Eh.test(c)) throw Error("");
                var d = a[c];
                if (null != d) {
                    var e = c;
                    if (d instanceof gvjs_Zg) d = gvjs_1g(d);
                    else if (e.toLowerCase() == gvjs_6d) {
                        if (!gvjs_Pe(d)) throw Error("");
                        d instanceof gvjs_kh || (d = gvjs_mh(d));
                        d = gvjs_lh(d)
                    } else {
                        if (/^on/i.test(e)) throw Error("");
                        if (e.toLowerCase() in gvjs_Vaa)
                            if (d instanceof gvjs_7g) d = gvjs_9g(d);
                            else if (d instanceof gvjs_bh) d = gvjs_dh(d);
                        else if (typeof d === gvjs_m) d = gvjs_gh(d).Wi();
                        else throw Error("");
                    }
                    d.jl && (d = d.Wi());
                    e = e + '="' + gvjs_3e(String(d)) + '"';
                    b += " " + e
                }
            }
    return b
}
var gvjs_Eh = /^[a-zA-Z0-9-]+$/,
    gvjs_Vaa = {
        action: !0,
        cite: !0,
        data: !0,
        formaction: !0,
        href: !0,
        manifest: !0,
        poster: !0,
        src: !0
    },
    gvjs_Taa = {
        APPLET: !0,
        BASE: !0,
        EMBED: !0,
        IFRAME: !0,
        LINK: !0,
        MATH: !0,
        META: !0,
        OBJECT: !0,
        SCRIPT: !0,
        STYLE: !0,
        SVG: !0,
        TEMPLATE: !0
    },
    gvjs_Waa = gvjs_zh("<!DOCTYPE html>"),
    gvjs_Fh = new gvjs_vh(gvjs_s.trustedTypes && gvjs_s.trustedTypes.emptyHTML || "", gvjs_uh),
    gvjs_Gh = gvjs_zh("<br>");
var gvjs_Xaa = gvjs_Pg(function() {
    var a = document.createElement(gvjs_5b),
        b = document.createElement(gvjs_5b);
    b.appendChild(document.createElement(gvjs_5b));
    a.appendChild(b);
    b = a.firstChild.firstChild;
    a.innerHTML = gvjs_xh(gvjs_Fh);
    return !b.parentElement
});

function gvjs_Hh(a, b) {
    if (gvjs_Xaa())
        for (; a.lastChild;) a.removeChild(a.lastChild);
    a.innerHTML = gvjs_xh(b)
}
var gvjs_Yaa = /^[\w+/_-]+[=]{0,2}$/;

function gvjs_Ih(a) {
    a = (a || gvjs_s).document;
    return a.querySelector ? (a = a.querySelector("script[nonce]")) && (a = a.nonce || a.getAttribute(gvjs_Jd)) && gvjs_Yaa.test(a) ? a : "" : ""
};
var gvjs_Jh = String.prototype.repeat ? function(a, b) {
    return a.repeat(b)
} : function(a, b) {
    return Array(b + 1).join(a)
};

function gvjs_Kh(a, b) {
    if (!Number.isFinite(a)) return String(a);
    a = String(a);
    var c = a.indexOf("."); - 1 === c && (c = a.length);
    var d = "-" === a[0] ? "-" : "";
    d && (a = a.substring(1));
    return d + gvjs_Jh("0", Math.max(0, b - c)) + a
}

function gvjs_Lh(a) {
    return null == a ? "" : String(a)
}

function gvjs_Mh() {
    return Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ gvjs_Ue()).toString(36)
}

function gvjs_Nh(a) {
    return String(a).replace(/\-([a-z])/g, function(b, c) {
        return c.toUpperCase()
    })
}

function gvjs_Zaa(a) {
    return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
        return c + d.toUpperCase()
    })
};

function gvjs_Oh(a, b) {
    switch (b) {
        case 1:
            return 0 != a % 4 || 0 == a % 100 && 0 != a % 400 ? 28 : 29;
        case 5:
        case 8:
        case 10:
        case 3:
            return 30
    }
    return 31
}

function gvjs_Ph(a, b, c, d, e) {
    a = new Date(a, b, c);
    e = e || 0;
    return a.valueOf() + 864E5 * (((void 0 !== d ? d : 3) - e + 7) % 7 - ((a.getDay() + 6) % 7 - e + 7) % 7)
}

function gvjs_Qh(a, b, c, d, e, f) {
    typeof a === gvjs_m ? (this.ih = "y" == a ? b : 0, this.months = "m" == a ? b : 0, this.days = "d" == a ? b : 0, this.hours = "h" == a ? b : 0, this.minutes = "n" == a ? b : 0, this.seconds = "s" == a ? b : 0) : (this.ih = a || 0, this.months = b || 0, this.days = c || 0, this.hours = d || 0, this.minutes = e || 0, this.seconds = f || 0)
}
gvjs_ = gvjs_Qh.prototype;
gvjs_.cw = function(a) {
    var b = Math.min(this.ih, this.months, this.days, this.hours, this.minutes, this.seconds),
        c = Math.max(this.ih, this.months, this.days, this.hours, this.minutes, this.seconds);
    if (0 > b && 0 < c) return null;
    if (!a && 0 == b && 0 == c) return "PT0S";
    c = [];
    0 > b && c.push("-");
    c.push("P");
    (this.ih || a) && c.push(Math.abs(this.ih) + "Y");
    (this.months || a) && c.push(Math.abs(this.months) + "M");
    (this.days || a) && c.push(Math.abs(this.days) + "D");
    if (this.hours || this.minutes || this.seconds || a) c.push("T"), (this.hours || a) && c.push(Math.abs(this.hours) +
        "H"), (this.minutes || a) && c.push(Math.abs(this.minutes) + "M"), (this.seconds || a) && c.push(Math.abs(this.seconds) + "S");
    return c.join("")
};
gvjs_.equals = function(a) {
    return a.ih == this.ih && a.months == this.months && a.days == this.days && a.hours == this.hours && a.minutes == this.minutes && a.seconds == this.seconds
};
gvjs_.clone = function() {
    return new gvjs_Qh(this.ih, this.months, this.days, this.hours, this.minutes, this.seconds)
};
gvjs_.xJ = gvjs_p(1);
gvjs_.add = function(a) {
    this.ih += a.ih;
    this.months += a.months;
    this.days += a.days;
    this.hours += a.hours;
    this.minutes += a.minutes;
    this.seconds += a.seconds
};

function gvjs_Rh(a, b, c) {
    typeof a === gvjs_f ? (this.date = gvjs_Sh(a, b || 0, c || 1), gvjs_Th(this, c || 1)) : gvjs_Pe(a) ? (this.date = gvjs_Sh(a.getFullYear(), a.getMonth(), a.getDate()), gvjs_Th(this, a.getDate())) : (this.date = new Date(gvjs_Ue()), a = this.date.getDate(), this.date.setHours(0), this.date.setMinutes(0), this.date.setSeconds(0), this.date.setMilliseconds(0), gvjs_Th(this, a))
}

function gvjs_Sh(a, b, c) {
    b = new Date(a, b, c);
    0 <= a && 100 > a && b.setFullYear(b.getFullYear() - 1900);
    return b
}
gvjs_ = gvjs_Rh.prototype;
gvjs_.Xx = gvjs_Mg.ZG;
gvjs_.Zx = gvjs_Mg.aH;
gvjs_.clone = function() {
    var a = new gvjs_Rh(this.date);
    a.Xx = this.Xx;
    a.Zx = this.Zx;
    return a
};
gvjs_.getFullYear = function() {
    return this.date.getFullYear()
};
gvjs_.getYear = function() {
    return this.getFullYear()
};
gvjs_.getMonth = function() {
    return this.date.getMonth()
};
gvjs_.getDate = function() {
    return this.date.getDate()
};
gvjs_.getTime = function() {
    return this.date.getTime()
};
gvjs_.getDay = function() {
    return this.date.getDay()
};
gvjs_.getUTCFullYear = function() {
    return this.date.getUTCFullYear()
};
gvjs_.getUTCMonth = function() {
    return this.date.getUTCMonth()
};
gvjs_.getUTCDate = function() {
    return this.date.getUTCDate()
};
gvjs_.getUTCDay = function() {
    return this.date.getDay()
};
gvjs_.getUTCHours = function() {
    return this.date.getUTCHours()
};
gvjs_.getUTCMinutes = function() {
    return this.date.getUTCMinutes()
};
gvjs_.getTimezoneOffset = function() {
    return this.date.getTimezoneOffset()
};
gvjs_.set = function(a) {
    this.date = new Date(a.getFullYear(), a.getMonth(), a.getDate())
};
gvjs_.setFullYear = function(a) {
    this.date.setFullYear(a)
};
gvjs_.setYear = function(a) {
    this.setFullYear(a)
};
gvjs_.setMonth = function(a) {
    this.date.setMonth(a)
};
gvjs_.setDate = function(a) {
    this.date.setDate(a)
};
gvjs_.setTime = function(a) {
    this.date.setTime(a)
};
gvjs_.setUTCFullYear = function(a) {
    this.date.setUTCFullYear(a)
};
gvjs_.setUTCMonth = function(a) {
    this.date.setUTCMonth(a)
};
gvjs_.setUTCDate = function(a) {
    this.date.setUTCDate(a)
};
gvjs_.add = function(a) {
    if (a.ih || a.months) {
        var b = this.getMonth() + a.months + 12 * a.ih,
            c = this.getYear() + Math.floor(b / 12);
        b %= 12;
        0 > b && (b += 12);
        var d = Math.min(gvjs_Oh(c, b), this.getDate());
        this.setDate(1);
        this.setFullYear(c);
        this.setMonth(b);
        this.setDate(d)
    }
    a.days && (c = this.getYear(), b = 0 <= c && 99 >= c ? -1900 : 0, a = new Date((new Date(c, this.getMonth(), this.getDate(), 12)).getTime() + 864E5 * a.days), this.setDate(1), this.setFullYear(a.getFullYear() + b), this.setMonth(a.getMonth()), this.setDate(a.getDate()), gvjs_Th(this, a.getDate()))
};
gvjs_.cw = function(a) {
    var b = this.getFullYear(),
        c = 0 > b ? "-" : 1E4 <= b ? "+" : "";
    return [c + gvjs_Kh(Math.abs(b), c ? 6 : 4), gvjs_Kh(this.getMonth() + 1, 2), gvjs_Kh(this.getDate(), 2)].join(a ? "-" : "") + ""
};
gvjs_.equals = function(a) {
    return !(!a || this.getYear() != a.getYear() || this.getMonth() != a.getMonth() || this.getDate() != a.getDate())
};
gvjs_.toString = function() {
    return this.cw()
};

function gvjs_Th(a, b) {
    a.getDate() != b && a.date.setUTCHours(a.date.getUTCHours() + (a.getDate() < b ? 1 : -1))
}
gvjs_.valueOf = function() {
    return this.date.valueOf()
};

function gvjs_Uh(a, b, c, d, e, f, g) {
    this.date = typeof a === gvjs_f ? new Date(a, b || 0, c || 1, d || 0, e || 0, f || 0, g || 0) : new Date(a && a.getTime ? a.getTime() : gvjs_Ue())
}
gvjs_u(gvjs_Uh, gvjs_Rh);
gvjs_ = gvjs_Uh.prototype;
gvjs_.getHours = function() {
    return this.date.getHours()
};
gvjs_.getMinutes = function() {
    return this.date.getMinutes()
};
gvjs_.getSeconds = function() {
    return this.date.getSeconds()
};
gvjs_.getMilliseconds = function() {
    return this.date.getMilliseconds()
};
gvjs_.getUTCDay = function() {
    return this.date.getUTCDay()
};
gvjs_.getUTCHours = function() {
    return this.date.getUTCHours()
};
gvjs_.getUTCMinutes = function() {
    return this.date.getUTCMinutes()
};
gvjs_.getUTCSeconds = function() {
    return this.date.getUTCSeconds()
};
gvjs_.getUTCMilliseconds = function() {
    return this.date.getUTCMilliseconds()
};
gvjs_.setHours = function(a) {
    this.date.setHours(a)
};
gvjs_.setMinutes = function(a) {
    this.date.setMinutes(a)
};
gvjs_.setSeconds = function(a) {
    this.date.setSeconds(a)
};
gvjs_.setMilliseconds = function(a) {
    this.date.setMilliseconds(a)
};
gvjs_.setUTCHours = function(a) {
    this.date.setUTCHours(a)
};
gvjs_.setUTCMinutes = function(a) {
    this.date.setUTCMinutes(a)
};
gvjs_.setUTCSeconds = function(a) {
    this.date.setUTCSeconds(a)
};
gvjs_.setUTCMilliseconds = function(a) {
    this.date.setUTCMilliseconds(a)
};
gvjs_.add = function(a) {
    gvjs_Rh.prototype.add.call(this, a);
    a.hours && this.setUTCHours(this.date.getUTCHours() + a.hours);
    a.minutes && this.setUTCMinutes(this.date.getUTCMinutes() + a.minutes);
    a.seconds && this.setUTCSeconds(this.date.getUTCSeconds() + a.seconds)
};
gvjs_.cw = function(a) {
    var b = gvjs_Rh.prototype.cw.call(this, a);
    return a ? b + "T" + gvjs_Kh(this.getHours(), 2) + ":" + gvjs_Kh(this.getMinutes(), 2) + ":" + gvjs_Kh(this.getSeconds(), 2) : b + "T" + gvjs_Kh(this.getHours(), 2) + gvjs_Kh(this.getMinutes(), 2) + gvjs_Kh(this.getSeconds(), 2)
};
gvjs_.equals = function(a) {
    return this.getTime() == a.getTime()
};
gvjs_.toString = function() {
    return this.cw()
};
gvjs_.clone = function() {
    var a = new gvjs_Uh(this.date);
    a.Xx = this.Xx;
    a.Zx = this.Zx;
    return a
};

function gvjs_Vh(a, b, c, d, e, f, g) {
    a = typeof a === gvjs_f ? Date.UTC(a, b || 0, c || 1, d || 0, e || 0, f || 0, g || 0) : a ? a.getTime() : gvjs_Ue();
    this.date = new Date(a)
}
gvjs_u(gvjs_Vh, gvjs_Uh);
gvjs_ = gvjs_Vh.prototype;
gvjs_.clone = function() {
    var a = new gvjs_Vh(this.date);
    a.Xx = this.Xx;
    a.Zx = this.Zx;
    return a
};
gvjs_.add = function(a) {
    (a.ih || a.months) && gvjs_Rh.prototype.add.call(this, new gvjs_Qh(a.ih, a.months));
    this.date = new Date(this.date.getTime() + 1E3 * (a.seconds + 60 * (a.minutes + 60 * (a.hours + 24 * a.days))))
};
gvjs_.getTimezoneOffset = function() {
    return 0
};
gvjs_.getFullYear = gvjs_Uh.prototype.getUTCFullYear;
gvjs_.getMonth = gvjs_Uh.prototype.getUTCMonth;
gvjs_.getDate = gvjs_Uh.prototype.getUTCDate;
gvjs_.getHours = gvjs_Uh.prototype.getUTCHours;
gvjs_.getMinutes = gvjs_Uh.prototype.getUTCMinutes;
gvjs_.getSeconds = gvjs_Uh.prototype.getUTCSeconds;
gvjs_.getMilliseconds = gvjs_Uh.prototype.getUTCMilliseconds;
gvjs_.getDay = gvjs_Uh.prototype.getUTCDay;
gvjs_.setFullYear = gvjs_Uh.prototype.setUTCFullYear;
gvjs_.setMonth = gvjs_Uh.prototype.setUTCMonth;
gvjs_.setDate = gvjs_Uh.prototype.setUTCDate;
gvjs_.setHours = gvjs_Uh.prototype.setUTCHours;
gvjs_.setMinutes = gvjs_Uh.prototype.setUTCMinutes;
gvjs_.setSeconds = gvjs_Uh.prototype.setUTCSeconds;
gvjs_.setMilliseconds = gvjs_Uh.prototype.setUTCMilliseconds;

function gvjs_Wh() {}

function gvjs_Xh(a) {
    if (typeof a == gvjs_f) {
        var b = new gvjs_Wh;
        b.U8 = a;
        var c = a;
        if (0 == c) c = "Etc/GMT";
        else {
            var d = ["Etc/GMT", 0 > c ? "-" : "+"];
            c = Math.abs(c);
            d.push(Math.floor(c / 60) % 100);
            c %= 60;
            0 != c && d.push(":", gvjs_Kh(c, 2));
            c = d.join("")
        }
        b.HW = c;
        c = a;
        0 == c ? c = "UTC" : (d = ["UTC", 0 > c ? "+" : "-"], c = Math.abs(c), d.push(Math.floor(c / 60) % 100), c %= 60, 0 != c && d.push(":", c), c = d.join(""));
        a = gvjs_Yh(a);
        b.WW = [c, c];
        b.iw = {
            mpa: a,
            t_: a
        };
        b.tA = [];
        return b
    }
    b = new gvjs_Wh;
    b.HW = a.id;
    b.U8 = -a.std_offset;
    b.WW = a.names;
    b.iw = a.names_ext;
    b.tA = a.transitions;
    return b
}

function gvjs_Yh(a) {
    var b = ["GMT"];
    b.push(0 >= a ? "+" : "-");
    a = Math.abs(a);
    b.push(gvjs_Kh(Math.floor(a / 60) % 100, 2), ":", gvjs_Kh(a % 60, 2));
    return b.join("")
}

function gvjs_Zh(a, b) {
    b = Date.UTC(b.getUTCFullYear(), b.getUTCMonth(), b.getUTCDate(), b.getUTCHours(), b.getUTCMinutes()) / 36E5;
    for (var c = 0; c < a.tA.length && b >= a.tA[c];) c += 2;
    return 0 == c ? 0 : a.tA[c - 1]
}
gvjs_Wh.prototype.getOffset = function(a) {
    a = this.U8 - gvjs_Zh(this, a);
    return -1440 === a ? 0 : a
};

function gvjs__h(a) {
    this.wL = [];
    this.Zc = gvjs_Mg;
    typeof a == gvjs_f ? this.DH(a) : this.ho(a)
}
var gvjs_0h = [/^'(?:[^']|'')*('|$)/, /^(?:G+|y+|Y+|M+|k+|S+|E+|a+|b+|B+|h+|K+|H+|c+|L+|Q+|d+|m+|s+|v+|V+|w+|z+|Z+)/, /^[^'GyYMkSEabBhKHcLQdmsvVwzZ]+/];

function gvjs_1h(a) {
    return a.getHours ? a.getHours() : 0
}
gvjs__h.prototype.ho = function(a) {
    for (gvjs__aa && (a = a.replace(/\u200f/g, "")); a;) {
        for (var b = a, c = 0; c < gvjs_0h.length; ++c) {
            var d = a.match(gvjs_0h[c]);
            if (d) {
                var e = d[0];
                a = a.substring(e.length);
                0 == c && ("''" == e ? e = "'" : (e = e.substring(1, "'" == d[1] ? e.length - 1 : e.length), e = e.replace(/''/g, "'")));
                this.wL.push({
                    text: e,
                    type: c
                });
                break
            }
        }
        if (b === a) throw Error("Malformed pattern part: " + a);
    }
};
gvjs__h.prototype.format = function(a, b) {
    if (!a) throw Error("The date to format must be non-null.");
    var c = b ? 6E4 * (a.getTimezoneOffset() - b.getOffset(a)) : 0,
        d = c ? new Date(a.getTime() + c) : a,
        e = d;
    b && d.getTimezoneOffset() != a.getTimezoneOffset() && (d = new Date(d.getTime() + 6E4 * (d.getTimezoneOffset() - a.getTimezoneOffset())), e = new Date(a.getTime() + (c + (0 < c ? -864E5 : 864E5))));
    c = [];
    for (var f = 0; f < this.wL.length; ++f) {
        var g = this.wL[f].text;
        1 == this.wL[f].type ? c.push(gvjs_0aa(this, g, a, d, e, b)) : c.push(g)
    }
    return c.join("")
};
gvjs__h.prototype.DH = function(a) {
    if (4 > a) var b = this.Zc.YG[a];
    else if (8 > a) b = this.Zc.yO[a - 4];
    else if (12 > a) b = this.Zc.UY[a - 8], b = b.replace("{1}", this.Zc.YG[a - 8]), b = b.replace("{0}", this.Zc.yO[a - 8]);
    else if (12 === a) b = this.Zc.YG[0].replace(/[^EMd]*yy*[^EMd]*/, "");
    else {
        this.DH(10);
        return
    }
    this.ho(b)
};

function gvjs_2h(a, b) {
    b = String(b);
    a = a.Zc || gvjs_Mg;
    if (void 0 !== a.Iaa) {
        for (var c = [], d = 0; d < b.length; d++) {
            var e = b.charCodeAt(d);
            c.push(48 <= e && 57 >= e ? String.fromCharCode(a.Iaa + e - 48) : b.charAt(d))
        }
        b = c.join("")
    }
    return b
}
var gvjs__aa = !1;

function gvjs_3h(a) {
    if (!(a.getHours && a.getSeconds && a.getMinutes)) throw Error("The date to format has no time (probably a goog.date.Date). Use Date or goog.date.DateTime, or use a pattern without time fields.");
}

function gvjs_4h(a, b) {
    gvjs_3h(b);
    b = gvjs_1h(b);
    return a.Zc.xX[12 <= b && 24 > b ? 1 : 0]
}

function gvjs_0aa(a, b, c, d, e, f) {
    var g = b.length;
    switch (b.charAt(0)) {
        case "G":
            return c = 0 < d.getFullYear() ? 1 : 0, 4 <= g ? a.Zc.XY[c] : a.Zc.YY[c];
        case "y":
            return c = d.getFullYear(), 0 > c && (c = -c), 2 == g && (c %= 100), gvjs_2h(a, gvjs_Kh(c, g));
        case "Y":
            return c = (new Date(gvjs_Ph(d.getFullYear(), d.getMonth(), d.getDate(), a.Zc.aH, a.Zc.ZG))).getFullYear(), 0 > c && (c = -c), 2 == g && (c %= 100), gvjs_2h(a, gvjs_Kh(c, g));
        case "M":
            a: switch (c = d.getMonth(), g) {
                case 5:
                    g = a.Zc.HZ[c];
                    break a;
                case 4:
                    g = a.Zc.MONTHS[c];
                    break a;
                case 3:
                    g = a.Zc.Mw[c];
                    break a;
                default:
                    g = gvjs_2h(a, gvjs_Kh(c + 1, g))
            }
            return g;
        case "k":
            return gvjs_3h(e), gvjs_2h(a, gvjs_Kh(gvjs_1h(e) || 24, g));
        case "S":
            return gvjs_2h(a, (e.getMilliseconds() / 1E3).toFixed(Math.min(3, g)).slice(2) + (3 < g ? gvjs_Kh(0, g - 3) : ""));
        case "E":
            return c = d.getDay(), 4 <= g ? a.Zc.BO[c] : a.Zc.m_[c];
        case "a":
            return gvjs_4h(a, e);
        case "b":
            return gvjs_4h(a, e);
        case "B":
            return gvjs_4h(a, e);
        case "h":
            return gvjs_3h(e), gvjs_2h(a, gvjs_Kh(gvjs_1h(e) % 12 || 12, g));
        case "K":
            return gvjs_3h(e), gvjs_2h(a, gvjs_Kh(gvjs_1h(e) % 12, g));
        case "H":
            return gvjs_3h(e),
                gvjs_2h(a, gvjs_Kh(gvjs_1h(e), g));
        case "c":
            a: switch (c = d.getDay(), g) {
                case 5:
                    g = a.Zc.p_[c];
                    break a;
                case 4:
                    g = a.Zc.s_[c];
                    break a;
                case 3:
                    g = a.Zc.r_[c];
                    break a;
                default:
                    g = gvjs_2h(a, gvjs_Kh(c, 1))
            }
            return g;
        case "L":
            a: switch (c = d.getMonth(), g) {
                case 5:
                    g = a.Zc.o_[c];
                    break a;
                case 4:
                    g = a.Zc.n_[c];
                    break a;
                case 3:
                    g = a.Zc.q_[c];
                    break a;
                default:
                    g = gvjs_2h(a, gvjs_Kh(c + 1, g))
            }
            return g;
        case "Q":
            return c = Math.floor(d.getMonth() / 3), 4 > g ? a.Zc.l_[c] : a.Zc.MZ[c];
        case "d":
            return gvjs_2h(a, gvjs_Kh(d.getDate(), g));
        case "m":
            return gvjs_3h(e),
                gvjs_2h(a, gvjs_Kh(e.getMinutes ? e.getMinutes() : 0, g));
        case "s":
            return gvjs_3h(e), gvjs_2h(a, gvjs_Kh(e.getSeconds(), g));
        case "v":
            return (f || gvjs_Xh(c.getTimezoneOffset())).HW;
        case "V":
            return a = f || gvjs_Xh(c.getTimezoneOffset()), 2 >= g ? a.HW : 0 < gvjs_Zh(a, c) ? void 0 !== a.iw.z$ ? a.iw.z$ : a.iw.DST_GENERIC_LOCATION : void 0 !== a.iw.t_ ? a.iw.t_ : a.iw.STD_GENERIC_LOCATION;
        case "w":
            return c = gvjs_Ph(e.getFullYear(), e.getMonth(), e.getDate(), a.Zc.aH, a.Zc.ZG), gvjs_2h(a, gvjs_Kh(Math.floor(Math.round((c - (new Date((new Date(c)).getFullYear(),
                0, 1)).valueOf()) / 864E5) / 7) + 1, g));
        case "z":
            return a = f || gvjs_Xh(c.getTimezoneOffset()), 4 > g ? a.WW[0 < gvjs_Zh(a, c) ? 2 : 0] : a.WW[0 < gvjs_Zh(a, c) ? 3 : 1];
        case "Z":
            return b = f || gvjs_Xh(c.getTimezoneOffset()), 4 > g ? (g = -b.getOffset(c), a = [0 > g ? "-" : "+"], g = Math.abs(g), a.push(gvjs_Kh(Math.floor(g / 60) % 100, 2), gvjs_Kh(g % 60, 2)), g = a.join("")) : g = gvjs_2h(a, gvjs_Yh(b.getOffset(c))), g;
        default:
            return ""
    }
};
var gvjs_5h = {
        DO: "y",
        Jpa: "y G",
        EO: "MMM y",
        Haa: "MMMM y",
        Kpa: "MM/y",
        FZ: "MMM d",
        Y$: "MMMM dd",
        GZ: "M/d",
        Z$: "MMMM d",
        aaa: "MMM d, y",
        Fpa: "EEE, MMM d",
        Gpa: "EEE, MMM d, y",
        w$: "d",
        Moa: "MMM d, h:mm\u202fa zzzz"
    },
    gvjs_6h = gvjs_5h;
gvjs_6h = gvjs_5h;

function gvjs_7h(a, b, c) {
    return Math.min(Math.max(a, b), c)
}

function gvjs_8h(a) {
    return isFinite(a) && 0 == a % 1
};
var gvjs_9h = {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: gvjs_ea,
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyan: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgreen: "#006400",
    darkgrey: "#a9a9a9",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: gvjs_fa,
    green: "#008000",
    greenyellow: "#adff2f",
    grey: gvjs_fa,
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgreen: "#90ee90",
    lightgrey: "#d3d3d3",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    steelblue: "#4682b4",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    tomato: "#ff6347",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: gvjs_ga,
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
};

function gvjs_$h(a) {
    var b = {};
    a = String(a);
    var c = "#" == a.charAt(0) ? a : "#" + a;
    if (gvjs_ai.test(c)) return b.hex = gvjs_bi(c), b.type = "hex", b;
    c = gvjs_ci(a);
    if (c.length) return b.hex = gvjs_di(c), b.type = "rgb", b;
    if (gvjs_9h && (c = gvjs_9h[a.toLowerCase()])) return b.hex = c, b.type = "named", b;
    throw Error(a + " is not a valid color string");
}
var gvjs_1aa = /#(.)(.)(.)/;

function gvjs_bi(a) {
    if (!gvjs_ai.test(a)) throw Error("'" + a + "' is not a valid hex color");
    4 == a.length && (a = a.replace(gvjs_1aa, "#$1$1$2$2$3$3"));
    return a.toLowerCase()
}

function gvjs_ei(a) {
    a = gvjs_bi(a);
    a = parseInt(a.slice(1), 16);
    return [a >> 16, a >> 8 & 255, a & 255]
}

function gvjs_fi(a, b, c) {
    a = Number(a);
    b = Number(b);
    c = Number(c);
    if (a != (a & 255) || b != (b & 255) || c != (c & 255)) throw Error('"(' + a + "," + b + "," + c + '") is not a valid RGB color');
    b = a << 16 | b << 8 | c;
    return 16 > a ? "#" + (16777216 | b).toString(16).slice(1) : "#" + b.toString(16)
}

function gvjs_di(a) {
    return gvjs_fi(a[0], a[1], a[2])
}
var gvjs_ai = /^#(?:[0-9a-f]{3}){1,2}$/i,
    gvjs_2aa = /^(?:rgb)?\((0|[1-9]\d{0,2}),\s?(0|[1-9]\d{0,2}),\s?(0|[1-9]\d{0,2})\)$/i;

function gvjs_ci(a) {
    var b = a.match(gvjs_2aa);
    if (b) {
        a = Number(b[1]);
        var c = Number(b[2]);
        b = Number(b[3]);
        if (0 <= a && 255 >= a && 0 <= c && 255 >= c && 0 <= b && 255 >= b) return [a, c, b]
    }
    return []
}

function gvjs_gi(a, b, c) {
    c = gvjs_7h(c, 0, 1);
    return [Math.round(b[0] + c * (a[0] - b[0])), Math.round(b[1] + c * (a[1] - b[1])), Math.round(b[2] + c * (a[2] - b[2]))]
};
try {
    (new self.OffscreenCanvas(0, 0)).getContext("2d")
} catch (a) {}
var gvjs_3aa = gvjs_x || gvjs_If;

function gvjs_A(a, b) {
    this.x = void 0 !== a ? a : 0;
    this.y = void 0 !== b ? b : 0
}
gvjs_ = gvjs_A.prototype;
gvjs_.clone = function() {
    return new gvjs_A(this.x, this.y)
};
gvjs_.equals = function(a) {
    return a instanceof gvjs_A && gvjs_hi(this, a)
};

function gvjs_hi(a, b) {
    return a == b ? !0 : a && b ? a.x == b.x && a.y == b.y : !1
}
gvjs_.ceil = function() {
    this.x = Math.ceil(this.x);
    this.y = Math.ceil(this.y);
    return this
};
gvjs_.floor = function() {
    this.x = Math.floor(this.x);
    this.y = Math.floor(this.y);
    return this
};
gvjs_.round = function() {
    this.x = Math.round(this.x);
    this.y = Math.round(this.y);
    return this
};
gvjs_.translate = function(a, b) {
    a instanceof gvjs_A ? (this.x += a.x, this.y += a.y) : (this.x += Number(a), typeof b === gvjs_f && (this.y += b));
    return this
};
gvjs_.scale = function(a, b) {
    this.x *= a;
    this.y *= typeof b === gvjs_f ? b : a;
    return this
};

function gvjs_B(a, b) {
    this.width = a;
    this.height = b
}
gvjs_ = gvjs_B.prototype;
gvjs_.clone = function() {
    return new gvjs_B(this.width, this.height)
};
gvjs_.area = function() {
    return this.width * this.height
};
gvjs_.aspectRatio = function() {
    return this.width / this.height
};
gvjs_.isEmpty = function() {
    return !this.area()
};
gvjs_.ceil = function() {
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this
};
gvjs_.floor = function() {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this
};
gvjs_.round = function() {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this
};
gvjs_.scale = function(a, b) {
    this.width *= a;
    this.height *= typeof b === gvjs_f ? b : a;
    return this
};

function gvjs_ii(a) {
    return a ? new gvjs_ji(gvjs_ki(a)) : gvjs_Ye || (gvjs_Ye = new gvjs_ji)
}

function gvjs_li(a, b) {
    return typeof b === gvjs_m ? a.getElementById(b) : b
}

function gvjs_mi(a, b, c, d) {
    a = d || a;
    b = b && "*" != b ? String(b).toUpperCase() : "";
    if (a.querySelectorAll && a.querySelector && (b || c)) return a.querySelectorAll(b + (c ? "." + c : ""));
    if (c && a.getElementsByClassName) {
        a = a.getElementsByClassName(c);
        if (b) {
            d = {};
            for (var e = 0, f = 0, g; g = a[f]; f++) b == g.nodeName && (d[e++] = g);
            d.length = e;
            return d
        }
        return a
    }
    a = a.getElementsByTagName(b || "*");
    if (c) {
        d = {};
        for (f = e = 0; g = a[f]; f++) b = g.className, typeof b.split == gvjs_c && gvjs_tf(b.split(/\s+/), c) && (d[e++] = g);
        d.length = e;
        return d
    }
    return a
}

function gvjs_ni(a, b) {
    gvjs_y(b, function(c, d) {
        c && typeof c == gvjs_g && c.jl && (c = c.Wi());
        d == gvjs_6d ? a.style.cssText = c : d == gvjs_Qb ? a.className = c : "for" == d ? a.htmlFor = c : gvjs_oi.hasOwnProperty(d) ? a.setAttribute(gvjs_oi[d], c) : gvjs_0e(d, "aria-") || gvjs_0e(d, gvjs__b) ? a.setAttribute(d, c) : a[d] = c
    })
}
var gvjs_oi = {
    cellpadding: "cellPadding",
    cellspacing: "cellSpacing",
    colspan: "colSpan",
    frameborder: "frameBorder",
    height: gvjs_jd,
    maxlength: "maxLength",
    nonce: gvjs_Jd,
    role: gvjs_Vd,
    rowspan: "rowSpan",
    type: gvjs_ge,
    usemap: "useMap",
    valign: "vAlign",
    width: gvjs_le
};

function gvjs_pi(a, b) {
    var c = b[1],
        d = gvjs_qi(a, String(b[0]));
    c && (typeof c === gvjs_m ? d.className = c : Array.isArray(c) ? d.className = c.join(" ") : gvjs_ni(d, c));
    2 < b.length && gvjs_ri(a, d, b, 2);
    return d
}

function gvjs_ri(a, b, c, d) {
    function e(h) {
        h && b.appendChild(typeof h === gvjs_m ? a.createTextNode(h) : h)
    }
    for (; d < c.length; d++) {
        var f = c[d];
        if (gvjs_Ne(f) && !gvjs_si(f)) {
            a: {
                if (f && typeof f.length == gvjs_f) {
                    if (gvjs_Pe(f)) {
                        var g = typeof f.item == gvjs_c || typeof f.item == gvjs_m;
                        break a
                    }
                    if (typeof f === gvjs_c) {
                        g = typeof f.item == gvjs_c;
                        break a
                    }
                }
                g = !1
            }
            gvjs_v(g ? gvjs_wf(f) : f, e)
        }
        else e(f)
    }
}

function gvjs_ti(a) {
    return gvjs_qi(document, a)
}

function gvjs_qi(a, b) {
    b = String(b);
    "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
    return a.createElement(b)
}

function gvjs_ui(a) {
    return "CSS1Compat" == a.compatMode
}

function gvjs_vi(a) {
    if (1 != a.nodeType) return !1;
    switch (a.tagName) {
        case "APPLET":
        case "AREA":
        case "BASE":
        case "BR":
        case "COL":
        case "COMMAND":
        case "EMBED":
        case "FRAME":
        case "HR":
        case "IMG":
        case gvjs_Oa:
        case gvjs_Na:
        case "ISINDEX":
        case "KEYGEN":
        case "LINK":
        case "NOFRAMES":
        case "NOSCRIPT":
        case "META":
        case gvjs_4a:
        case "PARAM":
        case "SCRIPT":
        case gvjs_$a:
        case gvjs_bb:
        case "TRACK":
        case "WBR":
            return !1
    }
    return !0
}

function gvjs_wi(a, b) {
    gvjs_ri(gvjs_ki(a), a, arguments, 1)
}

function gvjs_xi(a) {
    for (var b; b = a.firstChild;) a.removeChild(b)
}

function gvjs_yi(a, b) {
    b.parentNode && b.parentNode.insertBefore(a, b)
}

function gvjs_zi(a, b) {
    b.parentNode && b.parentNode.insertBefore(a, b.nextSibling)
}

function gvjs_Ai(a) {
    return a && a.parentNode ? a.parentNode.removeChild(a) : null
}

function gvjs_Bi(a) {
    return void 0 != a.children ? a.children : Array.prototype.filter.call(a.childNodes, function(b) {
        return 1 == b.nodeType
    })
}

function gvjs_Ci(a) {
    return void 0 !== a.firstElementChild ? a.firstElementChild : gvjs_Di(a.firstChild, !0)
}

function gvjs_Ei(a) {
    return void 0 !== a.nextElementSibling ? a.nextElementSibling : gvjs_Di(a.nextSibling, !0)
}

function gvjs_Di(a, b) {
    for (; a && 1 != a.nodeType;) a = b ? a.nextSibling : a.previousSibling;
    return a
}

function gvjs_si(a) {
    return gvjs_Pe(a) && 0 < a.nodeType
}

function gvjs_Fi(a) {
    return gvjs_Pe(a) && 1 == a.nodeType
}

function gvjs_Gi(a) {
    var b;
    if (gvjs_3aa && (b = a.parentElement)) return b;
    b = a.parentNode;
    return gvjs_Fi(b) ? b : null
}

function gvjs_Hi(a, b) {
    if (!a || !b) return !1;
    if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
    if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
    for (; b && a != b;) b = b.parentNode;
    return b == a
}

function gvjs_ki(a) {
    return 9 == a.nodeType ? a : a.ownerDocument || a.document
}

function gvjs_Ii(a) {
    return a.contentDocument || a.contentWindow.document
}

function gvjs_Ji(a, b) {
    if ("textContent" in a) a.textContent = b;
    else if (3 == a.nodeType) a.data = String(b);
    else if (a.firstChild && 3 == a.firstChild.nodeType) {
        for (; a.lastChild != a.firstChild;) a.removeChild(a.lastChild);
        a.firstChild.data = String(b)
    } else gvjs_xi(a), a.appendChild(gvjs_ki(a).createTextNode(String(b)))
}

function gvjs_Ki(a) {
    if ("outerHTML" in a) return a.outerHTML;
    var b = gvjs_qi(gvjs_ki(a), gvjs_b);
    b.appendChild(a.cloneNode(!0));
    return b.innerHTML
}
var gvjs_4aa = {
        SCRIPT: 1,
        STYLE: 1,
        HEAD: 1,
        IFRAME: 1,
        OBJECT: 1
    },
    gvjs_Li = {
        IMG: " ",
        BR: "\n"
    };

function gvjs_Mi(a) {
    var b = [];
    gvjs_Ni(a, b, !0);
    a = b.join("");
    a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
    a = a.replace(/\u200B/g, "");
    a = a.replace(/ +/g, " ");
    " " != a && (a = a.replace(/^\s*/, ""));
    return a
}

function gvjs_Ni(a, b, c) {
    if (!(a.nodeName in gvjs_4aa))
        if (3 == a.nodeType) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
        else if (a.nodeName in gvjs_Li) b.push(gvjs_Li[a.nodeName]);
    else
        for (a = a.firstChild; a;) gvjs_Ni(a, b, c), a = a.nextSibling
}

function gvjs_Oi(a, b, c, d) {
    a && !c && (a = a.parentNode);
    for (c = 0; a && (null == d || c <= d);) {
        if (b(a)) return a;
        a = a.parentNode;
        c++
    }
    return null
}

function gvjs_ji(a) {
    this.ac = a || gvjs_s.document || document
}
gvjs_ = gvjs_ji.prototype;
gvjs_.fa = gvjs_ii;
gvjs_.Hb = function() {
    return this.ac
};
gvjs_.j = function(a) {
    return gvjs_li(this.ac, a)
};
gvjs_.getElementsByTagName = function(a, b) {
    return (b || this.ac).getElementsByTagName(String(a))
};

function gvjs_Pi(a, b, c, d) {
    return gvjs_mi(a.ac, b, c, d)
}
gvjs_.Im = gvjs_p(2);
gvjs_.Vb = gvjs_p(4);
gvjs_.BJ = gvjs_p(6);
gvjs_.setProperties = gvjs_ni;
gvjs_.F = function(a, b, c) {
    return gvjs_pi(this.ac, arguments)
};
gvjs_.createElement = function(a) {
    return gvjs_qi(this.ac, a)
};
gvjs_.createTextNode = function(a) {
    return this.ac.createTextNode(String(a))
};
gvjs_.oQ = gvjs_p(7);
gvjs_.Yi = function() {
    var a = this.ac;
    return a.parentWindow || a.defaultView
};
gvjs_.lu = gvjs_p(8);
gvjs_.appendChild = function(a, b) {
    a.appendChild(b)
};
gvjs_.append = gvjs_wi;
gvjs_.canHaveChildren = gvjs_vi;
gvjs_.xb = gvjs_xi;
gvjs_.FS = gvjs_yi;
gvjs_.mha = gvjs_zi;
gvjs_.removeNode = gvjs_Ai;
gvjs_.getChildren = gvjs_Bi;
gvjs_.s3 = gvjs_Ci;
gvjs_.t3 = gvjs_Ei;
gvjs_.ll = gvjs_si;
gvjs_.NS = gvjs_Fi;
gvjs_.isWindow = function(a) {
    return gvjs_Pe(a) && a.window == a
};
gvjs_.zJ = gvjs_Gi;
gvjs_.contains = gvjs_Hi;
gvjs_.uea = gvjs_ki;
gvjs_.qea = gvjs_Ii;
gvjs_.UV = gvjs_Ji;
gvjs_.Sm = gvjs_p(10);
gvjs_.wea = gvjs_Mi;
gvjs_.l3 = gvjs_Oi;

function gvjs_Qi(a, b) {
    if (null != a && "" !== a && a !== gvjs_ee && a !== gvjs_e) {
        if (gvjs_pg(a)) return a.color || "";
        if (typeof a === gvjs_m) {
            try {
                return a.includes("rgba") ? a : gvjs_$h(a).hex
            } catch (c) {
                if (!b) throw Error("Invalid color: " + a);
            }
            return a
        }
    }
    return gvjs_e
};
var gvjs_Ri;

function gvjs_Si(a, b, c, d) {
    this.cc = a || [{}];
    this.mE = d || Array(this.cc.length).fill(1);
    this.KH = b || null;
    this.OS = null != c ? c : !1
}
gvjs_ = gvjs_Si.prototype;
gvjs_.view = function(a) {
    a = gvjs_Ti(this, a);
    return new gvjs_Si(Array.from(this.cc), a, this.OS, Array.from(this.mE))
};

function gvjs_Ti(a, b) {
    typeof b === gvjs_m && (b = [b]);
    return null != a.KH ? gvjs_Ui(a.KH, b) : b
}

function gvjs_Ui(a, b) {
    var c = typeof a === gvjs_m ? [a] : a;
    b = typeof b === gvjs_m ? [b] : b;
    if (0 === c.length) return b;
    if (0 === b.length) return c;
    a = [];
    c = gvjs_q(c);
    for (var d = c.next(); !d.done; d = c.next()) {
        d = d.value;
        for (var e = null == d || "" === d, f = gvjs_q(b), g = f.next(); !g.done; g = f.next()) {
            g = g.value;
            var h = null == g || "" === g;
            e || h ? e ? h || a.push(g) : a.push(d) : a.push(d + "." + g)
        }
    }
    return a
}

function gvjs_Vi(a, b, c, d) {
    typeof b === gvjs_m && (b = [b]);
    for (var e = 0; e < b.length; ++e) {
        var f = gvjs_Wi(a, b[e], c, d);
        if (null != f) return f
    }
    return null
}

function gvjs_Wi(a, b, c, d) {
    a = d ? a[b] : gvjs_zg(b, a);
    return null != a && typeof c === gvjs_c ? c(a) : a
}
gvjs_.Wb = function(a, b) {
    var c = [];
    null != b && c.push(b);
    a = gvjs_Ti(this, a);
    for (b = this.cc.length - 1; 0 <= b; b--)
        for (var d = a.length - 1; 0 <= d; d--) {
            var e = gvjs_Wi(this.cc[b], a[d], void 0, this.OS);
            null != e && c.unshift(e)
        }
    return c
};
gvjs_.R = function(a, b, c) {
    a = gvjs_Ti(this, a);
    for (var d = 0; d < this.cc.length; d++) {
        var e = gvjs_Vi(this.cc[d], a, c, this.OS);
        if (null != e) return e
    }
    e = null != b && c ? c(b) : b;
    return null != e ? e : null
};
gvjs_.La = function(a, b, c) {
    a: {
        var d = {};a = this.Wb(a, b);
        for (b = a.length - 1; 0 <= b; b--) {
            var e = a[b];
            if (typeof e !== gvjs_g) {
                d = void 0;
                break a
            }
            gvjs_Bg(d, e)
        }
    }
    c && (d = c(d));
    return d || {}
};

function gvjs_Xi(a, b, c, d, e, f) {
    function g(h) {
        return b(h, f)
    }
    a = a.R(d, e, g);
    null == a && (a = g(c), null == a && (a = c));
    if (null == a) throw Error("Unexpected null value for " + d);
    return a
}

function gvjs_Yi(a, b, c, d) {
    a = a.R(c, null, function(e) {
        return b(e, d)
    });
    return null == a ? null : a
}

function gvjs_Zi(a, b) {
    a = null != a && typeof a !== gvjs_g ? String(a) : null;
    return b ? Array.isArray(b) ? null != a && b.includes(a) ? a : null : Object.values(b).includes(a) ? a : null : a
}

function gvjs_C(a, b, c, d) {
    return gvjs_Xi(a, gvjs_Zi, "", b, c, d)
}
gvjs_.Ca = function(a, b) {
    return gvjs_Yi(this, gvjs_Zi, a, b)
};

function gvjs__i(a, b) {
    if (null == a) return null;
    typeof a === gvjs_m && (a = [a]);
    return Array.isArray(a) ? a.map(function(c) {
        return gvjs_Zi(c, b)
    }).filter(function(c) {
        return null != c
    }) : null
}
gvjs_.Ey = function(a, b) {
    return gvjs_Yi(this, gvjs__i, a, b)
};

function gvjs_0i(a) {
    if (null == a) return null;
    if (typeof a === gvjs_Lb) return a;
    a = String(a);
    return "1" === a || a.toLowerCase() === gvjs_fe ? !0 : "0" === a || a.toLowerCase() === gvjs_8b ? !1 : null
}

function gvjs_D(a, b, c) {
    return gvjs_Xi(a, gvjs_0i, !1, b, c)
}
gvjs_.Pm = function(a) {
    return gvjs_Yi(this, gvjs_0i, a)
};

function gvjs_1i(a) {
    if (null == a) return null;
    if (typeof a === gvjs_f) return a;
    a = Number(String(a).trim());
    return isNaN(a) ? null : a
}

function gvjs_E(a, b, c) {
    return gvjs_Xi(a, gvjs_1i, 0, b, c)
}
gvjs_.ha = function(a) {
    return gvjs_Yi(this, gvjs_1i, a)
};

function gvjs_2i(a) {
    return null == a ? null : typeof a === gvjs_f || typeof a === gvjs_m || typeof a === gvjs_Lb ? a : null
}
gvjs_.lp = function(a) {
    return gvjs_Yi(this, gvjs_2i, a)
};

function gvjs_3i(a) {
    return null == a ? null : Array.isArray(a) ? a.map(gvjs_1i).filter(function(b) {
        return null != b
    }) : null
}
gvjs_.LD = function(a) {
    return gvjs_Yi(this, gvjs_3i, a)
};

function gvjs_4i(a) {
    a = gvjs_1i(a);
    return null != a && 0 <= a ? a : null
}

function gvjs_5i(a, b, c) {
    return gvjs_Xi(a, gvjs_4i, 0, b, c)
}
gvjs_.Dy = function(a) {
    return gvjs_Yi(this, gvjs_4i, a)
};

function gvjs_6i(a) {
    a = gvjs_1i(a);
    return null != a ? Math.min(Math.max(a, 0), 1) : null
}
gvjs_.cha = function(a) {
    return gvjs_Yi(this, gvjs_6i, a)
};

function gvjs_7i(a, b) {
    if (null == a) return null;
    if ("" === a) return gvjs_e;
    if (typeof a === gvjs_g) return a.color || a.lighter || a.darker ? a : null;
    a = gvjs_Zi(a);
    if (Array.isArray(b) && null != a && b.includes(a)) return a;
    try {
        return gvjs_Qi(a)
    } catch (c) {
        return null
    }
}
gvjs_.Bu = function(a, b) {
    return gvjs_Yi(this, gvjs_7i, a, b)
};

function gvjs_8i(a, b) {
    b = null != b ? b : 1;
    var c = gvjs_1i(a);
    null == c && (a = gvjs_Zi(a), null != a && (a = a.trim(), a.endsWith("%") && (c = a.slice(0, -1), c = b * Number(c) / 100)));
    null != c && (c = 0 === b ? 0 : b * Math.min(Math.max(c / b, 0), 1));
    return c
}
gvjs_.Ze = function(a, b) {
    return gvjs_Yi(this, gvjs_8i, a, b)
};
gvjs_Ri = {
    string: gvjs_Si.prototype.Ca,
    number: gvjs_Si.prototype.ha,
    "boolean": gvjs_Si.prototype.Pm,
    numberOrString: [gvjs_f, gvjs_m],
    primitive: gvjs_Si.prototype.lp,
    ratio: gvjs_Si.prototype.cha,
    nonNegative: gvjs_Si.prototype.Dy,
    absOrPercentage: gvjs_Si.prototype.Ze,
    arrayOfNumber: gvjs_Si.prototype.LD,
    arrayOfString: gvjs_Si.prototype.Ey,
    color: gvjs_Si.prototype.Bu,
    object: gvjs_Si.prototype.La
};

function gvjs_9i() {}
gvjs_9i.prototype.formatValue = function(a) {
    return this.oJ(a) || ""
};
gvjs_9i.prototype.format = function(a, b, c) {
    a.format(b, c || this)
};
gvjs_9i.prototype.Xq = function() {
    var a = this;
    return {
        format: function(b) {
            return a.formatValue(b)
        }
    }
};
gvjs_9i.prototype.yR = function(a, b) {
    return a.format(b, null)
};

function gvjs_$i(a) {
    this.Za = this.pattern = null;
    this.init(a)
}
gvjs_r(gvjs_$i, gvjs_9i);
gvjs_ = gvjs_$i.prototype;
gvjs_.init = function(a) {
    a = new gvjs_Si([a || {}, {
        formatType: gvjs_1d,
        valueType: gvjs_2b
    }]);
    this.pattern = a.R(gvjs_Md);
    this.Za = null;
    this.formatType = a.Ca("formatType", Object.values(gvjs_5aa));
    this.eca = a.Ca("valueType", Object.values(gvjs_qg));
    this.Yba = gvjs_D(a, "clearMinutes", !1);
    this.timeZone = null;
    a = a.ha("timeZone");
    null != a && (this.timeZone = gvjs_Xh(60 * -a))
};

function gvjs_6aa(a, b) {
    switch (a) {
        case gvjs_1b:
            switch (b) {
                case gvjs_9b:
                    return 0;
                case "long":
                    return 1;
                case gvjs_yd:
                    return 2;
                case gvjs_1d:
                    return 3;
                default:
                    return 8
            }
        case gvjs_2b:
            switch (b) {
                case gvjs_9b:
                    return 8;
                case "long":
                    return 9;
                case gvjs_yd:
                    return 10;
                case gvjs_1d:
                    return 11;
                default:
                    return 8
            }
        case "time":
            switch (b) {
                case gvjs_9b:
                    return 4;
                case "long":
                    return 5;
                case gvjs_yd:
                    return 6;
                case gvjs_1d:
                    return 7;
                default:
                    return 8
            }
        default:
            return 8
    }
}
gvjs_.oJ = function(a) {
    if (gvjs_aj) return gvjs_aj.call(this, a, this.pattern);
    this.Za || (this.Za = this.Xq(this.eca));
    return this.yR(this.Za, a)
};
gvjs_.fl = function(a) {
    a = gvjs_Zi(a, gvjs_qg);
    return a !== gvjs_1b && a !== gvjs_2b ? null : a
};
gvjs_.Xq = function(a) {
    var b = this.pattern;
    null == b && (b = gvjs_6aa(a, this.formatType));
    var c = new gvjs__h(b);
    return {
        format: function(d, e) {
            return c.format(d, e)
        }
    }
};
gvjs_.yR = function(a, b) {
    if (null === b) return "";
    var c = this.timeZone;
    null == c && (c = gvjs_Xh(b.getTimezoneOffset()));
    b = new Date(b.getTime());
    this.Yba && b.setMinutes(0);
    return a.format(b, c)
};
var gvjs_aj = void 0,
    gvjs_bj = gvjs_6h,
    gvjs_5aa = {
        moa: gvjs_9b,
        Doa: "long",
        Ioa: gvjs_yd,
        SHORT: gvjs_1d
    };
var gvjs_cj = {
        OY: {
            1E3: {
                other: "0K"
            },
            1E4: {
                other: "00K"
            },
            1E5: {
                other: "000K"
            },
            1E6: {
                other: "0M"
            },
            1E7: {
                other: "00M"
            },
            1E8: {
                other: "000M"
            },
            1E9: {
                other: "0B"
            },
            1E10: {
                other: "00B"
            },
            1E11: {
                other: "000B"
            },
            1E12: {
                other: "0T"
            },
            1E13: {
                other: "00T"
            },
            1E14: {
                other: "000T"
            }
        },
        u$: {
            1E3: {
                other: "0 thousand"
            },
            1E4: {
                other: "00 thousand"
            },
            1E5: {
                other: "000 thousand"
            },
            1E6: {
                other: "0 million"
            },
            1E7: {
                other: "00 million"
            },
            1E8: {
                other: "000 million"
            },
            1E9: {
                other: "0 billion"
            },
            1E10: {
                other: "00 billion"
            },
            1E11: {
                other: "000 billion"
            },
            1E12: {
                other: "0 trillion"
            },
            1E13: {
                other: "00 trillion"
            },
            1E14: {
                other: "000 trillion"
            }
        }
    },
    gvjs_dj = gvjs_cj;
gvjs_dj = gvjs_cj;
var gvjs_ej = {
    AED: [2, "dh", "\u062f.\u0625."],
    ALL: [0, "Lek", "Lek"],
    AUD: [2, "$", "AU$"],
    BDT: [2, "\u09f3", "Tk"],
    BGN: [2, "lev", "lev"],
    BRL: [2, "R$", "R$"],
    CAD: [2, "$", "C$"],
    CDF: [2, "FrCD", "CDF"],
    CHF: [2, "CHF", "CHF"],
    CLP: [0, "$", "CL$"],
    CNY: [2, "\u00a5", "RMB\u00a5"],
    COP: [32, "$", "COL$"],
    CRC: [0, "\u20a1", "CR\u20a1"],
    CZK: [50, "K\u010d", "K\u010d"],
    DKK: [50, "kr.", "kr."],
    DOP: [2, "RD$", "RD$"],
    EGP: [2, "\u00a3", "LE"],
    ETB: [2, "Birr", "Birr"],
    EUR: [2, "\u20ac", "\u20ac"],
    GBP: [2, "\u00a3", "GB\u00a3"],
    HKD: [2, "$", "HK$"],
    HRK: [2, "kn", "kn"],
    HUF: [34,
        "Ft", "Ft"
    ],
    IDR: [0, "Rp", "Rp"],
    ILS: [34, "\u20aa", "IL\u20aa"],
    INR: [2, "\u20b9", "Rs"],
    IRR: [0, "Rial", "IRR"],
    ISK: [0, "kr", "kr"],
    JMD: [2, "$", "JA$"],
    JPY: [0, "\u00a5", "JP\u00a5"],
    KRW: [0, "\u20a9", "KR\u20a9"],
    LKR: [2, "Rs", "SLRs"],
    LTL: [2, "Lt", "Lt"],
    MNT: [0, "\u20ae", "MN\u20ae"],
    MVR: [2, "Rf", "MVR"],
    MXN: [2, "$", "Mex$"],
    MYR: [2, "RM", "RM"],
    NOK: [50, "kr", "NOkr"],
    PAB: [2, "B/.", "B/."],
    PEN: [2, "S/.", "S/."],
    PHP: [2, "\u20b1", "PHP"],
    PKR: [0, "Rs", "PKRs."],
    PLN: [50, "z\u0142", "z\u0142"],
    RON: [2, "RON", "RON"],
    RSD: [0, "din", "RSD"],
    RUB: [50, "\u20bd",
        "RUB"
    ],
    SAR: [2, "SAR", "SAR"],
    SEK: [50, "kr", "kr"],
    SGD: [2, "$", "S$"],
    THB: [2, "\u0e3f", "THB"],
    TRY: [2, "\u20ba", "TRY"],
    TWD: [2, "$", "NT$"],
    TZS: [0, "TSh", "TSh"],
    UAH: [2, "\u0433\u0440\u043d.", "UAH"],
    USD: [2, "$", "US$"],
    UYU: [2, "$", "$U"],
    VND: [48, "\u20ab", "VN\u20ab"],
    YER: [0, "Rial", "Rial"],
    ZAR: [2, "R", "ZAR"]
};
var gvjs_fj = {
        DECIMAL_SEP: ".",
        GROUP_SEP: ",",
        rO: "%",
        FO: "0",
        raa: "+",
        EZ: "-",
        bZ: "E",
        LZ: "\u2030",
        oO: "\u221e",
        haa: "NaN",
        DECIMAL_PATTERN: "#,##0.###",
        uaa: "#E0",
        qaa: "#,##0%",
        v$: "\u00a4#,##0.00",
        x$: "USD"
    },
    gvjs_gj = gvjs_fj,
    gvjs_hj = gvjs_fj;
gvjs_hj = gvjs_gj = gvjs_fj;

function gvjs_ij(a) {
    this.pha = null;
    this.Cca = 0;
    this.Qja = null;
    this.yE = 40;
    this.tl = 1;
    this.Pv = 0;
    this.rl = 3;
    this.TK = this.an = 0;
    this.H8 = this.P9 = !1;
    this.bF = this.yv = "";
    this.ds = gvjs_jj(this).EZ;
    this.jz = "";
    this.fk = 1;
    this.fv = !1;
    this.qu = [];
    this.BN = this.M1 = !1;
    this.fC = 0;
    this.q0 = null;
    typeof a === gvjs_f ? this.DH(a) : this.ho(a)
}
var gvjs_kj = !1;

function gvjs_jj(a) {
    return a.Qja || (gvjs_kj ? gvjs_hj : gvjs_gj)
}

function gvjs_lj(a) {
    return a.pha || gvjs_jj(a).x$
}

function gvjs_mj(a, b) {
    if (308 < b) throw Error("Unsupported maximum fraction digits: " + b);
    a.rl = b
}

function gvjs_nj(a, b) {
    if (0 < a.an && 0 <= b) throw Error("Can't combine significant digits and minimum fraction digits");
    a.Pv = b
}
gvjs_ij.prototype.ho = function(a) {
    a.replace(/ /g, "\u00a0");
    var b = [0];
    this.yv = gvjs_oj(this, a, b);
    for (var c = b[0], d = -1, e = 0, f = 0, g = 0, h = -1, k = a.length, l = !0; b[0] < k && l; b[0]++) switch (a.charAt(b[0])) {
        case "#":
            0 < f ? g++ : e++;
            0 <= h && 0 > d && h++;
            break;
        case "0":
            if (0 < g) throw Error('Unexpected "0" in pattern "' + a + '"');
            f++;
            0 <= h && 0 > d && h++;
            break;
        case ",":
            0 < h && this.qu.push(h);
            h = 0;
            break;
        case ".":
            if (0 <= d) throw Error('Multiple decimal separators in pattern "' + a + '"');
            d = e + f + g;
            break;
        case "E":
            if (this.BN) throw Error('Multiple exponential symbols in pattern "' +
                a + '"');
            this.BN = !0;
            this.TK = 0;
            b[0] + 1 < k && "+" == a.charAt(b[0] + 1) && (b[0]++, this.P9 = !0);
            for (; b[0] + 1 < k && "0" == a.charAt(b[0] + 1);) b[0]++, this.TK++;
            if (1 > e + f || 1 > this.TK) throw Error('Malformed exponential pattern "' + a + '"');
            l = !1;
            break;
        default:
            b[0]--, l = !1
    }
    0 == f && 0 < e && 0 <= d && (f = d, 0 == f && f++, g = e - f, e = f - 1, f = 1);
    if (0 > d && 0 < g || 0 <= d && (d < e || d > e + f) || 0 == h) throw Error('Malformed pattern "' + a + '"');
    g = e + f + g;
    this.rl = 0 <= d ? g - d : 0;
    0 <= d && (this.an = e + f - d, 0 > this.an && (this.an = 0));
    this.tl = (0 <= d ? d : g) - e;
    this.BN && (this.yE = e + this.tl, 0 == this.rl &&
        0 == this.tl && (this.tl = 1));
    this.qu.push(Math.max(0, h));
    this.M1 = 0 == d || d == g;
    c = b[0] - c;
    this.bF = gvjs_oj(this, a, b);
    b[0] < a.length && ";" == a.charAt(b[0]) ? (b[0]++, 1 != this.fk && (this.fv = !0), this.ds = gvjs_oj(this, a, b), b[0] += c, this.jz = gvjs_oj(this, a, b)) : (this.ds += this.yv, this.jz += this.bF)
};
gvjs_ij.prototype.DH = function(a) {
    switch (a) {
        case 1:
            this.ho(gvjs_jj(this).DECIMAL_PATTERN);
            break;
        case 2:
            this.ho(gvjs_jj(this).uaa);
            break;
        case 3:
            this.ho(gvjs_jj(this).qaa);
            break;
        case 4:
            a = this.ho;
            var b = gvjs_jj(this).v$;
            var c = ["0"],
                d = gvjs_ej[gvjs_lj(this)];
            if (d) {
                d = d[0] & 7;
                if (0 < d) {
                    c.push(".");
                    for (var e = 0; e < d; e++) c.push("0")
                }
                b = b.replace(/0.00/g, c.join(""))
            }
            a.call(this, b);
            break;
        case 5:
            gvjs_pj(this, 1);
            break;
        case 6:
            gvjs_pj(this, 2);
            break;
        default:
            throw Error("Unsupported pattern type.");
    }
};

function gvjs_pj(a, b) {
    a.fC = b;
    a.ho(gvjs_jj(a).DECIMAL_PATTERN);
    a.an = 0;
    gvjs_mj(a, 2);
    gvjs_nj(a, 2)
}
gvjs_ij.prototype.parse = function(a, b) {
    b = b || [0];
    if (0 !== this.fC) throw Error("Parsing of compact numbers is unimplemented");
    a = a.replace(/ |\u202f/g, "\u00a0");
    var c = a.indexOf(this.yv, b[0]) == b[0],
        d = a.indexOf(this.ds, b[0]) == b[0];
    c && d && (this.yv.length > this.ds.length ? d = !1 : this.yv.length < this.ds.length && (c = !1));
    c ? b[0] += this.yv.length : d && (b[0] += this.ds.length);
    if (a.indexOf(gvjs_jj(this).oO, b[0]) == b[0]) {
        b[0] += gvjs_jj(this).oO.length;
        var e = Infinity
    } else {
        e = a;
        var f = !1,
            g = !1,
            h = !1,
            k = -1,
            l = 1,
            m = gvjs_jj(this).DECIMAL_SEP,
            n = gvjs_jj(this).GROUP_SEP,
            p = gvjs_jj(this).bZ;
        if (0 != this.fC) throw Error("Parsing of compact style numbers is not implemented");
        n = n.replace(/\u202f/g, "\u00a0");
        for (var q = ""; b[0] < e.length; b[0]++) {
            var r = e.charAt(b[0]),
                t = gvjs_qj(this, r);
            if (0 <= t && 9 >= t) q += t, h = !0;
            else if (r == m.charAt(0)) {
                if (f || g) break;
                q += ".";
                f = !0
            } else if (r == n.charAt(0) && ("\u00a0" != n.charAt(0) || b[0] + 1 < e.length && 0 <= gvjs_qj(this, e.charAt(b[0] + 1)))) {
                if (f || g) break
            } else if (r == p.charAt(0)) {
                if (g) break;
                q += "E";
                g = !0;
                k = b[0]
            } else if ("+" == r || "-" == r) {
                if (h &&
                    k != b[0] - 1) break;
                q += r
            } else if (1 == this.fk && r == gvjs_jj(this).rO.charAt(0)) {
                if (1 != l) break;
                l = 100;
                if (h) {
                    b[0]++;
                    break
                }
            } else if (1 == this.fk && r == gvjs_jj(this).LZ.charAt(0)) {
                if (1 != l) break;
                l = 1E3;
                if (h) {
                    b[0]++;
                    break
                }
            } else break
        }
        1 != this.fk && (l = this.fk);
        e = parseFloat(q) / l
    }
    if (c) {
        if (a.indexOf(this.bF, b[0]) != b[0]) return NaN;
        b[0] += this.bF.length
    } else if (d) {
        if (a.indexOf(this.jz, b[0]) != b[0]) return NaN;
        b[0] += this.jz.length
    }
    return d ? -e : e
};
gvjs_ij.prototype.format = function(a) {
    if (this.an > this.rl) throw Error(gvjs_Za);
    if (isNaN(a)) return gvjs_jj(this).haa;
    var b = [];
    var c = null === this.q0 ? a : this.q0;
    if (0 == this.fC) c = gvjs_rj;
    else {
        c = Math.abs(c);
        var d = gvjs_sj(this, 1 >= c ? 0 : gvjs_tj(c)).OQ;
        c = gvjs_sj(this, d + gvjs_tj(gvjs_uj(this, gvjs_vj(c, -d)).U4))
    }
    a = gvjs_vj(a, -c.OQ);
    (d = 0 > a || 0 == a && 0 > 1 / a) ? c.aU ? b.push(c.aU) : (b.push(c.prefix), b.push(this.ds)): (b.push(c.prefix), b.push(this.yv));
    if (isFinite(a))
        if (a *= d ? -1 : 1, a *= this.fk, this.BN) {
            var e = a;
            if (0 == e) gvjs_wj(this,
                e, this.tl, b), gvjs_xj(this, 0, b);
            else {
                var f = Math.floor(Math.log(e) / Math.log(10) + 2E-15);
                e = gvjs_vj(e, -f);
                var g = this.tl;
                1 < this.yE && this.yE > this.tl ? (g = f % this.yE, 0 > g && (g = this.yE + g), e = gvjs_vj(e, g), f -= g, g = 1) : 1 > this.tl ? (f++, e = gvjs_vj(e, -1)) : (f -= this.tl - 1, e = gvjs_vj(e, this.tl - 1));
                gvjs_wj(this, e, g, b);
                gvjs_xj(this, f, b)
            }
        } else gvjs_wj(this, a, this.tl, b);
    else b.push(gvjs_jj(this).oO);
    d ? c.bU ? b.push(c.bU) : (isFinite(a) && b.push(c.suffix), b.push(this.jz)) : (isFinite(a) && b.push(c.suffix), b.push(this.bF));
    return b.join("")
};

function gvjs_uj(a, b) {
    var c = gvjs_vj(b, a.rl);
    0 < a.Pv && (c = gvjs_yj(c, a.Pv, a.rl));
    c = Math.round(c);
    isFinite(c) ? (b = Math.floor(gvjs_vj(c, -a.rl)), a = Math.floor(c - gvjs_vj(b, a.rl))) : a = 0;
    return {
        U4: b,
        fea: a
    }
}

function gvjs_wj(a, b, c, d) {
    if (a.an > a.rl) throw Error(gvjs_Za);
    d || (d = []);
    b = gvjs_uj(a, b);
    var e = b.U4,
        f = b.fea,
        g = 0 == e ? 0 : gvjs_tj(e) + 1,
        h = 0 < a.an || 0 < f || a.H8 && g < a.Pv;
    b = a.an;
    h && (b = a.H8 && 0 < a.Pv ? a.Pv - g : a.an);
    var k = "";
    for (g = e; 1E20 < g;) k = "0" + k, g = Math.round(gvjs_vj(g, -1));
    k = g + k;
    var l = gvjs_jj(a).DECIMAL_SEP;
    g = gvjs_jj(a).FO.charCodeAt(0);
    var m = k.length,
        n = 0;
    if (0 < e || 0 < c) {
        for (e = m; e < c; e++) d.push(String.fromCharCode(g));
        if (2 <= a.qu.length)
            for (c = 1; c < a.qu.length; c++) n += a.qu[c];
        c = m - n;
        if (0 < c) {
            e = a.qu;
            n = m = 0;
            for (var p, q = gvjs_jj(a).GROUP_SEP,
                    r = k.length, t = 0; t < r; t++)
                if (d.push(String.fromCharCode(g + 1 * Number(k.charAt(t)))), 1 < r - t)
                    if (p = e[n], t < c) {
                        var u = c - t;
                        (1 === p || 0 < p && 1 === u % p) && d.push(q)
                    } else n < e.length && (t === c ? n += 1 : p === t - c - m + 1 && (d.push(q), m += p, n += 1))
        } else {
            c = k;
            k = a.qu;
            e = gvjs_jj(a).GROUP_SEP;
            p = c.length;
            q = [];
            for (m = k.length - 1; 0 <= m && 0 < p; m--) {
                n = k[m];
                for (r = 0; r < n && 0 <= p - r - 1; r++) q.push(String.fromCharCode(g + 1 * Number(c.charAt(p - r - 1))));
                p -= n;
                0 < p && q.push(e)
            }
            d.push.apply(d, q.reverse())
        }
    } else h || d.push(String.fromCharCode(g));
    (a.M1 || h) && d.push(l);
    f = String(f);
    h = f.split("e+");
    2 == h.length && (f = String(gvjs_yj(parseFloat(h[0]), a.Pv, 1)), f = f.replace(".", ""), f += gvjs_Jh("0", parseInt(h[1], 10) - f.length + 1));
    a.rl + 1 > f.length && (f = "1" + gvjs_Jh("0", a.rl - f.length) + f);
    for (a = f.length;
        "0" == f.charAt(a - 1) && a > b + 1;) a--;
    for (b = 1; b < a; b++) d.push(String.fromCharCode(g + 1 * Number(f.charAt(b))))
}

function gvjs_xj(a, b, c) {
    c.push(gvjs_jj(a).bZ);
    0 > b ? (b = -b, c.push(gvjs_jj(a).EZ)) : a.P9 && c.push(gvjs_jj(a).raa);
    b = "" + b;
    for (var d = gvjs_jj(a).FO, e = b.length; e < a.TK; e++) c.push(d);
    c.push(b)
}

function gvjs_qj(a, b) {
    b = b.charCodeAt(0);
    if (48 <= b && 58 > b) return b - 48;
    a = gvjs_jj(a).FO.charCodeAt(0);
    return a <= b && b < a + 10 ? b - a : -1
}

function gvjs_oj(a, b, c) {
    for (var d = "", e = !1, f = b.length; c[0] < f; c[0]++) {
        var g = b.charAt(c[0]);
        if ("'" == g) c[0] + 1 < f && "'" == b.charAt(c[0] + 1) ? (c[0]++, d += "'") : e = !e;
        else if (e) d += g;
        else switch (g) {
            case "#":
            case "0":
            case ",":
            case ".":
            case ";":
                return d;
            case "\u00a4":
                if (c[0] + 1 < f && "\u00a4" == b.charAt(c[0] + 1)) c[0]++, d += gvjs_lj(a);
                else switch (a.Cca) {
                    case 0:
                        g = gvjs_lj(a);
                        d += g in gvjs_ej ? gvjs_ej[g][1] : g;
                        break;
                    case 2:
                        g = gvjs_lj(a);
                        var h = gvjs_ej[g];
                        d += h ? g == h[1] ? g : g + " " + h[1] : g;
                        break;
                    case 1:
                        g = gvjs_lj(a), d += g in gvjs_ej ? gvjs_ej[g][2] :
                            g
                }
                break;
            case "%":
                if (!a.fv && 1 != a.fk) throw Error(gvjs_pb);
                if (a.fv && 100 != a.fk) throw Error(gvjs_Ra);
                a.fk = 100;
                a.fv = !1;
                d += gvjs_jj(a).rO;
                break;
            case "\u2030":
                if (!a.fv && 1 != a.fk) throw Error(gvjs_pb);
                if (a.fv && 1E3 != a.fk) throw Error(gvjs_Ra);
                a.fk = 1E3;
                a.fv = !1;
                d += gvjs_jj(a).LZ;
                break;
            default:
                d += g
        }
    }
    return d
}
var gvjs_rj = {
    OQ: 0,
    aU: "",
    bU: "",
    prefix: "",
    suffix: ""
};

function gvjs_sj(a, b) {
    a = 1 == a.fC ? gvjs_dj.OY : gvjs_dj.u$;
    null == a && (a = gvjs_dj.OY);
    if (3 > b) return gvjs_rj;
    b = Math.min(14, b);
    var c = a[gvjs_vj(1, b)];
    for (--b; !c && 3 <= b;) c = a[gvjs_vj(1, b)], b--;
    if (!c) return gvjs_rj;
    c = c.other;
    var d = a = "",
        e = c.indexOf(";");
    0 <= e && (c = c.substring(0, e), e = c.substring(e + 1)) && (d = /([^0]*)(0+)(.*)/.exec(e), a = d[1], d = d[3]);
    return c && "0" != c ? (c = /([^0]*)(0+)(.*)/.exec(c)) ? {
        OQ: b + 1 - (c[2].length - 1),
        aU: a,
        bU: d,
        prefix: c[1],
        suffix: c[3]
    } : gvjs_rj : gvjs_rj
}

function gvjs_tj(a) {
    if (!isFinite(a)) return 0 < a ? a : 0;
    for (var b = 0; 1 <= (a /= 10);) b++;
    return b
}

function gvjs_vj(a, b) {
    if (!a || !isFinite(a) || 0 == b) return a;
    a = String(a).split("e");
    return parseFloat(a[0] + "e" + (parseInt(a[1] || 0, 10) + b))
}

function gvjs_zj(a, b) {
    return a && isFinite(a) ? gvjs_vj(Math.round(gvjs_vj(a, b)), -b) : a
}

function gvjs_yj(a, b, c) {
    if (!a) return a;
    b = b - gvjs_tj(a) - 1;
    return b < -c ? gvjs_zj(a, -c) : gvjs_zj(a, b)
};

function gvjs_Aj(a) {
    this.Za = null;
    var b = new gvjs_Si([a || {}, {
        decimalSymbol: gvjs_Bj,
        groupingSymbol: gvjs_Cj,
        fractionDigits: 2,
        significantDigits: null,
        negativeParens: !1,
        prefix: "",
        suffix: "",
        scaleFactor: 1
    }]);
    this.fractionDigits = gvjs_5i(b, "fractionDigits");
    a && typeof a.fractionDigits === gvjs_f && isNaN(a.fractionDigits) && (this.fractionDigits = NaN);
    this.iW = b.Dy("significantDigits");
    this.decimalSymbol = gvjs_C(b, "decimalSymbol");
    this.groupingSymbol = gvjs_C(b, "groupingSymbol");
    this.prefix = gvjs_C(b, gvjs_Qd);
    this.suffix =
        gvjs_C(b, gvjs_7d);
    this.negativeColor = b.Bu("negativeColor");
    this.negativeParens = gvjs_D(b, "negativeParens");
    this.pattern = b.Ca(gvjs_Md);
    a = (this.pattern || "").toLowerCase();
    a in gvjs_Dj && (this.pattern = gvjs_Dj[a]);
    this.scaleFactor = gvjs_E(b, "scaleFactor");
    if (0 >= this.scaleFactor) throw Error("Scale factor must be a positive number.");
}
gvjs_r(gvjs_Aj, gvjs_9i);
gvjs_ = gvjs_Aj.prototype;
gvjs_.format = function(a, b) {
    if (a.getColumnType(b) === gvjs_f)
        for (var c = 0; c < a.getNumberOfRows(); c++) {
            var d = a.getValue(c, b);
            if (null != d) {
                var e = this.formatValue(d);
                a.setFormattedValue(c, b, e);
                0 > d && (d = this.negativeColor || "", "" !== d && a.setProperty(c, b, gvjs_6d, gvjs_Tb + d + ";"))
            }
        }
};
gvjs_.fl = function(a) {
    return a === gvjs_f ? a : null
};
gvjs_.Xq = function() {
    var a = this;
    return {
        format: function(b) {
            if (null == b) return null;
            b = Number(b);
            return a.formatValue(b)
        }
    }
};
gvjs_.oJ = function(a) {
    if (gvjs_Ej) return a = gvjs_Ej.call(this, a / this.scaleFactor, this.pattern), this.prefix + a + this.suffix;
    var b = a / this.scaleFactor;
    if (null !== this.pattern) {
        a = gvjs_kj;
        gvjs_kj = !gvjs_Fj;
        var c = new gvjs_ij(this.pattern);
        5 !== this.pattern && 6 !== this.pattern || gvjs_nj(c, 3);
        this.Za = c;
        null != this.iW && (gvjs_nj(c, this.iW), gvjs_mj(c, this.iW));
        b = c.format(b);
        b = this.prefix + b + this.suffix;
        gvjs_kj = a
    } else {
        if (isNaN(this.fractionDigits)) return String(a);
        this.negativeParens && (b = Math.abs(b));
        c = b;
        0 === this.fractionDigits &&
            (c = Math.round(c));
        b = [];
        0 > c && (c = -c, b.push("-"));
        var d = Math.pow(10, this.fractionDigits),
            e = Math.round(c * d);
        c = String(Math.floor(e / d));
        d = String(e % d);
        if (3 < c.length && this.groupingSymbol)
            for (e = c.length % 3, 0 < e && (b.push(c.substring(0, e), this.groupingSymbol), c = c.substring(e)); 3 < c.length;) b.push(c.substring(0, 3), this.groupingSymbol), c = c.substring(3);
        b.push(c);
        0 < this.fractionDigits && (b.push(this.decimalSymbol), d.length < this.fractionDigits && (d = gvjs_ma + d), b.push(d.substring(d.length - this.fractionDigits)));
        b = b.join("");
        b = this.prefix + b + this.suffix;
        this.negativeParens && 0 > a && (b = "(" + b + ")");
        this.negativeColor && (b += "")
    }
    return b
};
gvjs_.parse = function(a) {
    if (this.Za && this.Za.parse) {
        var b = gvjs_kj;
        gvjs_kj = !gvjs_Fj;
        a = this.Za.parse(a);
        gvjs_kj = b;
        return a
    }
    throw Error("Cannot parse without parser.");
};
var gvjs_Ej = void 0,
    gvjs_Bj = gvjs_gj.DECIMAL_SEP,
    gvjs_Cj = gvjs_gj.GROUP_SEP,
    gvjs_Gj = gvjs_gj.DECIMAL_PATTERN,
    gvjs_Fj = !1,
    gvjs_Dj = {
        decimal: 1,
        scientific: 2,
        percent: 3,
        currency: 4,
        "short": 5,
        "long": 6
    };

function gvjs_Hj() {}
gvjs_r(gvjs_Hj, gvjs_9i);
gvjs_Hj.prototype.fl = function(a) {
    return a === gvjs_m ? a : null
};
gvjs_Hj.prototype.oJ = function(a) {
    return String(a)
};

function gvjs_Ij(a, b) {
    this.x = a;
    this.y = b
}
gvjs_u(gvjs_Ij, gvjs_A);
gvjs_ = gvjs_Ij.prototype;
gvjs_.clone = function() {
    return new gvjs_Ij(this.x, this.y)
};
gvjs_.magnitude = function() {
    return Math.hypot(this.x, this.y)
};
gvjs_.scale = gvjs_A.prototype.scale;
gvjs_.invert = function() {
    this.x = -this.x;
    this.y = -this.y;
    return this
};
gvjs_.normalize = function() {
    return this.scale(1 / this.magnitude())
};
gvjs_.add = function(a) {
    this.x += a.x;
    this.y += a.y;
    return this
};
gvjs_.eN = gvjs_p(11);
gvjs_.rotate = function(a) {
    var b = Math.cos(a);
    a = Math.sin(a);
    var c = this.y * b + this.x * a;
    this.x = this.x * b - this.y * a;
    this.y = c;
    return this
};
gvjs_.equals = function(a) {
    return this === a ? !0 : a instanceof gvjs_Ij && !!a && this.x == a.x && this.y == a.y
};

function gvjs_Jj(a) {
    a = 4 > a.length ? a.concat(Array(4 - a.length).fill(0)) : Array.from(a);
    return a.reverse()
}

function gvjs_Kj(a) {
    a = gvjs_Jj(a);
    var b = new Date(Date.UTC(1970, 0, 1, 0, 0, 0, 0));
    b.setUTCFullYear((a[6] || 0) + 1970);
    b.setUTCMonth(a[5] || 0);
    b.setUTCDate((a[4] || 0) + 1);
    b.setUTCHours(a[3] || 0);
    b.setUTCMinutes(a[2] || 0);
    b.setUTCSeconds(a[1] || 0);
    b.setUTCMilliseconds(a[0] || 0);
    return b
}
for (var gvjs_Lj = "milliseconds seconds minutes hours days months years".split(" "), gvjs_Mj = {}, gvjs_Nj = gvjs_q(gvjs_Lj.entries()), gvjs_Oj = gvjs_Nj.next(); !gvjs_Oj.done; gvjs_Oj = gvjs_Nj.next()) {
    var gvjs_Pj = gvjs_q(gvjs_Oj.value),
        gvjs_7aa = gvjs_Pj.next().value,
        gvjs_8aa = gvjs_Pj.next().value;
    gvjs_Mj[gvjs_8aa] = gvjs_7aa
};

function gvjs_Qj(a) {
    var b = a && a.granularity;
    if (null == b || typeof b !== gvjs_f) b = 1;
    a = Object.assign({}, {
        pattern: 1 < b ? gvjs_Ja : 1 === b ? gvjs_Ka : gvjs_La
    }, a || {});
    this.Za = new gvjs_$i(a)
}
gvjs_r(gvjs_Qj, gvjs_9i);
gvjs_Qj.prototype.fl = function(a) {
    return a === gvjs_be ? a : null
};
gvjs_Qj.prototype.oJ = function(a) {
    a = gvjs_Kj(a);
    return this.Za.formatValue(a)
};

function gvjs_Rj(a) {
    var b = {};
    if (gvjs_Me(a) !== gvjs_g || gvjs_Oe(a)) b.v = null != a ? a : null;
    else {
        b.v = "undefined" === typeof a.v ? null : a.v;
        if (null != a.f)
            if (typeof a.f === gvjs_m) b.f = a.f;
            else throw Error("Formatted value ('f'), if specified, must be a string.");
        if (null != a.p)
            if (typeof a.p === gvjs_g) b.p = a.p;
            else throw Error("Properties ('p'), if specified, must be an object.");
    }
    return b
}

function gvjs_9aa(a, b, c) {
    if (typeof b === gvjs_c) return b(a, c);
    for (var d = 0; d < b.length; d++) {
        var e = b[d],
            f = a.getColumnIndex(e.column),
            g = a.getValue(c, f),
            h = a.getColumnType(f);
        if (gvjs_o in e) {
            if (0 !== gvjs_Sj(h, g, e.value)) return !1
        } else if (null != e.minValue || null != e.maxValue)
            if (null == g || null != e.minValue && 0 > gvjs_Sj(h, g, e.minValue) || null != e.maxValue && 0 < gvjs_Sj(h, g, e.maxValue)) return !1;
        e = e.test;
        if (null != e && typeof e === gvjs_c && !e(g, c, f, a)) return !1
    }
    return !0
}

function gvjs_Tj(a, b) {
    if (typeof b !== gvjs_c) {
        if (!Array.isArray(b) || 0 === b.length) throw Error("columnFilters must be a non-empty array");
        for (var c = [], d = 0, e = gvjs_q(b), f = e.next(); !f.done; f = e.next()) {
            f = f.value;
            if (typeof f !== gvjs_g || !(gvjs_Vb in f)) {
                if (!(gvjs_o in f || gvjs_Ad in f || gvjs_xd in f)) throw Error(gvjs_Wb + d + '] must have properties "column" and one of "value", "minValue" or "maxValue"');
                if (gvjs_o in f && (gvjs_Ad in f || gvjs_xd in f)) throw Error(gvjs_Wb + d + '] must specify either "value" or range properties ("minValue" and/or "maxValue"');
            }
            var g = f.column;
            gvjs_Uj(a, g);
            var h = a.getColumnIndex(g);
            if (c[h]) throw Error(gvjs_xa + g + " is duplicate in columnFilters.");
            gvjs_Vj(a, h, f.value);
            c[h] = !0;
            d++
        }
    }
    c = [];
    d = a.getNumberOfRows();
    for (e = 0; e < d; e++) gvjs_9aa(a, b, e) && c.push(e);
    return c
}

function gvjs_Wj(a, b, c) {
    if (typeof b === gvjs_g && gvjs_Vb in b) {
        if ("desc" in b && typeof b.desc !== gvjs_Lb) throw Error('Property "desc" in ' + c + " must be boolean.");
        if (null != b.compare && typeof b.compare !== gvjs_c) throw Error('Property "compare" in ' + c + " must be a function.");
    } else throw Error(c + ' must be an object with a "column" property.');
    gvjs_Uj(a, b.column)
}

function gvjs_Xj(a, b, c) {
    function d(l, m) {
        for (var n = 0; n < e.length; n++) {
            var p = e[n],
                q = p.column,
                r = b(l, q),
                t = b(m, q),
                u = p.compare;
            q = null != u ? null === r ? null === t ? 0 : -1 : null === t ? 1 : u(r, t) : gvjs_Sj(a.getColumnType(q), r, t);
            if (0 !== q) return q * (p.desc ? -1 : 1)
        }
        return 0
    }
    var e = [];
    if (typeof c === gvjs_c) d = c;
    else if (typeof c === gvjs_f || typeof c === gvjs_m) gvjs_Uj(a, c), e = [{
        column: a.getColumnIndex(c)
    }];
    else if (gvjs_pg(c))
        if (Array.isArray(c)) {
            if (0 === c.length) throw Error("sortColumns is an empty array. Must have at least one element.");
            e = [];
            for (var f = [], g = 0, h = 0; h < c.length; h++) {
                g = c[h];
                if (typeof g === gvjs_f || typeof g === gvjs_m) gvjs_Uj(a, g), g = a.getColumnIndex(g), e.push({
                    column: g
                });
                else if (gvjs_pg(g)) {
                    var k = g;
                    gvjs_Wj(a, k, "sortColumns[" + h + "]");
                    g = k.column;
                    g = a.getColumnIndex(g);
                    k.column = g;
                    e.push(k)
                } else throw Error("sortColumns is an array, but not composed of only objects or numbers.");
                if (g in f) throw Error("Column index " + g + " is duplicated in sortColumns.");
                f[g] = !0
            }
        } else gvjs_Wj(a, c, "sortColumns"), e = [c];
    return d
}

function gvjs_Sj(a, b, c) {
    if (null == b) return null == c ? 0 : -1;
    if (null == c) return 1;
    if (a === gvjs_be) {
        for (a = 0; 3 > a; a++) {
            if (b[a] < c[a]) return -1;
            if (c[a] < b[a]) return 1
        }
        b = 4 > b.length ? 0 : b[3];
        c = 4 > c.length ? 0 : c[3];
        return b < c ? -1 : c < b ? 1 : 0
    }
    return b < c ? -1 : c < b ? 1 : 0
}

function gvjs_Yj(a, b) {
    b = gvjs_Xj(a, function(f, g) {
        return a.getValue(f, g)
    }, b);
    for (var c = [], d = a.getNumberOfRows(), e = 0; e < d; e++) c.push(e);
    gvjs_Zj(c, b);
    return c
}

function gvjs_Zj(a, b) {
    for (var c = Array(a.length), d = 0; d < a.length; d++) c[d] = {
        index: d,
        value: a[d]
    };
    c.sort(function(e, f) {
        return b(e.value, f.value) || e.index - f.index
    });
    for (d = 0; d < a.length; d++) a[d] = c[d].value
}

function gvjs__j(a, b) {
    a = a.getNumberOfRows();
    if (0 < a) {
        if (Math.floor(b) !== b || 0 > b || b >= a) throw Error("Invalid row index " + b + ". Should be in the range [0-" + (a - 1 + "]."));
    } else throw Error("Table has no rows.");
}

function gvjs_Uj(a, b) {
    if (typeof b === gvjs_f) gvjs_0j(a, b);
    else {
        if (typeof b !== gvjs_m) throw Error("Column reference " + b + " must be a number or string");
        if (-1 === a.getColumnIndex(b)) throw Error('Invalid column id "' + b + '"');
    }
}

function gvjs_0j(a, b) {
    a = a.getNumberOfColumns();
    if (0 < a) {
        if (Math.floor(b) !== b || 0 > b || b >= a) throw Error("Invalid column index " + b + ".  Should be an integer in the range [0-" + (a - 1 + "]."));
    } else throw Error("Table has no columns.");
}

function gvjs_Vj(a, b, c) {
    a = a.getColumnType(b);
    if (!gvjs_1j(c, a)) throw Error(gvjs_sb + c + gvjs_aa + a + (" in column index " + b));
}

function gvjs_1j(a, b) {
    if (null == a) return !0;
    var c = typeof a;
    switch (b) {
        case gvjs_f:
            if (c === gvjs_f) return !0;
            break;
        case gvjs_m:
            if (c === gvjs_m) return !0;
            break;
        case gvjs_Lb:
            if (c === gvjs_Lb) return !0;
            break;
        case gvjs_c:
            if (c === gvjs_c) return !0;
            break;
        case gvjs_1b:
        case gvjs_2b:
            if (gvjs_Oe(a)) return !0;
            break;
        case gvjs_be:
            if (Array.isArray(a) && 0 < a.length && 8 > a.length) {
                b = !0;
                for (c = 0; c < a.length; c++) {
                    var d = a[c];
                    if (typeof d !== gvjs_f || d !== Math.floor(d)) {
                        b = !1;
                        break
                    }
                }
                if (b) return !0
            }
    }
    return !1
}

function gvjs_2j(a, b) {
    gvjs_Uj(a, b);
    b = a.getColumnIndex(b);
    var c = a.getColumnType(b),
        d = null,
        e = null,
        f, g = a.getNumberOfRows();
    for (f = 0; f < g; f++) {
        var h = a.getValue(f, b);
        if (null != h) {
            e = d = h;
            break
        }
    }
    if (null == d) return {
        min: null,
        max: null
    };
    for (f++; f < g; f++) h = a.getValue(f, b), null != h && (0 > gvjs_Sj(c, h, d) ? d = h : 0 > gvjs_Sj(c, e, h) && (e = h));
    return {
        min: d,
        max: e
    }
}

function gvjs_3j(a, b) {
    gvjs_Uj(a, b);
    var c = a.getColumnIndex(b),
        d = a.getNumberOfRows();
    if (0 === d) return [];
    b = [];
    for (var e = 0; e < d; ++e) b.push(a.getValue(e, c));
    var f = a.getColumnType(c);
    gvjs_Zj(b, function(g, h) {
        return gvjs_Sj(f, g, h)
    });
    a = b[0];
    c = [];
    c.push(a);
    for (d = 1; d < b.length; d++) e = b[d], 0 !== gvjs_Sj(f, e, a) && c.push(e), a = e;
    return c
}

function gvjs_4j(a, b, c) {
    if (null == a) return "";
    if (c) return c.formatValue(a);
    switch (b) {
        case gvjs_be:
            if (!(a instanceof Array)) throw Error("Type of value, " + a + ", is not timeofday");
            b = new Date(1970, 0, 1, a[0], a[1], a[2], a[3] || 0);
            c = gvjs_Ja;
            if (a[2] || a[3]) c += ":ss";
            a[3] && (c += ".SSS");
            c = new gvjs_$i({
                pattern: c
            });
            a = c.formatValue(b);
            break;
        case gvjs_1b:
            c = new gvjs_$i({
                formatType: gvjs_yd,
                valueType: gvjs_1b
            });
            a = c.formatValue(a);
            break;
        case gvjs_2b:
            c = new gvjs_$i({
                formatType: gvjs_yd,
                valueType: gvjs_2b
            });
            a = c.formatValue(a);
            break;
        case gvjs_f:
            c = new gvjs_Aj({
                pattern: gvjs_3b
            });
            a = c.formatValue(a);
            break;
        default:
            a = null != a ? String(a) : ""
    }
    return a
}

function gvjs_$aa(a) {
    switch (a) {
        case gvjs_be:
            return new gvjs_Qj;
        case gvjs_1b:
            return new gvjs_$i;
        case gvjs_2b:
            return new gvjs_$i({
                formatType: gvjs_yd,
                valueType: gvjs_2b
            });
        case gvjs_f:
            return new gvjs_Aj({
                pattern: gvjs_3b
            });
        default:
            return new gvjs_Hj
    }
}

function gvjs_5j(a, b, c) {
    var d = a.getColumnType(b);
    if (null == c) c = gvjs_$aa(d);
    else if (null == c.fl(d)) return;
    d = c.fl(d);
    d = c.Xq(d);
    for (var e = a.getNumberOfRows(), f = 0; f < e; f++) {
        var g = a.getValue(f, b);
        g = c.yR(d, g);
        a.setFormattedValue(f, b, g)
    }
}

function gvjs_6j(a, b, c, d) {
    for (var e = null, f = a.getNumberOfRows();
        (d ? 0 <= b : b < f) && null === e;) e = a.getValue(b, c), b += d ? -1 : 1;
    return e
}

function gvjs_7j(a) {
    if (!a) throw Error("Data table is not defined.");
    if (!(a instanceof gvjs_rg)) {
        var b = "the wrong type of data";
        Array.isArray(a) ? b = "an Array" : typeof a === gvjs_m && (b = "a String");
        throw Error("You called the draw() method with " + b + " rather than a DataTable or DataView");
    }
};
var gvjs_aba = {
    Dpa: "0.5",
    Epa: "0.6"
};

function gvjs_F(a, b) {
    this.Hi = null;
    this.Ud = [];
    this.Cd = [];
    this.In = null;
    this.cache = [];
    if (typeof this.getTableProperties !== gvjs_c) throw Error('You called google.visualization.DataTable() without the "new" keyword');
    this.version = "0.5" === b ? "0.5" : "0.6";
    if (null != a) {
        if (typeof a === gvjs_m) a = gvjs_Jg(a);
        else a: {
            b = a.cols || [];
            for (var c = a.rows || [], d = b.length, e = 0; e < d; e++) {
                var f = b[e].type;
                if (f === gvjs_1b || f === gvjs_2b) {
                    f = c.length;
                    for (var g = 0; g < f; g++) {
                        var h = c[g].c[e];
                        if (h) {
                            var k = h.v;
                            if (gvjs_Oe(k)) break a;
                            typeof k === gvjs_m &&
                                (h = gvjs_Gg(h), h = gvjs_Jg(h), c[g].c[e] = h)
                        }
                    }
                }
            }
        }
        this.In = a.p || null;
        if (null != a.cols)
            for (b = gvjs_q(a.cols), c = b.next(); !c.done; c = b.next()) this.addColumn(c.value);
        null != a.rows && (this.Cd = a.rows)
    } else this.Ud = [], this.Cd = [], this.In = null;
    this.cache = []
}
gvjs_r(gvjs_F, gvjs_rg);
gvjs_ = gvjs_F.prototype;
gvjs_.getNumberOfRows = function() {
    return this.Cd.length
};
gvjs_.getNumberOfColumns = function() {
    return this.Ud.length
};
gvjs_.Hm = gvjs_p(14);
gvjs_.getColumnId = function(a) {
    gvjs_0j(this, a);
    return this.Ud[a].id || ""
};
gvjs_.getColumnLabel = function(a) {
    gvjs_0j(this, a);
    return String(this.Ud[a].label || "")
};
gvjs_.getColumnPattern = function(a) {
    gvjs_0j(this, a);
    a = this.Ud[a].pattern;
    return "undefined" !== typeof a ? a : null
};
gvjs_.getColumnRole = function(a) {
    a = this.getColumnProperty(a, gvjs_Vd);
    return typeof a === gvjs_m ? a : ""
};
gvjs_.getColumnType = function(a) {
    gvjs_0j(this, a);
    a = this.Ud[a].type;
    return "undefined" !== typeof a ? a : gvjs_m
};
gvjs_.getValue = function(a, b) {
    gvjs__j(this, a);
    gvjs_0j(this, b);
    a = this.mg(a, b);
    b = null;
    a && (b = a.v, b = "undefined" !== typeof b ? b : null);
    return b
};
gvjs_.mg = function(a, b) {
    return this.Cd[a].c[b]
};
gvjs_.getFormattedValue = function(a, b, c) {
    gvjs__j(this, a);
    gvjs_0j(this, b);
    var d = this.mg(a, b),
        e = "";
    if (d)
        if (null != d.f) e = String(d.f);
        else {
            this.cache[a] = this.cache[a] || [];
            var f = this.cache[a];
            d = f[b] || {};
            f[b] = d;
            "undefined" !== typeof d.qe ? e = d.qe : (a = this.getValue(a, b), null !== a && (e = gvjs_4j(a, this.getColumnType(b), c), null == e && (e = void 0)), d.qe = e)
        }
    return null == e ? "" : e.toString()
};
gvjs_.format = function(a, b) {
    gvjs_5j(this, a, b)
};
gvjs_.getProperty = function(a, b, c) {
    gvjs__j(this, a);
    gvjs_0j(this, b);
    return (a = (a = this.mg(a, b)) && a.p) && c in a ? a[c] : null
};
gvjs_.getProperties = function(a, b) {
    gvjs__j(this, a);
    gvjs_0j(this, b);
    var c = this.mg(a, b);
    c || (c = {
        v: null
    }, this.Cd[a].c[b] = c);
    c.p || (c.p = {});
    return c.p
};
gvjs_.getTableProperties = function() {
    return this.In
};
gvjs_.getTableProperty = function(a) {
    var b = this.In;
    return b && a in b ? b[a] : null
};
gvjs_.setTableProperties = function(a) {
    this.In = a || {}
};
gvjs_.setTableProperty = function(a, b) {
    null == this.In && (this.In = {});
    this.In[a] = b
};
gvjs_.setValue = function(a, b, c) {
    this.setCell(a, b, c, void 0, void 0)
};
gvjs_.setFormattedValue = function(a, b, c) {
    this.setCell(a, b, void 0, c, void 0)
};
gvjs_.setProperties = function(a, b, c) {
    this.setCell(a, b, void 0, void 0, c)
};
gvjs_.setProperty = function(a, b, c, d) {
    this.getProperties(a, b)[c] = d
};
gvjs_.setCell = function(a, b, c, d, e) {
    gvjs__j(this, a);
    gvjs_0j(this, b);
    var f = this.cache[a];
    f && f[b] && (f[b] = {});
    f = this.mg(a, b);
    f || (f = {}, this.Cd[a].c[b] = f);
    "undefined" !== typeof c && (this.getColumnType(b) !== gvjs_f || typeof c !== gvjs_m || isNaN(c) ? (gvjs_Vj(this, b, c), f.v = c) : f.v = Number(c));
    "undefined" !== typeof d && (f.f = d);
    "undefined" !== typeof e && (f.p = gvjs_pg(e) ? e : {})
};
gvjs_.setRowProperties = function(a, b) {
    gvjs__j(this, a);
    this.Cd[a].p = b
};
gvjs_.setRowProperty = function(a, b, c) {
    this.getRowProperties(a)[b] = c
};
gvjs_.getRowProperty = function(a, b) {
    gvjs__j(this, a);
    return (a = (a = this.Cd[a]) && a.p) && b in a ? a[b] : null
};
gvjs_.getRowProperties = function(a) {
    gvjs__j(this, a);
    a = this.Cd[a];
    a.p || (a.p = {});
    return a.p
};
gvjs_.setColumnLabel = function(a, b) {
    gvjs_0j(this, a);
    this.Ud[a].label = b
};
gvjs_.setColumnProperties = function(a, b) {
    gvjs_0j(this, a);
    this.Ud[a].p = b
};
gvjs_.setColumnProperty = function(a, b, c) {
    this.getColumnProperties(a)[b] = c
};
gvjs_.getColumnProperty = function(a, b) {
    gvjs_0j(this, a);
    return (a = (a = this.Ud[a]) && a.p) && b in a ? a[b] : null
};
gvjs_.getColumnProperties = function(a) {
    gvjs_0j(this, a);
    a = this.Ud[a];
    a.p || (a.p = {});
    return a.p
};
gvjs_.insertColumn = function(a, b, c, d) {
    a !== this.Ud.length && (this.cache = [], gvjs_0j(this, a));
    if (typeof b === gvjs_m) {
        var e = b;
        c = c || "";
        d = d || "";
        b = {
            id: d,
            label: c,
            pattern: "",
            type: e
        }
    }
    if (!gvjs_pg(b)) throw Error("Invalid column specification, " + b + gvjs_ka + a + '".');
    gvjs_qd in b && (c = b.label);
    gvjs_nd in b && (d = b.id);
    c = c || d || a;
    gvjs_ge in b && (e = b.type);
    null == e && (e = gvjs_m);
    if (!Object.values(gvjs_qg).includes(e)) throw Error("Invalid type, " + e + gvjs_ka + c + '".');
    b = Object.assign({}, b, {
        type: e
    });
    if (e = b.role) c = b.p || {}, null == c.role &&
        (c.role = e, b.p = c);
    this.Ud.splice(a, 0, b);
    this.Hi = null;
    for (b = 0; b < this.Cd.length; b++) this.Cd[b].c.splice(a, 0, {
        v: null
    })
};
gvjs_.addColumn = function(a, b, c) {
    this.insertColumn(this.Ud.length, a, b, c);
    return this.Ud.length - 1
};
gvjs_.insertRows = function(a, b) {
    a !== this.Cd.length && (this.cache = [], gvjs__j(this, a));
    if (!Array.isArray(b))
        if (typeof b === gvjs_f) {
            if (b !== Math.floor(b) || 0 > b) throw Error(gvjs_Ua + b + ". If numOrArray is a number it must be a nonnegative integer.");
            b = Array(b).fill(null)
        } else throw Error(gvjs_Ua + b + ".Must be a non-negative number or an array of arrays of cells.");
    for (var c = [], d = 0; d < b.length; d++) {
        var e = b[d],
            f = [];
        if (null === e)
            for (e = 0; e < this.Ud.length; e++) f.push({
                v: null
            });
        else if (Array.isArray(e)) {
            if (e.length !==
                this.Ud.length) throw Error("Row " + d + " given with size different than " + this.Ud.length + " (the number of columns in the table).");
            for (var g = 0; g < e.length; g++) {
                var h = f,
                    k = h.push,
                    l = g,
                    m = gvjs_Rj(e[g]);
                gvjs_Vj(this, l, m.v);
                k.call(h, m)
            }
        } else throw Error("Row " + d + " is not null or an array.");
        c.push({
            c: f
        });
        1E4 === c.length && (this.Cd.splice.apply(this.Cd, [a, 0].concat(gvjs_we(c))), a += c.length, c = [])
    }
    this.Cd.splice.apply(this.Cd, [a, 0].concat(gvjs_we(c)));
    return a + c.length - 1
};
gvjs_.addRows = function(a) {
    if (typeof a === gvjs_f || Array.isArray(a)) return this.insertRows(this.Cd.length, a);
    throw Error("Argument given to addRows must be either a number or an array");
};
gvjs_.addRow = function(a) {
    if (Array.isArray(a)) return this.addRows([a]);
    if (null == a) return this.addRows(1);
    throw Error("If argument is given to addRow, it must be an array, or null");
};
gvjs_.getColumnRange = function(a) {
    return gvjs_2j(this, a)
};
gvjs_.getSortedRows = function(a) {
    return gvjs_Yj(this, a)
};
gvjs_.sort = function(a) {
    this.cache = [];
    a = gvjs_Xj(this, function(b, c) {
        b = b.c[c];
        return null != b && typeof b === gvjs_g && "v" in b ? b.v : null
    }, a);
    gvjs_Zj(this.Cd, a)
};
gvjs_.getTableRowIndex = function(a) {
    return a
};
gvjs_.getUnderlyingTableColumnIndex = function(a) {
    gvjs_0j(this, a);
    return a
};
gvjs_.getUnderlyingTableRowIndex = function(a) {
    gvjs__j(this, a);
    return a
};
gvjs_.toDataTable = function() {
    return this.clone()
};
gvjs_.clone = function() {
    return new gvjs_F(this.toPOJO())
};
gvjs_.toPOJO = function() {
    var a = {
        cols: this.Ud,
        rows: this.Cd
    };
    this.In && (a.p = this.In);
    return gvjs_Hg(a, gvjs_Ig)
};
gvjs_.toJSON = function() {
    for (var a = 0; a < this.Ud.length; a++)
        if (this.getColumnType(a) === gvjs_c) throw Error("Cannot get JSON representation of data table due to function data type at column " + a);
    return gvjs_Fg(this.toPOJO())
};
gvjs_.getDistinctValues = function(a) {
    return gvjs_3j(this, a)
};
gvjs_.getFilteredRows = function(a) {
    return gvjs_Tj(this, a)
};
gvjs_.removeRows = function(a, b) {
    0 >= b || (this.cache = [], gvjs__j(this, a), a + b > this.Cd.length && (b = this.Cd.length - a), this.Cd.splice(a, b))
};
gvjs_.removeRow = function(a) {
    this.removeRows(a, 1)
};
gvjs_.removeColumns = function(a, b) {
    if (!(0 >= b)) {
        this.cache = [];
        gvjs_0j(this, a);
        a + b > this.Ud.length && (b = this.Ud.length - a);
        this.Ud.splice(a, b);
        this.Hi = null;
        for (var c = 0; c < this.Cd.length; c++) this.Cd[c].c.splice(a, b)
    }
};
gvjs_.removeColumn = function(a) {
    this.removeColumns(a, 1)
};

function gvjs_8j(a) {
    return null == a ? null : a instanceof gvjs_rg ? a : Array.isArray(a) ? gvjs_9j(a) : new gvjs_F(a)
}

function gvjs_bba(a, b) {
    if (b) {
        if (!Array.isArray(a)) throw Error("Column header row must be an array.");
        b = a.map(function(d) {
            if (typeof d === gvjs_m) return {
                label: d
            };
            if (gvjs_pg(d)) return Object.assign({}, d);
            throw Error("Unknown type of column header: " + d);
        })
    } else {
        b = [];
        var c = 0;
        Array.isArray(a) ? c = a.length : gvjs_pg(a) && null != a && "c" in a && Array.isArray(a.c) && (c = a.c.length);
        for (a = 0; a < c; a++) b.push({
            type: void 0
        })
    }
    return b
}

function gvjs_9j(a, b) {
    if (!Array.isArray(a)) throw Error("Data for arrayToDataTable is not an array.");
    if (0 === a.length) b = new gvjs_F;
    else {
        var c = !b;
        if (0 === a.length) throw Error("Array of rows must be non-empty");
        b = gvjs_bba(a[0], c);
        var d = [];
        for (c = c ? 1 : 0; c < a.length; c++) {
            var e = void 0,
                f = a[c],
                g = c;
            if (Array.isArray(f)) var h = f;
            else if (gvjs_pg(f) && null != f && "c" in f) h = f.c, e = f.p;
            else throw Error("Invalid row #" + g);
            if (h.length !== b.length) throw Error("Row " + g + " has " + h.length + " columns, but must have " + b.length);
            h = Array.from(h);
            e = {
                c: h,
                p: e
            };
            for (f = 0; f < b.length; f++)
                if (g = h[f], gvjs_pg(g) && ("v" in g || "f" in g) ? g = g.v : h[f] = {
                        v: g
                    }, null == b[f].type || "date?" === b[f].type) {
                    var k = null;
                    if (null != g)
                        if (typeof g === gvjs_m) k = gvjs_m;
                        else if (typeof g === gvjs_f) k = gvjs_f;
                    else if (Array.isArray(g)) k = gvjs_be;
                    else if (typeof g === gvjs_Lb) k = gvjs_Lb;
                    else if (gvjs_Oe(g)) g = new Date(g.getTime()), k = 0 !== g.getHours() + g.getMinutes() + g.getSeconds() + g.getMilliseconds() ? gvjs_2b : gvjs_1b;
                    else throw Error("Unknown type of value, " + g);
                    g = k;
                    null == b[f].type && g === gvjs_1b && (g =
                        "date?");
                    null != g && (b[f].type = g)
                }
            d.push(e)
        }
        for (a = 0; a < b.length; a++) c = b[a], "date?" === c.type && (c.type = gvjs_1b);
        b = new gvjs_F({
            cols: b,
            rows: d
        })
    }
    return b
}

function gvjs_$j(a) {
    function b(k) {
        for (var l = Object.keys(k), m = l.length, n = Array(m); m--;) n[m] = [l[m], k[l[m]]];
        return n
    }
    for (var c = {}, d = 0, e = gvjs_q(a), f = e.next(); !f.done; f = e.next()) {
        f = gvjs_q(b(f.value));
        for (var g = f.next(); !g.done; g = f.next()) g = gvjs_q(g.value).next().value, c[g] || (c[g] = {
            id: g,
            index: d++
        })
    }
    d = [];
    e = [];
    f = gvjs_q(b(c));
    for (g = f.next(); !g.done; g = f.next()) {
        var h = gvjs_q(g.value);
        g = h.next().value;
        h = h.next().value;
        e[h.index] = {
            id: g
        }
    }
    d.unshift(e);
    a = gvjs_q(a);
    for (f = a.next(); !f.done; f = a.next())
        for (f = f.value,
            e = [], d.push(e), f = gvjs_q(b(f)), g = f.next(); !g.done; g = f.next()) h = gvjs_q(g.value), g = h.next().value, h = h.next().value, e[c[g].index] = h;
    return gvjs_9j(d)
}

function gvjs_cba(a) {
    a = a.map(function(b) {
        return {
            data: b
        }
    });
    return gvjs_$j(a)
};

function gvjs_G(a) {
    this.Hi = null;
    this.dataTable = a;
    this.columns = [];
    this.Rm = !0;
    this.qn = null;
    this.zP = [];
    this.wP = !0;
    var b = [];
    a = a.getNumberOfColumns();
    for (var c = 0; c < a; c++) b.push(c);
    this.columns = b
}
gvjs_r(gvjs_G, gvjs_rg);
gvjs_ = gvjs_G.prototype;
gvjs_.getDataTable = function() {
    return this.dataTable
};

function gvjs_dba(a, b, c) {
    return c.map(function(d) {
        if (typeof d === gvjs_m) d = a.getColumnIndex(d);
        else if (gvjs_pg(d)) {
            d = gvjs_yg(d);
            var e = d.properties || {};
            delete d.properties;
            d.p = e;
            var f = d.role;
            f && (e.role = f);
            e = d.sourceColumn;
            typeof e === gvjs_m && (e = d.sourceColumn = a.getColumnIndex(e));
            typeof e === gvjs_f && (gvjs_0j(b, e), d.calc = d.calc || "identity", d.type = d.type || b.getColumnType(e))
        }
        return d
    })
}

function gvjs_ak(a) {
    a.wP = !0;
    a.Hi = null
}

function gvjs_eba(a) {
    for (var b = [], c = a.dataTable.getNumberOfRows(), d = 0; d < c; d++) b.push(d);
    a.qn = b;
    gvjs_ak(a)
}
gvjs_.setColumns = function(a) {
    for (var b = this.dataTable, c = Object.keys(gvjs_bk), d = 0; d < a.length; d++) {
        var e = a[d];
        if (typeof e === gvjs_f || typeof e === gvjs_m) gvjs_Uj(b, e);
        else if (gvjs_pg(e)) {
            var f = e.sourceColumn,
                g = e.calc;
            if (typeof g === gvjs_m) {
                if (!c || c && !c.includes(g)) throw Error('Unknown function "' + g + '"');
                null != f && gvjs_Uj(b, f)
            } else if (null != g && !e.type) throw Error('Calculated column must have a "type" property.');
        } else throw Error("Invalid column input, expected either a number, string, or an object.");
    }
    this.columns =
        gvjs_dba(this, this.dataTable, a);
    gvjs_ak(this)
};
gvjs_.Hm = gvjs_p(13);

function gvjs_ck(a, b, c) {
    if (Array.isArray(b)) {
        if (void 0 !== c) throw Error("If the first parameter is an array, no second parameter is expected");
        for (c = 0; c < b.length; c++) gvjs__j(a.dataTable, b[c]);
        return Array.from(b)
    }
    if (typeof b === gvjs_f) {
        if (typeof c !== gvjs_f) throw Error("If first parameter is a number, second parameter must be specified and be a number.");
        if (b > c) throw Error("The first parameter (min) must be smaller than or equal to the second parameter (max).");
        gvjs__j(a.dataTable, b);
        gvjs__j(a.dataTable,
            c);
        for (a = []; b <= c; b++) a.push(b);
        return a
    }
    throw Error("First parameter must be a number or an array.");
}
gvjs_.setRows = function(a, b) {
    this.qn = gvjs_ck(this, a, b);
    this.Rm = !1;
    gvjs_ak(this)
};
gvjs_.getViewColumns = function() {
    return gvjs_yg(this.columns)
};
gvjs_.getViewRows = function() {
    if (this.Rm) {
        for (var a = [], b = this.dataTable.getNumberOfRows(), c = 0; c < b; c++) a.push(c);
        return a
    }
    return Array.from(this.qn || [])
};
gvjs_.hideColumns = function(a) {
    this.setColumns(this.columns.filter(function(b) {
        return !a.includes(b)
    }));
    gvjs_ak(this)
};
gvjs_.hideRows = function(a, b) {
    var c = gvjs_ck(this, a, b);
    this.Rm && (gvjs_eba(this), this.Rm = !1);
    this.setRows((this.qn || []).filter(function(d) {
        return !c.includes(d)
    }));
    gvjs_ak(this)
};
gvjs_.getViewColumnIndex = function(a) {
    for (var b = 0; b < this.columns.length; b++) {
        var c = this.columns[b];
        if (c === a || gvjs_pg(c) && c.sourceColumn === a) return b
    }
    return -1
};
gvjs_.getViewRowIndex = function(a) {
    return this.Rm ? 0 > a || a >= this.dataTable.getNumberOfRows() ? -1 : a : (this.qn || []).indexOf(a)
};
gvjs_.getTableColumnIndex = function(a) {
    gvjs_0j(this, a);
    a = this.columns[a];
    return typeof a === gvjs_f ? a : gvjs_pg(a) && typeof a.sourceColumn === gvjs_f ? a.sourceColumn : -1
};
gvjs_.getUnderlyingTableColumnIndex = function(a) {
    a = this.getTableColumnIndex(a);
    return -1 === a ? a : a = this.dataTable.getUnderlyingTableColumnIndex(a)
};
gvjs_.getTableRowIndex = function(a) {
    gvjs__j(this, a);
    return this.Rm ? a : this.qn[a]
};
gvjs_.getUnderlyingTableRowIndex = function(a) {
    a = this.getTableRowIndex(a);
    return a = this.dataTable.getUnderlyingTableRowIndex(a)
};
gvjs_.getNumberOfRows = function() {
    return this.Rm ? this.dataTable.getNumberOfRows() : this.qn.length
};
gvjs_.getNumberOfColumns = function() {
    return this.columns.length
};
gvjs_.getColumnId = function(a) {
    gvjs_0j(this, a);
    a = this.columns[a];
    return typeof a === gvjs_f ? this.dataTable.getColumnId(a) : a.id || ""
};
gvjs_.getColumnLabel = function(a) {
    gvjs_0j(this, a);
    a = this.columns[a];
    return typeof a === gvjs_f ? this.dataTable.getColumnLabel(a) : a.label || ""
};
gvjs_.getColumnPattern = function(a) {
    gvjs_0j(this, a);
    a = this.columns[a];
    return typeof a === gvjs_f ? this.dataTable.getColumnPattern(a) : null
};
gvjs_.getColumnRole = function(a) {
    a = this.getColumnProperty(a, gvjs_Vd);
    return typeof a === gvjs_m ? a : ""
};
gvjs_.getColumnType = function(a) {
    gvjs_0j(this, a);
    a = this.columns[a];
    return typeof a === gvjs_f ? this.dataTable.getColumnType(a) : a.type
};
gvjs_.mg = function(a, b) {
    gvjs_0j(this, b);
    var c = this.columns[b],
        d = null;
    a = this.getTableRowIndex(a);
    if (gvjs_pg(c)) {
        if (this.wP) {
            for (c = 0; c < this.columns.length; c++) gvjs_pg(this.columns[c]) && (this.zP[c] = []);
            this.wP = !1
        }
        c = this.zP[b][a];
        if (void 0 !== c) d = c;
        else {
            c = null;
            d = this.columns[b];
            var e = d.calc;
            if (typeof e === gvjs_m) {
                c = gvjs_bk[e];
                if (typeof d !== gvjs_g) throw Error("Object expected for column " + d);
                c = c(this.dataTable, a, d)
            } else typeof e === gvjs_c && (c = e.call(null, this.dataTable, a));
            c = gvjs_Rj(c);
            d = d.type;
            e = c.v;
            if ("" ===
                (null == d ? "" : String(d))) throw Error('"type" must be specified');
            if (!gvjs_1j(e, d)) throw Error(gvjs_sb + e + gvjs_aa + d + ".");
            d = this.zP[b][a] = c
        }
        d.p = gvjs_pg(d.p) ? d.p : {}
    } else if (typeof c === gvjs_f) d = {
        v: this.dataTable.getValue(a, c)
    };
    else throw Error("Invalid column definition: " + d + ".");
    return d
};
gvjs_.getValue = function(a, b) {
    return this.mg(a, b).v
};
gvjs_.getFormattedValue = function(a, b, c) {
    var d = this.mg(a, b);
    if (null == d.f) {
        var e = this.columns[b];
        gvjs_pg(e) ? (e = this.getColumnType(b), d.f = null == d.v ? "" : gvjs_4j(d.v, e, c)) : typeof e === gvjs_f && (a = this.getTableRowIndex(a), d.f = this.dataTable.getFormattedValue(a, e, c))
    }
    c = d.f;
    return null == c ? "" : c.toString()
};
gvjs_.setFormattedValue = function() {};
gvjs_.format = function(a, b) {
    gvjs_5j(this, a, b)
};
gvjs_.getProperty = function(a, b, c) {
    a = this.getProperties(a, b)[c];
    return void 0 !== a ? a : null
};
gvjs_.getProperties = function(a, b) {
    var c = this.mg(a, b);
    return c.p ? c.p : (a = this.getTableRowIndex(a), b = this.getTableColumnIndex(b), this.dataTable.getProperties(a, b))
};
gvjs_.setProperty = function() {};
gvjs_.getColumnProperty = function(a, b) {
    gvjs_0j(this, a);
    var c = this.columns[a];
    return typeof c === gvjs_f ? this.dataTable.getColumnProperty(c, b) : this.getColumnProperties(a)[b] || null
};
gvjs_.getColumnProperties = function(a) {
    gvjs_0j(this, a);
    a = this.columns[a];
    return typeof a === gvjs_f ? this.dataTable.getColumnProperties(a) : a.p || {}
};
gvjs_.getTableProperty = function(a) {
    return this.dataTable.getTableProperty(a)
};
gvjs_.getTableProperties = function() {
    return this.dataTable.getTableProperties()
};
gvjs_.getRowProperty = function(a, b) {
    a = this.getTableRowIndex(a);
    return this.dataTable.getRowProperty(a, b)
};
gvjs_.getRowProperties = function(a) {
    gvjs__j(this, a);
    a = this.getTableRowIndex(a);
    return this.dataTable.getRowProperties(a)
};
gvjs_.getColumnRange = function(a) {
    return gvjs_2j(this, a)
};
gvjs_.getDistinctValues = function(a) {
    return gvjs_3j(this, a)
};
gvjs_.getSortedRows = function(a) {
    return gvjs_Yj(this, a)
};
gvjs_.getFilteredRows = function(a) {
    return gvjs_Tj(this, a)
};
gvjs_.toDataTable = function() {
    var a = this.dataTable;
    typeof a.toDataTable === gvjs_c && (a = a.toDataTable());
    a = a.toPOJO();
    var b = this.getNumberOfColumns(),
        c = this.getNumberOfRows(),
        d, e = [],
        f = [];
    for (d = 0; d < b; d++) {
        var g = this.columns[d];
        if (gvjs_pg(g)) {
            var h = Object.assign({}, g);
            delete h.calc;
            delete h.sourceColumn
        } else if (typeof g === gvjs_f) h = (a.cols || [])[g];
        else throw Error(gvjs_Sa);
        e.push(h)
    }
    if (!this.Rm && null == this.qn) throw Error("Unexpected state of rowIndices");
    var k = a.rows || [];
    for (h = 0; h < c; h++) {
        var l = k[this.Rm ?
                h : this.qn[h]],
            m = [];
        for (d = 0; d < b; d++) {
            g = this.columns[d];
            if (gvjs_pg(g)) g = {
                v: this.getValue(h, d)
            };
            else if (typeof g === gvjs_f) g = l.c[g];
            else throw Error(gvjs_Sa);
            m.push(g)
        }
        l.c = m;
        f.push(l)
    }
    a.cols = e;
    a.rows = f;
    return new gvjs_F(a)
};
gvjs_.toPOJO = function() {
    for (var a = {}, b = [], c = 0; c < this.columns.length; c++) {
        var d = this.columns[c];
        gvjs_pg(d) && typeof d.calc !== gvjs_m || b.push(d)
    }
    0 !== b.length && (a.columns = b);
    this.Rm || (a.rows = Array.from(this.qn || []));
    return a
};
gvjs_.toJSON = function() {
    return gvjs_Gg(this.toPOJO())
};

function gvjs_dk(a, b) {
    typeof b === gvjs_m && (b = gvjs_Jg(b));
    a = new gvjs_G(a);
    var c = b.columns;
    b = b.rows;
    null != c && a.setColumns(c);
    null != b && a.setRows(b);
    return a
}
var gvjs_bk = {
    emptyString: function() {
        return ""
    },
    error: function(a, b, c) {
        var d = c.sourceColumn,
            e = c.magnitude;
        if (typeof d !== gvjs_f || typeof e !== gvjs_f) return null;
        a = a.getValue(b, d);
        return typeof a !== gvjs_f ? null : c.errorType === gvjs_Nd ? a + e / 100 * a : a + e
    },
    mapFromSource: function(a, b, c) {
        var d = c.sourceColumn;
        c = c.mapping;
        return typeof d === gvjs_f && c && (a = a.getValue(b, d), typeof a === gvjs_m) ? a in c ? c[a] : null : null
    },
    stringify: function(a, b, c) {
        c = c.sourceColumn;
        return typeof c !== gvjs_f ? "" : a.getFormattedValue(b, c)
    },
    fillFromTop: function(a,
        b, c) {
        c = c.sourceColumn;
        return typeof c !== gvjs_f ? null : gvjs_6j(a, b, c, !0)
    },
    fillFromBottom: function(a, b, c) {
        c = c.sourceColumn;
        return typeof c !== gvjs_f ? null : gvjs_6j(a, b, c, !1)
    },
    identity: function(a, b, c) {
        c = c.sourceColumn;
        return typeof c !== gvjs_f ? null : a.getValue(b, c)
    }
};
var gvjs_ek = null;

function gvjs_fk() {
    null == gvjs_ek && (gvjs_ek = new gvjs_ji);
    return gvjs_ek
}

function gvjs_gk() {
    return gvjs_fk().Hb()
}

function gvjs_hk(a) {
    var b = gvjs_fk();
    if (!a || !b.ll(a)) throw Error(gvjs_Aa);
    return a
};

function gvjs_H(a, b, c, d) {
    this.top = a;
    this.right = b;
    this.bottom = c;
    this.left = d
}
gvjs_ = gvjs_H.prototype;
gvjs_.pb = gvjs_p(16);
gvjs_.getHeight = function() {
    return this.bottom - this.top
};
gvjs_.clone = function() {
    return new gvjs_H(this.top, this.right, this.bottom, this.left)
};
gvjs_.contains = function(a) {
    return this && a ? a instanceof gvjs_H ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
};
gvjs_.expand = function(a, b, c, d) {
    gvjs_Pe(a) ? (this.top -= a.top, this.right += a.right, this.bottom += a.bottom, this.left -= a.left) : (this.top -= a, this.right += Number(b), this.bottom += Number(c), this.left -= Number(d));
    return this
};
gvjs_.ceil = function() {
    this.top = Math.ceil(this.top);
    this.right = Math.ceil(this.right);
    this.bottom = Math.ceil(this.bottom);
    this.left = Math.ceil(this.left);
    return this
};
gvjs_.floor = function() {
    this.top = Math.floor(this.top);
    this.right = Math.floor(this.right);
    this.bottom = Math.floor(this.bottom);
    this.left = Math.floor(this.left);
    return this
};
gvjs_.round = function() {
    this.top = Math.round(this.top);
    this.right = Math.round(this.right);
    this.bottom = Math.round(this.bottom);
    this.left = Math.round(this.left);
    return this
};
gvjs_.translate = function(a, b) {
    a instanceof gvjs_A ? (this.left += a.x, this.right += a.x, this.top += a.y, this.bottom += a.y) : (this.left += a, this.right += a, typeof b === gvjs_f && (this.top += b, this.bottom += b));
    return this
};
gvjs_.scale = function(a, b) {
    b = typeof b === gvjs_f ? b : a;
    this.left *= a;
    this.right *= a;
    this.top *= b;
    this.bottom *= b;
    return this
};

function gvjs_I(a, b, c) {
    if (typeof b === gvjs_m)(b = gvjs_ik(a, b)) && (a.style[b] = c);
    else
        for (var d in b) {
            c = a;
            var e = b[d],
                f = gvjs_ik(c, d);
            f && (c.style[f] = e)
        }
}
var gvjs_jk = {};

function gvjs_ik(a, b) {
    var c = gvjs_jk[b];
    if (!c) {
        var d = gvjs_Nh(b);
        c = d;
        void 0 === a.style[d] && (d = (gvjs_If ? "Webkit" : gvjs_Hf ? "Moz" : gvjs_x ? "ms" : null) + gvjs_Zaa(d), void 0 !== a.style[d] && (c = d));
        gvjs_jk[b] = c
    }
    return c
}

function gvjs_kk(a, b) {
    var c = gvjs_ki(a);
    return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
}

function gvjs_lk(a, b) {
    return gvjs_kk(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
}

function gvjs_mk(a) {
    return gvjs_lk(a, gvjs_Pd)
}
var gvjs_nk = gvjs_Hf ? "MozUserSelect" : gvjs_If || gvjs_Gf ? "WebkitUserSelect" : null;

function gvjs_ok(a) {
    var b = gvjs_ki(a),
        c = gvjs_x && a.currentStyle;
    if (c && gvjs_ui(gvjs_ii(b).ac) && c.width != gvjs_Gb && c.height != gvjs_Gb && !c.boxSizing) return b = gvjs_pk(a, c.width, gvjs_le, "pixelWidth"), a = gvjs_pk(a, c.height, gvjs_jd, "pixelHeight"), new gvjs_B(b, a);
    c = new gvjs_B(a.offsetWidth, a.offsetHeight);
    b = gvjs_qk(a);
    a = gvjs_rk(a);
    return new gvjs_B(c.width - a.left - b.left - b.right - a.right, c.height - a.top - b.top - b.bottom - a.bottom)
}

function gvjs_pk(a, b, c, d) {
    if (/^\d+px?$/.test(b)) return parseInt(b, 10);
    var e = a.style[c],
        f = a.runtimeStyle[c];
    a.runtimeStyle[c] = a.currentStyle[c];
    a.style[c] = b;
    b = a.style[d];
    a.style[c] = e;
    a.runtimeStyle[c] = f;
    return +b
}

function gvjs_sk(a, b) {
    return (b = a.currentStyle ? a.currentStyle[b] : null) ? gvjs_pk(a, b, gvjs_sd, "pixelLeft") : 0
}

function gvjs_qk(a) {
    if (gvjs_x) {
        var b = gvjs_sk(a, "paddingLeft"),
            c = gvjs_sk(a, "paddingRight"),
            d = gvjs_sk(a, "paddingTop");
        a = gvjs_sk(a, "paddingBottom");
        return new gvjs_H(d, c, a, b)
    }
    b = gvjs_kk(a, "paddingLeft");
    c = gvjs_kk(a, "paddingRight");
    d = gvjs_kk(a, "paddingTop");
    a = gvjs_kk(a, "paddingBottom");
    return new gvjs_H(parseFloat(d), parseFloat(c), parseFloat(a), parseFloat(b))
}
var gvjs_tk = {
    thin: 2,
    medium: 4,
    thick: 6
};

function gvjs_uk(a, b) {
    if ((a.currentStyle ? a.currentStyle[b + "Style"] : null) == gvjs_e) return 0;
    b = a.currentStyle ? a.currentStyle[b + "Width"] : null;
    return b in gvjs_tk ? gvjs_tk[b] : gvjs_pk(a, b, gvjs_sd, "pixelLeft")
}

function gvjs_rk(a) {
    if (gvjs_x && !gvjs_Tf(9)) {
        var b = gvjs_uk(a, "borderLeft"),
            c = gvjs_uk(a, "borderRight"),
            d = gvjs_uk(a, "borderTop");
        a = gvjs_uk(a, "borderBottom");
        return new gvjs_H(d, c, a, b)
    }
    b = gvjs_kk(a, "borderLeftWidth");
    c = gvjs_kk(a, "borderRightWidth");
    d = gvjs_kk(a, "borderTopWidth");
    a = gvjs_kk(a, "borderBottomWidth");
    return new gvjs_H(parseFloat(d), parseFloat(c), parseFloat(a), parseFloat(b))
};
var gvjs_J = {
    mO: "google-visualization-errors"
};
gvjs_J.ZY = gvjs_J.mO + "-";
gvjs_J.AZ = gvjs_J.mO + ":";
gvjs_J.bO = gvjs_J.mO + "-all-";
gvjs_J.PY = gvjs_J.AZ + " container is null";
gvjs_J.B$ = "background-color: #c00000; color: white; padding: 2px;";
gvjs_J.Daa = "background-color: #fff4c2; color: black; white-space: nowrap; padding: 2px; border: 1px solid black;";
gvjs_J.Gaa = "font: normal 0.8em arial,sans-serif; margin-bottom: 5px;";
gvjs_J.saa = "font-size: 1.1em; color: #00c; font-weight: bold; cursor: pointer; padding-left: 10px; color: black;text-align: right; vertical-align: top;";
var gvjs_vk = 0;

function gvjs_wk(a, b, c, d) {
    if (!gvjs_xk(a)) throw Error(gvjs_J.PY + ". message: " + b);
    d = gvjs_yk(b, c, d);
    var e = d.errorMessage;
    c = d.detailedMessage;
    d = d.options;
    var f = null != d.showInTooltip ? !!d.showInTooltip : !0,
        g = (d.type === gvjs_ke ? gvjs_ke : gvjs_7b) === gvjs_7b ? gvjs_J.B$ : gvjs_J.Daa;
    g += d.style ? d.style : "";
    var h = !!d.removable;
    b = gvjs_fk();
    e = b.F(gvjs_ab, {
        style: g
    }, b.createTextNode(e));
    g = "" + gvjs_J.ZY + gvjs_vk++;
    var k = b.F(gvjs_b, {
        id: g,
        style: gvjs_J.Gaa
    }, e);
    c && (f ? e.title = c : (c = b.F(gvjs_ab, {}, b.createTextNode(c)), b.appendChild(k,
        b.F(gvjs_b, {
            style: "padding: 2px"
        }, c))));
    h && (c = b.F(gvjs_ab, {
        style: gvjs_J.saa
    }, b.createTextNode("\u00d7")), c.onclick = function() {
        gvjs_zk(k)
    }, b.appendChild(e, c));
    gvjs_Ak(a, k);
    d.removeDuplicates && gvjs_Bk(a, k);
    return g
}
gvjs_J.addError = gvjs_wk;
gvjs_J.removeAll = function(a) {
    gvjs_Ck(a);
    if (a = gvjs_Dk(a, !1)) a.style.display = gvjs_e, gvjs_xi(a)
};
gvjs_J.removeError = function(a) {
    a = gvjs_gk().getElementById(a);
    return null != a && gvjs_Ek(a) ? (gvjs_zk(a), !0) : !1
};
gvjs_J.getContainer = function(a) {
    a = gvjs_gk().getElementById(a);
    return null != a && gvjs_Ek(a) && null != a.parentNode && null != a.parentNode.parentNode ? a.parentNode.parentNode : null
};
gvjs_J.createProtectedCallback = function(a, b) {
    return function() {
        try {
            a.apply(null, arguments)
        } catch (c) {
            typeof b === gvjs_c ? b(c) : gvjs_wk(b, c.message)
        }
    }
};

function gvjs_zk(a) {
    var b = a.parentNode;
    gvjs_Ai(a);
    b && 0 === b.childNodes.length && (b.style.display = gvjs_e)
}
gvjs_J.hsa = gvjs_zk;

function gvjs_Ek(a) {
    return gvjs_si(a) && a.id && a.id.startsWith(gvjs_J.ZY) && (a = a.parentNode) && a.id && a.id.startsWith(gvjs_J.bO) && a.parentNode ? !0 : !1
}
gvjs_J.wta = gvjs_Ek;

function gvjs_yk(a, b, c) {
    var d = null != a && a ? a : gvjs_7b,
        e = "";
    c = c || {};
    var f = arguments.length;
    2 === f ? b && typeof b === gvjs_g ? c = b : e = null != b ? b : e : 3 === f && (e = null != b ? b : e);
    d = d.trim();
    e = (e || "").trim();
    return {
        errorMessage: d,
        detailedMessage: e,
        options: c
    }
}
gvjs_J.qsa = gvjs_yk;

function gvjs_xk(a) {
    return null != a && gvjs_si(a)
}
gvjs_J.vta = gvjs_xk;

function gvjs_Ck(a, b) {
    if (!gvjs_xk(a)) throw Error((void 0 === b ? "" : b) || gvjs_J.PY);
}
gvjs_J.lna = gvjs_Ck;

function gvjs_Dk(a, b) {
    for (var c = a.childNodes, d = null, e = gvjs_fk(), f = 0; f < c.length; f++) {
        var g = c[f];
        if (g.id && g.id.startsWith(gvjs_J.bO)) {
            d = g;
            e.removeNode(d);
            break
        }
    }!d && b && (d = "" + gvjs_J.bO + gvjs_vk++, d = e.F(gvjs_b, {
        id: d,
        style: "display: none; padding-top: 2px"
    }, null));
    d && ((b = a.firstChild) ? e.FS(d, b) : e.appendChild(a, d));
    return d
}
gvjs_J.bsa = gvjs_Dk;

function gvjs_Ak(a, b) {
    a = gvjs_Dk(a, !0);
    a.style.display = gvjs_Jb;
    a.appendChild(b)
}
gvjs_J.addElement = gvjs_Ak;

function gvjs_Fk(a, b) {
    a = (a = gvjs_Dk(a, !0)) && gvjs_Bi(a);
    a = gvjs_q(a);
    for (var c = a.next(); !c.done; c = a.next()) c = c.value, gvjs_Ek(c) && b(c)
}
gvjs_J.Yra = gvjs_Fk;

function gvjs_Bk(a, b) {
    var c = /id="?google-visualization-errors-[0-9]*"?/,
        d = gvjs_Ki(b);
    d = d.replace(c, "");
    var e = [];
    gvjs_Fk(a, function(g) {
        if (g !== b) {
            var h = gvjs_Ki(g);
            h = h.replace(c, "");
            h === d && e.push(g)
        }
    });
    a = gvjs_q(e);
    for (var f = a.next(); !f.done; f = a.next()) gvjs_zk(f.value);
    return e.length
}
gvjs_J.Tsa = gvjs_Bk;

function gvjs_Gk(a) {
    this.dataTable = this.K8 = null;
    this.errors = [];
    this.warnings = [];
    this.U7 = gvjs_Hk(a);
    this.ZI = a.status;
    this.warnings = a.warnings || [];
    this.errors = a.errors || [];
    gvjs_Ik(this.warnings);
    gvjs_Ik(this.errors);
    this.ZI !== gvjs_7b && (this.K8 = a.sig, this.dataTable = new gvjs_F(a.table, this.U7))
}

function gvjs_Ik(a) {
    for (var b = 0; b < a.length; b++) {
        var c = a[b].detailed_message;
        c && (a[b].detailed_message = c ? c.match(gvjs_fba) && !c.match(gvjs_gba) ? c : c.replace(/&/g, "&amp;").replace(/</g, gvjs_ha).replace(/>/g, "&gt;").replace(/"/g, gvjs_ia) : "")
    }
}

function gvjs_Hk(a) {
    a = a.version || "0.6";
    return Object.values(gvjs_aba).includes(a) ? a : "0.6"
}
gvjs_ = gvjs_Gk.prototype;
gvjs_.getVersion = function() {
    return this.U7
};
gvjs_.getExecutionStatus = function() {
    return this.ZI
};
gvjs_.isError = function() {
    return this.ZI === gvjs_7b
};
gvjs_.hasWarning = function() {
    return this.ZI === gvjs_ke
};
gvjs_.containsReason = function(a) {
    for (var b = 0; b < this.errors.length; b++)
        if (this.errors[b].reason === a) return !0;
    for (b = 0; b < this.warnings.length; b++)
        if (this.warnings[b].reason === a) return !0;
    return !1
};
gvjs_.getDataSignature = function() {
    return this.K8
};
gvjs_.getDataTable = function() {
    return this.dataTable
};

function gvjs_Jk(a, b) {
    return a.isError() && a.errors && a.errors[0] && a.errors[0][b] ? a.errors[0][b] : a.hasWarning() && a.warnings && a.warnings[0] && a.warnings[0][b] ? a.warnings[0][b] : null
}
gvjs_.getReasons = function() {
    var a = gvjs_Jk(this, "reason");
    return null != a && "" !== a ? [a] : []
};
gvjs_.getMessage = function() {
    return gvjs_Jk(this, "message") || ""
};
gvjs_.getDetailedMessage = function() {
    return gvjs_Jk(this, "detailed_message") || ""
};

function gvjs_Kk(a, b) {
    (0, gvjs_J.lna)(a);
    if (!b) throw Error(gvjs_J.AZ + " response is null");
    if (b.isError() || b.hasWarning()) {
        var c = b.getReasons(),
            d = !0;
        b.isError() && (d = !(c.includes("user_not_authenticated") || c.includes("invalid_query")));
        c = b.getMessage();
        var e = b.getDetailedMessage();
        d = {
            showInTooltip: d
        };
        d.type = b.isError() ? gvjs_7b : gvjs_ke;
        d.removeDuplicates = !0;
        a = {
            container: a,
            message: c,
            detailedMessage: e,
            options: d
        }
    } else a = null;
    return null == a ? null : (0, gvjs_J.addError)(a.container, a.message, a.detailedMessage,
        a.options)
}
var gvjs_fba = RegExp("^[^<]*(<a(( )+target=('_blank')?(\"_blank\")?)?( )+(href=('[^']*')?(\"[^\"]*\")?)>[^<]*</a>[^<]*)*$"),
    gvjs_gba = RegExp("javascript((s)?( )?)*:");

function gvjs_Lk(a, b) {
    this.start = a < b ? a : b;
    this.end = a < b ? b : a
}
gvjs_Lk.prototype.clone = function() {
    return new gvjs_Lk(this.start, this.end)
};
gvjs_Lk.prototype.getLength = function() {
    return this.end - this.start
};

function gvjs_Mk(a, b) {
    return a.start <= b && a.end >= b
};

function gvjs_K(a) {
    a && typeof a.xa == gvjs_c && a.xa()
};

function gvjs_L() {
    this.Ue = this.Ue;
    this.mv = this.mv
}
gvjs_L.prototype.Ue = !1;
gvjs_L.prototype.sf = gvjs_p(17);
gvjs_L.prototype.xa = function() {
    this.Ue || (this.Ue = !0, this.J())
};
gvjs_L.prototype.J = function() {
    if (this.mv)
        for (; this.mv.length;) this.mv.shift()()
};

function gvjs_Nk(a, b) {
    this.type = a;
    this.currentTarget = this.target = b;
    this.defaultPrevented = this.eF = !1
}
gvjs_Nk.prototype.stopPropagation = function() {
    this.eF = !0
};
gvjs_Nk.prototype.preventDefault = function() {
    this.defaultPrevented = !0
};
var gvjs_Ok = "PointerEvent" in gvjs_s,
    gvjs_hba = function() {
        if (!gvjs_s.addEventListener || !Object.defineProperty) return !1;
        var a = !1,
            b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
        try {
            gvjs_s.addEventListener("test", function() {}, b), gvjs_s.removeEventListener("test", function() {}, b)
        } catch (c) {}
        return a
    }();

function gvjs_Pk(a, b) {
    gvjs_Nk.call(this, a ? a.type : "");
    this.relatedTarget = this.currentTarget = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = this.offsetY = this.offsetX = 0;
    this.key = "";
    this.charCode = this.keyCode = 0;
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.QU = !1;
    this.pointerId = 0;
    this.pointerType = "";
    this.fi = null;
    a && this.init(a, b)
}
gvjs_u(gvjs_Pk, gvjs_Nk);
var gvjs_iba = {
    2: "touch",
    3: "pen",
    4: "mouse"
};
gvjs_Pk.prototype.init = function(a, b) {
    var c = this.type = a.type,
        d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
    this.target = a.target || a.srcElement;
    this.currentTarget = b;
    (b = a.relatedTarget) ? gvjs_Hf && (gvjs_Ef(b, gvjs_Hd) || (b = null)): c == gvjs_Dd ? b = a.fromElement : c == gvjs_Cd && (b = a.toElement);
    this.relatedTarget = b;
    d ? (this.clientX = void 0 !== d.clientX ? d.clientX : d.pageX, this.clientY = void 0 !== d.clientY ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.offsetX = gvjs_If || void 0 !==
        a.offsetX ? a.offsetX : a.layerX, this.offsetY = gvjs_If || void 0 !== a.offsetY ? a.offsetY : a.layerY, this.clientX = void 0 !== a.clientX ? a.clientX : a.pageX, this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
    this.button = a.button;
    this.keyCode = a.keyCode || 0;
    this.key = a.key || "";
    this.charCode = a.charCode || (c == gvjs_pd ? a.keyCode : 0);
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.QU = gvjs_Jf ? a.metaKey : a.ctrlKey;
    this.pointerId =
        a.pointerId || 0;
    this.pointerType = typeof a.pointerType === gvjs_m ? a.pointerType : gvjs_iba[a.pointerType] || "";
    this.state = a.state;
    this.fi = a;
    a.defaultPrevented && gvjs_Pk.G.preventDefault.call(this)
};
gvjs_Pk.prototype.stopPropagation = function() {
    gvjs_Pk.G.stopPropagation.call(this);
    this.fi.stopPropagation ? this.fi.stopPropagation() : this.fi.cancelBubble = !0
};
gvjs_Pk.prototype.preventDefault = function() {
    gvjs_Pk.G.preventDefault.call(this);
    var a = this.fi;
    a.preventDefault ? a.preventDefault() : a.returnValue = !1
};
var gvjs_Qk = "closure_listenable_" + (1E6 * Math.random() | 0);

function gvjs_Rk(a) {
    return !(!a || !a[gvjs_Qk])
};
var gvjs_jba = 0;

function gvjs_kba(a, b, c, d, e) {
    this.listener = a;
    this.proxy = null;
    this.src = b;
    this.type = c;
    this.capture = !!d;
    this.handler = e;
    this.key = ++gvjs_jba;
    this.qk = this.RH = !1
}

function gvjs_Sk(a) {
    a.qk = !0;
    a.listener = null;
    a.proxy = null;
    a.src = null;
    a.handler = null
};

function gvjs_Tk(a) {
    this.src = a;
    this.Tf = {};
    this.oG = 0
}
gvjs_ = gvjs_Tk.prototype;
gvjs_.add = function(a, b, c, d, e) {
    var f = a.toString();
    a = this.Tf[f];
    a || (a = this.Tf[f] = [], this.oG++);
    var g = gvjs_Uk(a, b, d, e); - 1 < g ? (b = a[g], c || (b.RH = !1)) : (b = new gvjs_kba(b, this.src, f, !!d, e), b.RH = c, a.push(b));
    return b
};
gvjs_.remove = function(a, b, c, d) {
    a = a.toString();
    if (!(a in this.Tf)) return !1;
    var e = this.Tf[a];
    b = gvjs_Uk(e, b, c, d);
    return -1 < b ? (gvjs_Sk(e[b]), Array.prototype.splice.call(e, b, 1), 0 == e.length && (delete this.Tf[a], this.oG--), !0) : !1
};

function gvjs_Vk(a, b) {
    var c = b.type;
    if (!(c in a.Tf)) return !1;
    var d = gvjs_uf(a.Tf[c], b);
    d && (gvjs_Sk(b), 0 == a.Tf[c].length && (delete a.Tf[c], a.oG--));
    return d
}
gvjs_.removeAll = function(a) {
    a = a && a.toString();
    var b = 0,
        c;
    for (c in this.Tf)
        if (!a || c == a) {
            for (var d = this.Tf[c], e = 0; e < d.length; e++) ++b, gvjs_Sk(d[e]);
            delete this.Tf[c];
            this.oG--
        }
    return b
};
gvjs_.iy = gvjs_p(19);
gvjs_.hD = function(a, b, c, d) {
    a = this.Tf[a.toString()];
    var e = -1;
    a && (e = gvjs_Uk(a, b, c, d));
    return -1 < e ? a[e] : null
};
gvjs_.hasListener = function(a, b) {
    var c = void 0 !== a,
        d = c ? a.toString() : "",
        e = void 0 !== b;
    return gvjs_Qg(this.Tf, function(f) {
        for (var g = 0; g < f.length; ++g)
            if (!(c && f[g].type != d || e && f[g].capture != b)) return !0;
        return !1
    })
};

function gvjs_Uk(a, b, c, d) {
    for (var e = 0; e < a.length; ++e) {
        var f = a[e];
        if (!f.qk && f.listener == b && f.capture == !!c && f.handler == d) return e
    }
    return -1
};
var gvjs_Wk = "closure_lm_" + (1E6 * Math.random() | 0),
    gvjs_Xk = {},
    gvjs_Yk = 0;

function gvjs_M(a, b, c, d, e) {
    if (d && d.once) return gvjs_Zk(a, b, c, d, e);
    if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) gvjs_M(a, b[f], c, d, e);
        return null
    }
    c = gvjs__k(c);
    return gvjs_Rk(a) ? a.o(b, c, gvjs_Pe(d) ? !!d.capture : !!d, e) : gvjs_0k(a, b, c, !1, d, e)
}

function gvjs_0k(a, b, c, d, e, f) {
    if (!b) throw Error("Invalid event type");
    var g = gvjs_Pe(e) ? !!e.capture : !!e,
        h = gvjs_1k(a);
    h || (a[gvjs_Wk] = h = new gvjs_Tk(a));
    c = h.add(b, c, d, g, f);
    if (c.proxy) return c;
    d = gvjs_lba();
    c.proxy = d;
    d.src = a;
    d.listener = c;
    if (a.addEventListener) gvjs_hba || (e = g), void 0 === e && (e = !1), a.addEventListener(b.toString(), d, e);
    else if (a.attachEvent) a.attachEvent(gvjs_2k(b.toString()), d);
    else if (a.addListener && a.removeListener) a.addListener(d);
    else throw Error("addEventListener and attachEvent are unavailable.");
    gvjs_Yk++;
    return c
}

function gvjs_lba() {
    function a(c) {
        return b.call(a.src, a.listener, c)
    }
    var b = gvjs_mba;
    return a
}

function gvjs_Zk(a, b, c, d, e) {
    if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) gvjs_Zk(a, b[f], c, d, e);
        return null
    }
    c = gvjs__k(c);
    return gvjs_Rk(a) ? a.Uy(b, c, gvjs_Pe(d) ? !!d.capture : !!d, e) : gvjs_0k(a, b, c, !0, d, e)
}

function gvjs_3k(a, b, c, d, e) {
    if (Array.isArray(b))
        for (var f = 0; f < b.length; f++) gvjs_3k(a, b[f], c, d, e);
    else d = gvjs_Pe(d) ? !!d.capture : !!d, c = gvjs__k(c), gvjs_Rk(a) ? a.Ta(b, c, d, e) : a && (a = gvjs_1k(a)) && (b = a.hD(b, c, d, e)) && gvjs_4k(b)
}

function gvjs_4k(a) {
    if (typeof a === gvjs_f || !a || a.qk) return !1;
    var b = a.src;
    if (gvjs_Rk(b)) return gvjs_Vk(b.Xk, a);
    var c = a.type,
        d = a.proxy;
    b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(gvjs_2k(c), d) : b.addListener && b.removeListener && b.removeListener(d);
    gvjs_Yk--;
    (c = gvjs_1k(b)) ? (gvjs_Vk(c, a), 0 == c.oG && (c.src = null, b[gvjs_Wk] = null)) : gvjs_Sk(a);
    return !0
}

function gvjs_5k(a) {
    if (!a) return 0;
    if (gvjs_Rk(a)) return a.removeAllListeners(void 0);
    a = gvjs_1k(a);
    if (!a) return 0;
    var b = 0,
        c;
    for (c in a.Tf)
        for (var d = a.Tf[c].concat(), e = 0; e < d.length; ++e) gvjs_4k(d[e]) && ++b;
    return b
}

function gvjs_2k(a) {
    return a in gvjs_Xk ? gvjs_Xk[a] : gvjs_Xk[a] = "on" + a
}

function gvjs_mba(a, b) {
    if (a.qk) a = !0;
    else {
        b = new gvjs_Pk(b, this);
        var c = a.listener,
            d = a.handler || a.src;
        a.RH && gvjs_4k(a);
        a = c.call(d, b)
    }
    return a
}

function gvjs_1k(a) {
    a = a[gvjs_Wk];
    return a instanceof gvjs_Tk ? a : null
}
var gvjs_6k = "__closure_events_fn_" + (1E9 * Math.random() >>> 0);

function gvjs__k(a) {
    if (typeof a === gvjs_c) return a;
    a[gvjs_6k] || (a[gvjs_6k] = function(b) {
        return a.handleEvent(b)
    });
    return a[gvjs_6k]
};

function gvjs_7k() {
    gvjs_L.call(this);
    this.Xk = new gvjs_Tk(this);
    this.Naa = this;
    this.LU = null
}
gvjs_u(gvjs_7k, gvjs_L);
gvjs_7k.prototype[gvjs_Qk] = !0;
gvjs_ = gvjs_7k.prototype;
gvjs_.jy = function() {
    return this.LU
};
gvjs_.Lv = gvjs_p(20);
gvjs_.addEventListener = function(a, b, c, d) {
    gvjs_M(this, a, b, c, d)
};
gvjs_.removeEventListener = function(a, b, c, d) {
    gvjs_3k(this, a, b, c, d)
};
gvjs_.dispatchEvent = function(a) {
    var b, c = this.jy();
    if (c)
        for (b = []; c; c = c.jy()) b.push(c);
    c = this.Naa;
    var d = a.type || a;
    if (typeof a === gvjs_m) a = new gvjs_Nk(a, c);
    else if (a instanceof gvjs_Nk) a.target = a.target || c;
    else {
        var e = a;
        a = new gvjs_Nk(d, c);
        gvjs_Wg(a, e)
    }
    e = !0;
    if (b)
        for (var f = b.length - 1; !a.eF && 0 <= f; f--) {
            var g = a.currentTarget = b[f];
            e = gvjs_8k(g, d, !0, a) && e
        }
    a.eF || (g = a.currentTarget = c, e = gvjs_8k(g, d, !0, a) && e, a.eF || (e = gvjs_8k(g, d, !1, a) && e));
    if (b)
        for (f = 0; !a.eF && f < b.length; f++) g = a.currentTarget = b[f], e = gvjs_8k(g, d, !1,
            a) && e;
    return e
};
gvjs_.J = function() {
    gvjs_7k.G.J.call(this);
    this.removeAllListeners();
    this.LU = null
};
gvjs_.o = function(a, b, c, d) {
    return this.Xk.add(String(a), b, !1, c, d)
};
gvjs_.Uy = function(a, b, c, d) {
    return this.Xk.add(String(a), b, !0, c, d)
};
gvjs_.Ta = function(a, b, c, d) {
    return this.Xk.remove(String(a), b, c, d)
};
gvjs_.removeAllListeners = function(a) {
    return this.Xk ? this.Xk.removeAll(a) : 0
};

function gvjs_8k(a, b, c, d) {
    b = a.Xk.Tf[String(b)];
    if (!b) return !0;
    b = b.concat();
    for (var e = !0, f = 0; f < b.length; ++f) {
        var g = b[f];
        if (g && !g.qk && g.capture == c) {
            var h = g.listener,
                k = g.handler || g.src;
            g.RH && gvjs_Vk(a.Xk, g);
            e = !1 !== h.call(k, d) && e
        }
    }
    return e && !d.defaultPrevented
}
gvjs_.iy = gvjs_p(18);
gvjs_.hD = function(a, b, c, d) {
    return this.Xk.hD(String(a), b, c, d)
};
gvjs_.hasListener = function(a, b) {
    return this.Xk.hasListener(void 0 !== a ? String(a) : void 0, b)
};

function gvjs_9k(a, b) {
    this.dia = 100;
    this.tca = a;
    this.Aka = b;
    this.iL = 0;
    this.vb = null
}
gvjs_9k.prototype.get = function() {
    if (0 < this.iL) {
        this.iL--;
        var a = this.vb;
        this.vb = a.next;
        a.next = null
    } else a = this.tca();
    return a
};
gvjs_9k.prototype.put = function(a) {
    this.Aka(a);
    this.iL < this.dia && (this.iL++, a.next = this.vb, this.vb = a)
};
var gvjs_$k;

function gvjs_nba() {
    var a = gvjs_s.MessageChannel;
    "undefined" === typeof a && "undefined" !== typeof window && window.postMessage && window.addEventListener && !gvjs_bf("Presto") && (a = function() {
        var e = gvjs_ti(gvjs_Na);
        e.style.display = gvjs_e;
        document.documentElement.appendChild(e);
        var f = e.contentWindow;
        e = f.document;
        e.open();
        e.close();
        var g = "callImmediate" + Math.random(),
            h = "file:" == f.location.protocol ? "*" : f.location.protocol + "//" + f.location.host;
        e = gvjs_Se(function(k) {
            if (("*" == h || k.origin == h) && k.data == g) this.port1.onmessage()
        }, this);
        f.addEventListener("message", e, !1);
        this.port1 = {};
        this.port2 = {
            postMessage: function() {
                f.postMessage(g, h)
            }
        }
    });
    if ("undefined" !== typeof a && !gvjs_ef()) {
        var b = new a,
            c = {},
            d = c;
        b.port1.onmessage = function() {
            if (void 0 !== c.next) {
                c = c.next;
                var e = c.L0;
                c.L0 = null;
                e()
            }
        };
        return function(e) {
            d.next = {
                L0: e
            };
            d = d.next;
            b.port2.postMessage(0)
        }
    }
    return function(e) {
        gvjs_s.setTimeout(e, 0)
    }
};

function gvjs_al() {
    this.KN = this.xA = null
}
gvjs_al.prototype.add = function(a, b) {
    var c = gvjs_bl.get();
    c.set(a, b);
    this.KN ? this.KN.next = c : this.xA = c;
    this.KN = c
};
gvjs_al.prototype.remove = function() {
    var a = null;
    this.xA && (a = this.xA, this.xA = this.xA.next, this.xA || (this.KN = null), a.next = null);
    return a
};
var gvjs_bl = new gvjs_9k(function() {
    return new gvjs_cl
}, function(a) {
    return a.reset()
});

function gvjs_cl() {
    this.next = this.scope = this.Yo = null
}
gvjs_cl.prototype.set = function(a, b) {
    this.Yo = a;
    this.scope = b;
    this.next = null
};
gvjs_cl.prototype.reset = function() {
    this.next = this.scope = this.Yo = null
};
var gvjs_dl, gvjs_el = !1,
    gvjs_fl = new gvjs_al;

function gvjs_gl(a, b) {
    gvjs_dl || gvjs_oba();
    gvjs_el || (gvjs_dl(), gvjs_el = !0);
    gvjs_fl.add(a, b)
}

function gvjs_oba() {
    if (gvjs_s.Promise && gvjs_s.Promise.resolve) {
        var a = gvjs_s.Promise.resolve(void 0);
        gvjs_dl = function() {
            a.then(gvjs_hl)
        }
    } else gvjs_dl = function() {
        var b = gvjs_hl;
        typeof gvjs_s.setImmediate !== gvjs_c || gvjs_s.Window && gvjs_s.Window.prototype && (gvjs_cf() || !gvjs_bf(gvjs_Da)) && gvjs_s.Window.prototype.setImmediate == gvjs_s.setImmediate ? (gvjs_$k || (gvjs_$k = gvjs_nba()), gvjs_$k(b)) : gvjs_s.setImmediate(b)
    }
}

function gvjs_hl() {
    for (var a; a = gvjs_fl.remove();) {
        try {
            a.Yo.call(a.scope)
        } catch (b) {
            gvjs__e(b)
        }
        gvjs_bl.put(a)
    }
    gvjs_el = !1
};

function gvjs_il(a) {
    if (!a) return !1;
    try {
        return !!a.$goog_Thenable
    } catch (b) {
        return !1
    }
};

function gvjs_jl(a) {
    this.V = 0;
    this.Eh = void 0;
    this.tx = this.Lq = this.Fc = null;
    this.GJ = this.nR = !1;
    if (a != gvjs_Og) try {
        var b = this;
        a.call(void 0, function(c) {
            gvjs_kl(b, 2, c)
        }, function(c) {
            gvjs_kl(b, 3, c)
        })
    } catch (c) {
        gvjs_kl(this, 3, c)
    }
}

function gvjs_ll() {
    this.next = this.context = this.mz = this.TE = this.child = null;
    this.BH = !1
}
gvjs_ll.prototype.reset = function() {
    this.context = this.mz = this.TE = this.child = null;
    this.BH = !1
};
var gvjs_ml = new gvjs_9k(function() {
    return new gvjs_ll
}, function(a) {
    a.reset()
});

function gvjs_nl(a, b, c) {
    var d = gvjs_ml.get();
    d.TE = a;
    d.mz = b;
    d.context = c;
    return d
}

function gvjs_ol() {
    var a, b, c = new gvjs_jl(function(d, e) {
        a = d;
        b = e
    });
    return new gvjs_pba(c, a, b)
}
gvjs_jl.prototype.then = function(a, b, c) {
    return gvjs_pl(this, typeof a === gvjs_c ? a : null, typeof b === gvjs_c ? b : null, c)
};
gvjs_jl.prototype.$goog_Thenable = !0;
gvjs_ = gvjs_jl.prototype;
gvjs_.i9 = function(a, b) {
    return gvjs_pl(this, null, a, b)
};
gvjs_.catch = gvjs_jl.prototype.i9;
gvjs_.cancel = function(a) {
    if (0 == this.V) {
        var b = new gvjs_ql(a);
        gvjs_gl(function() {
            gvjs_rl(this, b)
        }, this)
    }
};

function gvjs_rl(a, b) {
    if (0 == a.V)
        if (a.Fc) {
            var c = a.Fc;
            if (c.Lq) {
                for (var d = 0, e = null, f = null, g = c.Lq; g && (g.BH || (d++, g.child == a && (e = g), !(e && 1 < d))); g = g.next) e || (f = g);
                e && (0 == c.V && 1 == d ? gvjs_rl(c, b) : (f ? (d = f, d.next == c.tx && (c.tx = d), d.next = d.next.next) : gvjs_sl(c), gvjs_tl(c, e, 3, b)))
            }
            a.Fc = null
        } else gvjs_kl(a, 3, b)
}

function gvjs_ul(a, b) {
    a.Lq || 2 != a.V && 3 != a.V || gvjs_vl(a);
    a.tx ? a.tx.next = b : a.Lq = b;
    a.tx = b
}

function gvjs_pl(a, b, c, d) {
    var e = gvjs_nl(null, null, null);
    e.child = new gvjs_jl(function(f, g) {
        e.TE = b ? function(h) {
            try {
                var k = b.call(d, h);
                f(k)
            } catch (l) {
                g(l)
            }
        } : f;
        e.mz = c ? function(h) {
            try {
                var k = c.call(d, h);
                void 0 === k && h instanceof gvjs_ql ? g(h) : f(k)
            } catch (l) {
                g(l)
            }
        } : g
    });
    e.child.Fc = a;
    gvjs_ul(a, e);
    return e.child
}
gvjs_.Sma = function(a) {
    this.V = 0;
    gvjs_kl(this, 2, a)
};
gvjs_.Tma = function(a) {
    this.V = 0;
    gvjs_kl(this, 3, a)
};

function gvjs_kl(a, b, c) {
    if (0 == a.V) {
        a === c && (b = 3, c = new TypeError("Promise cannot resolve to itself"));
        a.V = 1;
        a: {
            var d = c,
                e = a.Sma,
                f = a.Tma;
            if (d instanceof gvjs_jl) {
                gvjs_ul(d, gvjs_nl(e || gvjs_Og, f || null, a));
                var g = !0
            } else if (gvjs_il(d)) d.then(e, f, a),
            g = !0;
            else {
                if (gvjs_Pe(d)) try {
                    var h = d.then;
                    if (typeof h === gvjs_c) {
                        gvjs_qba(d, h, e, f, a);
                        g = !0;
                        break a
                    }
                } catch (k) {
                    f.call(a, k);
                    g = !0;
                    break a
                }
                g = !1
            }
        }
        g || (a.Eh = c, a.V = b, a.Fc = null, gvjs_vl(a), 3 != b || c instanceof gvjs_ql || gvjs_rba(a, c))
    }
}

function gvjs_qba(a, b, c, d, e) {
    function f(k) {
        h || (h = !0, d.call(e, k))
    }

    function g(k) {
        h || (h = !0, c.call(e, k))
    }
    var h = !1;
    try {
        b.call(a, g, f)
    } catch (k) {
        f(k)
    }
}

function gvjs_vl(a) {
    a.nR || (a.nR = !0, gvjs_gl(a.Pda, a))
}

function gvjs_sl(a) {
    var b = null;
    a.Lq && (b = a.Lq, a.Lq = b.next, b.next = null);
    a.Lq || (a.tx = null);
    return b
}
gvjs_.Pda = function() {
    for (var a; a = gvjs_sl(this);) gvjs_tl(this, a, this.V, this.Eh);
    this.nR = !1
};

function gvjs_tl(a, b, c, d) {
    if (3 == c && b.mz && !b.BH)
        for (; a && a.GJ; a = a.Fc) a.GJ = !1;
    if (b.child) b.child.Fc = null, gvjs_wl(b, c, d);
    else try {
        b.BH ? b.TE.call(b.context) : gvjs_wl(b, c, d)
    } catch (e) {
        gvjs_xl.call(null, e)
    }
    gvjs_ml.put(b)
}

function gvjs_wl(a, b, c) {
    2 == b ? a.TE.call(a.context, c) : a.mz && a.mz.call(a.context, c)
}

function gvjs_rba(a, b) {
    a.GJ = !0;
    gvjs_gl(function() {
        a.GJ && gvjs_xl.call(null, b)
    })
}
var gvjs_xl = gvjs__e;

function gvjs_ql(a) {
    gvjs_Xe.call(this, a)
}
gvjs_u(gvjs_ql, gvjs_Xe);
gvjs_ql.prototype.name = gvjs_Nb;

function gvjs_pba(a, b, c) {
    this.promise = a;
    this.resolve = b;
    this.reject = c
};

function gvjs_yl(a, b, c) {
    if (typeof a === gvjs_c) c && (a = gvjs_Se(a, c));
    else if (a && typeof a.handleEvent == gvjs_c) a = gvjs_Se(a.handleEvent, a);
    else throw Error("Invalid listener argument");
    return 2147483647 < Number(b) ? -1 : gvjs_s.setTimeout(a, b || 0)
}

function gvjs_zl(a) {
    gvjs_s.clearTimeout(a)
};

function gvjs_sba() {};
/*

 Copyright 2005, 2007 Bob Ippolito. All Rights Reserved.
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: MIT
*/
function gvjs_Al(a, b) {
    this.vM = [];
    this.P6 = a;
    this.S1 = b || null;
    this.oD = this.Wx = !1;
    this.Eh = void 0;
    this.jW = this.sba = this.mP = !1;
    this.AN = 0;
    this.Fc = null;
    this.tP = 0
}
gvjs_u(gvjs_Al, gvjs_sba);
gvjs_ = gvjs_Al.prototype;
gvjs_.cancel = function(a) {
    if (this.Wx) this.Eh instanceof gvjs_Al && this.Eh.cancel();
    else {
        if (this.Fc) {
            var b = this.Fc;
            delete this.Fc;
            a ? b.cancel(a) : (b.tP--, 0 >= b.tP && b.cancel())
        }
        this.P6 ? this.P6.call(this.S1, this) : this.jW = !0;
        this.Wx || (a = new gvjs_Bl(this), this.om(), gvjs_Cl(this, !1, a))
    }
};
gvjs_.l1 = function(a, b) {
    this.mP = !1;
    gvjs_Cl(this, a, b)
};

function gvjs_Cl(a, b, c) {
    a.Wx = !0;
    a.Eh = c;
    a.oD = !b;
    gvjs_Dl(a)
}
gvjs_.om = function() {
    if (this.Wx) {
        if (!this.jW) throw new gvjs_El(this);
        this.jW = !1
    }
};
gvjs_.callback = function(a) {
    this.om();
    gvjs_Cl(this, !0, a)
};

function gvjs_Fl(a, b, c, d) {
    a.vM.push([b, c, d]);
    a.Wx && gvjs_Dl(a)
}
gvjs_.then = function(a, b, c) {
    var d, e, f = new gvjs_jl(function(g, h) {
        e = g;
        d = h
    });
    gvjs_Fl(this, e, function(g) {
        g instanceof gvjs_Bl ? f.cancel() : d(g);
        return gvjs_Gl
    }, this);
    return f.then(a, b, c)
};
gvjs_Al.prototype.$goog_Thenable = !0;
gvjs_Al.prototype.isError = function(a) {
    return a instanceof Error
};

function gvjs_Hl(a) {
    return gvjs_rf(a.vM, function(b) {
        return typeof b[1] === gvjs_c
    })
}
var gvjs_Gl = {};

function gvjs_Dl(a) {
    if (a.AN && a.Wx && gvjs_Hl(a)) {
        var b = a.AN,
            c = gvjs_Il[b];
        c && (gvjs_s.clearTimeout(c.vd), delete gvjs_Il[b]);
        a.AN = 0
    }
    a.Fc && (a.Fc.tP--, delete a.Fc);
    b = a.Eh;
    for (var d = c = !1; a.vM.length && !a.mP;) {
        var e = a.vM.shift(),
            f = e[0],
            g = e[1];
        e = e[2];
        if (f = a.oD ? g : f) try {
            var h = f.call(e || a.S1, b);
            h === gvjs_Gl && (h = void 0);
            void 0 !== h && (a.oD = a.oD && (h == b || a.isError(h)), a.Eh = b = h);
            if (gvjs_il(b) || typeof gvjs_s.Promise === gvjs_c && b instanceof gvjs_s.Promise) d = !0, a.mP = !0
        } catch (k) {
            b = k, a.oD = !0, gvjs_Hl(a) || (c = !0)
        }
    }
    a.Eh = b;
    d && (h =
        gvjs_Se(a.l1, a, !0), d = gvjs_Se(a.l1, a, !1), b instanceof gvjs_Al ? (gvjs_Fl(b, h, d), b.sba = !0) : b.then(h, d));
    c && (b = new gvjs_Jl(b), gvjs_Il[b.vd] = b, a.AN = b.vd)
}

function gvjs_El() {
    gvjs_Xe.call(this)
}
gvjs_u(gvjs_El, gvjs_Xe);
gvjs_El.prototype.message = "Deferred has already fired";
gvjs_El.prototype.name = "AlreadyCalledError";

function gvjs_Bl() {
    gvjs_Xe.call(this)
}
gvjs_u(gvjs_Bl, gvjs_Xe);
gvjs_Bl.prototype.message = "Deferred was canceled";
gvjs_Bl.prototype.name = "CanceledError";

function gvjs_Jl(a) {
    this.vd = gvjs_s.setTimeout(gvjs_Se(this.oma, this), 0);
    this.au = a
}
gvjs_Jl.prototype.oma = function() {
    delete gvjs_Il[this.vd];
    throw this.au;
};
var gvjs_Il = {};
var gvjs_tba = gvjs_2g("https://maps.googleapis.com/maps/api/js?key=%{key}");

function gvjs_Kl() {}
gvjs_Kl.eb = function() {
    throw Error(gvjs_1a);
};

function gvjs_Ll() {
    this.cache = {};
    this.logger = null;
    this.by = new google.maps.Geocoder;
    this.cache[gvjs_Fg({
        address: ""
    })] = {
        response: [],
        status: google.maps.GeocoderStatus.ZERO_RESULTS
    };
    this.ht = new Set;
    this.ps = new Map;
    this.wz = []
}
gvjs_r(gvjs_Ll, gvjs_Kl);
gvjs_Ll.prototype.JR = gvjs_p(21);
gvjs_Ll.prototype.sD = gvjs_p(22);
gvjs_Le(gvjs_Ll);

function gvjs_Ml() {}
gvjs_Ml.prototype.cb = function() {};

function gvjs_Nl(a) {
    if (gvjs_Pe(a) && typeof a.getNumberOfColumns === gvjs_c && typeof a.getNumberOfRows === gvjs_c) return a;
    throw Error("Invalid data table.");
}
gvjs_Ml.prototype.oh = function(a) {
    return this.cb(a) ? 2 : 0
};

function gvjs_Ol(a, b, c) {
    return 0 === c.length || gvjs_rf(c, function(d) {
        return null == d || a.getColumnRole(b) === d
    })
}

function gvjs_Pl(a, b, c) {
    return 0 === c.length || gvjs_rf(c, function(d) {
        return a.getColumnType(b) === d
    })
}

function gvjs_Ql(a, b, c, d) {
    var e;
    if (e = b < a.getNumberOfColumns()) e = a.getColumnType(b) === c;
    if (c = e) d = null == d ? null : d, c = null == d || a.getColumnRole(b) === d;
    return c
}

function gvjs_Rl(a, b, c, d) {
    d = null == d ? [] : [d];
    return b < a.getNumberOfColumns() && gvjs_Pl(a, b, c) && gvjs_Ol(a, b, d)
}
gvjs_Ml.prototype.indexOf = function(a, b) {
    for (var c = 0; c < a.getNumberOfColumns(); c++)
        if (a.getColumnType(c) == b) return c;
    return -1
};

function gvjs_Sl(a, b, c) {
    for (var d = 0; d < b.length; ++d) {
        var e = b[d];
        if (e >= a.getNumberOfColumns() || a.getColumnType(e) != c[d]) return !1
    }
    return !0
}

function gvjs_Tl(a, b) {
    return gvjs_Ql(a, b, gvjs_f) ? gvjs_Ul(a, b, function(c) {
        return 0 <= c
    }) : !1
}

function gvjs_Ul(a, b, c) {
    for (var d = Math.min(a.getNumberOfRows(), 20), e = 0; e < d; e++) {
        var f = a.getValue(e, b);
        if (null != f && !c(f)) return !1
    }
    return !0
}

function gvjs_uba(a) {
    function b(c) {
        return gvjs_Mk(new gvjs_Lk(-180, 180), c) && !gvjs_8h(c)
    }
    return gvjs_Ql(a, 0, gvjs_f) && gvjs_Ql(a, 1, gvjs_f) ? gvjs_Ul(a, 0, function(c) {
        return gvjs_Mk(new gvjs_Lk(-90, 90), c) && !gvjs_8h(c)
    }) && gvjs_Ul(a, 1, b) : !1
}

function gvjs_Vl(a) {
    for (var b = a.getDistinctValues(0), c = Math.min(a.getNumberOfRows(), 20), d = 0, e = 0; e < c; e++) {
        var f = a.getValue(e, 1);
        f && !gvjs_tf(b, f) || d++
    }
    return .6 < d / c
};

function gvjs_Wl() {}
gvjs_r(gvjs_Wl, gvjs_Ml);
gvjs_Wl.prototype.cb = function(a) {
    a = gvjs_Nl(a);
    var b = a.getNumberOfColumns();
    if (2 > b) return !1;
    var c = a.getColumnType(0);
    if (c != gvjs_1b && c != gvjs_2b || a.getColumnType(1) != gvjs_f) return !1;
    c = 0;
    for (var d = 1; d < b; d++) {
        var e = a.getColumnType(d);
        if (e == gvjs_f) c = 0;
        else if (e == gvjs_m) {
            if (c++, 2 < c) return !1
        } else return !1
    }
    return !0
};
gvjs_Wl.prototype.oh = function(a) {
    if (!this.cb(a)) return 0;
    a = gvjs_Nl(a);
    var b = 0 < this.indexOf(a, gvjs_m),
        c = a.getNumberOfRows(),
        d = a.getSortedRows(0);
    if (50 < c) a = !0;
    else {
        for (var e = Number.MAX_VALUE, f = Number.MIN_VALUE, g = 1; g < c; g++) {
            var h = Math.abs(a.getValue(d[g - 1], 0) - a.getValue(d[g], 0));
            e = 0 < h && h < e ? h : e;
            f = h > f ? h : f
        }
        a = 0 != e && 50 < f / e ? !0 : !1
    }
    return b && a ? 3 : b || a ? 2 : 1
};

function gvjs_Xl(a) {
    a = a || {};
    this.V_ = !!a.Zw
}
gvjs_r(gvjs_Xl, gvjs_Ml);
gvjs_Xl.prototype.cb = function(a) {
    gvjs_Nl(a);
    var b = 0,
        c = a.getNumberOfColumns();
    if (1 > c) return !1;
    if (!gvjs_Ql(a, 0, gvjs_f) && (b++, this.V_))
        for (; b < c && gvjs_Ql(a, b, gvjs_m);) b++;
    for (var d = null; b < c;) {
        var e = a.getColumnType(b);
        if (e == gvjs_f) d = {};
        else if (this.V_ && e == gvjs_m) {
            if (!d) return !1
        } else if (e == gvjs_Lb) {
            if (!d || d.Bt) return !1;
            d.Bt = b
        } else return !1;
        b++
    }
    return null !== d
};

function gvjs_Yl(a) {
    gvjs_Xl.call(this, a);
    this.US = a && a.isStacked || !1
}
gvjs_r(gvjs_Yl, gvjs_Xl);
gvjs_Yl.prototype.cb = function(a) {
    gvjs_Nl(a);
    if (!gvjs_Xl.prototype.cb.call(this, a)) return !1;
    var b = a.getNumberOfColumns();
    if (this.US)
        for (var c = 1; c < b; c++)
            if (gvjs_Ql(a, c, gvjs_f) && !gvjs_Tl(a, c)) return !1;
    return !0
};
gvjs_Yl.prototype.oh = function(a) {
    for (var b = a.getNumberOfColumns(), c = a.getNumberOfRows(), d = 0, e = !1, f = 0; f < b; f++) gvjs_Ql(a, f, gvjs_f) && (d++, gvjs_Tl(a, f) || (e = !0));
    return this.cb(a) ? 1 == c || e || gvjs_Ql(a, 0, gvjs_m) ? 1 : 2 < d && this.US ? 3 : 1 != d || this.US ? 1 : 2 : 0
};

function gvjs_Zl() {}
gvjs_r(gvjs_Zl, gvjs_Ml);
gvjs_Zl.prototype.cb = function(a) {
    a = gvjs_Nl(a);
    var b = a.getNumberOfColumns();
    return 3 > b || 5 < b || !gvjs_Ql(a, 0, gvjs_m) || !gvjs_Ql(a, 1, gvjs_f) || !gvjs_Ql(a, 2, gvjs_f) || 3 < b && !gvjs_Ql(a, 3, gvjs_m) || 4 < b && !gvjs_Ql(a, 4, gvjs_f) ? !1 : !0
};
gvjs_Zl.prototype.oh = function(a) {
    a = gvjs_Nl(a);
    if (this.cb(a)) {
        var b = a;
        if (gvjs_Ql(b, 3, gvjs_m)) {
            for (var c = {}, d = 0, e = Math.min(b.getNumberOfRows(), 20), f = 0; f < e; f++) {
                var g = b.getValue(f, 3);
                c[g] || d++;
                c[g] = !0
            }
            b = 10 > d
        } else b = !1;
        a = b ? 3 : gvjs_Ql(a, 3, gvjs_m) ? 1 : 2
    } else a = 0;
    return a
};

function gvjs__l() {}
gvjs_r(gvjs__l, gvjs_Ml);
gvjs__l.prototype.cb = function(a) {
    gvjs_Nl(a);
    var b = a.getNumberOfColumns();
    if (5 > b || 6 < b || !(gvjs_Ql(a, 0, gvjs_m) && gvjs_Ql(a, 1, gvjs_f) && gvjs_Ql(a, 2, gvjs_f) && gvjs_Ql(a, 3, gvjs_f) && gvjs_Ql(a, 4, gvjs_f)) || 6 == b && !gvjs_Ql(a, 5, gvjs_m)) return !1;
    b = Math.min(a.getNumberOfRows(), 20);
    for (var c = !0, d = 0; d < b; d++) {
        var e = a.getValue(d, 1),
            f = a.getValue(d, 2),
            g = a.getValue(d, 3),
            h = a.getValue(d, 4);
        if (null != e && null != f && null != g && null != h && (c = !1, e != Math.min(e, f, g, h) || h != Math.max(e, f, g, h))) return !1
    }
    return !c
};
gvjs__l.prototype.oh = function(a) {
    return this.cb(a) ? 3 : 0
};

function gvjs_0l(a) {
    gvjs_Xl.call(this, a)
}
gvjs_r(gvjs_0l, gvjs_Xl);
gvjs_0l.prototype.oh = function(a) {
    a = gvjs_Nl(a);
    var b = gvjs_Ql(a, 0, gvjs_f),
        c = a.getNumberOfColumns();
    b || c--;
    return this.cb(a) ? 2 > c ? 1 : 2 : 0
};

function gvjs_1l() {}
gvjs_r(gvjs_1l, gvjs_Ml);
gvjs_1l.prototype.cb = function(a) {
    gvjs_Nl(a);
    var b = a.getNumberOfColumns();
    if (1 > b || 2 < b) b = !1;
    else {
        var c = !0;
        2 == b && (c = c && gvjs_Ql(a, 0, gvjs_m));
        b = c = c && gvjs_Tl(a, b - 1)
    }
    if (!b)
        if (b = a.getNumberOfColumns(), c = a.getNumberOfRows(), 0 == b || 1 != c) b = !1;
        else {
            c = !0;
            for (var d = 0; d < b; d++)
                if (!gvjs_Ql(a, d, gvjs_f)) {
                    c = !1;
                    break
                }
            b = c
        }
    return b
};
gvjs_1l.prototype.oh = function(a) {
    return this.cb(a) ? 1 < a.getNumberOfRows() ? 2 : 3 : 0
};

function gvjs_2l(a, b, c) {
    a = gvjs_3l(a);
    b = gvjs_M(a, b, gvjs_4l(c));
    return new gvjs_5l(b)
}

function gvjs_6l(a, b, c) {
    a = gvjs_3l(a);
    b = gvjs_Zk(a, b, gvjs_4l(c));
    return new gvjs_5l(b)
}

function gvjs_N(a, b, c) {
    gvjs_3l(a).dispatchEvent(new gvjs_7l(b, c))
}

function gvjs_8l(a) {
    return (a = a && typeof a.getKey === gvjs_c && a.getKey()) ? gvjs_4k(a) : !1
}

function gvjs_9l(a) {
    var b = gvjs_3l(a);
    b = gvjs_5k(b);
    gvjs_K(a.__eventTarget);
    a.__eventTarget = void 0;
    return b
}

function gvjs_3l(a) {
    var b = a.__eventTarget;
    null != b ? a = b : (b = new gvjs_7k, a = a.__eventTarget = b);
    return a
}

function gvjs_4l(a) {
    return function(b) {
        b && b.oea ? a(b.properties) : a()
    }
}

function gvjs_5l(a) {
    this.key = a
}
gvjs_5l.prototype.getKey = function() {
    return this.key
};

function gvjs_7l(a, b) {
    gvjs_Nk.call(this, a);
    this.properties = b
}
gvjs_r(gvjs_7l, gvjs_Nk);
gvjs_7l.prototype.oea = function() {
    return this.properties
};

function gvjs_$l(a, b, c) {
    this.visualization = a;
    this.container = b;
    this.Qx = null;
    this.visualization = a;
    this.container = b;
    if (void 0 === c ? 0 : c) a = gvjs_mk(b), "" !== a && "static" !== a || gvjs_I(b, gvjs_Pd, gvjs_Td), this.Qx = document.createElement(gvjs_5b), gvjs_I(this.Qx, {
        position: gvjs_xb,
        top: 0,
        left: 0,
        "z-index": 1
    })
}

function gvjs_am(a) {
    return a.Qx ? (a.Qx.parentNode !== a.container && a.container.appendChild(a.Qx), a.Qx) : a.container
}
gvjs_$l.prototype.addError = function(a) {
    gvjs_bm(this, a, gvjs_7b)
};
gvjs_$l.prototype.dm = gvjs_p(23);

function gvjs_bm(a, b, c, d) {
    d = void 0 === d ? !0 : d;
    var e = gvjs_am(a);
    c = {
        removable: !0,
        type: c
    };
    e = (0, gvjs_J.addError)(e, b, null, c);
    (null == d || d) && gvjs_N(a.visualization, gvjs_7b, {
        id: e,
        message: b,
        detailedMessage: "",
        options: c
    })
}
gvjs_$l.prototype.removeAll = function() {
    var a = gvjs_am(this);
    (0, gvjs_J.removeAll)(a)
};

function gvjs_cm(a, b, c) {
    try {
        return c ? b.call(c) : b()
    } catch (d) {
        a.addError(d.message)
    }
};

function gvjs_dm() {}
gvjs_r(gvjs_dm, gvjs_Ml);
gvjs_dm.prototype.cb = function(a) {
    var b = a.getNumberOfColumns();
    if (1 > b || 2 < b) return !1;
    var c = gvjs_Ql(a, 0, gvjs_m);
    2 == b && (c = c && gvjs_Ql(a, 1, gvjs_f));
    return c
};
gvjs_dm.prototype.oh = function(a) {
    return this.cb(a) ? 1 : 0
};
gvjs_dm.prototype.Tb = function(a, b, c) {
    try {
        a = gvjs_Nl(a);
        b = b || gvjs_Gb;
        var d = 0,
            e = -1,
            f = -1,
            g = -1,
            h = -1;
        if (gvjs_Sl(a, [d, d + 1], [gvjs_f, gvjs_f])) {
            var k = gvjs_rd;
            g = d;
            h = d + 1;
            d += 2;
            if (b === gvjs_Sd) throw Error("displayMode must be set to Markers when using lat/long addresses.");
            b === gvjs_Gb && (b = gvjs_vd)
        } else if (gvjs_Sl(a, [d], [gvjs_m])) {
            switch (b) {
                case gvjs_Gb:
                    k = gvjs_Rd;
                    b = gvjs_Sd;
                    e = d;
                    break;
                case gvjs_Sd:
                    k = gvjs_Rd;
                    e = d;
                    break;
                case gvjs_vd:
                case gvjs_n:
                    k = "address";
                    f = d;
                    break;
                default:
                    throw Error("Unknown displayMode: " + b);
            }
            d +=
                1
        } else throw Error("Unknown address type.");
        var l = null;
        gvjs_Sl(a, [d], [gvjs_m]) && gvjs_de != a.getColumnProperty(d, gvjs_Vd) && (l = d++);
        var m = null,
            n = null;
        gvjs_Sl(a, [d], [gvjs_f]) && (m = d++, gvjs_Sl(a, [d], [gvjs_f]) && (n = d++));
        var p = null;
        gvjs_Sl(a, [d], [gvjs_m]) && gvjs_de == a.getColumnProperty(d, gvjs_Vd) && (p = d++);
        k != gvjs_Rd && null != m && null == n && (n = m);
        if (a.getNumberOfColumns() != d) throw Error("Table contains more columns than expected (Expecting " + d + " columns)");
        return {
            NO: k,
            displayMode: b,
            mF: e,
            rB: f,
            Qy: g,
            Wy: h,
            rE: l,
            Sq: m,
            Zz: n,
            NW: p
        }
    } catch (q) {
        return c && c.addError("Incompatible data table: " + q), null
    }
};

function gvjs_em(a) {
    gvjs_Xl.call(this, a)
}
gvjs_r(gvjs_em, gvjs_Xl);
gvjs_em.prototype.cb = function(a) {
    gvjs_Nl(a);
    return gvjs_Xl.prototype.cb.call(this, a) ? !0 : !1
};
gvjs_em.prototype.oh = function(a) {
    for (var b = a.getNumberOfColumns(), c = a.getNumberOfRows(), d = 0, e = 0, f = 0; f < b; f++) gvjs_Ql(a, f, gvjs_f) ? d++ : gvjs_Ql(a, f, gvjs_1b) && e++;
    return this.cb(a) ? 10 > c ? 1 : 2 > d && 0 == e ? 3 : 2 : 0
};

function gvjs_fm() {}
gvjs_r(gvjs_fm, gvjs_Ml);
gvjs_fm.prototype.cb = function(a) {
    return gvjs_gm(a) || gvjs_hm(a)
};
gvjs_fm.prototype.oh = function(a) {
    var b = gvjs_gm(a);
    a = gvjs_hm(a);
    return b || a ? a ? 1 : 3 : 0
};

function gvjs_gm(a) {
    gvjs_Nl(a);
    var b = a.getNumberOfColumns();
    if (2 > b || 3 < b) return !1;
    var c = gvjs_Ql(a, 0, gvjs_f);
    c = c && gvjs_Ql(a, 1, gvjs_f);
    3 == b && (c = c && gvjs_Ql(a, 2, gvjs_m));
    return c && gvjs_uba(a)
}

function gvjs_hm(a) {
    gvjs_Nl(a);
    var b = a.getNumberOfColumns();
    return 1 > b || 2 < b || !gvjs_Ql(a, 0, gvjs_m) || 2 == b && !gvjs_Ql(a, 1, gvjs_m) ? !1 : !0
};

function gvjs_im() {}
gvjs_r(gvjs_im, gvjs_Ml);
gvjs_im.prototype.cb = function(a) {
    a = gvjs_Nl(a);
    var b = a.getNumberOfColumns();
    if (3 > b || a.getColumnType(0) != gvjs_m) return !1;
    var c = a.getColumnType(1);
    if (c != gvjs_f && c != gvjs_1b && c != gvjs_m || c == gvjs_m && !gvjs_vba(a) && !gvjs_wba(a) || c == gvjs_f && !gvjs_Ul(a, 1, function(e) {
            return gvjs_8h(e)
        })) return !1;
    for (c = 2; c < b; c++) {
        var d = a.getColumnType(c);
        if (d != gvjs_f && d != gvjs_m) return !1
    }
    return !0
};
gvjs_im.prototype.oh = function(a) {
    try {
        a = gvjs_Nl(a)
    } catch (b) {
        return 0
    }
    return this.cb(a) ? gvjs_Ql(a, 1, gvjs_f) && !gvjs_xba(a) ? 1 : 3 : 0
};

function gvjs_xba(a) {
    return gvjs_Ul(a, 1, function(b) {
        return 1900 < b && 2100 > b
    })
}

function gvjs_vba(a) {
    return gvjs_Ul(a, 1, function(b) {
        return 7 != b.length || isNaN(b.substring(0, 3)) || "W" != b.charAt(4) || isNaN(b.substring(6, 7)) ? !1 : !0
    })
}

function gvjs_wba(a) {
    return gvjs_Ul(a, 1, function(b) {
        return 6 != b.length || isNaN(b.substring(0, 3)) || "Q" != b.charAt(4) || isNaN(b.charAt(5)) ? !1 : !0
    })
};

function gvjs_jm() {}
gvjs_r(gvjs_jm, gvjs_Ml);
gvjs_jm.prototype.cb = function(a) {
    gvjs_Nl(a);
    var b = a.getNumberOfColumns();
    if (2 > b || 3 < b) return !1;
    var c = gvjs_Ql(a, 0, gvjs_m) && gvjs_Ql(a, 1, gvjs_m);
    3 == b && (c = c && gvjs_Ql(a, 2, gvjs_m));
    return c && gvjs_Vl(a)
};
gvjs_jm.prototype.oh = function(a) {
    return this.cb(a) ? 3 : 0
};

function gvjs_km() {}
gvjs_r(gvjs_km, gvjs_Ml);
gvjs_km.prototype.cb = function(a) {
    gvjs_Nl(a);
    var b = a.getNumberOfColumns();
    return 1 > b || 2 < b ? !1 : gvjs_Ql(a, b - 1, gvjs_f) && gvjs_Tl(a, b - 1)
};
gvjs_km.prototype.oh = function(a) {
    if (this.cb(a))
        if (1 == a.getNumberOfRows()) a = 1;
        else {
            var b;
            if (!(b = !gvjs_Ql(a, 0, gvjs_m) || 25 < a.getNumberOfRows())) {
                for (var c = b = 0; c < a.getNumberOfRows(); c++) b += a.getValue(c, 1);
                b = !(97 < b && 103 > b || .97 < b && 1.03 > b)
            }
            a = b ? 2 : 3
        }
    else a = 0;
    return a
};

function gvjs_lm() {}
gvjs_r(gvjs_lm, gvjs_Ml);
gvjs_lm.prototype.cb = function(a) {
    gvjs_Nl(a);
    var b = a.getNumberOfColumns();
    if (0 == b) return !1;
    for (var c = gvjs_Ql(a, 0, gvjs_m) ? 1 : 0, d = b > c; c < b; c++)
        if (!gvjs_Ql(a, c, gvjs_f)) {
            d = !1;
            break
        }
    return d
};

function gvjs_mm() {}
gvjs_r(gvjs_mm, gvjs_Ml);
gvjs_mm.prototype.cb = function(a) {
    gvjs_Nl(a);
    for (var b = !0, c = a.getNumberOfColumns(), d = 0; d < c; d++)
        if (!gvjs_Ql(a, d, gvjs_f)) {
            b = !1;
            break
        }
    return b
};
gvjs_mm.prototype.oh = function(a) {
    return this.cb(a) ? 2 > a.getNumberOfColumns() ? 1 : 2 : 0
};

function gvjs_nm() {}
gvjs_r(gvjs_nm, gvjs_Ml);
gvjs_nm.prototype.cb = function() {
    return !0
};

function gvjs_om(a) {
    this.m = a || new gvjs_Si([])
}
gvjs_r(gvjs_om, gvjs_Ml);
gvjs_om.prototype.cb = function(a) {
    try {
        this.Tb(a)
    } catch (b) {
        return !1
    }
    return !0
};
gvjs_om.prototype.Tb = function(a) {
    a = gvjs_Nl(a);
    for (var b = [], c = a.getNumberOfColumns(), d = 0; d < c; ++d) {
        var e = a.getColumnRole(d);
        if ("" === e) b.push({
            index: d,
            he: {}
        });
        else {
            if (1 > b.length) throw Error("At least 1 data column must come before any role columns");
            gvjs_nf(b).he[e] = d
        }
    }
    c = b.length;
    if (3 !== c && 4 !== c) throw Error("Invalid data table format: must have 3 or 4 data columns.");
    d = 4 == c;
    this.Ha(a, b[0].index, gvjs_m);
    d && this.Ha(a, b[1].index, gvjs_m);
    this.Ha(a, b[d ? 2 : 1].index, gvjs_pm);
    this.Ha(a, b[d ? 3 : 2].index, gvjs_pm);
    return 4 === c ? (a = !gvjs_D(this.m, "timeline.taskMajor", !0), {
        bs: b[a ? 1 : 0],
        up: b[a ? 0 : 1],
        MF: b[2],
        NC: b[3]
    }) : {
        bs: b[0],
        up: null,
        MF: b[1],
        NC: b[2]
    }
};
gvjs_om.prototype.Ha = function(a, b, c) {
    Array.isArray(c) || (c = [c]);
    if (!gvjs_Rl(a, b, c)) throw Error(gvjs_Ta + b + gvjs_ca + c + "'.");
};
var gvjs_pm = [gvjs_1b, gvjs_f, gvjs_2b];

function gvjs_qm() {}
gvjs_r(gvjs_qm, gvjs_Ml);
gvjs_qm.prototype.cb = function(a) {
    gvjs_Nl(a);
    var b = a.getNumberOfColumns();
    if (2 > b || 4 < b) return !1;
    var c = gvjs_Ql(a, 0, gvjs_m) && gvjs_Ql(a, 1, gvjs_m);
    2 < b && (c = c && gvjs_Tl(a, 2)) && 3 < b && (c = c && gvjs_Ql(a, 3, gvjs_f));
    return c && gvjs_Vl(a)
};
gvjs_qm.prototype.oh = function(a) {
    return this.cb(a) ? 3 : 0
};

function gvjs_rm(a) {
    this.mm = Array.isArray(a) ? a : gvjs_Sg(gvjs_yba)
}
gvjs_rm.prototype.DP = function(a) {
    var b = [];
    gvjs_v(this.mm, function(c) {
        var d = gvjs_zba[c],
            e = d && d.format;
        e && (e = e.oh(a), 0 != e && b.push({
            type: c,
            T2: e,
            Yc: d.Yc
        }))
    });
    gvjs_Aba(b);
    return gvjs_w(b, function(c) {
        return c.type
    })
};

function gvjs_Aba(a) {
    gvjs_Cf(a, function(b, c) {
        var d = b.T2 - c.T2;
        0 == d && (d = b.Yc - c.Yc);
        return -d
    })
}
var gvjs_yba = {
        Fna: gvjs_oa,
        j$: gvjs_pa,
        Kna: gvjs_sa,
        Vna: gvjs_ta,
        Xna: gvjs_va,
        boa: gvjs_ya,
        t$: gvjs_za,
        noa: gvjs_Ha,
        ooa: gvjs_Ia,
        F$: gvjs_Ma,
        soa: gvjs_Pa,
        toa: gvjs_Qa,
        Noa: gvjs_0a,
        M$: gvjs_Wa,
        Woa: gvjs_7a,
        Foa: gvjs_Xa,
        Roa: gvjs_6a,
        taa: gvjs_db,
        lpa: gvjs_qa,
        opa: gvjs_fb,
        u_: gvjs_mb,
        vpa: gvjs_ob,
        xpa: gvjs_qb,
        Faa: gvjs_ub
    },
    gvjs_zba = {
        AnnotatedTimeLine: {
            format: new gvjs_Wl,
            Yc: 3
        },
        AreaChart: {
            format: new gvjs_Yl({
                Zw: !0
            }),
            Yc: 2
        },
        BarChart: {
            format: new gvjs_Xl({
                Zw: !0
            }),
            Yc: 2
        },
        BubbleChart: {
            format: new gvjs_Zl,
            Yc: 2
        },
        CandlestickChart: {
            format: new gvjs__l,
            Yc: 2
        },
        ColumnChart: {
            format: new gvjs_Xl({
                Zw: !0
            }),
            Yc: 2
        },
        ComboChart: {
            format: new gvjs_0l({
                Zw: !0
            }),
            Yc: 2
        },
        Gauge: {
            format: new gvjs_1l,
            Yc: 1
        },
        GeoChart: {
            format: new gvjs_dm,
            Yc: 3
        },
        Histogram: {
            format: new gvjs_em,
            Yc: 3
        },
        LineChart: {
            format: new gvjs_Xl({
                Zw: !0
            }),
            Yc: 2
        },
        ImageRadarChart: {
            format: new gvjs_lm,
            Yc: 1
        },
        ImageSparkLine: {
            format: new gvjs_mm,
            Yc: 1
        },
        Map: {
            format: new gvjs_fm,
            Yc: 2
        },
        MotionChart: {
            format: new gvjs_im,
            Yc: 3
        },
        OrgChart: {
            format: new gvjs_jm,
            Yc: 2
        },
        PieChart: {
            format: new gvjs_km,
            Yc: 2
        },
        ScatterChart: {
            format: new gvjs_Xl({
                Zw: !0
            }),
            Yc: 2
        },
        "AreaChart-stacked": {
            format: new gvjs_Yl({
                isStacked: !0
            }),
            Yc: 2
        },
        SteppedAreaChart: {
            format: new gvjs_Yl,
            Yc: 2
        },
        Table: {
            format: new gvjs_nm,
            Yc: 0
        },
        Timeline: {
            format: new gvjs_om,
            Yc: 2
        },
        TreeMap: {
            format: new gvjs_qm,
            Yc: 2
        },
        WordTree: {
            format: new gvjs_dm,
            Yc: 2
        }
    };

function gvjs_sm(a, b) {
    this.Vba = a[gvjs_s.Symbol.iterator]();
    this.nia = b
}
gvjs_sm.prototype[Symbol.iterator] = function() {
    return this
};
gvjs_sm.prototype.next = function() {
    var a = this.Vba.next();
    return {
        value: a.done ? void 0 : this.nia.call(void 0, a.value),
        done: a.done
    }
};

function gvjs_tm() {}
gvjs_tm.prototype.next = function() {
    return gvjs_um
};
var gvjs_um = {
    done: !0,
    value: void 0
};
gvjs_tm.prototype.Di = function() {
    return this
};

function gvjs_vm(a) {
    this.FR = a
}
gvjs_vm.prototype.Di = function() {
    return new gvjs_wm(this.FR())
};
gvjs_vm.prototype[Symbol.iterator] = function() {
    return new gvjs_xm(this.FR())
};
gvjs_vm.prototype.gG = gvjs_p(25);

function gvjs_wm(a) {
    this.dE = a
}
gvjs_r(gvjs_wm, gvjs_tm);
gvjs_wm.prototype.next = function() {
    return this.dE.next()
};
gvjs_wm.prototype[Symbol.iterator] = function() {
    return new gvjs_xm(this.dE)
};
gvjs_wm.prototype.gG = gvjs_p(24);

function gvjs_xm(a) {
    gvjs_vm.call(this, function() {
        return a
    });
    this.dE = a
}
gvjs_r(gvjs_xm, gvjs_vm);
gvjs_xm.prototype.next = function() {
    return this.dE.next()
};
gvjs_t("google.visualization.ChartSelection", gvjs_rm);
gvjs_rm.prototype.calculateChartTypes = gvjs_rm.prototype.DP;
var gvjs_Bba = new Set([gvjs_ec, gvjs_fc, gvjs_gc, gvjs_ic, gvjs_jc, gvjs_kc, gvjs_lc, gvjs_mc, gvjs_nc, gvjs_oc, gvjs_pc, gvjs_qc, gvjs_rc, "google.visualization.Circles", gvjs_sc, gvjs_tc, gvjs_uc, gvjs_vc, gvjs_wc, gvjs_xc, gvjs_zc, gvjs_Ac, gvjs_Bc, gvjs_Cc, gvjs_Dc, gvjs_Ec, gvjs_Fc, gvjs_Gc, gvjs_Hc, gvjs_Ic, gvjs_Jc, gvjs_Kc, gvjs_Lc, gvjs_Mc, gvjs_Nc, gvjs_Oc, gvjs_Pc, gvjs_Qc, gvjs_Rc, gvjs_Sc, gvjs_Tc, gvjs_Vc, gvjs_Wc, gvjs_Xc, gvjs_Yc, gvjs_Zc, gvjs__c, gvjs_1c, gvjs_2c, gvjs_3c, gvjs_4c, gvjs_5c, gvjs_6c, gvjs_7c, gvjs_8c, gvjs_9c, gvjs_$c,
    gvjs_ad, "google.visualization.TableTextChart", gvjs_bd, gvjs_cd, gvjs_dd, gvjs_gd, gvjs_fd
]);

function gvjs_Cba(a) {
    a = String(a);
    return [gvjs_hc + a, gvjs_dc + a, a].some(function(b) {
        return gvjs_Bba.has(b)
    }) ? a : ""
};
var gvjs_ym = {};

function gvjs_zm(a) {
    var b = gvjs_ym.hasOwnProperty(a) ? gvjs_ym[a] : null;
    if (b) return b;
    65536 < Object.keys(gvjs_ym).length && (gvjs_ym = {});
    var c = [0, 0, 0, 0],
        d = RegExp("\\\\[0-9A-Fa-f]{1,5}\\s", "g");
    b = gvjs_Am(a, RegExp("\\\\[0-9A-Fa-f]{6}\\s?", "g"));
    b = gvjs_Am(b, d);
    b = gvjs_Am(b, /\\./g);
    b = b.replace(RegExp(":not\\(([^\\)]*)\\)", "g"), "     $1 ");
    b = b.replace(RegExp("{[^]*", "gm"), "");
    b = gvjs_Bm(b, c, RegExp("(\\[[^\\]]+\\])", "g"), 2);
    b = gvjs_Bm(b, c, RegExp("(#[^\\#\\s\\+>~\\.\\[:]+)", "g"), 1);
    b = gvjs_Bm(b, c, RegExp("(\\.[^\\s\\+>~\\.\\[:]+)", "g"),
        2);
    b = gvjs_Bm(b, c, /(::[^\s\+>~\.\[:]+|:first-line|:first-letter|:before|:after)/gi, 3);
    b = gvjs_Bm(b, c, /(:[\w-]+\([^\)]*\))/gi, 2);
    b = gvjs_Bm(b, c, /(:[^\s\+>~\.\[:]+)/g, 2);
    b = b.replace(/[\*\s\+>~]/g, " ");
    b = b.replace(/[#\.]/g, " ");
    gvjs_Bm(b, c, /([^\s\+>~\.\[:]+)/g, 3);
    b = c;
    return gvjs_ym[a] = b
}

function gvjs_Bm(a, b, c, d) {
    return a.replace(c, function(e) {
        b[d] += 1;
        return Array(e.length + 1).join(" ")
    })
}

function gvjs_Am(a, b) {
    return a.replace(b, function(c) {
        return Array(c.length + 1).join("A")
    })
};
var gvjs_Dba = {
        rgb: !0,
        rgba: !0,
        alpha: !0,
        rect: !0,
        image: !0,
        "linear-gradient": !0,
        "radial-gradient": !0,
        "repeating-linear-gradient": !0,
        "repeating-radial-gradient": !0,
        "cubic-bezier": !0,
        matrix: !0,
        perspective: !0,
        rotate: !0,
        rotate3d: !0,
        rotatex: !0,
        rotatey: !0,
        steps: !0,
        rotatez: !0,
        scale: !0,
        scale3d: !0,
        scalex: !0,
        scaley: !0,
        scalez: !0,
        skew: !0,
        skewx: !0,
        skewy: !0,
        translate: !0,
        translate3d: !0,
        translatex: !0,
        translatey: !0,
        translatez: !0
    },
    gvjs_Eba = /[\n\f\r"'()*<>]/g,
    gvjs_Fba = {
        "\n": "%0a",
        "\f": "%0c",
        "\r": "%0d",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "*": "%2a",
        "<": "%3c",
        ">": "%3e"
    };

function gvjs_Gba(a) {
    return gvjs_Fba[a]
}

function gvjs_Hba(a, b, c) {
    b = gvjs_2e(b);
    if ("" == b) return null;
    var d = b.slice(0, 4);
    d = String(d).toLowerCase();
    if (0 == ("url(" < d ? -1 : "url(" == d ? 0 : 1)) {
        if (!b.endsWith(")") || 1 < (b ? b.split("(").length - 1 : 0) || 1 < (b ? b.split(")").length - 1 : 0) || !c) a = null;
        else {
            a: for (b = b.substring(4, b.length - 1), d = 0; 2 > d; d++) {
                var e = "\"'".charAt(d);
                if (b.charAt(0) == e && b.charAt(b.length - 1) == e) {
                    b = b.substring(1, b.length - 1);
                    break a
                }
            }
            a = c ? (a = c(b, a)) && gvjs_dh(a) != gvjs_wb ? 'url("' + gvjs_dh(a).replace(gvjs_Eba, gvjs_Gba) + '")' : null : null
        }
        return a
    }
    if (0 < b.indexOf("(")) {
        if (/"|'/.test(b)) return null;
        for (a = /([\-\w]+)\(/g; c = a.exec(b);)
            if (!(c[1].toLowerCase() in gvjs_Dba)) return null
    }
    return b
};

function gvjs_Cm(a, b) {
    a = gvjs_s[a];
    return a && a.prototype ? (b = Object.getOwnPropertyDescriptor(a.prototype, b)) && b.get || null : null
}

function gvjs_Dm(a, b) {
    return (a = gvjs_s[a]) && a.prototype && a.prototype[b] || null
}
var gvjs_Iba = gvjs_Cm(gvjs_Ea, gvjs_Fb) || gvjs_Cm(gvjs_2a, gvjs_Fb),
    gvjs_Em = gvjs_Dm(gvjs_Ea, gvjs_hd),
    gvjs_Fm = gvjs_Dm(gvjs_Ea, gvjs_ac),
    gvjs_Jba = gvjs_Dm(gvjs_Ea, gvjs_0d),
    gvjs_Kba = gvjs_Dm(gvjs_Ea, gvjs_Ud);
gvjs_Cm(gvjs_Ea, "innerHTML") || gvjs_Cm("HTMLElement", "innerHTML");
var gvjs_Lba = gvjs_Dm(gvjs_Ea, gvjs_bc),
    gvjs_Mba = gvjs_Dm(gvjs_Ea, "matches") || gvjs_Dm(gvjs_Ea, gvjs_Ed),
    gvjs_Nba = gvjs_Cm(gvjs_2a, gvjs_Hd),
    gvjs_Oba = gvjs_Cm(gvjs_2a, gvjs_Id),
    gvjs_Pba = gvjs_Cm(gvjs_2a, "parentNode");
gvjs_Cm(gvjs_2a, "childNodes");
var gvjs_Qba = gvjs_Cm("HTMLElement", gvjs_6d) || gvjs_Cm(gvjs_Ea, gvjs_6d),
    gvjs_Rba = gvjs_Cm("HTMLStyleElement", "sheet"),
    gvjs_Sba = gvjs_Dm(gvjs_ua, gvjs_cc),
    gvjs_Tba = gvjs_Dm(gvjs_ua, "setProperty"),
    gvjs_Uba = gvjs_Cm(gvjs_Ea, gvjs_Gd) || gvjs_Cm(gvjs_2a, gvjs_Gd);

function gvjs_Gm(a, b, c, d) {
    if (a) return a.apply(b);
    a = b[c];
    if (!d(a)) throw Error(gvjs_wa);
    return a
}

function gvjs_Hm(a, b, c, d) {
    if (a) return a.apply(b, d);
    if (gvjs_x && 10 > document.documentMode) {
        if (!b[c].call) throw Error("IE Clobbering detected");
    } else if (typeof b[c] != gvjs_c) throw Error(gvjs_wa);
    return b[c].apply(b, d)
}

function gvjs_Im(a) {
    return gvjs_Gm(gvjs_Iba, a, gvjs_Fb, function(b) {
        return b instanceof NamedNodeMap
    })
}

function gvjs_Jm(a, b, c) {
    try {
        gvjs_Hm(gvjs_Jba, a, gvjs_0d, [b, c])
    } catch (d) {
        if (-1 == d.message.indexOf("A security problem occurred")) throw d;
    }
}

function gvjs_Vba(a) {
    return gvjs_Gm(gvjs_Qba, a, gvjs_6d, function(b) {
        return b instanceof CSSStyleDeclaration
    })
}

function gvjs_Wba(a) {
    return gvjs_Gm(gvjs_Rba, a, "sheet", function(b) {
        return b instanceof CSSStyleSheet
    })
}

function gvjs_Km(a) {
    return gvjs_Gm(gvjs_Nba, a, gvjs_Hd, function(b) {
        return typeof b == gvjs_m
    })
}

function gvjs_Lm(a) {
    return gvjs_Gm(gvjs_Oba, a, gvjs_Id, function(b) {
        return typeof b == gvjs_f
    })
}

function gvjs_Mm(a) {
    return gvjs_Gm(gvjs_Pba, a, "parentNode", function(b) {
        return !(b && typeof b.name == gvjs_m && b.name && "parentnode" == b.name.toLowerCase())
    })
}

function gvjs_Nm(a, b) {
    return gvjs_Hm(gvjs_Sba, a, a.getPropertyValue ? gvjs_cc : gvjs_ac, [b]) || ""
}

function gvjs_Om(a, b, c) {
    gvjs_Hm(gvjs_Tba, a, a.setProperty ? "setProperty" : gvjs_0d, [b, c])
}

function gvjs_Xba(a) {
    return gvjs_Gm(gvjs_Uba, a, gvjs_Gd, function(b) {
        return typeof b == gvjs_m
    })
};
var gvjs_Yba = gvjs_x && 10 > document.documentMode ? null : RegExp("\\s*([^\\s'\",]+[^'\",]*(('([^'\\r\\n\\f\\\\]|\\\\[^])*')|(\"([^\"\\r\\n\\f\\\\]|\\\\[^])*\")|[^'\",])*)", "g"),
    gvjs_Zba = {
        "-webkit-border-horizontal-spacing": !0,
        "-webkit-border-vertical-spacing": !0
    };

function gvjs__ba(a, b, c) {
    var d = [];
    gvjs_Pm(gvjs_wf(a.cssRules)).forEach(function(e) {
        if (b && !/[a-zA-Z][\w-:\.]*/.test(b)) throw Error("Invalid container id");
        if (!(b && gvjs_x && 10 == document.documentMode && /\\['"]/.test(e.selectorText))) {
            var f = b ? e.selectorText.replace(gvjs_Yba, "#" + b + " $1") : e.selectorText,
                g = d.push;
            e = gvjs_Qm(e.style, c);
            if (gvjs_4e(f, "<")) throw Error("Selector does not allow '<', got: " + f);
            var h = f.replace(/('|")((?!\1)[^\r\n\f\\]|\\[\s\S])*\1/g, "");
            if (!/^[-_a-zA-Z0-9#.:* ,>+~[\]()=\\^$|]+$/.test(h)) throw Error("Selector allows only [-_a-zA-Z0-9#.:* ,>+~[\\]()=\\^$|] and strings, got: " +
                f);
            a: {
                for (var k = {
                        "(": ")",
                        "[": "]"
                    }, l = [], m = 0; m < h.length; m++) {
                    var n = h[m];
                    if (k[n]) l.push(k[n]);
                    else if (gvjs_Ug(k, n) && l.pop() != n) {
                        h = !1;
                        break a
                    }
                }
                h = 0 == l.length
            }
            if (!h) throw Error("() and [] in selector must be balanced, got: " + f);
            e instanceof gvjs_kh || (e = gvjs_mh(e));
            f = f + "{" + gvjs_lh(e).replace(/</g, "\\3C ") + "}";
            g.call(d, new gvjs_sh(f, gvjs_rh))
        }
    });
    return gvjs_Raa(d)
}

function gvjs_Pm(a) {
    return a.filter(function(b) {
        return b instanceof CSSStyleRule || b.type == CSSRule.STYLE_RULE
    })
}

function gvjs_0ba(a, b, c) {
    a = gvjs_Rm("<style>" + a + "</style>");
    return null == a || null == a.sheet ? gvjs_Saa : gvjs__ba(a.sheet, void 0 != b ? b : null, c)
}

function gvjs_Rm(a) {
    a = gvjs_zh("<html><head></head><body>" + a + "</body></html>");
    return (new DOMParser).parseFromString(gvjs_xh(a), "text/html").body.children[0]
}

function gvjs_Qm(a, b) {
    if (!a) return gvjs_oh;
    var c = document.createElement(gvjs_5b).style;
    gvjs_Sm(a).forEach(function(d) {
        var e = gvjs_If && d in gvjs_Zba ? d : d.replace(/^-(?:apple|css|epub|khtml|moz|mso?|o|rim|wap|webkit|xv)-(?=[a-z])/i, "");
        gvjs_0e(e, "--") || gvjs_0e(e, "var") || (d = gvjs_Nm(a, d), d = gvjs_Hba(e, d, b), null != d && gvjs_Om(c, e, d))
    });
    return new gvjs_kh(c.cssText || "", gvjs_jh)
}

function gvjs_1ba(a) {
    var b = Array.from(gvjs_Hm(gvjs_Lba, a, gvjs_bc, [gvjs_bb])),
        c = gvjs_paa(b, function(g) {
            return gvjs_wf(gvjs_Wba(g).cssRules)
        });
    c = gvjs_Pm(c);
    for (var d = [], e = 0; e < c.length; e++) d[e] = {
        index: e,
        rule: c[e]
    };
    d.sort(function(g, h) {
        var k = gvjs_zm(g.rule.selectorText),
            l = gvjs_zm(h.rule.selectorText);
        a: {
            for (var m = gvjs_Bf, n = Math.min(k.length, l.length), p = 0; p < n; p++) {
                var q = m(k[p], l[p]);
                if (0 != q) {
                    k = q;
                    break a
                }
            }
            k = gvjs_Bf(k.length, l.length)
        }
        return k || g.index - h.index
    });
    for (e = 0; e < d.length; e++) c[e] = d[e].rule;
    c.reverse();
    a = document.createTreeWalker(a, NodeFilter.SHOW_ELEMENT, null, !1);
    for (var f; f = a.nextNode();) c.forEach(function(g) {
        gvjs_Hm(gvjs_Mba, f, f.matches ? "matches" : gvjs_Ed, [g.selectorText]) && g.style && gvjs_2ba(f, g.style)
    });
    b.forEach(gvjs_Ai)
}

function gvjs_2ba(a, b) {
    var c = gvjs_Sm(a.style);
    gvjs_Sm(b).forEach(function(d) {
        if (!(0 <= c.indexOf(d))) {
            var e = gvjs_Nm(b, d);
            gvjs_Om(a.style, d, e)
        }
    })
}

function gvjs_Sm(a) {
    gvjs_Ne(a) ? a = gvjs_wf(a) : (a = gvjs_Tg(a), gvjs_uf(a, "cssText"));
    return a
};
var gvjs_3ba = {
        "* ARIA-CHECKED": !0,
        "* ARIA-COLCOUNT": !0,
        "* ARIA-COLINDEX": !0,
        "* ARIA-CONTROLS": !0,
        "* ARIA-DESCRIBEDBY": !0,
        "* ARIA-DISABLED": !0,
        "* ARIA-EXPANDED": !0,
        "* ARIA-GOOG-EDITABLE": !0,
        "* ARIA-HASPOPUP": !0,
        "* ARIA-HIDDEN": !0,
        "* ARIA-LABEL": !0,
        "* ARIA-LABELLEDBY": !0,
        "* ARIA-MULTILINE": !0,
        "* ARIA-MULTISELECTABLE": !0,
        "* ARIA-ORIENTATION": !0,
        "* ARIA-PLACEHOLDER": !0,
        "* ARIA-READONLY": !0,
        "* ARIA-REQUIRED": !0,
        "* ARIA-ROLEDESCRIPTION": !0,
        "* ARIA-ROWCOUNT": !0,
        "* ARIA-ROWINDEX": !0,
        "* ARIA-SELECTED": !0,
        "* ABBR": !0,
        "* ACCEPT": !0,
        "* ACCESSKEY": !0,
        "* ALIGN": !0,
        "* ALT": !0,
        "* AUTOCOMPLETE": !0,
        "* AXIS": !0,
        "* BGCOLOR": !0,
        "* BORDER": !0,
        "* CELLPADDING": !0,
        "* CELLSPACING": !0,
        "* CHAROFF": !0,
        "* CHAR": !0,
        "* CHECKED": !0,
        "* CLEAR": !0,
        "* COLOR": !0,
        "* COLSPAN": !0,
        "* COLS": !0,
        "* COMPACT": !0,
        "* COORDS": !0,
        "* DATETIME": !0,
        "* DIR": !0,
        "* DISABLED": !0,
        "* ENCTYPE": !0,
        "* FACE": !0,
        "* FRAME": !0,
        "* HEIGHT": !0,
        "* HREFLANG": !0,
        "* HSPACE": !0,
        "* ISMAP": !0,
        "* LABEL": !0,
        "* LANG": !0,
        "* MAX": !0,
        "* MAXLENGTH": !0,
        "* METHOD": !0,
        "* MULTIPLE": !0,
        "* NOHREF": !0,
        "* NOSHADE": !0,
        "* NOWRAP": !0,
        "* OPEN": !0,
        "* READONLY": !0,
        "* REQUIRED": !0,
        "* REL": !0,
        "* REV": !0,
        "* ROLE": !0,
        "* ROWSPAN": !0,
        "* ROWS": !0,
        "* RULES": !0,
        "* SCOPE": !0,
        "* SELECTED": !0,
        "* SHAPE": !0,
        "* SIZE": !0,
        "* SPAN": !0,
        "* START": !0,
        "* SUMMARY": !0,
        "* TABINDEX": !0,
        "* TITLE": !0,
        "* TYPE": !0,
        "* VALIGN": !0,
        "* VALUE": !0,
        "* VSPACE": !0,
        "* WIDTH": !0
    },
    gvjs_4ba = {
        "* USEMAP": !0,
        "* ACTION": !0,
        "* CITE": !0,
        "* HREF": !0,
        "* LONGDESC": !0,
        "* SRC": !0,
        "LINK HREF": !0,
        "* FOR": !0,
        "* HEADERS": !0,
        "* NAME": !0,
        "A TARGET": !0,
        "* CLASS": !0,
        "* ID": !0,
        "* STYLE": !0
    };
var gvjs_5ba = "undefined" != typeof WeakMap && -1 != WeakMap.toString().indexOf("[native code]"),
    gvjs_6ba = 0;

function gvjs_Tm() {
    this.Rb = [];
    this.pd = [];
    this.Hx = "data-elementweakmap-index-" + gvjs_6ba++
}
gvjs_Tm.prototype.set = function(a, b) {
    if (gvjs_Hm(gvjs_Em, a, gvjs_hd, [this.Hx])) {
        var c = parseInt(gvjs_Hm(gvjs_Fm, a, gvjs_ac, [this.Hx]) || null, 10);
        this.pd[c] = b
    } else c = this.pd.push(b) - 1, gvjs_Jm(a, this.Hx, c.toString()), this.Rb.push(a);
    return this
};
gvjs_Tm.prototype.get = function(a) {
    if (gvjs_Hm(gvjs_Em, a, gvjs_hd, [this.Hx])) return a = parseInt(gvjs_Hm(gvjs_Fm, a, gvjs_ac, [this.Hx]) || null, 10), this.pd[a]
};
gvjs_Tm.prototype.clear = function() {
    this.Rb.forEach(function(a) {
        gvjs_Hm(gvjs_Kba, a, gvjs_Ud, [this.Hx])
    }, this);
    this.Rb = [];
    this.pd = []
};
var gvjs_Um = !gvjs_x || gvjs_Tf(10),
    gvjs_7ba = !gvjs_x || null == document.documentMode;

function gvjs_Vm() {}
gvjs_Vm.prototype.oc = function(a) {
    if ("TEMPLATE" == gvjs_Km(a).toUpperCase()) return null;
    var b = gvjs_Km(a).toUpperCase();
    if (b in this.UF || gvjs_Xba(a) != gvjs_ld) b = null;
    else if (this.hA[b]) b = document.createElement(b);
    else {
        var c = gvjs_ti(gvjs_ab);
        this.XV && gvjs_Jm(c, "data-sanitizer-original-tag", b.toLowerCase());
        b = c
    }
    if (!b) return null;
    c = b;
    var d = gvjs_Im(a);
    if (null != d)
        for (var e = 0, f; f = d[e]; e++)
            if (f.specified) {
                var g = a;
                var h = f;
                var k = h.name;
                if (gvjs_0e(k, gvjs_0b)) h = null;
                else {
                    var l = gvjs_Km(g);
                    h = h.value;
                    var m = {
                            tagName: gvjs_2e(l).toLowerCase(),
                            attributeName: gvjs_2e(k).toLowerCase()
                        },
                        n = {
                            qQ: void 0
                        };
                    m.attributeName == gvjs_6d && (n.qQ = gvjs_Vba(g));
                    g = gvjs_Wm(l, k);
                    g in this.CB ? (k = this.CB[g], h = k(h, m, n)) : (k = gvjs_Wm(null, k), k in this.CB ? (k = this.CB[k], h = k(h, m, n)) : h = null)
                }
                null !== h && gvjs_Jm(c, f.name, h)
            }
    return b
};
var gvjs_8ba = {
    APPLET: !0,
    AUDIO: !0,
    BASE: !0,
    BGSOUND: !0,
    EMBED: !0,
    FORM: !0,
    IFRAME: !0,
    ISINDEX: !0,
    KEYGEN: !0,
    LAYER: !0,
    LINK: !0,
    META: !0,
    OBJECT: !0,
    SCRIPT: !0,
    SVG: !0,
    STYLE: !0,
    TEMPLATE: !0,
    VIDEO: !0
};
var gvjs_9ba = {
    A: !0,
    ABBR: !0,
    ACRONYM: !0,
    ADDRESS: !0,
    AREA: !0,
    ARTICLE: !0,
    ASIDE: !0,
    B: !0,
    BDI: !0,
    BDO: !0,
    BIG: !0,
    BLOCKQUOTE: !0,
    BR: !0,
    BUTTON: !0,
    CAPTION: !0,
    CENTER: !0,
    CITE: !0,
    CODE: !0,
    COL: !0,
    COLGROUP: !0,
    DATA: !0,
    DATALIST: !0,
    DD: !0,
    DEL: !0,
    DETAILS: !0,
    DFN: !0,
    DIALOG: !0,
    DIR: !0,
    DIV: !0,
    DL: !0,
    DT: !0,
    EM: !0,
    FIELDSET: !0,
    FIGCAPTION: !0,
    FIGURE: !0,
    FONT: !0,
    FOOTER: !0,
    FORM: !0,
    H1: !0,
    H2: !0,
    H3: !0,
    H4: !0,
    H5: !0,
    H6: !0,
    HEADER: !0,
    HGROUP: !0,
    HR: !0,
    I: !0,
    IMG: !0,
    INPUT: !0,
    INS: !0,
    KBD: !0,
    LABEL: !0,
    LEGEND: !0,
    LI: !0,
    MAIN: !0,
    MAP: !0,
    MARK: !0,
    MENU: !0,
    METER: !0,
    NAV: !0,
    NOSCRIPT: !0,
    OL: !0,
    OPTGROUP: !0,
    OPTION: !0,
    OUTPUT: !0,
    P: !0,
    PRE: !0,
    PROGRESS: !0,
    Q: !0,
    S: !0,
    SAMP: !0,
    SECTION: !0,
    SELECT: !0,
    SMALL: !0,
    SOURCE: !0,
    SPAN: !0,
    STRIKE: !0,
    STRONG: !0,
    STYLE: !0,
    SUB: !0,
    SUMMARY: !0,
    SUP: !0,
    TABLE: !0,
    TBODY: !0,
    TD: !0,
    TEXTAREA: !0,
    TFOOT: !0,
    TH: !0,
    THEAD: !0,
    TIME: !0,
    TR: !0,
    TT: !0,
    U: !0,
    UL: !0,
    VAR: !0,
    WBR: !0
};
var gvjs_$ba = {
    "ANNOTATION-XML": !0,
    "COLOR-PROFILE": !0,
    "FONT-FACE": !0,
    "FONT-FACE-SRC": !0,
    "FONT-FACE-URI": !0,
    "FONT-FACE-FORMAT": !0,
    "FONT-FACE-NAME": !0,
    "MISSING-GLYPH": !0
};

function gvjs_Xm(a) {
    a = a || new gvjs_Ym;
    gvjs_aca(a);
    this.CB = gvjs_z(a.Mk);
    this.UF = gvjs_z(a.UF);
    this.hA = gvjs_z(a.hA);
    this.XV = a.XV;
    a.D1.forEach(function(b) {
        if (!gvjs_0e(b, gvjs__b)) throw new gvjs_Ze('Only "data-" attributes allowed, got: %s.', [b]);
        if (gvjs_0e(b, gvjs_0b)) throw new gvjs_Ze('Attributes with "%s" prefix are not allowed, got: %s.', [gvjs_0b, b]);
        this.CB["* " + b.toUpperCase()] = gvjs_Zm
    }, this);
    a.z1.forEach(function(b) {
        b = b.toUpperCase();
        if (!gvjs_4e(b, "-") || gvjs_$ba[b]) throw new gvjs_Ze("Only valid custom element tag names allowed, got: %s.", [b]);
        this.hA[b] = !0
    }, this);
    this.IE = a.IE;
    this.OF = a.OF;
    this.uI = null;
    this.CS = a.CS
}
gvjs_u(gvjs_Xm, gvjs_Vm);

function gvjs__m(a) {
    return function(b, c) {
        b = gvjs_2e(b);
        return (c = a(b, c)) && gvjs_dh(c) != gvjs_wb ? gvjs_dh(c) : null
    }
}

function gvjs_Ym() {
    this.Mk = {};
    gvjs_v([gvjs_3ba, gvjs_4ba], function(a) {
        gvjs_Tg(a).forEach(function(b) {
            this.Mk[b] = gvjs_Zm
        }, this)
    }, this);
    this.ko = {};
    this.D1 = [];
    this.z1 = [];
    this.UF = gvjs_z(gvjs_8ba);
    this.hA = gvjs_z(gvjs_9ba);
    this.XV = !1;
    this.M9 = gvjs_gh;
    this.b8 = this.LW = this.w6 = this.IE = gvjs_Ng;
    this.OF = null;
    this.r7 = this.CS = !1
}

function gvjs_bca() {
    var a = new gvjs_Ym;
    a.b8 = gvjs_cca;
    gvjs_xf(a.D1, ["data-safe-link"]);
    return a
}

function gvjs_dca(a, b) {
    return function(c, d, e, f) {
        c = a(c, d, e, f);
        return null == c ? null : b(c, d, e, f)
    }
}

function gvjs_0m(a, b, c, d) {
    a[c] && !b[c] && (a[c] = gvjs_dca(a[c], d))
}
gvjs_Ym.prototype.Sd = function() {
    return new gvjs_Xm(this)
};

function gvjs_aca(a) {
    if (a.r7) throw Error("HtmlSanitizer.Builder.build() can only be used once.");
    gvjs_0m(a.Mk, a.ko, "* USEMAP", gvjs_eca);
    var b = gvjs__m(a.M9);
    ["* ACTION", "* CITE", "* HREF"].forEach(function(d) {
        gvjs_0m(this.Mk, this.ko, d, b)
    }, a);
    var c = gvjs__m(a.IE);
    ["* LONGDESC", "* SRC", "LINK HREF"].forEach(function(d) {
        gvjs_0m(this.Mk, this.ko, d, c)
    }, a);
    ["* FOR", "* HEADERS", "* NAME"].forEach(function(d) {
        gvjs_0m(this.Mk, this.ko, d, gvjs_Te(gvjs_fca, this.w6))
    }, a);
    gvjs_0m(a.Mk, a.ko, "A TARGET", gvjs_Te(gvjs_gca, ["_blank", "_self"]));
    gvjs_0m(a.Mk, a.ko, "* CLASS", gvjs_Te(gvjs_hca, a.LW));
    gvjs_0m(a.Mk, a.ko, "* ID", gvjs_Te(gvjs_ica, a.LW));
    gvjs_0m(a.Mk, a.ko, "* STYLE", gvjs_Te(a.b8, c));
    a.r7 = !0
}

function gvjs_Wm(a, b) {
    a || (a = "*");
    return (a + " " + b).toUpperCase()
}

function gvjs_cca(a, b, c, d) {
    if (!d.qQ) return null;
    b = gvjs_lh(gvjs_Qm(d.qQ, function(e, f) {
        c.Aca = f;
        e = a(e, c);
        return null == e ? null : gvjs_fh(e)
    }));
    return "" == b ? null : b
}

function gvjs_Zm(a) {
    return gvjs_2e(a)
}

function gvjs_gca(a, b) {
    b = gvjs_2e(b);
    return gvjs_tf(a, b.toLowerCase()) ? b : null
}

function gvjs_eca(a) {
    return (a = gvjs_2e(a)) && "#" == a.charAt(0) ? a : null
}

function gvjs_fca(a, b, c) {
    b = gvjs_2e(b);
    return a(b, c)
}

function gvjs_hca(a, b, c) {
    b = b.split(/(?:\s+)/);
    for (var d = [], e = 0; e < b.length; e++) {
        var f = a(b[e], c);
        f && d.push(f)
    }
    return 0 == d.length ? null : d.join(" ")
}

function gvjs_ica(a, b, c) {
    b = gvjs_2e(b);
    return a(b, c)
}
gvjs_Xm.prototype.sanitize = function(a) {
    var b = !(gvjs_bb in this.UF) && gvjs_bb in this.hA;
    this.uI = "*" == this.OF && b ? "sanitizer-" + gvjs_Mh() : this.OF;
    if (gvjs_Um) {
        b = a;
        if (gvjs_Um) {
            a = gvjs_ti(gvjs_ab);
            this.uI && "*" == this.OF && (a.id = this.uI);
            this.CS && (b = gvjs_Rm("<div>" + b + gvjs_a), gvjs_1ba(b), b = b.innerHTML);
            b = gvjs_zh(b);
            var c = document.createElement("template");
            if (gvjs_7ba && "content" in c) gvjs_Hh(c, b), c = c.content;
            else {
                var d = document.implementation.createHTMLDocument("x");
                c = d.body;
                gvjs_Hh(d.body, b)
            }
            b = document.createTreeWalker(c,
                NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, null, !1);
            c = gvjs_5ba ? new WeakMap : new gvjs_Tm;
            for (var e; e = b.nextNode();) {
                c: switch (d = e, gvjs_Lm(d)) {
                    case 3:
                        d = this.createTextNode(d);
                        break c;
                    case 1:
                        d = this.oc(d);
                        break c;
                    default:
                        d = null
                }
                if (d) {
                    1 == gvjs_Lm(d) && c.set(e, d);
                    e = gvjs_Mm(e);
                    var f = !1;
                    if (e) {
                        var g = gvjs_Lm(e),
                            h = gvjs_Km(e).toLowerCase(),
                            k = gvjs_Mm(e);
                        11 != g || k ? h == gvjs_Kb && k && (g = gvjs_Mm(k)) && !gvjs_Mm(g) && (f = !0) : f = !0;
                        g = null;
                        f || !e ? g = a : 1 == gvjs_Lm(e) && (g = c.get(e));
                        g.content && (g = g.content);
                        g.appendChild(d)
                    }
                } else gvjs_xi(e)
            }
            c.clear &&
                c.clear()
        } else a = gvjs_ti(gvjs_ab);
        0 < gvjs_Im(a).length && (b = gvjs_ti(gvjs_ab), b.appendChild(a), a = b);
        a = (new XMLSerializer).serializeToString(a);
        a = a.slice(a.indexOf(">") + 1, a.lastIndexOf("</"))
    } else a = "";
    return gvjs_zh(a)
};
gvjs_Xm.prototype.createTextNode = function(a) {
    var b = a.data;
    (a = gvjs_Mm(a)) && gvjs_Km(a).toLowerCase() == gvjs_6d && !(gvjs_bb in this.UF) && gvjs_bb in this.hA && (b = gvjs_th(gvjs_0ba(b, this.uI, gvjs_Se(function(c, d) {
        return this.IE(c, {
            Aca: d
        })
    }, this))));
    return document.createTextNode(b)
};

function gvjs_1m(a, b) {
    if (void 0 !== a.tagName) {
        if ("script" === a.tagName.toLowerCase()) throw Error("");
        if (a.tagName.toLowerCase() === gvjs_6d) throw Error("");
    }
    a.innerHTML = gvjs_xh(b)
};

function gvjs_jca(a) {
    var b = document.createElement("template");
    if (!("content" in b)) {
        b = gvjs_zh("<html><body>" + a);
        b = (new DOMParser).parseFromString(gvjs_xh(b), "text/html");
        for (a = b.createDocumentFragment(); 0 < b.body.childNodes.length;) a.appendChild(b.body.firstChild);
        return a
    }
    a = gvjs_zh(a);
    gvjs_1m(b, a);
    return b.content
};

function gvjs_2m(a) {
    a = a.nodeName;
    return typeof a === gvjs_m ? a : "FORM"
}

function gvjs_3m(a) {
    a = a.nodeType;
    return a === Node.ELEMENT_NODE || typeof a !== gvjs_f
};

function gvjs_kca(a, b, c) {
    c = a.m2.get(c);
    return (null == c ? 0 : c.has(b)) ? c.get(b) : a.Zaa.has(b) ? {
        Rg: 1
    } : (c = a.yea.get(b)) ? c : a.y3 && [].concat(gvjs_we(a.y3)).some(function(d) {
        return 0 === b.indexOf(d)
    }) ? {
        Rg: 1
    } : {
        Rg: 0
    }
};

function gvjs_4m(a) {
    return {
        valueOf: a
    }.valueOf()
};
var gvjs_lca = ["ARTICLE", "SECTION", "NAV", "ASIDE", "H1", "H2", "H3", "H4", "H5", "H6", "HEADER", "FOOTER", "ADDRESS", "P", "HR", "PRE", "BLOCKQUOTE", "OL", "UL", "LH", "LI", "DL", "DT", "DD", "FIGURE", "FIGCAPTION", "MAIN", gvjs_b, "EM", "STRONG", "SMALL", "S", "CITE", "Q", "DFN", "ABBR", "RUBY", "RB", "RT", "RTC", "RP", "DATA", "TIME", "CODE", "VAR", "SAMP", "KBD", "SUB", "SUP", "I", "B", "U", "MARK", "BDI", "BDO", gvjs_ab, "BR", "WBR", "INS", "DEL", "PICTURE", "PARAM", "TRACK", "MAP", gvjs_jb, "CAPTION", "COLGROUP", "COL", gvjs_kb, "THEAD", "TFOOT", "TR", gvjs_lb,
        "TH", gvjs_9a, "DATALIST", "OPTGROUP", "OPTION", "OUTPUT", "PROGRESS", "METER", "FIELDSET", "LEGEND", "DETAILS", "SUMMARY", "MENU", "DIALOG", "SLOT", "CANVAS", "FONT", "CENTER"
    ],
    gvjs_mca = [
        ["A", new Map([
            ["href", {
                Rg: 2
            }]
        ])],
        ["AREA", new Map([
            ["href", {
                Rg: 2
            }]
        ])],
        ["LINK", new Map([
            ["href", {
                Rg: 2,
                conditions: new Map([
                    ["rel", new Set("alternate author bookmark canonical cite help icon license next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" "))]
                ])
            }]
        ])],
        [gvjs_$a, new Map([
            ["src", {
                Rg: 1
            }]
        ])],
        ["IMG", new Map([
            ["src", {
                Rg: 1
            }]
        ])],
        ["VIDEO", new Map([
            ["src", {
                Rg: 1
            }]
        ])],
        ["AUDIO", new Map([
            ["src", {
                Rg: 1
            }]
        ])]
    ],
    gvjs_nca = [gvjs_ce, "aria-atomic", "aria-autocomplete", "aria-busy", "aria-checked", "aria-current", "aria-disabled", "aria-dropeffect", "aria-expanded", "aria-haspopup", gvjs_Bb, "aria-invalid", gvjs_Cb, "aria-level", "aria-live", "aria-multiline", "aria-multiselectable", "aria-orientation", "aria-posinset", "aria-pressed", "aria-readonly", "aria-relevant", "aria-required", "aria-selected", "aria-setsize", "aria-sort",
        "aria-valuemax", "aria-valuemin", "aria-valuenow", "aria-valuetext", "alt", "align", "autocapitalize", "autocomplete", "autocorrect", "autofocus", "autoplay", "bgcolor", gvjs_Mb, "cellpadding", "cellspacing", gvjs_Pb, gvjs_Sb, "cols", gvjs_Ub, gvjs_Yb, gvjs_2b, gvjs_4b, "download", "draggable", "enctype", "face", "formenctype", "frameborder", gvjs_jd, "hreflang", gvjs_kd, "ismap", gvjs_qd, "lang", "loop", gvjs_wd, "maxlength", "media", "minlength", gvjs_zd, gvjs_Fd, "muted", gvjs_Jd, "open", gvjs_Od, "preload", "rel", "required", "reversed", gvjs_Vd,
        gvjs_Xd, gvjs_Yd, gvjs__d, "shape", "size", "sizes", "slot", gvjs_2d, "spellcheck", gvjs_l, gvjs_4d, "summary", "translate", gvjs_ge, gvjs_je, gvjs_o, gvjs_le, "wrap", "itemscope", "itemtype", "itemid", "itemprop", "itemref"
    ],
    gvjs_oca = [
        ["dir", {
            Rg: 3,
            conditions: gvjs_4m(function() {
                return new Map([
                    ["dir", new Set([gvjs_Gb, gvjs_td, gvjs_Zd])]
                ])
            })
        }],
        [gvjs_Eb, {
            Rg: 3,
            conditions: gvjs_4m(function() {
                return new Map([
                    [gvjs_Eb, new Set([gvjs_Eb])]
                ])
            })
        }],
        ["cite", {
            Rg: 2
        }],
        ["loading", {
            Rg: 3,
            conditions: gvjs_4m(function() {
                return new Map([
                    ["loading",
                        new Set(["eager", "lazy"])
                    ]
                ])
            })
        }],
        ["poster", {
            Rg: 2
        }],
        [gvjs_9d, {
            Rg: 3,
            conditions: gvjs_4m(function() {
                return new Map([
                    [gvjs_9d, new Set(["_self", "_blank"])]
                ])
            })
        }]
    ],
    gvjs_pca = new function() {
        var a = new Set(gvjs_nca),
            b = new Map(gvjs_oca),
            c = new Map(gvjs_mca);
        this.Yaa = new Set(gvjs_lca);
        this.m2 = c;
        this.Zaa = a;
        this.yea = b;
        this.y3 = void 0
    };
var gvjs_qca = gvjs_4m(function() {
        try {
            return new URL("s://g"), !0
        } catch (a) {
            return !1
        }
    }),
    gvjs_rca = ["data:", "http:", gvjs_md, "mailto:", "ftp:"];

function gvjs_5m() {
    this.c8 = gvjs_pca;
    this.VH = []
}
gvjs_5m.prototype.sanitize = function(a) {
    var b = document.createElement(gvjs_2d);
    b.appendChild(gvjs_sca(this, a));
    a = (new XMLSerializer).serializeToString(b);
    a = a.slice(a.indexOf(">") + 1, a.lastIndexOf("</"));
    return gvjs_zh(a)
};

function gvjs_sca(a, b) {
    b = gvjs_jca(b);
    b = document.createTreeWalker(b, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, function(g) {
        return gvjs_tca(a, g)
    }, !1);
    for (var c = b.nextNode(), d = document.createDocumentFragment(), e = d; null !== c;) {
        var f = void 0;
        if (c.nodeType === Node.TEXT_NODE) f = document.createTextNode(c.data);
        else if (gvjs_3m(c)) f = gvjs_uca(a, c);
        else throw Error("");
        e.appendChild(f);
        if (c = b.firstChild()) e = f;
        else
            for (; !(c = b.nextSibling()) && (c = b.parentNode());) e = e.parentNode
    }
    return d
}

function gvjs_uca(a, b) {
    var c = gvjs_2m(b),
        d = document.createElement(c);
    b = b.attributes;
    for (var e = gvjs_q(b), f = e.next(); !f.done; f = e.next()) {
        var g = f.value;
        f = g.name;
        g = g.value;
        var h = gvjs_kca(a.c8, f, c),
            k;
        a: {
            if (k = h.conditions) {
                k = gvjs_q(k);
                for (var l = k.next(); !l.done; l = k.next()) {
                    var m = gvjs_q(l.value);
                    l = m.next().value;
                    m = m.next().value;
                    var n = void 0;
                    if ((l = null == (n = b.getNamedItem(l)) ? void 0 : n.value) && !m.has(l)) {
                        k = !1;
                        break a
                    }
                }
            }
            k = !0
        }
        if (k) switch (h.Rg) {
            case 1:
                d.setAttribute(f, g);
                break;
            case 2:
                a: if (h = void 0, gvjs_qca) {
                    try {
                        h =
                            new URL(g)
                    } catch (p) {
                        h = gvjs_md;
                        break a
                    }
                    h = h.protocol
                } else b: {
                    h = document.createElement("a");
                    try {
                        h.href = g
                    } catch (p) {
                        h = void 0;
                        break b
                    }
                    h = h.protocol;h = ":" === h || "" === h ? gvjs_md : h
                }
                h = void 0 !== h && -1 !== gvjs_rca.indexOf(h.toLowerCase()) ? g : gvjs_wb;
                h !== g && gvjs_6m(a);
                d.setAttribute(f, h);
                break;
            case 3:
                d.setAttribute(f, g.toLowerCase());
                break;
            case 4:
                d.setAttribute(f, g);
                break;
            case 0:
                gvjs_6m(a)
        } else gvjs_6m(a)
    }
    return d
}

function gvjs_tca(a, b) {
    if (b.nodeType === Node.TEXT_NODE) return NodeFilter.FILTER_ACCEPT;
    if (!gvjs_3m(b)) return NodeFilter.FILTER_REJECT;
    b = gvjs_2m(b);
    if (null === b) return gvjs_6m(a), NodeFilter.FILTER_REJECT;
    var c = a.c8;
    if ("form" !== b.toLowerCase() && (c.Yaa.has(b) || c.m2.has(b))) return NodeFilter.FILTER_ACCEPT;
    gvjs_6m(a);
    return NodeFilter.FILTER_REJECT
}

function gvjs_6m(a) {
    0 === a.VH.length && a.VH.push("")
}
var gvjs_7m = gvjs_4m(function() {
    return new gvjs_5m
});

function gvjs_vca(a) {
    var b = {
        nonce: gvjs_Ih()
    };
    b = void 0 === b ? {} : b;
    a = gvjs_5g(a).toString();
    var c = "<script";
    b.id && (c += gvjs_ba + gvjs_8m(b.id) + '"');
    b.nonce && (c += gvjs_da + gvjs_8m(b.nonce) + '"');
    b.type && (c += ' type="' + gvjs_8m(b.type) + '"');
    return gvjs_zh(c + (">" + a + "\x3c/script>"))
}

function gvjs_8m(a) {
    return a.replace(/&/g, "&amp;").replace(/</g, gvjs_ha).replace(/>/g, "&gt;").replace(/"/g, gvjs_ia).replace(/'/g, "&apos;")
};
var gvjs_9m = gvjs_Ke("goog.visualization.isSafeMode") || !1,
    gvjs_$m = function() {
        var a = gvjs_bca(),
            b = ["icon"];
        a.z1.push("iron-icon");
        b && b.forEach(function(c) {
            c = gvjs_Wm("iron-icon", c);
            this.Mk[c] = gvjs_Zm;
            this.ko[c] = !0
        }, a);
        return a
    }();
gvjs_$m.w6 = function(a) {
    return a
};
gvjs_$m.LW = function(a) {
    return a
};
gvjs_$m.IE = function(a, b) {
    return "img" == b.tagName && "src" == b.attributeName && a.startsWith("data:") ? gvjs_eh(a) || gvjs_hh : gvjs_gh(a)
};
gvjs_$m.M9 = gvjs_gh;
var gvjs_wca = gvjs_$m.Sd();

function gvjs_an(a) {
    var b = a;
    gvjs_9m && (b = gvjs_Cba(a));
    return b
};

function gvjs_bn(a) {
    this.nK = !1;
    this.Xd = a || null
}
gvjs_bn.prototype.d$ = function(a, b) {
    var c = this;
    return function() {
        var d = gvjs_Ce.apply(0, arguments);
        if (!c.nK) return c.Xd ? gvjs_cm(c.Xd, function() {
            return a.apply(b, d)
        }) : a.apply(b, d)
    }
};

function gvjs_cn(a) {
    gvjs_L.call(this);
    this.Gq = null;
    this.container = gvjs_hk(a);
    this.Xd = new gvjs_$l(this, this.container);
    this.wh = gvjs_ol()
}
gvjs_r(gvjs_cn, gvjs_L);
gvjs_ = gvjs_cn.prototype;
gvjs_.getContainer = function() {
    return this.container
};
gvjs_.pb = gvjs_p(15);
gvjs_.getHeight = function(a, b) {
    return a.Dy(gvjs_jd) || gvjs_ok(this.container).height || b || 200
};
gvjs_.draw = function(a, b, c) {
    var d = this;
    gvjs_cm(this.Xd, function() {
        gvjs_7j(a);
        if (null == a) throw Error("Undefined or null data");
        d.wh && d.wh.promise.cancel();
        d.wh = gvjs_ol();
        d.Gq && (d.Gq.nK = !0);
        d.Gq = new gvjs_bn(d.Xd);
        var e = d.Gq.d$.bind(d.Gq);
        d.Nc(e, a, b, c)
    })
};
gvjs_.getImageURI = function() {
    return ""
};
gvjs_.clearChart = function() {
    this.Gq && (this.Gq.nK = !0, this.Gq = null);
    this.wh && this.wh.promise && (this.wh.promise.cancel(), this.wh = null);
    this.Wc()
};
gvjs_.Wc = function() {};
gvjs_.J = function() {
    this.clearChart();
    gvjs_L.prototype.J.call(this)
};
gvjs_cn.prototype.clearChart = gvjs_cn.prototype.clearChart;

function gvjs_dn() {
    this.Xf = new Map;
    this.cp = new Map;
    this.Iq = new Map
}

function gvjs_en(a, b, c) {
    gvjs_fn(a, b, c) || (a.Xf.set(gvjs_gn(b), b), a.Xf.set(gvjs_gn(c), c), gvjs_hn(b, c, a.cp), gvjs_hn(c, b, a.Iq))
}
gvjs_ = gvjs_dn.prototype;
gvjs_.clear = function() {
    this.Xf.clear();
    this.cp.clear();
    this.Iq.clear()
};
gvjs_.isEmpty = function() {
    return 0 === this.Xf.size
};
gvjs_.De = gvjs_p(27);
gvjs_.Wb = function() {
    return Array.from(this.Xf.values())
};
gvjs_.contains = function(a) {
    return this.Xf.has(gvjs_gn(a))
};

function gvjs_fn(a, b, c) {
    b = gvjs_gn(b);
    return a.cp.has(b) && a.cp.get(b).has(gvjs_gn(c))
}

function gvjs_in(a, b) {
    if (!a.contains(b)) return null;
    var c = a.Iq.get(gvjs_gn(b));
    if (!c) return null;
    b = [];
    c = gvjs_q(c);
    for (var d = c.next(); !d.done; d = c.next()) b.push(a.Xf.get(d.value));
    return b
}
gvjs_.getChildren = function(a) {
    if (!this.contains(a)) return null;
    var b = this.cp.get(gvjs_gn(a));
    if (!b) return null;
    a = [];
    b = gvjs_q(b);
    for (var c = b.next(); !c.done; c = b.next()) a.push(this.Xf.get(c.value));
    return a
};

function gvjs_jn(a) {
    if (a.isEmpty()) return [];
    for (var b = [], c = gvjs_q(a.cp.keys()), d = c.next(); !d.done; d = c.next()) d = d.value, a.Iq.has(d) || b.push(a.Xf.get(d));
    if (0 == b.length) throw Error("Invalid state: DAG has not root node(s).");
    return b
}

function gvjs_xca(a) {
    for (var b = gvjs_yca(a.Iq), c = [], d = gvjs_w(gvjs_jn(a), function(l) {
            return gvjs_gn(l)
        }, a); 0 < d.length;) {
        for (var e = [], f = 0; f < d.length; f++) {
            var g = d[f];
            c.push(a.Xf.get(g));
            var h = a.cp.get(g);
            if (h) {
                h = gvjs_q(h);
                for (var k = h.next(); !k.done; k = h.next()) k = k.value, b.get(k).delete(g), 0 === b.get(k).size && (b.delete(k), e.push(k))
            }
        }
        d = e
    }
    if (c.length != a.Xf.size) throw Error("cycle detected");
}
gvjs_.clone = function() {
    return this.isEmpty() ? new gvjs_dn : gvjs_dn.prototype.gJ.apply(this, gvjs_jn(this))
};
gvjs_.gJ = function(a) {
    var b = new gvjs_dn;
    if (0 == arguments.length) return b;
    for (var c = 0; c < arguments.length; c++) gvjs_kn(this, arguments[c], b);
    return b
};

function gvjs_kn(a, b, c) {
    var d = a.getChildren(b);
    if (d) {
        d = gvjs_q(d);
        for (var e = d.next(); !e.done; e = d.next()) e = e.value, gvjs_en(c, b, e), gvjs_kn(a, e, c)
    }
}

function gvjs_gn(a) {
    var b = typeof a;
    return b == gvjs_g && a || b == gvjs_c ? "o" + gvjs_Qe(a) : b.substr(0, 1) + a
}

function gvjs_hn(a, b, c) {
    var d = c.get(gvjs_gn(a));
    d || (d = new Set, c.set(gvjs_gn(a), d));
    d.add(gvjs_gn(b))
}

function gvjs_ln(a, b, c) {
    var d = c.get(gvjs_gn(a));
    d.delete(gvjs_gn(b));
    0 === d.size && c.delete(gvjs_gn(a))
}

function gvjs_mn(a, b) {
    return !a.cp.has(gvjs_gn(b)) && !a.Iq.has(gvjs_gn(b))
}

function gvjs_yca(a) {
    var b = new Map;
    a = gvjs_q(a.entries());
    for (var c = a.next(); !c.done; c = a.next()) {
        var d = gvjs_q(c.value);
        c = d.next().value;
        d = d.next().value;
        b.set(c, new Set(d))
    }
    return b
};

function gvjs_nn() {
    var a = gvjs_Ke("google.visualization.ModulePath");
    if (null != a) return a;
    a = gvjs_Ke("google.loader.GoogleApisBase");
    null == a && (a = "//ajax.googleapis.com/ajax");
    var b = gvjs_Ke(gvjs_ed);
    null == b && (b = "current");
    return "" + a + "/static/modules/gviz/" + b
}

function gvjs_on() {
    return gvjs_Ke("google.visualization.Locale") || "en"
};

function gvjs_pn(a) {
    var b = gvjs_an(a);
    a = gvjs_fk().Yi();
    b = gvjs_q([gvjs_hc + b, gvjs_dc + b, b]);
    for (var c = b.next(); !c.done; c = b.next())
        if (c = gvjs_Ke(c.value, a), typeof c === gvjs_c) return c;
    return null
}
var gvjs_qn = [];

function gvjs_zca(a, b) {
    function c() {
        d()
    }

    function d() {
        f("visualization", a, b)
    }
    b = null == b ? {} : gvjs_z(b);
    var e = gvjs_on();
    e && !b.language && (b.language = e);
    b.debug = b.debug || gvjs_Ke("google.visualization.isDebug");
    b.pseudo = b.pseudo || gvjs_Ke("google.visualization.isPseudo");
    var f = gvjs_Ke("google.charts.load") || gvjs_Ke("google.load");
    if (!f) throw Error("No loader available.");
    var g = b.callback || function() {};
    b.callback = function() {
        g();
        if (0 < gvjs_qn.length) {
            var h = gvjs_qn.shift();
            h && h()
        }
    };
    0 === gvjs_qn.length ? d() : gvjs_qn.push(c)
};
var gvjs_rn = {
    Bar: gvjs_Ib,
    Line: gvjs_d,
    Scatter: gvjs_j,
    AnnotatedTimeLine: gvjs_zb,
    AnnotationChart: gvjs_Ab,
    AreaChart: gvjs_Zb,
    BarChart: gvjs_Zb,
    BubbleChart: gvjs_Zb,
    Calendar: "calendar",
    CandlestickChart: gvjs_Zb,
    ClusterChart: "clusterchart",
    ColumnChart: gvjs_Zb,
    ComboChart: gvjs_Zb,
    Gantt: "gantt",
    Gauge: "gauge",
    GeoChart: gvjs_$b,
    GeoMap: "geomap",
    Histogram: gvjs_Zb,
    ImageAreaChart: gvjs_od,
    ImageBarChart: gvjs_od,
    ImageCandlestickChart: gvjs_od,
    ImageChart: gvjs_od,
    ImageLineChart: gvjs_od,
    ImagePieChart: gvjs_od,
    ImageSparkLine: gvjs_od,
    LineChart: gvjs_Zb,
    Map: "map",
    MotionChart: gvjs_Bd,
    OrgChart: gvjs_Ld,
    PieChart: gvjs_Zb,
    RangeSelector: gvjs_Zb,
    Sankey: "sankey",
    ScatterChart: gvjs_Zb,
    SparklineChart: gvjs_Zb,
    SteppedAreaChart: gvjs_Zb,
    Table: gvjs_8d,
    Timeline: gvjs_ae,
    TreeMap: "treemap",
    VegaChart: "vegachart",
    WordTree: gvjs_ne,
    StringFilter: gvjs_Yb,
    DateRangeFilter: gvjs_Yb,
    NumberRangeFilter: gvjs_Yb,
    CategoryFilter: gvjs_Yb,
    ChartRangeFilter: gvjs_Yb,
    NumberRangeSetter: gvjs_Yb,
    ColumnSelector: gvjs_Yb,
    Dashboard: gvjs_Yb
};

function gvjs_sn(a, b) {
    var c = a.useFormatFromData;
    (typeof c !== gvjs_Lb || c) && gvjs_1e(gvjs_Lh(a.format)) && (b = gvjs_pf(b, function(d) {
        return !gvjs_1e(gvjs_Lh(d))
    }), gvjs_zf(b), 1 === b.length && (b = gvjs_Aca(b[0]), a.format = b))
}

function gvjs_Aca(a) {
    gvjs_1e(gvjs_Lh(a)) || (a = a.replace(/\d/g, "0"), a = a.replace(/#{10,}/, gvjs_Jh("#", 10)));
    return a
};

function gvjs_tn(a) {
    gvjs_ng.call(this, a)
}
gvjs_r(gvjs_tn, gvjs_ng);
var gvjs_Bca = function(a) {
    return function(b) {
        b = JSON.parse(b);
        if (!Array.isArray(b)) throw Error("Expected jspb data to be an array, got " + gvjs_Me(b) + ": " + b);
        gvjs_1f(b, 18);
        return new a(b)
    }
}(gvjs_tn);
var gvjs_un;

function gvjs_vn(a) {
    if (a.Wb && typeof a.Wb == gvjs_c) return a.Wb();
    if ("undefined" !== typeof Map && a instanceof Map || "undefined" !== typeof Set && a instanceof Set) return Array.from(a.values());
    if (typeof a === gvjs_m) return a.split("");
    if (gvjs_Ne(a)) {
        for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
        return b
    }
    return gvjs_Sg(a)
}

function gvjs_wn(a) {
    if (a.Km && typeof a.Km == gvjs_c) return a.Km();
    if (!a.Wb || typeof a.Wb != gvjs_c) {
        if ("undefined" !== typeof Map && a instanceof Map) return Array.from(a.keys());
        if (!("undefined" !== typeof Set && a instanceof Set)) {
            if (gvjs_Ne(a) || typeof a === gvjs_m) {
                var b = [];
                a = a.length;
                for (var c = 0; c < a; c++) b.push(c);
                return b
            }
            return gvjs_Tg(a)
        }
    }
}

function gvjs_Cca(a, b, c) {
    if (a.forEach && typeof a.forEach == gvjs_c) a.forEach(b, c);
    else if (gvjs_Ne(a) || typeof a === gvjs_m) Array.prototype.forEach.call(a, b, c);
    else
        for (var d = gvjs_wn(a), e = gvjs_vn(a), f = e.length, g = 0; g < f; g++) b.call(c, e[g], d && d[g], a)
};
var gvjs_xn = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

function gvjs_yn(a) {
    return a ? decodeURI(a) : a
}

function gvjs_zn(a, b) {
    return b.match(gvjs_xn)[a] || null
}

function gvjs_An(a) {
    a = gvjs_zn(1, a);
    !a && gvjs_s.self && gvjs_s.self.location && (a = gvjs_s.self.location.protocol.slice(0, -1));
    return a ? a.toLowerCase() : ""
}

function gvjs_Dca(a, b) {
    if (a) {
        a = a.split("&");
        for (var c = 0; c < a.length; c++) {
            var d = a[c].indexOf("="),
                e = null;
            if (0 <= d) {
                var f = a[c].substring(0, d);
                e = a[c].substring(d + 1)
            } else f = a[c];
            b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
        }
    }
}

function gvjs_Bn(a, b, c, d) {
    for (var e = c.length; 0 <= (b = a.indexOf(c, b)) && b < d;) {
        var f = a.charCodeAt(b - 1);
        if (38 == f || 63 == f)
            if (f = a.charCodeAt(b + e), !f || 61 == f || 38 == f || 35 == f) return b;
        b += e + 1
    }
    return -1
}
var gvjs_Cn = /#|$/;

function gvjs_Dn(a, b) {
    var c = a.search(gvjs_Cn),
        d = gvjs_Bn(a, 0, b, c);
    if (0 > d) return null;
    var e = a.indexOf("&", d);
    if (0 > e || e > c) e = c;
    d += b.length + 1;
    return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
};

function gvjs_En(a) {
    this.fr = this.nw = this.yl = "";
    this.ns = null;
    this.fu = this.uL = "";
    this.ak = this.Fha = !1;
    if (a instanceof gvjs_En) {
        this.ak = a.ak;
        gvjs_Fn(this, a.yl);
        var b = a.nw;
        gvjs_Gn(this);
        this.nw = b;
        gvjs_Hn(this, a.fr);
        gvjs_In(this, a.ns);
        this.setPath(a.getPath());
        gvjs_Jn(this, a.ue.clone());
        a = a.fu;
        gvjs_Gn(this);
        this.fu = a
    } else a && (b = String(a).match(gvjs_xn)) ? (this.ak = !1, gvjs_Fn(this, b[1] || "", !0), a = b[2] || "", gvjs_Gn(this), this.nw = gvjs_Kn(a), gvjs_Hn(this, b[3] || "", !0), gvjs_In(this, b[4]), this.setPath(b[5] || "", !0),
        gvjs_Jn(this, b[6] || "", !0), a = b[7] || "", gvjs_Gn(this), this.fu = gvjs_Kn(a)) : (this.ak = !1, this.ue = new gvjs_Ln(null, this.ak))
}
gvjs_ = gvjs_En.prototype;
gvjs_.toString = function() {
    var a = [],
        b = this.yl;
    b && a.push(gvjs_Mn(b, gvjs_Nn, !0), ":");
    var c = this.fr;
    if (c || "file" == b) a.push("//"), (b = this.nw) && a.push(gvjs_Mn(b, gvjs_Nn, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.ns, null != c && a.push(":", String(c));
    if (c = this.getPath()) this.fr && "/" != c.charAt(0) && a.push("/"), a.push(gvjs_Mn(c, "/" == c.charAt(0) ? gvjs_Eca : gvjs_Fca, !0));
    (c = this.ue.toString()) && a.push("?", c);
    (c = this.fu) && a.push("#", gvjs_Mn(c, gvjs_Gca));
    return a.join("")
};
gvjs_.resolve = function(a) {
    var b = this.clone(),
        c = !!a.yl;
    c ? gvjs_Fn(b, a.yl) : c = !!a.nw;
    if (c) {
        var d = a.nw;
        gvjs_Gn(b);
        b.nw = d
    } else c = !!a.fr;
    c ? gvjs_Hn(b, a.fr) : c = null != a.ns;
    d = a.getPath();
    if (c) gvjs_In(b, a.ns);
    else if (c = !!a.uL) {
        if ("/" != d.charAt(0))
            if (this.fr && !this.uL) d = "/" + d;
            else {
                var e = b.getPath().lastIndexOf("/"); - 1 != e && (d = b.getPath().slice(0, e + 1) + d)
            }
        e = d;
        if (".." == e || "." == e) d = "";
        else if (gvjs_4e(e, "./") || gvjs_4e(e, "/.")) {
            d = gvjs_0e(e, "/");
            e = e.split("/");
            for (var f = [], g = 0; g < e.length;) {
                var h = e[g++];
                "." == h ? d && g == e.length &&
                    f.push("") : ".." == h ? ((1 < f.length || 1 == f.length && "" != f[0]) && f.pop(), d && g == e.length && f.push("")) : (f.push(h), d = !0)
            }
            d = f.join("/")
        } else d = e
    }
    c ? b.setPath(d) : c = "" !== a.ue.toString();
    c ? gvjs_Jn(b, a.ue.clone()) : c = !!a.fu;
    c && (a = a.fu, gvjs_Gn(b), b.fu = a);
    return b
};
gvjs_.clone = function() {
    return new gvjs_En(this)
};

function gvjs_Fn(a, b, c) {
    gvjs_Gn(a);
    a.yl = c ? gvjs_Kn(b, !0) : b;
    a.yl && (a.yl = a.yl.replace(/:$/, ""))
}

function gvjs_Hn(a, b, c) {
    gvjs_Gn(a);
    a.fr = c ? gvjs_Kn(b, !0) : b
}

function gvjs_In(a, b) {
    gvjs_Gn(a);
    if (b) {
        b = Number(b);
        if (isNaN(b) || 0 > b) throw Error("Bad port number " + b);
        a.ns = b
    } else a.ns = null
}
gvjs_.getPath = function() {
    return this.uL
};
gvjs_.setPath = function(a, b) {
    gvjs_Gn(this);
    this.uL = b ? gvjs_Kn(a, !0) : a;
    return this
};

function gvjs_Jn(a, b, c) {
    gvjs_Gn(a);
    b instanceof gvjs_Ln ? (a.ue = b, a.ue.PV(a.ak)) : (c || (b = gvjs_Mn(b, gvjs_Hca)), a.ue = new gvjs_Ln(b, a.ak));
    return a
}
gvjs_.setQuery = function(a, b) {
    return gvjs_Jn(this, a, b)
};
gvjs_.getQuery = function() {
    return this.ue.toString()
};
gvjs_.lc = function(a, b) {
    gvjs_Gn(this);
    this.ue.set(a, b);
    return this
};
gvjs_.removeParameter = function(a) {
    gvjs_Gn(this);
    this.ue.remove(a);
    return this
};

function gvjs_Gn(a) {
    if (a.Fha) throw Error("Tried to modify a read-only Uri");
}
gvjs_.PV = function(a) {
    this.ak = a;
    this.ue && this.ue.PV(a)
};

function gvjs_Kn(a, b) {
    return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
}

function gvjs_Mn(a, b, c) {
    return typeof a === gvjs_m ? (a = encodeURI(a).replace(b, gvjs_Ica), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
}

function gvjs_Ica(a) {
    a = a.charCodeAt(0);
    return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
}
var gvjs_Nn = /[#\/\?@]/g,
    gvjs_Fca = /[#\?:]/g,
    gvjs_Eca = /[#\?]/g,
    gvjs_Hca = /[#\?@]/g,
    gvjs_Gca = /#/g;

function gvjs_Ln(a, b) {
    this.Cg = this.de = null;
    this.Mi = a || null;
    this.ak = !!b
}

function gvjs_On(a) {
    a.de || (a.de = new Map, a.Cg = 0, a.Mi && gvjs_Dca(a.Mi, function(b, c) {
        a.add(decodeURIComponent(b.replace(/\+/g, " ")), c)
    }))
}

function gvjs_Jca(a) {
    var b = gvjs_wn(a);
    if ("undefined" == typeof b) throw Error("Keys are undefined");
    var c = new gvjs_Ln(null);
    a = gvjs_vn(a);
    for (var d = 0; d < b.length; d++) {
        var e = b[d],
            f = a[d];
        Array.isArray(f) ? c.setValues(e, f) : c.add(e, f)
    }
    return c
}
gvjs_ = gvjs_Ln.prototype;
gvjs_.De = gvjs_p(26);
gvjs_.add = function(a, b) {
    gvjs_On(this);
    this.Mi = null;
    a = gvjs_Pn(this, a);
    var c = this.de.get(a);
    c || this.de.set(a, c = []);
    c.push(b);
    this.Cg += 1;
    return this
};
gvjs_.remove = function(a) {
    gvjs_On(this);
    a = gvjs_Pn(this, a);
    return this.de.has(a) ? (this.Mi = null, this.Cg -= this.de.get(a).length, this.de.delete(a)) : !1
};
gvjs_.clear = function() {
    this.de = this.Mi = null;
    this.Cg = 0
};
gvjs_.isEmpty = function() {
    gvjs_On(this);
    return 0 == this.Cg
};
gvjs_.sm = function(a) {
    gvjs_On(this);
    a = gvjs_Pn(this, a);
    return this.de.has(a)
};
gvjs_.Dx = gvjs_p(28);
gvjs_.forEach = function(a, b) {
    gvjs_On(this);
    this.de.forEach(function(c, d) {
        c.forEach(function(e) {
            a.call(b, e, d, this)
        }, this)
    }, this)
};
gvjs_.Km = function() {
    gvjs_On(this);
    for (var a = Array.from(this.de.values()), b = Array.from(this.de.keys()), c = [], d = 0; d < b.length; d++)
        for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
    return c
};
gvjs_.Wb = function(a) {
    gvjs_On(this);
    var b = [];
    if (typeof a === gvjs_m) this.sm(a) && (b = b.concat(this.de.get(gvjs_Pn(this, a))));
    else {
        a = Array.from(this.de.values());
        for (var c = 0; c < a.length; c++) b = b.concat(a[c])
    }
    return b
};
gvjs_.set = function(a, b) {
    gvjs_On(this);
    this.Mi = null;
    a = gvjs_Pn(this, a);
    this.sm(a) && (this.Cg -= this.de.get(a).length);
    this.de.set(a, [b]);
    this.Cg += 1;
    return this
};
gvjs_.get = function(a, b) {
    if (!a) return b;
    a = this.Wb(a);
    return 0 < a.length ? String(a[0]) : b
};
gvjs_.setValues = function(a, b) {
    this.remove(a);
    0 < b.length && (this.Mi = null, this.de.set(gvjs_Pn(this, a), gvjs_wf(b)), this.Cg += b.length)
};
gvjs_.toString = function() {
    if (this.Mi) return this.Mi;
    if (!this.de) return "";
    for (var a = [], b = Array.from(this.de.keys()), c = 0; c < b.length; c++) {
        var d = b[c],
            e = encodeURIComponent(String(d));
        d = this.Wb(d);
        for (var f = 0; f < d.length; f++) {
            var g = e;
            "" !== d[f] && (g += "=" + encodeURIComponent(String(d[f])));
            a.push(g)
        }
    }
    return this.Mi = a.join("&")
};
gvjs_.clone = function() {
    var a = new gvjs_Ln;
    a.Mi = this.Mi;
    this.de && (a.de = new Map(this.de), a.Cg = this.Cg);
    return a
};

function gvjs_Pn(a, b) {
    b = String(b);
    a.ak && (b = b.toLowerCase());
    return b
}
gvjs_.PV = function(a) {
    a && !this.ak && (gvjs_On(this), this.Mi = null, this.de.forEach(function(b, c) {
        var d = c.toLowerCase();
        c != d && (this.remove(c), this.setValues(d, b))
    }, this));
    this.ak = a
};
gvjs_.extend = function(a) {
    for (var b = 0; b < arguments.length; b++) gvjs_Cca(arguments[b], function(c, d) {
        this.add(d, c)
    }, this)
};

function gvjs_Kca() {
    var a = gvjs_un || (gvjs_un = gvjs_Bca('[null,null,null,null,null,"(function(){/*\\n\\n Copyright The Closure Library Authors.\\n SPDX-License-Identifier: Apache-2.0\\n*/\\n\'use strict\';var e\\u003dthis||self;function f(a){return a};var h;function k(a,c){this.g\\u003dc\\u003d\\u003d\\u003dl?a:\\"\\"}k.prototype.toString\\u003dfunction(){return this.g+\\"\\"};var l\\u003d{};function m(a){if(void 0\\u003d\\u003d\\u003dh){var c\\u003dnull;var b\\u003de.trustedTypes;if(b\\u0026\\u0026b.createPolicy){try{c\\u003db.createPolicy(\\"goog#html\\",{createHTML:f,createScript:f,createScriptURL:f})}catch(d){e.console\\u0026\\u0026e.console.error(d.message)}h\\u003dc}else h\\u003dc}a\\u003d(c\\u003dh)?c.createScriptURL(a):a;return new k(a,l)};/*\\n\\n SPDX-License-Identifier: Apache-2.0\\n*/\\nif(!function(){if(self.origin)return\\"null\\"\\u003d\\u003d\\u003dself.origin;if(\\"\\"!\\u003d\\u003dlocation.host)return!1;try{return window.parent.escape(\\"\\"),!1}catch(a){return!0}}())throw Error(\\"sandboxing error\\");\\nwindow.addEventListener(\\"message\\",function(a){var c\\u003da.ports[0];a\\u003da.data;var b\\u003da.callbackName.split(\\".\\"),d\\u003dwindow;\\"window\\"\\u003d\\u003d\\u003db[0]\\u0026\\u0026b.shift();for(var g\\u003d0;g\\u003cb.length-1;g++)d[b[g]]\\u003d{},d\\u003dd[b[g]];d[b[b.length-1]]\\u003dfunction(n){c.postMessage(JSON.stringify(n))};b\\u003ddocument.createElement(\\"script\\");a\\u003dm(a.url);b.src\\u003da instanceof k\\u0026\\u0026a.constructor\\u003d\\u003d\\u003dk?a.g:\\"type_error:TrustedResourceUrl\\";document.body.appendChild(b)},!0);}).call(this);\\n"]'));
    if (!a) return null;
    a = gvjs_cg(a, 6);
    return null === a || void 0 === a ? null : gvjs_6g(a)
};

function gvjs_Qn(a, b) {
    this.url = a;
    this.timeout = void 0 === b ? 5E3 : b;
    this.FP = this.EP = "callback";
    this.mr = this.JD = null
}
gvjs_Qn.prototype.fetch = function(a) {
    var b = this;
    a = void 0 === a ? {} : a;
    this.mr = gvjs_ol();
    var c = new gvjs_En(this.url),
        d = new Map;
    this.FP && d.set(this.FP, this.EP);
    c.ue.extend(gvjs_Jca(a), d);
    gvjs_Lca(this).then(function() {
        gvjs_Mca(b, c.toString())
    }).then(function() {
        return b.mr.promise
    }).then(function() {
        gvjs_Rn(b)
    }, function() {
        gvjs_Rn(b)
    });
    0 < this.timeout && (this.IW = setTimeout(function() {
        b.mr.reject("Timeout!")
    }, this.timeout));
    return this.mr.promise
};

function gvjs_Mca(a, b) {
    var c = new MessageChannel;
    a.JD.contentWindow.postMessage({
        url: b,
        callbackName: a.EP
    }, "*", [c.port2]);
    c.port1.onmessage = function(d) {
        var e = {};
        void 0 !== a.IW && (clearTimeout(a.IW), a.IW = void 0);
        void 0 === d.data && a.mr.reject("Callback called, but no data received");
        typeof d.data !== gvjs_m && a.mr.reject("Exploitation attempt! Data is not a string!");
        try {
            e = JSON.parse(d.data)
        } catch (f) {
            a.mr.reject("Invalid Data received: " + f.message)
        }
        a.mr.resolve(e)
    }
}

function gvjs_Lca(a) {
    var b = gvjs_ol(),
        c = gvjs_ti(gvjs_Na);
    if (!c.sandbox) throw Error("iframe sandboxes not supported");
    c.sandbox.value = "allow-scripts";
    c.style.display = gvjs_e;
    a.JD = c;
    a = gvjs_Kca();
    a = gvjs_Dh(gvjs_Waa, gvjs_Ah(gvjs_Kb, {}, gvjs_vca(a)));
    c.srcdoc = gvjs_xh(a);
    a = gvjs_ah("data:text/html;charset=UTF-8;base64," + btoa(gvjs_wh(a)));
    c.src = gvjs_9g(a);
    c.addEventListener("load", function() {
        return b.resolve(c)
    }, !1);
    c.addEventListener(gvjs_7b, function(d) {
        b.reject(d)
    }, !1);
    document.documentElement.appendChild(c);
    return b.promise
}

function gvjs_Rn(a) {
    null !== a.JD && (document.documentElement.removeChild(a.JD), a.JD = null)
};

function gvjs_Sn(a) {
    switch (a) {
        case 200:
        case 201:
        case 202:
        case 204:
        case 206:
        case 304:
        case 1223:
            return !0;
        default:
            return !1
    }
};

function gvjs_Tn() {}
gvjs_Tn.prototype.B0 = null;
gvjs_Tn.prototype.getOptions = function() {
    var a;
    (a = this.B0) || (a = {}, gvjs_Un(this) && (a[0] = !0, a[1] = !0), a = this.B0 = a);
    return a
};
var gvjs_Vn;

function gvjs_Wn() {}
gvjs_u(gvjs_Wn, gvjs_Tn);

function gvjs_Xn(a) {
    return (a = gvjs_Un(a)) ? new ActiveXObject(a) : new XMLHttpRequest
}

function gvjs_Un(a) {
    if (!a.G4 && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
        for (var b = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"], c = 0; c < b.length; c++) {
            var d = b[c];
            try {
                return new ActiveXObject(d), a.G4 = d
            } catch (e) {}
        }
        throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed");
    }
    return a.G4
}
gvjs_Vn = new gvjs_Wn;

function gvjs_Yn(a) {
    return gvjs_Nca(a).then(function(b) {
        return b.responseText
    })
}

function gvjs_Nca(a) {
    var b = {},
        c = b.wna ? gvjs_Xn(b.wna) : gvjs_Xn(gvjs_Vn);
    return (new gvjs_jl(function(d, e) {
        var f;
        try {
            c.open("GET", a, !0)
        } catch (k) {
            e(new gvjs_Zn("Error opening XHR: " + k.message, a, c))
        }
        c.onreadystatechange = function() {
            if (4 == c.readyState) {
                gvjs_s.clearTimeout(f);
                var k;
                !(k = gvjs_Sn(c.status)) && (k = 0 === c.status) && (k = gvjs_An(a), k = !("http" == k || "https" == k || "" == k));
                k ? d(c) : e(new gvjs__n(c.status, a, c))
            }
        };
        c.onerror = function() {
            e(new gvjs_Zn("Network error", a, c))
        };
        if (b.headers)
            for (var g in b.headers) {
                var h =
                    b.headers[g];
                null != h && c.setRequestHeader(g, h)
            }
        b.withCredentials && (c.withCredentials = b.withCredentials);
        b.responseType && (c.responseType = b.responseType);
        b.mimeType && c.overrideMimeType(b.mimeType);
        0 < b.tma && (f = gvjs_s.setTimeout(function() {
            c.onreadystatechange = function() {};
            c.abort();
            e(new gvjs_0n(a, c))
        }, b.tma));
        try {
            c.send(null)
        } catch (k) {
            c.onreadystatechange = function() {}, gvjs_s.clearTimeout(f), e(new gvjs_Zn("Error sending XHR: " + k.message, a, c))
        }
    })).i9(function(d) {
        d instanceof gvjs_ql && c.abort();
        throw d;
    })
}

function gvjs_Zn(a, b) {
    gvjs_Xe.call(this, a + ", url=" + b);
    this.url = b
}
gvjs_u(gvjs_Zn, gvjs_Xe);
gvjs_Zn.prototype.name = "XhrError";

function gvjs__n(a, b, c) {
    gvjs_Zn.call(this, "Request Failed, status=" + a, b, c);
    this.status = a
}
gvjs_u(gvjs__n, gvjs_Zn);
gvjs__n.prototype.name = "XhrHttpError";

function gvjs_0n(a, b) {
    gvjs_Zn.call(this, gvjs_8a, a, b)
}
gvjs_u(gvjs_0n, gvjs_Zn);
gvjs_0n.prototype.name = "XhrTimeoutError";

function gvjs_1n(a) {
    gvjs_7k.call(this);
    this.headers = new Map;
    this.NN = a || null;
    this.Aq = !1;
    this.MN = this.hb = null;
    this.Qu = this.jT = "";
    this.Au = this.wS = this.fK = this.hR = !1;
    this.rN = 0;
    this.qN = null;
    this.T7 = "";
    this.fX = this.hka = this.qX = !1;
    this.VW = null
}
gvjs_u(gvjs_1n, gvjs_7k);
var gvjs_Oca = /^https?$/i,
    gvjs_Pca = ["POST", "PUT"],
    gvjs_2n = [];

function gvjs_Qca(a, b, c, d, e) {
    var f = gvjs_Rca,
        g = new gvjs_1n;
    gvjs_2n.push(g);
    b && g.o(gvjs_Xb, b);
    g.Uy(gvjs_h, g.Wba);
    e && (g.qX = e);
    g.send(a, c, d, f)
}
gvjs_ = gvjs_1n.prototype;
gvjs_.Wba = function() {
    this.xa();
    gvjs_uf(gvjs_2n, this)
};
gvjs_.setTrustToken = function(a) {
    this.VW = a
};
gvjs_.send = function(a, b, c, d) {
    if (this.hb) throw Error("[goog.net.XhrIo] Object is active with another request=" + this.jT + "; newUri=" + a);
    b = b ? b.toUpperCase() : "GET";
    this.jT = a;
    this.Qu = "";
    this.hR = !1;
    this.Aq = !0;
    this.hb = this.NN ? gvjs_Xn(this.NN) : gvjs_Xn(gvjs_Vn);
    this.MN = this.NN ? this.NN.getOptions() : gvjs_Vn.getOptions();
    this.hb.onreadystatechange = gvjs_Se(this.X6, this);
    this.hka && "onprogress" in this.hb && (this.hb.onprogress = gvjs_Se(function(g) {
        this.W6(g, !0)
    }, this), this.hb.upload && (this.hb.upload.onprogress = gvjs_Se(this.W6,
        this)));
    try {
        this.wS = !0, this.hb.open(b, String(a), !0), this.wS = !1
    } catch (g) {
        this.au(5, g);
        return
    }
    a = c || "";
    c = new Map(this.headers);
    if (d)
        if (Object.getPrototypeOf(d) === Object.prototype)
            for (var e in d) c.set(e, d[e]);
        else if (typeof d.keys === gvjs_c && typeof d.get === gvjs_c) {
        e = gvjs_q(d.keys());
        for (var f = e.next(); !f.done; f = e.next()) f = f.value, c.set(f, d.get(f))
    } else throw Error("Unknown input type for opt_headers: " + String(d));
    d = Array.from(c.keys()).find(function(g) {
        return "content-type" == g.toLowerCase()
    });
    e = gvjs_s.FormData &&
        a instanceof gvjs_s.FormData;
    !gvjs_tf(gvjs_Pca, b) || d || e || c.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    b = gvjs_q(c);
    for (d = b.next(); !d.done; d = b.next()) c = gvjs_q(d.value), d = c.next().value, c = c.next().value, this.hb.setRequestHeader(d, c);
    this.T7 && (this.hb.responseType = this.T7);
    gvjs_me in this.hb && this.hb.withCredentials !== this.qX && (this.hb.withCredentials = this.qX);
    if ("setTrustToken" in this.hb && this.VW) try {
        this.hb.setTrustToken(this.VW)
    } catch (g) {}
    try {
        gvjs_3n(this), 0 < this.rN && ((this.fX =
            gvjs_Sca(this.hb)) ? (this.hb.timeout = this.rN, this.hb.ontimeout = gvjs_Se(this.bG, this)) : this.qN = gvjs_yl(this.bG, this.rN, this)), this.fK = !0, this.hb.send(a), this.fK = !1
    } catch (g) {
        this.au(5, g)
    }
};

function gvjs_Sca(a) {
    return gvjs_x && typeof a.timeout === gvjs_f && void 0 !== a.ontimeout
}
gvjs_.bG = function() {
    "undefined" != typeof gvjs_Je && this.hb && (this.Qu = "Timed out after " + this.rN + "ms, aborting", this.dispatchEvent("timeout"), this.abort(8))
};
gvjs_.au = function(a, b) {
    this.Aq = !1;
    this.hb && (this.Au = !0, this.hb.abort(), this.Au = !1);
    this.Qu = b;
    gvjs_4n(this);
    gvjs_5n(this)
};

function gvjs_4n(a) {
    a.hR || (a.hR = !0, a.dispatchEvent(gvjs_Xb), a.dispatchEvent(gvjs_7b))
}
gvjs_.abort = function() {
    this.hb && this.Aq && (this.Aq = !1, this.Au = !0, this.hb.abort(), this.Au = !1, this.dispatchEvent(gvjs_Xb), this.dispatchEvent("abort"), gvjs_5n(this))
};
gvjs_.J = function() {
    this.hb && (this.Aq && (this.Aq = !1, this.Au = !0, this.hb.abort(), this.Au = !1), gvjs_5n(this, !0));
    gvjs_1n.G.J.call(this)
};
gvjs_.X6 = function() {
    this.Ue || (this.wS || this.fK || this.Au ? gvjs_6n(this) : this.Dja())
};
gvjs_.Dja = function() {
    gvjs_6n(this)
};

function gvjs_6n(a) {
    if (a.Aq && "undefined" != typeof gvjs_Je && (!a.MN[1] || 4 != gvjs_7n(a) || 2 != a.getStatus()))
        if (a.fK && 4 == gvjs_7n(a)) gvjs_yl(a.X6, 0, a);
        else if (a.dispatchEvent("readystatechange"), 4 == gvjs_7n(a)) {
        a.Aq = !1;
        try {
            if (gvjs_8n(a)) a.dispatchEvent(gvjs_Xb), a.dispatchEvent("success");
            else {
                try {
                    var b = 2 < gvjs_7n(a) ? a.hb.statusText : ""
                } catch (c) {
                    b = ""
                }
                a.Qu = b + " [" + a.getStatus() + "]";
                gvjs_4n(a)
            }
        } finally {
            gvjs_5n(a)
        }
    }
}
gvjs_.W6 = function(a, b) {
    this.dispatchEvent(gvjs_9n(a, "progress"));
    this.dispatchEvent(gvjs_9n(a, b ? "downloadprogress" : "uploadprogress"))
};

function gvjs_9n(a, b) {
    return {
        type: b,
        lengthComputable: a.lengthComputable,
        loaded: a.loaded,
        total: a.total
    }
}

function gvjs_5n(a, b) {
    if (a.hb) {
        gvjs_3n(a);
        var c = a.hb,
            d = a.MN[0] ? function() {} : null;
        a.hb = null;
        a.MN = null;
        b || a.dispatchEvent(gvjs_h);
        try {
            c.onreadystatechange = d
        } catch (e) {}
    }
}

function gvjs_3n(a) {
    a.hb && a.fX && (a.hb.ontimeout = null);
    a.qN && (gvjs_zl(a.qN), a.qN = null)
}
gvjs_.isActive = function() {
    return !!this.hb
};

function gvjs_8n(a) {
    var b = a.getStatus(),
        c;
    if (!(c = gvjs_Sn(b))) {
        if (b = 0 === b) a = gvjs_An(String(a.jT)), b = !gvjs_Oca.test(a);
        c = b
    }
    return c
}

function gvjs_7n(a) {
    return a.hb ? a.hb.readyState : 0
}
gvjs_.getStatus = function() {
    try {
        return 2 < gvjs_7n(this) ? this.hb.status : -1
    } catch (a) {
        return -1
    }
};
gvjs_.getResponseHeader = function(a) {
    if (this.hb && 4 == gvjs_7n(this)) return a = this.hb.getResponseHeader(a), null === a ? void 0 : a
};
gvjs_.getAllResponseHeaders = function() {
    return this.hb && 2 <= gvjs_7n(this) ? this.hb.getAllResponseHeaders() || "" : ""
};

function gvjs_$n(a) {
    return typeof a.Qu === gvjs_m ? a.Qu : String(a.Qu)
};

function gvjs_ao() {
    this.position = null;
    gvjs_Xe.call(this, void 0)
}
gvjs_u(gvjs_ao, gvjs_Xe);
gvjs_ao.prototype.name = "ParseError";

function gvjs_Tca(a) {
    function b() {
        if (null != l) {
            var q = l;
            l = null;
            return q
        }
        if (e >= a.length) return f;
        q = a.charAt(e++);
        var r = !1;
        "\n" == q ? r = !0 : "\r" == q && (e < a.length && "\n" == a.charAt(e) && e++, r = !0);
        return r ? h : q
    }

    function c() {
        var q = e,
            r = m;
        m = !1;
        var t = b();
        if (t == k) return g;
        if (t == f || t == h) return r ? (l = k, "") : g;
        if ('"' == t) {
            q = e;
            r = null;
            for (t = b(); t != f; t = b())
                if ('"' == t)
                    if (r = e - 1, t = b(), '"' == t) r = null;
                    else {
                        if ("," == t || t == f || t == h) {
                            t == h && (l = t);
                            "," == t && (m = !0);
                            break
                        }
                        throw new gvjs_ao(a, e - 1, 'Unexpected character "' + t + '" after quote mark');
                    }
            if (null === r) throw new gvjs_ao(a, a.length - 1, "Unexpected end of text after open quote");
            return a.substring(q, r).replace(/""/g, '"')
        }
        for (;;) {
            if (t == f || t == h) {
                l = t;
                break
            }
            if ("," == t) {
                m = !0;
                break
            }
            if ('"' == t) throw new gvjs_ao(a, e - 1, "Unexpected quote mark");
            t = b()
        }
        return (t == f ? a.substring(q) : a.substring(q, e - 1)).replace(/[\r\n]+/g, "")
    }

    function d() {
        if (e >= a.length) return f;
        for (var q = [], r = c(); r != g; r = c()) q.push(r);
        return q
    }
    for (var e = 0, f = gvjs_Uca, g = gvjs_Vca, h = gvjs_Wca, k = gvjs_Xca, l = null, m = !1, n = [], p = d(); p != f; p = d()) n.push(p);
    return n
}
var gvjs_Xca = {},
    gvjs_Uca = {},
    gvjs_Vca = {},
    gvjs_Wca = {};

function gvjs_Yca(a, b, c) {
    this.Bca = a;
    this.columns = [];
    this.UJ = null != c ? c : !1;
    for (a = 0; a < b.length; a++)
        if (c = b[a], !gvjs_bo[c]) throw Error("Unsupported type: " + c);
    this.types = b
}
var gvjs_bo = {
    number: function(a) {
        var b = Number(a);
        if (isNaN(b)) throw Error("Not a number " + a);
        return b
    },
    string: function(a) {
        return a
    },
    "boolean": function(a) {
        return a.toLowerCase() === gvjs_fe
    },
    date: function(a) {
        return new Date(a)
    },
    datetime: function(a) {
        return new Date(a)
    },
    timeofday: function(a) {
        return a.split(",")
    }
};
var gvjs_Zca = RegExp("/spreadsheet"),
    gvjs_co = RegExp("/(ccc|tq|pub)$"),
    gvjs__ca = new RegExp(/^spreadsheets?[0-9]?\.google\.com$/),
    gvjs_0ca = new RegExp(/^docs\.google\.com*$/),
    gvjs_do = new RegExp(/^(trix|spreadsheets|docs|webdrive)(-[a-z]+)?\.(corp|sandbox)\.google\.com/),
    gvjs_eo = new RegExp(/^(\w*\.){1,2}corp\.google\.com$/),
    gvjs_1ca = RegExp("/spreadsheets(/d/[^/]+)?"),
    gvjs_2ca = RegExp("/(edit|gviz/tq|)$"),
    gvjs_3ca = new RegExp(/^docs\.google\.com*$/),
    gvjs_4ca = new RegExp(/^docs(-qa)?\.(corp|sandbox)\.google\.com*$/),
    gvjs_fo = new RegExp(/^(\w*\.){1,2}corp\.google\.com$/),
    gvjs_go = RegExp("^/a/([\\w-]+\\.)+\\w+"),
    gvjs_ho = RegExp("^(/a/([\\w-]+\\.)+\\w+)?"),
    gvjs_5ca = new RegExp(/^[a-z]+\d+:[a-z]+\d+$/i),
    gvjs_6ca = new RegExp(/^[a-z]+\d+$/i);

function gvjs_io(a) {
    var b = gvjs_yn(gvjs_zn(3, a)) || "",
        c = gvjs__ca.test(b),
        d = gvjs_do.test(b),
        e = gvjs_eo.test(b);
    b = gvjs_0ca.test(b);
    var f = gvjs_yn(gvjs_zn(5, a)) || "",
        g = new RegExp(gvjs_ho.source + gvjs_co.source);
    f = (a = (new RegExp(gvjs_ho.source + gvjs_Zca.source + gvjs_co.source)).test(f)) || g.test(f);
    return b && a || (d || e || c) && f
}

function gvjs_jo(a) {
    var b = gvjs_yn(gvjs_zn(3, a)) || "",
        c = gvjs_4ca.test(b),
        d = gvjs_fo.test(b);
    b = gvjs_3ca.test(b);
    a = gvjs_yn(gvjs_zn(5, a)) || "";
    a = (new RegExp(gvjs_ho.source + gvjs_1ca.source + gvjs_2ca.source)).test(a);
    return (b || c || d) && a
};
var gvjs_ko = {
        Hpa: "xhr",
        Ipa: "xhrpost",
        gpa: "scriptInjection",
        O$: gvjs_ud,
        TA: gvjs_Gb
    },
    gvjs_lo = Object.values(gvjs_ko),
    gvjs_Rca = {
        "X-DataSource-Auth": "a"
    };

function gvjs_mo(a, b) {
    this.o9 = 30;
    this.uu = this.nS = this.query = this.sN = this.qs = null;
    this.H7 = !0;
    this.refreshInterval = 0;
    this.kV = !1;
    this.Tu = this.kF = null;
    this.a5 = this.isActive = !1;
    this.dataSourceUrl = "";
    b = b || {};
    this.k7 = void 0 !== b.csvColumns;
    this.Wla = null != b.strictJSON ? !!b.strictJSON : !0;
    this.dca = b.csvColumns;
    this.UJ = !!b.csvHasHeader;
    this.sendMethod = b.sendMethod || gvjs_ko.TA;
    this.vna = !!b.xhrWithCredentials;
    if (!gvjs_lo.includes(this.sendMethod)) throw Error("Send method not supported: " + this.sendMethod);
    this.makeRequestParams =
        b.makeRequestParams || {};
    this.setDataSourceUrl(a);
    this.requestId = gvjs_7ca++;
    gvjs_8ca.push(this)
}
gvjs_ = gvjs_mo.prototype;
gvjs_.setDataSourceUrl = function(a) {
    if (gvjs_jo(a)) {
        var b = a;
        a = new gvjs_En(b);
        433 === a.ns && gvjs_In(a, null);
        var c = a.getPath();
        c = c.replace(/\/edit/, "/gviz/tq");
        a.setPath(c);
        c = gvjs_yn(gvjs_zn(3, b)) || "";
        b = null !== (Number(gvjs_zn(4, b)) || null);
        b = gvjs_fo.test(c) && b;
        gvjs_Fn(a, b ? "http" : "https");
        a = a.toString()
    } else if (gvjs_io(a)) {
        c = a;
        a = new gvjs_En(c);
        433 === a.ns && gvjs_In(a, null);
        b = a.getPath();
        b = b.replace(/\/ccc$/, "/tq");
        /\/pub$/.test(b) && (b = b.replace(/\/pub$/, "/tq"), a.lc("pub", "1"));
        a.setPath(b);
        b = gvjs_yn(gvjs_zn(3,
            c)) || "";
        c = null != (Number(gvjs_zn(4, c)) || null);
        var d = gvjs_do.test(b);
        b = gvjs_eo.test(b) && !d && c;
        gvjs_Fn(a, b ? "http" : "https");
        a = a.toString()
    }
    c = a;
    b = gvjs_io(c);
    c = gvjs_yn(gvjs_zn(5, c)) || "";
    c = gvjs_go.test(c);
    (b = b && c) || (c = a, b = gvjs_jo(c), c = gvjs_yn(gvjs_zn(5, c)) || "", c = gvjs_go.test(c), b = b && c);
    this.a5 = b;
    this.dataSourceUrl = a
};

function gvjs_no(a, b) {
    var c = a.indexOf("#"); - 1 !== c && (a = a.substring(0, c));
    var d = a.indexOf("?"),
        e = []; - 1 === d ? c = a : (c = a.substring(0, d), a = a.substring(d + 1), e = a.split("&"));
    a = [];
    for (d = 0; d < e.length; d++) {
        var f = {};
        f.name = e[d].split("=")[0];
        f.BU = e[d];
        a.push(f)
    }
    for (var g in b)
        if (b.hasOwnProperty(g)) {
            e = b[g];
            f = !1;
            for (d = 0; d < a.length; d++)
                if (a[d].name === g) {
                    a[d].BU = g + "=" + encodeURIComponent(e);
                    f = !0;
                    break
                }
            f || (d = {
                name: g
            }, d.BU = g + "=" + encodeURIComponent(e), a.push(d))
        }
    b = c;
    if (0 < a.length) {
        b += "?";
        g = [];
        for (d = 0; d < a.length; d++) g.push(a[d].BU);
        b += g.join("&")
    }
    return b
}

function gvjs_oo(a) {
    var b = a.reqId,
        c = gvjs_po[b];
    if (c) gvjs_po[b] = null, c.yy(a);
    else throw Error("Missing query for request id: " + b);
}

function gvjs_qo(a, b, c, d) {
    a.yy({
        version: "0.6",
        status: gvjs_7b,
        errors: [{
            reason: b,
            message: c,
            detailed_message: d
        }]
    })
}
gvjs_.MO = function(a) {
    var b = {};
    this.query && (b.tq = String(this.query));
    var c = "reqId:" + String(this.requestId),
        d = this.Tu;
    d && (c += ";sig:" + d);
    this.nS && (c += ";type:" + this.nS);
    b.tqx = c;
    if (this.uu) {
        c = [];
        for (var e in this.uu) this.uu.hasOwnProperty(e) && c.push(e + ":" + this.uu[e]);
        b.tqh = c.join(";")
    }
    a = gvjs_no(a, b);
    this.refreshInterval && (a = new gvjs_En(a), gvjs_If && (gvjs_Gn(a), a.lc("zx", gvjs_Mh())), a = a.toString());
    return a
};
gvjs_.sendQuery = function() {
    var a = this,
        b = this.MO(this.dataSourceUrl),
        c = gvjs_fk(),
        d = {};
    gvjs_po[String(this.requestId)] = this;
    var e = this.sendMethod,
        f = "GET";
    "xhrpost" === e && (e = "xhr", f = "POST");
    e === gvjs_Gb && (d = gvjs_9ca(b), e = d.sendMethod, d = d.options);
    if (e === gvjs_ud)
        if (gvjs_Ke("gadgets.io.makeRequest")) gvjs_$ca(this, b, this.makeRequestParams);
        else throw Error("gadgets.io.makeRequest is not defined.");
    else if ("xhr" === e || e === gvjs_Gb && gvjs_ada(c.Yi().location.href, b)) c = void 0, e = b, "POST" === f && (b = b.split("?"), 1 <=
        b.length && (e = b[0]), 2 <= b.length && (c = b[1])), gvjs_Qca(e, function(g) {
        var h = a.requestId;
        g = g.target;
        if (gvjs_8n(g)) {
            try {
                var k = g.hb ? g.hb.responseText : ""
            } catch (t) {
                k = ""
            }
            k = k.trim();
            if (a.k7) {
                var l = new gvjs_Yca(k, a.dca, a.UJ);
                g = gvjs_Tca(l.Bca);
                k = new gvjs_F;
                if (g && 0 < g.length) {
                    for (var m = [], n = l.types, p = 0, q = n.length; p < q; p++) m.push({
                        type: n[p]
                    });
                    if (l.UJ)
                        for (n = 0, p = m.length; n < p; n++) m[n].label = g[0][n];
                    n = 0;
                    for (p = m.length; n < p; n++) q = m[n], k.addColumn(q.type || gvjs_m, q.label);
                    l.columns = m;
                    m = l.columns;
                    n = l = l.UJ ? 1 : 0;
                    for (p = g.length; n <
                        p; n++) {
                        k.addRow();
                        q = 0;
                        for (var r = m.length; q < r; q++) k.setCell(n - l, q, gvjs_bo[m[q].type || gvjs_m](g[n][q]))
                    }
                }
                g = {};
                g.table = k.toJSON();
                g.version = gvjs_Hk(g);
                g.reqId = h;
                gvjs_oo(g)
            } else k.match(/^({.*})$/) ? gvjs_oo(gvjs_Jg(k)) : gvjs_Ve(k)
        } else if (a.qs) gvjs_qo(a, gvjs_0c, gvjs_$n(g));
        else throw Error("google.visualization.Query: " + gvjs_$n(g));
    }, f, c, this.vna || !!d.xhrWithCredentials);
    else {
        if (this.k7) throw Error("CSV files on other domains are not supported. Please use sendMethod: 'xhr' or 'auto' and serve your .csv file from the same domain as this page.");
        f = gvjs_Pi(c, gvjs_Kb)[0];
        d = null === this.Tu;
        if (this.a5 && d) {
            d = c.createElement("IMG");
            gvjs_bda(this, d, b);
            c.appendChild(f, d);
            return
        }
        gvjs_ro(this, b)
    }
    this.kV && gvjs_cda(this)
};

function gvjs_bda(a, b, c) {
    b.onerror = function() {
        gvjs_ro(a, c)
    };
    b.onload = function() {
        gvjs_ro(a, c)
    };
    b.style.display = gvjs_e;
    b.src = c + "&requireauth=1&" + (new Date).getTime()
}

function gvjs_9ca(a) {
    var b = {};
    if (/[?&]alt=gviz(&[^&]*)*$/.test(a)) a = gvjs_ko.O$;
    else {
        var c = (gvjs_Dn(a, "tqrt") || gvjs_ko.TA).split(":");
        a = c[0];
        "xhr" !== a && "xhrpost" !== a || !c.includes(gvjs_me) || (b.xhrWithCredentials = !0);
        gvjs_lo.includes(a) || (a = gvjs_ko.TA)
    }
    return {
        sendMethod: a,
        options: b
    }
}

function gvjs_ada(a, b) {
    b = (new gvjs_En(a)).resolve(new gvjs_En(b)).toString();
    a = a.match(gvjs_xn);
    b = b.match(gvjs_xn);
    return a[3] == b[3] && a[1] == b[1] && a[4] == b[4]
}

function gvjs_$ca(a, b, c) {
    var d = gvjs_Ke("gadgets.io");
    null == c[d.RequestParameters.CONTENT_TYPE] && (c[d.RequestParameters.CONTENT_TYPE] = d.ContentType.TEXT);
    null == c[d.RequestParameters.AUTHORIZATION] && (c[d.RequestParameters.AUTHORIZATION] = d.AuthorizationType.SIGNED);
    null == c.OAUTH_ENABLE_PRIVATE_NETWORK && (c.OAUTH_ENABLE_PRIVATE_NETWORK = !0);
    null == c.OAUTH_ADD_EMAIL && (c.OAUTH_ADD_EMAIL = !0);
    d.makeRequest(b, function() {
        return a.Qfa
    }, c);
    gvjs_so(a)
}
gvjs_.Qfa = function(a) {
    if (null != a && a.data) gvjs_Ve(a.data);
    else {
        var b = "";
        a && a.errors && (b = a.errors.join(" "));
        gvjs_qo(this, "make_request_failed", "gadgets.io.makeRequest failed", b)
    }
};

function gvjs_ro(a, b) {
    gvjs_so(a);
    a = a.Wla || gvjs_Gf;
    b.match(/^https?:\/\/spreadsheets.google.com/) && (a = !1);
    a ? gvjs_dda(b) : (b = new gvjs_Qn(b, 0), b.EP = "google.visualization.Query.setResponse", b.FP = "", b.fetch().then(gvjs_oo))
}

function gvjs_dda(a) {
    gvjs_Yn(a).then(function(b) {
        try {
            var c = RegExp("\\);?[\\s]*$", "g");
            b = b.replace(RegExp("^[\\s\\S]*google\\.visualization\\.Query\\.setResponse\\(", "g"), "");
            b = b.replace(c, "");
            gvjs_oo(gvjs_Jg(b))
        } catch (d) {
            throw Error("Error handling Query strict JSON response: " + d);
        }
    }, function(b) {
        throw Error("Error handling Query: " + b);
    })
}

function gvjs_to(a) {
    a.sN && (clearTimeout(a.sN), a.sN = null)
}

function gvjs_so(a) {
    gvjs_to(a);
    a.sN = setTimeout(function() {
        gvjs_qo(a, "timeout", gvjs_8a)
    }, 1E3 * a.o9)
}
gvjs_.setRefreshInterval = function(a) {
    if (typeof a !== gvjs_f || 0 > a) throw Error("Refresh interval must be a non-negative number");
    this.refreshInterval = a;
    this.kV = !0
};

function gvjs_uo(a) {
    a.kF && (clearTimeout(a.kF), a.kF = null)
}

function gvjs_cda(a) {
    gvjs_uo(a);
    if (0 !== a.refreshInterval && a.H7 && a.isActive) {
        var b = function() {
            a.sendQuery();
            a.kF = setTimeout(b, 1E3 * a.refreshInterval)
        };
        a.kF = setTimeout(b, 1E3 * a.refreshInterval);
        a.kV = !1
    }
}
gvjs_.send = function(a) {
    this.isActive = !0;
    this.qs = a;
    this.sendQuery()
};
gvjs_.makeRequest = function(a, b) {
    this.isActive = !0;
    this.qs = a;
    this.sendMethod = gvjs_ud;
    this.makeRequestParams = b || {};
    this.sendQuery()
};
gvjs_.abort = function() {
    this.isActive = !1;
    gvjs_to(this);
    gvjs_uo(this)
};
gvjs_.clear = function() {
    this.abort()
};
gvjs_.yy = function(a) {
    gvjs_to(this);
    a = new gvjs_Gk(a);
    if (!a.containsReason("not_modified")) {
        a.isError() ? this.Tu = null : this.Tu = a.getDataSignature();
        var b = this.qs;
        b && b.call(b, a)
    }
};
gvjs_.setTimeout = function(a) {
    if (typeof a !== gvjs_f || isNaN(a) || 0 >= a) throw Error("Timeout must be a positive number");
    this.o9 = a
};
gvjs_.setRefreshable = function(a) {
    if (typeof a !== gvjs_Lb) throw Error("Refreshable must be a boolean");
    return this.H7 = a
};
gvjs_.setQuery = function(a) {
    if (typeof a !== gvjs_m) throw Error("queryString must be a string");
    this.query = a
};
gvjs_.mla = function(a) {
    this.nS = a;
    null != a && this.t8(gvjs_ge, a)
};
gvjs_.t8 = function(a, b) {
    a = a.replace(/\\/g, "\\\\");
    b = b.replace(/\\/g, "\\\\");
    a = a.replace(/:/g, "\\c");
    b = b.replace(/:/g, "\\c");
    a = a.replace(/;/g, "\\s");
    b = b.replace(/;/g, "\\s");
    this.uu || (this.uu = {});
    this.uu[a] = b
};
var gvjs_7ca = 0,
    gvjs_po = {},
    gvjs_8ca = [];
var gvjs_eda = gvjs_J.addError,
    gvjs_vo = gvjs_J.createProtectedCallback;

function gvjs_wo(a, b) {
    gvjs_L.call(this);
    this.Mn = this.ZL = null;
    this.type = "";
    this.D7 = this.xI = this.IL = this.dataTable = this.IN = this.cL = this.visualization = this.Xy = null;
    b = b || {};
    typeof b === gvjs_m && (b = gvjs_Jg(b));
    this.container = b.container || null;
    this.containerId = b.containerId || null;
    this.DG = a;
    this.name = b[a + "Name"] || "";
    a = b[a + "Type"] || null;
    typeof a === gvjs_c ? (this.Gl(""), this.Mn = a) : typeof a === gvjs_m && "" !== a ? (this.Gl(a), this.Mn = null) : null == a && (this.Gl(a), this.Mn = null);
    a = b.packages;
    this.packages = void 0 !== a ? a : null;
    this.p5 = b.isDefaultVisualization || void 0 === b.isDefaultVisualization;
    this.dataSourceUrl = b.dataSourceUrl || null;
    this.Gca = b.dataSourceChecksum || null;
    this.setDataTable(b.dataTable);
    this.options = b.options || {};
    this.state = b.state || {};
    this.query = b.query || null;
    this.refreshInterval = b.refreshInterval || null;
    this.view = b.view || null;
    this.O4 = b.initialView || null;
    this.J2 = [gvjs_fda, gvjs_gda, gvjs_hda, gvjs_ida]
}
gvjs_r(gvjs_wo, gvjs_L);
gvjs_ = gvjs_wo.prototype;
gvjs_.J = function() {
    this.clear();
    gvjs_L.prototype.J.call(this)
};
gvjs_.clear = function() {
    gvjs_xo(this);
    gvjs_yo(this)
};

function gvjs_xo(a) {
    a.IL && (a.IL.clear(), a.IL = null)
}
gvjs_.clone = function() {
    var a = this.toPOJO();
    a = new this.constructor(a);
    a.xI = this.xI;
    return a
};
gvjs_.toJSON = function() {
    var a = gvjs_zo(this, this.getDataTable());
    a.container = void 0;
    a.typeConstructor = void 0;
    return gvjs_Gg(a)
};
gvjs_.toPOJO = function() {
    return gvjs_zo(this, this.D7 || this.getDataTable())
};

function gvjs_zo(a, b) {
    var c = a.getPackages(),
        d = void 0;
    b && (b = b.toDataTable(), d = b.toPOJO());
    b = {
        container: a.container || void 0,
        containerId: a.getContainerId() || void 0,
        dataSourceChecksum: a.Gca || void 0,
        dataSourceUrl: a.getDataSourceUrl() || void 0,
        dataTable: d,
        initialView: a.O4 || void 0,
        options: a.getOptions() || void 0,
        state: a.getState() || void 0,
        packages: null === c ? void 0 : c,
        refreshInterval: a.getRefreshInterval() || void 0,
        query: a.getQuery() || void 0,
        view: a.getView() || void 0,
        isDefaultVisualization: a.isDefaultVisualization()
    };
    b[a.DG + "Type"] = a.getType() || void 0;
    b[a.DG + "Name"] = a.getName() || void 0;
    a.J_(b);
    return b
}
gvjs_.J_ = function() {};
gvjs_.getSnapshot = function() {
    var a = this.toPOJO();
    return new this.constructor(a)
};
gvjs_.getName = function() {
    return this.name
};
gvjs_.yn = function(a) {
    this.name = a
};
gvjs_.getType = function() {
    return this.type
};
gvjs_.Gl = function(a) {
    this.type = a;
    this.Mn = null
};
gvjs_.getPackages = function() {
    return this.packages
};
gvjs_.setPackages = function(a) {
    this.packages = a
};
gvjs_.v3 = function() {
    return this.visualization
};
gvjs_.isDefaultVisualization = function() {
    return this.p5
};
gvjs_.setIsDefaultVisualization = function(a) {
    this.p5 = a
};

function gvjs_jda(a, b) {
    gvjs_Ao(a);
    var c = [];
    gvjs_v([gvjs_h, gvjs_k, gvjs_7b, gvjs_3d], function(d) {
        var e = gvjs_2l(b, d, function(f) {
            d === gvjs_h && (a.Xy = null, a.visualization = b);
            d !== gvjs_h && d !== gvjs_3d || typeof b.getState !== gvjs_c || a.setState(b.getState.call(b));
            gvjs_N(a, d, f)
        });
        c.push(e)
    });
    a.IN = c
}

function gvjs_yo(a) {
    a.visualization && typeof a.visualization.clearChart === gvjs_c && a.visualization.clearChart();
    gvjs_Ao(a);
    gvjs_K(a.visualization);
    a.visualization = null
}

function gvjs_Ao(a) {
    Array.isArray(a.IN) && (gvjs_v(a.IN, function(b) {
        gvjs_8l(b)
    }), a.IN = null)
}
gvjs_.getContainer = function() {
    var a;
    if (!(a = this.container)) a: {
        var b = this.ZL;
        if (null == b) {
            a = this.getContainerId();
            if (null == a) {
                a = b;
                break a
            }
            b = gvjs_fk();
            var c = b.j(a);
            if (!b.ll(c)) throw Error("The container #" + a + " is not defined.");
            b = this.ZL = c
        }
        a = b
    }
    return a
};
gvjs_.getContainerId = function() {
    return this.containerId
};
gvjs_.q8 = function(a) {
    this.ZL = this.containerId = this.container = null;
    typeof a === gvjs_m ? this.containerId = a : this.container = a
};
gvjs_.setContainerId = function(a) {
    this.ZL = this.container = null;
    this.containerId = a
};
gvjs_.getDataSourceUrl = function() {
    return this.dataSourceUrl
};
gvjs_.setDataSourceUrl = function(a) {
    a !== this.dataSourceUrl && (gvjs_xo(this), this.dataSourceUrl = a)
};
gvjs_.getDataTable = function() {
    return this.dataTable
};
gvjs_.setDataTable = function(a) {
    this.dataTable = gvjs_8j(a)
};
gvjs_.getView = function() {
    return this.view
};
gvjs_.setView = function(a) {
    this.view = a
};
gvjs_.pushView = function(a) {
    Array.isArray(this.view) ? this.view.push(a) : this.view = null === this.view ? [a] : [this.view, a]
};
gvjs_.getQuery = function() {
    return this.query
};
gvjs_.setQuery = function(a) {
    this.query = a;
    gvjs_xo(this)
};
gvjs_.sendQuery = function(a, b) {
    b = void 0 === b ? !1 : b;
    gvjs_xo(this);
    var c = this.getDataSourceUrl() || "";
    c = this.IL = new gvjs_mo(c);
    var d = this.getRefreshInterval();
    d && b && c.setRefreshInterval(d);
    (b = this.getQuery()) && c.setQuery(b);
    c.send(a)
};
gvjs_.getRefreshInterval = function() {
    return this.refreshInterval
};
gvjs_.setRefreshInterval = function(a) {
    this.refreshInterval = a;
    gvjs_xo(this)
};
gvjs_.getCustomRequestHandler = function() {
    return this.xI
};
gvjs_.setCustomRequestHandler = function(a) {
    this.xI = a
};
gvjs_.getOption = function(a, b) {
    return gvjs_Bo(this.options, a, b)
};

function gvjs_Bo(a, b, c) {
    a = -1 === b.indexOf(".") ? a[b] : gvjs_Ke(b, a);
    return null != a ? a : void 0 !== c ? c : null
}
gvjs_.getOptions = function() {
    return this.options
};
gvjs_.setOption = function(a, b) {
    if (null == b) {
        if (b = this.options, null !== gvjs_Bo(b, a)) {
            var c = a.split(".");
            1 < c.length && (a = c.pop(), b = gvjs_Bo(b, c.join(".")));
            delete b[a]
        }
    } else gvjs_Co(this.options, a, b)
};

function gvjs_Co(a, b, c) {
    b = b.split(".");
    for (var d = 0; d < b.length; d++) {
        var e = b[d];
        d === b.length - 1 ? a[e] = c : (gvjs_Pe(a[e]) && a[e] !== Object.prototype[e] || (a[e] = {}), a = a[e])
    }
}
gvjs_.setOptions = function(a) {
    this.options = a || {}
};
gvjs_.getState = function() {
    return this.state
};
gvjs_.setState = function(a) {
    this.state = a || {}
};
gvjs_.b2 = function(a) {
    var b = this.getDataTable();
    if (b) this.KI(a, b);
    else if (null !== this.getDataSourceUrl()) b = this.kda.bind(this, a), a = gvjs_vo(b, this.gS.bind(this, a)), this.sendQuery(a, !0);
    else throw Error("Cannot draw chart: no data specified.");
};
gvjs_.kda = function(a, b) {
    if (b.isError()) {
        var c = b.getMessage(),
            d = b.getDetailedMessage();
        a = gvjs_Kk(a, b);
        gvjs_N(this, gvjs_7b, {
            id: a,
            message: c,
            detailedMessage: d
        })
    } else c = b.getDataTable(), this.KI(a, c)
};
gvjs_.KI = function(a, b) {
    var c = this.getType(),
        d = this.Mn || gvjs_pn(c);
    if (!d) throw Error("Invalid " + this.DG + " type: " + (c || String(this.Mn) || "unknown"));
    this.Mn = d;
    this.cL && (gvjs_yo(this), this.visualization = this.cL, this.cL = null);
    if (c = this.visualization && this.visualization.constructor === d) c = (c = this.visualization) && typeof c.getContainer === gvjs_c ? c.getContainer() === a : !1;
    c ? a = this.visualization : (gvjs_yo(this), a = new d(a));
    this.Xy && this.Xy !== a && typeof this.Xy.clearChart === gvjs_c && this.Xy.clearChart();
    this.Xy = a;
    gvjs_jda(this, a);
    this.D7 = b;
    d = gvjs_yg(this.getOptions());
    b = new gvjs_wo(this.DG, {
        chartType: this.getType(),
        dataTable: b,
        options: d,
        view: this.getView()
    });
    for (d = 0; d < this.J2.length; d++) this.J2[d](b);
    a.draw(b.getDataTable(), b.getOptions(), this.getState())
};
gvjs_.draw = function(a) {
    a && this.q8(a);
    a = this.getContainer();
    try {
        if (!this.Mn && (null == this.type || "" === this.type)) throw Error("The " + this.DG + " type is not defined.");
        if (this.Mn) var b = this.Mn;
        else {
            var c = this.getType();
            b = gvjs_pn(c)
        }
        if (b) this.b2(a);
        else {
            var d = this.b2.bind(this, a),
                e = gvjs_vo(d, this.gS.bind(this, a)),
                f = this.getPackages();
            if (null == f) {
                var g = this.getType();
                g = g.replace(gvjs_hc, "");
                g = g.replace(gvjs_dc, "");
                f = g in gvjs_rn ? gvjs_rn[g] : null;
                if (null == f) throw Error("Invalid visualization type: " + g);
            }
            typeof f ===
                gvjs_m && (f = [f]);
            b = {
                packages: f,
                callback: e
            };
            var h = gvjs_Ke(gvjs_ed);
            null === h && (h = "current");
            gvjs_zca(h, b)
        }
    } catch (k) {
        this.gS(a, k)
    }
};
gvjs_.gS = function(a, b) {
    b = b && "undefined" !== typeof b.message ? b.message : gvjs_7b;
    a = gvjs_eda(a, b);
    gvjs_N(this, gvjs_7b, {
        id: a,
        message: b
    })
};
gvjs_.setProperty = function(a, b) {
    a = a.split(".");
    if (0 < a.length) {
        var c = a.shift();
        if (typeof c !== gvjs_m) throw Error('Bad path component in "' + a + '"');
        if (c = gvjs_kda[c]) 0 === a.length ? c.set.apply(this, b) : (c = c.get.apply(this), gvjs_Co(c, a.join("."), b))
    }
};
var gvjs_kda = {
    name: {
        get: gvjs_wo.prototype.getName,
        set: gvjs_wo.prototype.yn
    },
    type: {
        get: gvjs_wo.prototype.getType,
        set: gvjs_wo.prototype.Gl
    },
    container: {
        get: gvjs_wo.prototype.getContainer,
        set: gvjs_wo.prototype.q8
    },
    containerId: {
        get: gvjs_wo.prototype.getContainerId,
        set: gvjs_wo.prototype.setContainerId
    },
    options: {
        get: gvjs_wo.prototype.getOptions,
        set: gvjs_wo.prototype.setOptions
    },
    state: {
        get: gvjs_wo.prototype.getState,
        set: gvjs_wo.prototype.setState
    },
    dataSourceUrl: {
        get: gvjs_wo.prototype.getDataSourceUrl,
        set: gvjs_wo.prototype.setDataSourceUrl
    },
    dataTable: {
        get: gvjs_wo.prototype.getDataTable,
        set: gvjs_wo.prototype.setDataTable
    },
    refreshInterval: {
        get: gvjs_wo.prototype.getRefreshInterval,
        set: gvjs_wo.prototype.setRefreshInterval
    },
    query: {
        get: gvjs_wo.prototype.getQuery,
        set: gvjs_wo.prototype.setQuery
    },
    view: {
        get: gvjs_wo.prototype.getView,
        set: gvjs_wo.prototype.setView
    }
};

function gvjs_hda(a) {
    var b = a.getDataTable();
    if (b) {
        var c = a.getType();
        a = a.getOptions();
        a: {
            var d = a.useFormatFromData;
            if (typeof d !== gvjs_Lb || d) {
                d = [gvjs_ie, gvjs_$d, "targetAxes.0", "targetAxes.1", gvjs_6b];
                for (var e = 0; e < d.length; e++)
                    if (gvjs_Ke(d[e] + gvjs_la, a)) {
                        d = !1;
                        break a
                    }
                d = !0
            } else d = !1
        }
        if (d)
            if (c === gvjs_ta) 3 > b.getNumberOfColumns() || (c = b.getColumnPattern(1), d = a.hAxis || {}, gvjs_sn(d, [c]), a.hAxis = d, b = b.getColumnPattern(2), c = a.vAxes || {}, d = c[0] || {}, gvjs_sn(d, [b]), c[0] = d, a.vAxes = c);
            else if (c !== gvjs_Ma) {
            d = a.vAxes || [{}, {}];
            e = a.hAxis || {};
            for (var f = d[0] || {}, g = d[1] || {}, h = [], k = [], l = b && b.getNumberOfColumns() || 0, m, n = 0; n < l; n++)
                if (b.getColumnType(n) === gvjs_f) {
                    m = b.getColumnPattern(n);
                    var p = n;
                    0 === p ? p = null : (p--, p = ((a.series || {})[p] || {}).targetAxisIndex || 0);
                    switch (p) {
                        case 0:
                            h.push(m);
                            break;
                        case 1:
                            k.push(m)
                    }
                }
            c === gvjs_sa ? gvjs_sn(e, h) : (gvjs_sn(f, h), gvjs_sn(g, k));
            0 < l && b.getColumnType(0) !== gvjs_m && (c = c === gvjs_sa ? f : e, m = b.getColumnPattern(0), gvjs_sn(c, [m]));
            d[0] = f;
            d[1] = g;
            a.vAxes = d;
            a.hAxis = e
        }
    }
}

function gvjs_fda(a) {
    var b = a.getDataTable(),
        c = a.getView();
    if (Array.isArray(c))
        for (var d = 0; d < c.length; d++) b = gvjs_dk(b, c[d]);
    else null !== c && (b = gvjs_dk(b, c));
    a.setView(null);
    a.setDataTable(b)
}

function gvjs_gda(a) {
    var b = a.getType();
    if ((b in gvjs_rn ? gvjs_rn[b] : null) === gvjs_Zb && b !== gvjs_db) {
        var c = a.getDataTable(),
            d = a.getOption(gvjs_id);
        if (null != d) {
            b = [{
                calc: d ? gvjs_5d : "emptyString",
                sourceColumn: 0,
                type: gvjs_m
            }];
            var e = d ? 1 : 0;
            for (d = c.getNumberOfColumns(); e < d; e++) b.push(e);
            c = new gvjs_G(c);
            c.setColumns(b);
            a.setOption(gvjs_id, null);
            a.setDataTable(c)
        }
    }
}

function gvjs_ida(a) {
    if (a.getOption(gvjs_yb)) {
        var b = a.getDataTable();
        a.getType() === gvjs_db && 2 === b.getNumberOfColumns() && (b = gvjs_lda(b), a.setDataTable(b), a.setOption("series.1.lineWidth", 2), a.setOption("series.1.pointSize", 0), a.setOption("series.1.visibleInLegend", !1));
        a.setOption(gvjs_yb, null)
    }
}

function gvjs_lda(a) {
    var b = gvjs_mda(a),
        c = new gvjs_G(a);
    c.setColumns([0, 1, {
        type: gvjs_f,
        calc: function(d, e) {
            d = gvjs_Do(a, e);
            return null !== d ? b.slope * d.x + b.intercept : null
        }
    }]);
    return c
}

function gvjs_mda(a) {
    var b = a.getNumberOfRows();
    for (var c = new gvjs_A, d = 0; d < b; d++) {
        var e = gvjs_Do(a, d);
        null !== e && (c.x += e.x, c.y += e.y)
    }
    b = new gvjs_A(c.x / b, c.y / b);
    for (e = d = c = 0; e < a.getNumberOfRows(); e++) {
        var f = gvjs_Do(a, e);
        null !== f && (f = new gvjs_A(f.x - b.x, f.y - b.y), c += f.x * f.y, d += f.x * f.x)
    }
    a = c / d || 1;
    return {
        slope: a,
        intercept: b.y - a * b.x
    }
}

function gvjs_Do(a, b) {
    var c = a.getValue(b, 0);
    a = a.getValue(b, 1);
    return null == c || null == a ? null : new gvjs_A(c, a)
};

function gvjs_O(a) {
    gvjs_wo.call(this, "control", a)
}
gvjs_r(gvjs_O, gvjs_wo);
gvjs_ = gvjs_O.prototype;
gvjs_.v3 = function() {
    return this.visualization
};
gvjs_.getControl = function() {
    return this.visualization
};
gvjs_.setControlType = gvjs_wo.prototype.Gl;
gvjs_.getControlType = gvjs_wo.prototype.getType;
gvjs_.setControlName = gvjs_wo.prototype.yn;
gvjs_.getControlName = gvjs_wo.prototype.getName;

function gvjs_Eo(a, b) {
    return new Set([].concat(gvjs_we(a)).filter(function(c) {
        return !b.has(c)
    }))
}

function gvjs_Fo(a, b) {
    return a.size === b.size && [].concat(gvjs_we(a)).every(function(c) {
        return b.has(c)
    })
}

function gvjs_Go() {
    this.hf = new Set;
    this.pi = new Set;
    this.Jh = new Set
}
gvjs_ = gvjs_Go.prototype;
gvjs_.clear = function() {
    this.hf = new Set;
    this.pi = new Set;
    this.Jh = new Set
};
gvjs_.clone = function() {
    var a = new gvjs_Go;
    a.hf = new Set(this.hf);
    a.pi = new Set(gvjs_Cg(this.pi));
    a.Jh = new Set(gvjs_Cg(this.Jh));
    return a
};
gvjs_.equals = function(a) {
    return gvjs_Fo(this.hf, a.hf) && gvjs_Fo(this.pi, a.pi) && gvjs_Fo(this.Jh, a.Jh)
};

function gvjs_Ho(a, b) {
    return gvjs_Cg(b === gvjs_Wd ? a.hf : a.pi).map(function(c) {
        return Number(c)
    })
}

function gvjs_Io(a) {
    return gvjs_Ho(a, gvjs_Wd)
}

function gvjs_Jo(a) {
    return gvjs_Cg(a.Jh).map(function(b) {
        b = b.split(",");
        return {
            row: Number(b[0]),
            column: Number(b[1])
        }
    })
}
gvjs_.getSelection = function() {
    var a = gvjs_Io(this),
        b = gvjs_Ho(this, gvjs_Vb),
        c = gvjs_Jo(this);
    return [].concat(gvjs_we(a.map(function(d) {
        var e = {};
        return e.row = d, e.column = null, e
    })), gvjs_we(b.map(function(d) {
        var e = {};
        return e.row = null, e.column = d, e
    })), gvjs_we(c.map(function(d) {
        var e = {};
        return e.row = d.row, e.column = d.column, e
    })))
};
gvjs_.contains = function(a, b) {
    return a === gvjs_Wd ? gvjs_Ko(this, b[0]) : a === gvjs_Vb ? gvjs_Lo(this, b[0]) : gvjs_Mo(this, b[0], b[1])
};

function gvjs_Ko(a, b) {
    return a.hf.has(String(b))
}

function gvjs_Lo(a, b) {
    return a.pi.has(String(b))
}

function gvjs_Mo(a, b, c) {
    return a.Jh.has(String(b + "," + c))
}
gvjs_.add = function(a, b) {
    if (this.contains(a, b)) return !1;
    a === gvjs_Wd ? this.hf.add(String(b[0])) : a === gvjs_Vb ? this.pi.add(String(b[0])) : this.Jh.add(String(b[0] + "," + b[1]));
    return !0
};
gvjs_.addRow = function(a) {
    return this.add(gvjs_Wd, [a])
};
gvjs_.addColumn = function(a) {
    return this.add(gvjs_Vb, [a])
};

function gvjs_No(a, b, c) {
    a.add("cell", [b, c])
}
gvjs_.removeRow = function(a) {
    if (!gvjs_Ko(this, a)) return !1;
    this.hf.delete(String(a));
    return !0
};
gvjs_.removeColumn = function(a) {
    if (!gvjs_Lo(this, a)) return !1;
    this.pi.delete(String(a));
    return !0
};
gvjs_.oF = function(a, b) {
    gvjs_Mo(this, a, b) && this.Jh.delete(String(a + "," + b))
};
gvjs_.setSelection = function(a) {
    var b = new Set,
        c = new Set,
        d = new Set;
    a || (a = []);
    for (var e = 0; e < a.length; e++) {
        var f = a[e];
        null != f.row && null != f.column ? d.add("" + f.row + "," + f.column) : null != f.row ? b.add(String(f.row)) : null != f.column && c.add(String(f.column))
    }
    var g = gvjs_Eo(b, this.hf),
        h = gvjs_Eo(c, this.pi),
        k = gvjs_Eo(d, this.Jh);
    a = gvjs_Eo(this.hf, b);
    e = gvjs_Eo(this.pi, c);
    f = gvjs_Eo(this.Jh, d);
    this.hf = b;
    this.pi = c;
    this.Jh = d;
    b = new gvjs_Go;
    b.hf = g;
    b.pi = h;
    b.Jh = k;
    c = new gvjs_Go;
    c.hf = a;
    c.pi = e;
    c.Jh = f;
    return new gvjs_nda(b, c)
};

function gvjs_nda(a, b) {
    this.Xw = a;
    this.qk = b
};

function gvjs_Oo(a) {
    gvjs_L.call(this);
    this.xf = new gvjs_dn;
    this.wd = new gvjs_Go;
    this.FV = {};
    this.yx = {};
    this.KD = null;
    this.Vy = [];
    this.ad = new gvjs_$l(this, a);
    this.Lj = null
}
gvjs_r(gvjs_Oo, gvjs_L);
gvjs_ = gvjs_Oo.prototype;
gvjs_.getSelection = function() {
    return this.wd.getSelection()
};
gvjs_.J = function() {
    this.clear();
    gvjs_L.prototype.J.call(this)
};
gvjs_.clear = function() {
    gvjs_v(this.Vy, function(a) {
        gvjs_8l(a)
    });
    this.Vy = [];
    this.Lj = null;
    this.xf.clear()
};
gvjs_.bind = function(a, b) {
    if (gvjs_Po(a) && typeof a.getControl === gvjs_c)
        if (gvjs_Po(b)) {
            var c = gvjs_Qe(a);
            if (gvjs_Qe(b) == c) this.ad.addError("Cannot bind a control to itself.");
            else {
                c = [];
                this.xf.contains(a) || c.push(a);
                this.xf.contains(b) || c.push(b);
                gvjs_en(this.xf, a, b);
                try {
                    gvjs_xca(this.xf);
                    var d = !0
                } catch (e) {
                    d = !1
                }
                d ? d = !0 : (this.ad.addError("The requested control and participant cannot be bound together, as this would introduce a dependency cycle"), d = !1);
                if (d)
                    for (a = 0; a < c.length; a++) b = c[a], this.Vy.push(gvjs_2l(b,
                        gvjs_3d, this.fga.bind(this, b))), this.Vy.push(gvjs_2l(b, gvjs_h, this.dga.bind(this, b))), this.Vy.push(gvjs_2l(b, gvjs_7b, this.cga.bind(this, b))), b.getChart && this.Vy.push(gvjs_2l(b, gvjs_k, this.ega.bind(this, b)));
                else c = this.xf, gvjs_fn(c, a, b) && (gvjs_ln(a, b, c.cp), gvjs_ln(b, a, c.Iq), gvjs_mn(c, a) && c.Xf.delete(gvjs_gn(a)), gvjs_mn(c, b) && c.Xf.delete(gvjs_gn(b)))
            }
        } else this.ad.addError(b + " does not fit either the Control or Visualization specification.");
    else this.ad.addError(a + " does not fit the Control specification.")
};
gvjs_.draw = function(a) {
    if (a && !this.xf.isEmpty()) {
        this.KD = gvjs_8j(a);
        this.Lj = new gvjs_Qo(this);
        a = gvjs_jn(this.xf);
        for (var b = 0; b < a.length; b++) a[b].setDataTable(this.KD);
        this.Lj.start(a)
    }
};

function gvjs_Po(a) {
    return gvjs_Pe(a) && typeof a.draw === gvjs_c && typeof a.setDataTable === gvjs_c
}
gvjs_.fga = function(a) {
    this.Lj = this.Lj || new gvjs_Qo(this);
    gvjs_Ro(this.Lj, a)
};
gvjs_.dga = function(a) {
    var b;
    if (b = gvjs_Po(a) && typeof a.getControl === gvjs_c) {
        b = a.getControl();
        if (gvjs_Pe(b))
            if (typeof b.W_ === gvjs_c) a: {
                b = this.xf;
                for (var c = b.gJ(a), d = c.Wb(), e = 0; e < d.length; e++) {
                    var f = d[e];
                    if (f != a && gvjs_in(c, f).length != gvjs_in(b, f).length) {
                        b = !1;
                        break a
                    }
                }
                b = !0
            }
        else b = typeof b.apply === gvjs_c ? !0 : !1;
        else b = !1;
        b = !b
    }
    b ? this.ad.addError(a + " does not fit the Control specification while handling 'ready' event.") : (this.Lj = this.Lj || new gvjs_Qo(this), gvjs_Ro(this.Lj, a))
};

function gvjs_So(a, b) {
    var c = b.row;
    b = b.column;
    if (null != c || null != b) null == c ? a.wd.removeColumn(b) : null == b ? a.wd.removeRow(c) : a.wd.oF(c, b)
}
gvjs_.ega = function(a) {
    var b = gvjs_Qe(a),
        c = a.getChart().getSelection();
    this.FV[b] || (this.FV[b] = new gvjs_Go);
    c = gvjs_pf(gvjs_w(c, function(e) {
        for (var f = a.getDataTable(); f !== this.KD;) {
            var g = f;
            e = {
                row: null == e.row ? null : g.getTableRowIndex(e.row),
                column: null == e.column ? null : g.getTableRowIndex(e.column)
            };
            0 > e.row && (e.row = null);
            0 > e.column && (e.column = null);
            if (null == e.row && null == e.column) return null;
            f = f.getDataTable()
        }
        return e
    }, this), function(e) {
        return null != e
    });
    var d = this.FV[b].setSelection(c);
    c = d.Xw.getSelection();
    d = d.qk.getSelection();
    gvjs_v(c, function(e) {
        var f = e.row + "," + e.column;
        this.yx[f] || (this.yx[f] = new Set);
        this.yx[f].add(b);
        f = e.row;
        e = e.column;
        if (null != f || null != e) null == f ? this.wd.addColumn(e) : null == e ? this.wd.addRow(f) : gvjs_No(this.wd, f, e)
    }, this);
    gvjs_v(d, function(e) {
        var f = e.row + "," + e.column;
        this.yx[f] ? (this.yx[f].delete(b), 0 === this.yx[f].size && gvjs_So(this, e)) : gvjs_So(this, e)
    }, this)
};
gvjs_.cga = function(a) {
    this.Lj && this.Lj.handleError(a)
};

function gvjs_oda(a, b) {
    b ? gvjs_N(a, gvjs_h, null) : a.ad.addError("One or more participants failed to draw()");
    a.Lj = null
}

function gvjs_pda(a, b) {
    if (1 == b.length) return b[0];
    var c = b[0],
        d = gvjs_yf(b, 1),
        e = new Set(gvjs_To(a, d[0]));
    for (b = 1; b < d.length && (e = gvjs_Dg(e, new Set(gvjs_To(a, d[b]))), 0 !== e.size); b++);
    b = [];
    for (var f = 0; f < c.getNumberOfRows(); f++) e.has(gvjs_Uo(a, c, f)) && b.push(f);
    e = new Set(gvjs_Vo(a, d[0]));
    for (f = 1; f < d.length && (e = gvjs_Dg(e, new Set(gvjs_Vo(a, d[f]))), 0 !== e.size); f++);
    d = [];
    for (f = 0; f < c.getNumberOfColumns(); f++) e.has(gvjs_Wo(a, c, f)) && d.push(f);
    a = new gvjs_G(c);
    a.setRows(b);
    a.setColumns(d);
    return a
}

function gvjs_To(a, b) {
    for (var c = [], d = 0; d < b.getNumberOfRows(); d++) {
        var e = gvjs_Uo(a, b, d);
        null != e && c.push(e)
    }
    return c
}

function gvjs_Uo(a, b, c) {
    for (; b !== a.KD;) c = b.getTableRowIndex(c), b = b.getDataTable();
    return c
}

function gvjs_Vo(a, b) {
    for (var c = [], d = 0; d < b.getNumberOfColumns(); d++) {
        var e = gvjs_Wo(a, b, d);
        null != e && c.push(e)
    }
    return c
}

function gvjs_Wo(a, b, c) {
    for (; b !== a.KD && -1 !== c;) c = b.getTableColumnIndex(c), b = b.getDataTable(); - 1 == c && (c = null);
    return c
}

function gvjs_Qo(a) {
    this.pm = a;
    this.xf = a.xf.clone();
    this.Gn = {};
    a = this.xf.Wb();
    for (var b = 0; b < a.length; b++) this.Gn[gvjs_Qe(a[b])] = gvjs_h
}
gvjs_Qo.prototype.start = function(a) {
    gvjs_Qo.prototype.U5.apply(this, a);
    for (var b = 0; b < a.length; b++) this.th(a[b])
};

function gvjs_Ro(a, b) {
    if (a.xf.contains(b)) {
        switch (a.Gn[gvjs_Qe(b)]) {
            case "pending":
                break;
            case gvjs_7b:
                break;
            case "drawing":
                a.Gn[gvjs_Qe(b)] = gvjs_h;
                gvjs_Xo(a, b);
                break;
            case gvjs_h:
                a.U5(b);
                gvjs_Xo(a, b);
                break;
            default:
                gvjs_Qe(b)
        }
        gvjs_Yo(a)
    }
}
gvjs_Qo.prototype.handleError = function(a) {
    if (this.xf.contains(a)) {
        switch (this.Gn[gvjs_Qe(a)]) {
            case "pending":
            case gvjs_h:
            case gvjs_7b:
                break;
            case "drawing":
                this.Gn[gvjs_Qe(a)] = gvjs_7b;
                a = this.xf.gJ(a).Wb();
                for (var b = 1; b < a.length; b++) this.Gn[gvjs_Qe(a[b])] = gvjs_7b;
                break;
            default:
                gvjs_Qe(a)
        }
        gvjs_Yo(this)
    }
};

function gvjs_Yo(a) {
    var b = 0;
    gvjs_Rg(a.Gn, function(c) {
        if (c == gvjs_7b) b++;
        else if (c != gvjs_h) return !1;
        return !0
    }, a) && gvjs_oda(a.pm, 0 == b)
}
gvjs_Qo.prototype.U5 = function(a) {
    for (var b = gvjs_dn.prototype.gJ.apply(this.xf, arguments), c = b.Wb(), d = 0; d < c.length; d++) {
        var e = c[d];
        if (!b.contains(e) || b.Iq.has(gvjs_gn(e))) this.Gn[gvjs_Qe(c[d])] = "pending"
    }
};
gvjs_Qo.prototype.th = function(a) {
    this.Gn[gvjs_Qe(a)] = "drawing";
    var b = (0, gvjs_J.createProtectedCallback)(function() {
        a.draw()
    }, this.handleError.bind(this, a));
    gvjs_yl(b)
};

function gvjs_Xo(a, b) {
    var c = a.xf.getChildren(b);
    if (c) {
        if ("undefined" === typeof b.getControl) throw Error("Dashboard participant is not a control.");
        b = b.getControl();
        b.r8 && b.r8(c);
        for (b = 0; b < c.length; b++) {
            var d = c[b];
            a: {
                var e = a;
                var f = gvjs_in(e.xf, d);
                if (f)
                    for (var g = 0; g < f.length; g++)
                        if (e.Gn[gvjs_Qe(f[g])] != gvjs_h) {
                            e = !1;
                            break a
                        }
                e = !0
            }
            e && (e = gvjs_qda(a, d), d.setDataTable(e), a.th(d))
        }
    }
}

function gvjs_qda(a, b) {
    b = gvjs_w(gvjs_in(a.xf, b), function(c) {
        c = c.getControl();
        if (typeof c.apply === gvjs_c) return c.apply.call(c)
    });
    return gvjs_pda(a.pm, b)
};

function gvjs_Zo(a) {
    gvjs_L.call(this);
    this.nb = a;
    this.pm = new gvjs_Oo(this.nb);
    gvjs_K(this.hV);
    this.hV = gvjs_2l(this.pm, gvjs_h, this.P3.bind(this, gvjs_h));
    gvjs_K(this.iR);
    this.iR = gvjs_2l(this.pm, gvjs_7b, this.P3.bind(this, gvjs_7b))
}
gvjs_r(gvjs_Zo, gvjs_L);
gvjs_ = gvjs_Zo.prototype;
gvjs_.J = function() {
    this.clear();
    gvjs_K(this.hV);
    gvjs_K(this.iR);
    gvjs_K(this.pm);
    gvjs_L.prototype.J.call(this)
};
gvjs_.clear = function() {
    gvjs_8l(this.hV);
    gvjs_8l(this.iR);
    this.pm.clear()
};
gvjs_.bind = function(a, b) {
    Array.isArray(a) || (a = [a]);
    Array.isArray(b) || (b = [b]);
    for (var c = 0; c < a.length; c++)
        for (var d = 0; d < b.length; d++) this.pm.bind(a[c], b[d]);
    return this
};
gvjs_.draw = function(a) {
    this.pm.draw(a)
};
gvjs_.getContainer = function() {
    return this.nb
};
gvjs_.getSelection = function() {
    return this.pm.getSelection()
};
gvjs_.P3 = function(a, b) {
    gvjs_N(this, a, b || null)
};

function gvjs__o(a, b, c, d) {
    this.query = a;
    this.container = d;
    this.Xd = this.dataTable = this.A1 = this.tQ = this.GQ = null;
    this.options = c || {};
    this.visualization = b;
    d && (this.Xd = this.GQ = gvjs_rda(d));
    if (!(b && "draw" in b) || typeof b.draw !== gvjs_c) throw Error("Visualization must have a draw method.");
}

function gvjs_rda(a) {
    return function(b) {
        (0, gvjs_J.removeAll)(a);
        var c = b.isError();
        c && gvjs_Kk(a, b);
        return !c
    }
}
gvjs_ = gvjs__o.prototype;
gvjs_.setOptions = function(a) {
    this.options = a || {}
};
gvjs_.draw = function() {
    this.visualization && this.visualization.draw(this.dataTable, this.options)
};
gvjs_.ila = function(a) {
    var b = this.container;
    this.Xd = a ? a : b ? this.Xd = this.GQ : null
};
gvjs_.sendAndDraw = function() {
    var a = this;
    if (!this.Xd) throw Error("If no container was supplied, a custom error handler must be supplied instead.");
    this.query.send(function(b) {
        var c = a.tQ;
        c && c(b);
        a.yy(b);
        (c = a.A1) && c(b)
    })
};
gvjs_.yy = function(a) {
    var b = this.Xd;
    b(a) && this.visualization && (this.dataTable = a.getDataTable(), this.visualization.draw(this.dataTable, this.options))
};
gvjs_.setCustomResponseHandler = function(a) {
    if (null == a) this.tQ = null;
    else {
        if (typeof a !== gvjs_c) throw Error(gvjs_Ba);
        this.tQ = a
    }
};
gvjs_.setCustomPostResponseHandler = function(a) {
    if (null != a) {
        if (typeof a !== gvjs_c) throw Error("Custom post response handler must be a function.");
        this.A1 = a
    }
};
gvjs_.abort = function() {
    this.query.abort()
};

function gvjs_P(a, b) {
    this.Hi = null;
    if (a instanceof gvjs_rg) this.Sb = a;
    else if (null == a) this.Sb = new gvjs_F;
    else {
        this.data = a;
        a: {
            if (b && (a = b ? gvjs_zg(b, this.data) : this.data, Array.isArray(a))) {
                b = a[0];
                a = Array.isArray(b) ? gvjs_9j(a) : typeof b === gvjs_g ? gvjs_$j(a) : gvjs_cba(a);
                break a
            }
            a = new gvjs_F
        }
        this.Sb = a
    }
}
gvjs_r(gvjs_P, gvjs_rg);
gvjs_ = gvjs_P.prototype;
gvjs_.getData = function() {
    return this.data
};
gvjs_.getDistinctValues = function(a) {
    return this.Sb.getDistinctValues(a)
};
gvjs_.getNumberOfRows = function() {
    return this.Sb.getNumberOfRows()
};
gvjs_.getNumberOfColumns = function() {
    return this.Sb.getNumberOfColumns()
};
gvjs_.Hm = gvjs_p(12);
gvjs_.getColumnId = function(a) {
    return this.Sb.getColumnId(a)
};
gvjs_.getColumnLabel = function(a) {
    return this.Sb.getColumnLabel(a)
};
gvjs_.getColumnPattern = function(a) {
    return this.Sb.getColumnPattern(a)
};
gvjs_.getColumnRole = function(a) {
    return this.Sb.getColumnRole(a)
};
gvjs_.getColumnType = function(a) {
    return this.Sb.getColumnType(a)
};
gvjs_.getValue = function(a, b) {
    return this.Sb.getValue(a, b)
};
gvjs_.mg = function(a, b) {
    return this.Sb.mg(a, b)
};
gvjs_.getFormattedValue = function(a, b) {
    return this.Sb.getFormattedValue(a, b)
};
gvjs_.setFormattedValue = function(a, b, c) {
    this.Sb.setFormattedValue(a, b, c)
};
gvjs_.format = function(a, b) {
    this.Sb.format(a, b)
};
gvjs_.getColumnRange = function(a) {
    return this.Sb.getColumnRange(a)
};
gvjs_.getProperty = function(a, b, c) {
    return this.Sb.getProperty(a, b, c)
};
gvjs_.setProperty = function(a, b, c, d) {
    this.Sb.setProperty(a, b, c, d)
};
gvjs_.getProperties = function(a, b) {
    return this.Sb.getProperties(a, b)
};
gvjs_.getTableProperty = function(a) {
    return this.Sb.getTableProperty(a)
};
gvjs_.getTableProperties = function() {
    return this.Sb.getTableProperties()
};
gvjs_.getRowProperty = function(a, b) {
    return this.Sb.getRowProperty(a, b)
};
gvjs_.getRowProperties = function(a) {
    return this.Sb.getRowProperties(a)
};
gvjs_.getColumnProperty = function(a, b) {
    return this.Sb.getColumnProperty(a, b)
};
gvjs_.getColumnProperties = function(a) {
    return this.Sb.getColumnProperties(a)
};
gvjs_.getSortedRows = function(a) {
    return this.Sb.getSortedRows(a)
};
gvjs_.getFilteredRows = function(a) {
    return this.Sb.getFilteredRows(a)
};
gvjs_.getTableRowIndex = function(a) {
    return this.Sb.getTableRowIndex(a)
};
gvjs_.getUnderlyingTableColumnIndex = function(a) {
    return this.Sb.getUnderlyingTableColumnIndex(a)
};
gvjs_.getUnderlyingTableRowIndex = function(a) {
    return this.Sb.getUnderlyingTableRowIndex(a)
};
gvjs_.toDataTable = function() {
    return this.Sb.toDataTable()
};
gvjs_.toPOJO = function() {
    return this.Sb.toPOJO()
};
gvjs_.toJSON = function() {
    return this.Sb.toJSON()
};

function gvjs_0o(a, b) {
    this.yka = a;
    this.dataSourceUrl = b
}
gvjs_0o.prototype.send = function(a) {
    this.qs = a;
    this.sendQuery()
};
gvjs_0o.prototype.MO = function(a) {
    var b = {},
        c, d = this.Tu;
    d && (c = "sig:" + d);
    c && (b.tqx = c, a = gvjs_no(a, b));
    return a
};
gvjs_0o.prototype.sendQuery = function() {
    var a = this,
        b = this.MO(this.dataSourceUrl);
    this.yka.call(this, function(c) {
        a.yy(c)
    }, b)
};
gvjs_0o.prototype.yy = function(a) {
    a = new gvjs_Gk(a);
    if (!a.containsReason("not_modified")) {
        a.isError() ? this.Tu = null : this.Tu = a.getDataSignature();
        var b = this.qs;
        if (!b) throw Error("Response handler undefined.");
        b.call(b, a)
    }
};
gvjs_t(gvjs_0c, gvjs_mo);
gvjs_mo.prototype.makeRequest = gvjs_mo.prototype.makeRequest;
gvjs_mo.prototype.setRefreshInterval = gvjs_mo.prototype.setRefreshInterval;
gvjs_mo.prototype.setQuery = gvjs_mo.prototype.setQuery;
gvjs_mo.prototype.send = gvjs_mo.prototype.send;
gvjs_mo.prototype.setRefreshable = gvjs_mo.prototype.setRefreshable;
gvjs_mo.prototype.setTimeout = gvjs_mo.prototype.setTimeout;
gvjs_mo.prototype.setHandlerType = gvjs_mo.prototype.mla;
gvjs_mo.prototype.setHandlerParameter = gvjs_mo.prototype.t8;
gvjs_mo.setResponse = gvjs_oo;
gvjs_mo.prototype.abort = gvjs_mo.prototype.abort;
gvjs_mo.prototype.clear = gvjs_mo.prototype.clear;
gvjs_t("google.visualization.CustomQuery", gvjs_0o);
gvjs_0o.prototype.send = gvjs_0o.prototype.send;
gvjs_t("google.visualization.QueryResponse", gvjs_Gk);
gvjs_Gk.prototype.getDataTable = gvjs_Gk.prototype.getDataTable;
gvjs_Gk.prototype.isError = gvjs_Gk.prototype.isError;
gvjs_Gk.prototype.hasWarning = gvjs_Gk.prototype.hasWarning;
gvjs_Gk.prototype.getReasons = gvjs_Gk.prototype.getReasons;
gvjs_Gk.prototype.getMessage = gvjs_Gk.prototype.getMessage;
gvjs_Gk.prototype.getDetailedMessage = gvjs_Gk.prototype.getDetailedMessage;
gvjs_Gk.addErrorFromQueryResponse = gvjs_Kk;
gvjs_t("google.visualization.Data", gvjs_P);
gvjs_P.prototype.getColumnId = gvjs_P.prototype.getColumnId;
gvjs_P.prototype.getColumnIndex = gvjs_P.prototype.getColumnIndex;
gvjs_P.prototype.getColumnLabel = gvjs_P.prototype.getColumnLabel;
gvjs_P.prototype.getColumnPattern = gvjs_P.prototype.getColumnPattern;
gvjs_P.prototype.getColumnProperty = gvjs_P.prototype.getColumnProperty;
gvjs_P.prototype.getColumnProperty = gvjs_P.prototype.getColumnProperty;
gvjs_P.prototype.getColumnProperties = gvjs_P.prototype.getColumnProperties;
gvjs_P.prototype.getColumnRange = gvjs_P.prototype.getColumnRange;
gvjs_P.prototype.getColumnRole = gvjs_P.prototype.getColumnRole;
gvjs_P.prototype.getColumnType = gvjs_P.prototype.getColumnType;
gvjs_P.prototype.getDistinctValues = gvjs_P.prototype.getDistinctValues;
gvjs_P.prototype.getFilteredRows = gvjs_P.prototype.getFilteredRows;
gvjs_P.prototype.getFormattedValue = gvjs_P.prototype.getFormattedValue;
gvjs_P.prototype.getNumberOfColumns = gvjs_P.prototype.getNumberOfColumns;
gvjs_P.prototype.getNumberOfRows = gvjs_P.prototype.getNumberOfRows;
gvjs_P.prototype.getProperties = gvjs_P.prototype.getProperties;
gvjs_P.prototype.getProperty = gvjs_P.prototype.getProperty;
gvjs_P.prototype.getRowProperty = gvjs_P.prototype.getRowProperty;
gvjs_P.prototype.getRowProperties = gvjs_P.prototype.getRowProperties;
gvjs_P.prototype.getSortedRows = gvjs_P.prototype.getSortedRows;
gvjs_P.prototype.getUnderlyingTableColumnIndex = gvjs_P.prototype.getUnderlyingTableColumnIndex;
gvjs_P.prototype.getTableRowIndex = gvjs_P.prototype.getTableRowIndex;
gvjs_P.prototype.getUnderlyingTableRowIndex = gvjs_P.prototype.getUnderlyingTableRowIndex;
gvjs_P.prototype.getTableProperty = gvjs_P.prototype.getTableProperty;
gvjs_P.prototype.getTableProperties = gvjs_P.prototype.getTableProperties;
gvjs_P.prototype.getValue = gvjs_P.prototype.getValue;
gvjs_P.prototype.toDataTable = gvjs_P.prototype.toDataTable;
gvjs_P.prototype.toJSON = gvjs_P.prototype.toJSON;
gvjs_t("google.visualization.DataTable", gvjs_F);
gvjs_F.prototype.addColumn = gvjs_F.prototype.addColumn;
gvjs_F.prototype.addRow = gvjs_F.prototype.addRow;
gvjs_F.prototype.addRows = gvjs_F.prototype.addRows;
gvjs_F.prototype.clone = gvjs_F.prototype.clone;
gvjs_F.prototype.getColumnId = gvjs_F.prototype.getColumnId;
gvjs_F.prototype.getColumnIndex = gvjs_F.prototype.getColumnIndex;
gvjs_F.prototype.getColumnLabel = gvjs_F.prototype.getColumnLabel;
gvjs_F.prototype.getColumnPattern = gvjs_F.prototype.getColumnPattern;
gvjs_F.prototype.getColumnProperty = gvjs_F.prototype.getColumnProperty;
gvjs_F.prototype.getColumnProperties = gvjs_F.prototype.getColumnProperties;
gvjs_F.prototype.getColumnRange = gvjs_F.prototype.getColumnRange;
gvjs_F.prototype.getColumnRole = gvjs_F.prototype.getColumnRole;
gvjs_F.prototype.getColumnType = gvjs_F.prototype.getColumnType;
gvjs_F.prototype.getDistinctValues = gvjs_F.prototype.getDistinctValues;
gvjs_F.prototype.getFilteredRows = gvjs_F.prototype.getFilteredRows;
gvjs_F.prototype.getFormattedValue = gvjs_F.prototype.getFormattedValue;
gvjs_F.prototype.getNumberOfColumns = gvjs_F.prototype.getNumberOfColumns;
gvjs_F.prototype.getNumberOfRows = gvjs_F.prototype.getNumberOfRows;
gvjs_F.prototype.getProperties = gvjs_F.prototype.getProperties;
gvjs_F.prototype.getProperty = gvjs_F.prototype.getProperty;
gvjs_F.prototype.getRowProperty = gvjs_F.prototype.getRowProperty;
gvjs_F.prototype.getRowProperties = gvjs_F.prototype.getRowProperties;
gvjs_F.prototype.getSortedRows = gvjs_F.prototype.getSortedRows;
gvjs_F.prototype.getTableProperty = gvjs_F.prototype.getTableProperty;
gvjs_F.prototype.getTableProperties = gvjs_F.prototype.getTableProperties;
gvjs_F.prototype.getUnderlyingTableColumnIndex = gvjs_F.prototype.getUnderlyingTableColumnIndex;
gvjs_F.prototype.getUnderlyingTableRowIndex = gvjs_F.prototype.getUnderlyingTableRowIndex;
gvjs_F.prototype.getValue = gvjs_F.prototype.getValue;
gvjs_F.prototype.insertColumn = gvjs_F.prototype.insertColumn;
gvjs_F.prototype.insertRows = gvjs_F.prototype.insertRows;
gvjs_F.prototype.removeColumn = gvjs_F.prototype.removeColumn;
gvjs_F.prototype.removeColumns = gvjs_F.prototype.removeColumns;
gvjs_F.prototype.removeRow = gvjs_F.prototype.removeRow;
gvjs_F.prototype.removeRows = gvjs_F.prototype.removeRows;
gvjs_F.prototype.setCell = gvjs_F.prototype.setCell;
gvjs_F.prototype.setColumnLabel = gvjs_F.prototype.setColumnLabel;
gvjs_F.prototype.setColumnProperties = gvjs_F.prototype.setColumnProperties;
gvjs_F.prototype.setColumnProperty = gvjs_F.prototype.setColumnProperty;
gvjs_F.prototype.setFormattedValue = gvjs_F.prototype.setFormattedValue;
gvjs_F.prototype.setProperties = gvjs_F.prototype.setProperties;
gvjs_F.prototype.setProperty = gvjs_F.prototype.setProperty;
gvjs_F.prototype.setRowProperties = gvjs_F.prototype.setRowProperties;
gvjs_F.prototype.setRowProperty = gvjs_F.prototype.setRowProperty;
gvjs_F.prototype.setTableProperties = gvjs_F.prototype.setTableProperties;
gvjs_F.prototype.setTableProperty = gvjs_F.prototype.setTableProperty;
gvjs_F.prototype.setValue = gvjs_F.prototype.setValue;
gvjs_F.prototype.sort = gvjs_F.prototype.sort;
gvjs_F.prototype.toJSON = gvjs_F.prototype.toJSON;
gvjs_t("google.visualization.arrayToDataTable", gvjs_9j);
gvjs_t("google.visualization.DataView", gvjs_G);
gvjs_G.fromJSON = gvjs_dk;
gvjs_G.prototype.getColumnId = gvjs_G.prototype.getColumnId;
gvjs_G.prototype.getColumnIndex = gvjs_G.prototype.getColumnIndex;
gvjs_G.prototype.getColumnLabel = gvjs_G.prototype.getColumnLabel;
gvjs_G.prototype.getColumnPattern = gvjs_G.prototype.getColumnPattern;
gvjs_G.prototype.getColumnProperty = gvjs_G.prototype.getColumnProperty;
gvjs_G.prototype.getColumnProperty = gvjs_G.prototype.getColumnProperty;
gvjs_G.prototype.getColumnProperties = gvjs_G.prototype.getColumnProperties;
gvjs_G.prototype.getColumnRange = gvjs_G.prototype.getColumnRange;
gvjs_G.prototype.getColumnRole = gvjs_G.prototype.getColumnRole;
gvjs_G.prototype.getColumnType = gvjs_G.prototype.getColumnType;
gvjs_G.prototype.getDistinctValues = gvjs_G.prototype.getDistinctValues;
gvjs_G.prototype.getFilteredRows = gvjs_G.prototype.getFilteredRows;
gvjs_G.prototype.getFormattedValue = gvjs_G.prototype.getFormattedValue;
gvjs_G.prototype.getNumberOfColumns = gvjs_G.prototype.getNumberOfColumns;
gvjs_G.prototype.getNumberOfRows = gvjs_G.prototype.getNumberOfRows;
gvjs_G.prototype.getProperties = gvjs_G.prototype.getProperties;
gvjs_G.prototype.getProperty = gvjs_G.prototype.getProperty;
gvjs_G.prototype.getRowProperty = gvjs_G.prototype.getRowProperty;
gvjs_G.prototype.getRowProperties = gvjs_G.prototype.getRowProperties;
gvjs_G.prototype.getSortedRows = gvjs_G.prototype.getSortedRows;
gvjs_G.prototype.getTableColumnIndex = gvjs_G.prototype.getTableColumnIndex;
gvjs_G.prototype.getUnderlyingTableColumnIndex = gvjs_G.prototype.getUnderlyingTableColumnIndex;
gvjs_G.prototype.getTableRowIndex = gvjs_G.prototype.getTableRowIndex;
gvjs_G.prototype.getUnderlyingTableRowIndex = gvjs_G.prototype.getUnderlyingTableRowIndex;
gvjs_G.prototype.getTableProperty = gvjs_G.prototype.getTableProperty;
gvjs_G.prototype.getTableProperties = gvjs_G.prototype.getTableProperties;
gvjs_G.prototype.getValue = gvjs_G.prototype.getValue;
gvjs_G.prototype.getViewColumnIndex = gvjs_G.prototype.getViewColumnIndex;
gvjs_G.prototype.getViewColumns = gvjs_G.prototype.getViewColumns;
gvjs_G.prototype.getViewRowIndex = gvjs_G.prototype.getViewRowIndex;
gvjs_G.prototype.getViewRows = gvjs_G.prototype.getViewRows;
gvjs_G.prototype.hideColumns = gvjs_G.prototype.hideColumns;
gvjs_G.prototype.hideRows = gvjs_G.prototype.hideRows;
gvjs_G.prototype.setColumns = gvjs_G.prototype.setColumns;
gvjs_G.prototype.setRows = gvjs_G.prototype.setRows;
gvjs_G.prototype.toDataTable = gvjs_G.prototype.toDataTable;
gvjs_G.prototype.toJSON = gvjs_G.prototype.toJSON;
gvjs_t("google.visualization.errors", gvjs_J);
gvjs_J.addError = gvjs_J.addError;
gvjs_J.removeAll = gvjs_J.removeAll;
gvjs_J.removeError = gvjs_J.removeError;
gvjs_J.getContainer = gvjs_J.getContainer;
gvjs_J.createProtectedCallback = gvjs_J.createProtectedCallback;
gvjs_J.addErrorFromQueryResponse = gvjs_Kk;
gvjs_t("google.visualization.events.addListener", gvjs_2l);
gvjs_t("google.visualization.events.addOneTimeListener", gvjs_6l);
gvjs_t("google.visualization.events.trigger", gvjs_N);
gvjs_t("google.visualization.events.removeListener", gvjs_8l);
gvjs_t("google.visualization.events.removeAllListeners", gvjs_9l);
gvjs_t("google.visualization.QueryWrapper", gvjs__o);
gvjs__o.prototype.setOptions = gvjs__o.prototype.setOptions;
gvjs__o.prototype.draw = gvjs__o.prototype.draw;
gvjs__o.prototype.setCustomErrorHandler = gvjs__o.prototype.ila;
gvjs__o.prototype.sendAndDraw = gvjs__o.prototype.sendAndDraw;
gvjs__o.prototype.setCustomPostResponseHandler = gvjs__o.prototype.setCustomPostResponseHandler;
gvjs__o.prototype.setCustomResponseHandler = gvjs__o.prototype.setCustomResponseHandler;
gvjs__o.prototype.abort = gvjs__o.prototype.abort;
gvjs_t("google.visualization.datautils.arrayToDataTable", gvjs_9j);
gvjs_t("google.visualization.datautils.compareValues", gvjs_Sj);
gvjs_t("google.visualization.dataTableToCsv", function(a) {
    for (var b = "", c = 0; c < a.getNumberOfRows(); c++) {
        for (var d = 0; d < a.getNumberOfColumns(); d++) {
            0 < d && (b += ",");
            var e = a.getFormattedValue(c, d);
            e = e.replace(RegExp('"', "g"), '""');
            var f = -1 !== e.indexOf(","),
                g = -1 !== e.indexOf("\n"),
                h = -1 !== e.indexOf('"');
            if (f || g || h) e = '"' + e + '"';
            b += e
        }
        b += "\n"
    }
    return b
});

function gvjs_Q(a) {
    gvjs_wo.call(this, gvjs_Ob, a)
}
gvjs_r(gvjs_Q, gvjs_wo);
gvjs_ = gvjs_Q.prototype;
gvjs_.getChart = function() {
    return this.visualization
};
gvjs_.setChart = function(a) {
    a !== this.visualization && (this.cL = a)
};
gvjs_.setChartType = function(a) {
    this.Gl(a)
};
gvjs_.getChartType = function() {
    return this.getType()
};
gvjs_.setChartName = function(a) {
    this.yn(a)
};
gvjs_.getChartName = function() {
    return this.getName()
};

function gvjs_1o(a) {
    a = a || {};
    typeof a === gvjs_m && (a = gvjs_Jg(a));
    return a.dashboardType ? new(gvjs_Ke(gvjs_yc))(a) : a.controlType ? new gvjs_O(a) : new gvjs_Q(a)
};

function gvjs_2o(a) {
    gvjs_wo.call(this, "dashboard", a);
    a = a || {};
    typeof a === gvjs_m && (a = gvjs_Jg(a));
    this.MH = this.Ns = null;
    gvjs_3o(this, a.wrappers, a.bindings);
    this.Gl(a.dashboardType || "Dashboard")
}
gvjs_r(gvjs_2o, gvjs_wo);
gvjs_ = gvjs_2o.prototype;
gvjs_.KI = function(a, b) {
    function c(m) {
        return f[m]
    }
    gvjs_K(this.visualization);
    a = gvjs_hk(a);
    for (var d = new gvjs_Zo(a), e = this.MH || [], f = this.Ns, g = e.length, h = 0; h < g; h++) {
        var k = gvjs_w(e[h].controls, c),
            l = gvjs_w(e[h].participants, c);
        d.bind(k, l)
    }
    this.visualization = d;
    gvjs_wo.prototype.KI.call(this, a, b)
};
gvjs_.J_ = function(a) {
    a.wrappers = this.Ns ? gvjs_w(this.Ns, function(b) {
        return b.toJSON()
    }) : void 0;
    a.bindings = this.MH || void 0
};
gvjs_.setWrappers = function(a) {
    gvjs_3o(this, a, null)
};
gvjs_.getWrappers = function() {
    return this.Ns
};
gvjs_.setBindings = function(a) {
    gvjs_3o(this, null, a)
};
gvjs_.getBindings = function() {
    return this.MH
};

function gvjs_3o(a, b, c) {
    if (null !== b && !Array.isArray(b)) {
        var d = [];
        gvjs_y(b, function(e, f) {
            var g;
            gvjs_4o(e) || (g = gvjs_1o(e));
            g.yn(f);
            d.push(g)
        });
        b = d
    }
    gvjs_5o(b) && gvjs_5o(c) || (a.Ns = gvjs_w(b, a.hU, a), a.MH = gvjs_w(c, a.cja, a))
}
gvjs_.hU = function(a) {
    gvjs_4o(a) || (a = gvjs_1o(a));
    a.setDataTable(null);
    a.setDataSourceUrl(null);
    return a
};
gvjs_.cja = function(a) {
    var b = a.controls,
        c = a.participants;
    if (gvjs_5o(b) || gvjs_5o(c)) throw Error("invalid binding: " + a);
    b = gvjs_w(b, this.P2, this);
    c = gvjs_w(c, this.P2, this);
    return {
        controls: b,
        participants: c
    }
};
gvjs_.P2 = function(a) {
    var b = a,
        c = /^{.*}$/;
    if (gvjs_Pe(a) || typeof a === gvjs_m && c.test(a)) return gvjs_4o(b) || (b = gvjs_1o(b)), this.Ns.push(b), this.Ns.length - 1;
    a = gvjs_sda(this);
    a = gvjs_1e(gvjs_Lh(b)) ? -1 : gvjs_of(a, b);
    if (-1 == a) throw Error("Invalid wrapper name: " + b);
    return a
};

function gvjs_4o(a) {
    return typeof a.toJSON === gvjs_c
}

function gvjs_sda(a) {
    return (a.Ns || []).map(function(b) {
        return b.getName()
    })
}

function gvjs_5o(a) {
    return Array.isArray(a) ? 0 == a.length : !0
}
gvjs_.getDashboard = gvjs_wo.prototype.v3;
gvjs_.setDashboardName = gvjs_wo.prototype.yn;
gvjs_.getDashboardName = gvjs_wo.prototype.getName;

function gvjs_6o(a) {
    this.options = a || {}
}
gvjs_6o.prototype.format = function(a, b) {
    if (a.getColumnType(b) === gvjs_f)
        for (var c = this.options.base || 0, d = 0; d < a.getNumberOfRows(); d++) {
            var e = a.getValue(d, b);
            a.setProperty(d, b, gvjs_Rb, null != e && e < c ? "google-visualization-formatters-arrow-dr" : null != e && e > c ? "google-visualization-formatters-arrow-ug" : "google-visualization-formatters-arrow-empty")
        }
};
gvjs_6o.prototype.fl = function(a) {
    return a === gvjs_f ? a : null
};

function gvjs_7o(a) {
    this.options = a || {}
}

function gvjs_8o(a, b, c) {
    0 < b && c.push('<span class="google-charts-bar-' + (a || "w") + '" style="width:' + b + 'px;"></span>')
}
gvjs_7o.prototype.format = function(a, b) {
    var c = a.getColumnType(b);
    if (null != this.fl(c)) {
        c = this.options;
        var d = c.min,
            e = c.max,
            f = null;
        if (null == d || null == e) f = a.getColumnRange(b), null == e && (e = f.max), null == d && (d = Math.min(0, f.min));
        d >= e && (f = f || a.getColumnRange(b), e = f.max, d = f.min);
        d === e && (0 === d ? e = 1 : 0 < d ? d = 0 : e = 0);
        f = e - d;
        var g = c.base || 0;
        g = Math.max(d, Math.min(e, g));
        var h = c.width || 100,
            k = c.showValue;
        null == k && (k = !0);
        for (var l = Math.round((g - d) / f * h), m = h - l, n = 0; n < a.getNumberOfRows(); n++) {
            var p = Number(a.getValue(n, b)),
                q = [];
            p = Math.max(d, Math.min(e, p));
            var r = Math.ceil((p - d) / f * h);
            q.push('<span class="google-visualization-formatters-bars">');
            gvjs_8o("s", 1, q);
            var t = gvjs_9o(c.colorPositive, "b"),
                u = gvjs_9o(c.colorNegative, "r"),
                v = c.drawZeroLine ? 1 : 0;
            0 < l ? p < g ? (gvjs_8o("w", r, q), gvjs_8o(u, l - r, q), 0 < v && gvjs_8o("z", v, q), gvjs_8o("w", m, q)) : (gvjs_8o("w", l, q), 0 < v && gvjs_8o("z", v, q), gvjs_8o(t, r - l, q), gvjs_8o("w", h - r, q)) : (gvjs_8o(t, r, q), gvjs_8o("w", h - r, q));
            gvjs_8o("s", 1, q);
            p = a.getProperty(n, b, gvjs_vb);
            null == p && (p = a.getFormattedValue(n, b), a.setProperty(n,
                b, gvjs_vb, p));
            k && (q.push("\u00a0"), q.push(p));
            q.push("</span>\u00a0");
            a.setFormattedValue(n, b, q.join(""))
        }
    }
};
gvjs_7o.prototype.fl = function(a) {
    return a === gvjs_f ? a : null
};

function gvjs_9o(a, b) {
    a = (a || "").toLowerCase();
    return gvjs_tda[a] || b
}
var gvjs_tda = {
    red: "r",
    blue: "b",
    green: "g"
};

function gvjs_$o(a, b, c, d) {
    null != a && a instanceof Date && (a = a.getTime());
    null != b && b instanceof Date && (b = b.getTime());
    null != a && Array.isArray(a) && (a = gvjs_ap(a));
    null != b && Array.isArray(b) && (b = gvjs_ap(b));
    this.from = a;
    this.bw = b;
    this.color = c;
    this.hm = d
}
gvjs_$o.prototype.contains = function(a) {
    var b = this.from,
        c = this.bw;
    if (null == a) return null == b && null == c;
    a instanceof Date ? a = a.getTime() : Array.isArray(a) && (a = gvjs_ap(a));
    return (null == b || a >= b) && (null == c || a < c)
};
gvjs_$o.prototype.Gm = function() {
    return this.color
};
gvjs_$o.prototype.getBackgroundColor = function() {
    return this.hm
};

function gvjs_bp(a, b, c, d, e) {
    gvjs_$o.call(this, a, b, c, "");
    this.JL = 0;
    typeof a === gvjs_f && typeof b === gvjs_f && (this.JL = b - a, 0 >= this.JL && (this.JL = 1));
    this.gea = gvjs_ei(gvjs_$h(d).hex);
    this.zma = gvjs_ei(gvjs_$h(e).hex)
}
gvjs_r(gvjs_bp, gvjs_$o);
gvjs_bp.prototype.getBackgroundColor = function(a) {
    if (typeof a !== gvjs_f) return "";
    a = gvjs_gi(this.gea, this.zma, 1 - (a - this.from) / this.JL);
    return gvjs_fi(a[0], a[1], a[2])
};

function gvjs_cp() {
    this.KL = []
}
gvjs_cp.prototype.addRange = function(a, b, c, d) {
    this.KL.push(new gvjs_$o(a, b, c, d))
};
gvjs_cp.prototype.addGradientRange = function(a, b, c, d, e) {
    this.KL.push(new gvjs_bp(a, b, c, d, e))
};
gvjs_cp.prototype.format = function(a, b) {
    var c = a.getColumnType(b);
    if (null != this.fl(c))
        for (c = 0; c < a.getNumberOfRows(); c++) {
            for (var d = a.getValue(c, b), e = "", f = 0; f < this.KL.length; f++) {
                var g = this.KL[f];
                if ("undefined" !== typeof d && g.contains(d)) {
                    f = g.Gm();
                    d = g.getBackgroundColor(d);
                    f && (e += gvjs_Tb + f + ";");
                    d && (e += gvjs_Hb + d + ";");
                    break
                }
            }
            a.setProperty(c, b, gvjs_6d, e)
        }
};
gvjs_cp.prototype.fl = function(a) {
    return a !== gvjs_1b && a !== gvjs_2b && a !== gvjs_be && a !== gvjs_f && a !== gvjs_m ? null : a
};

function gvjs_ap(a) {
    return 36E5 * a[0] + 6E4 * a[1] + 1E3 * a[2] + (4 === a.length ? a[3] : 0)
};

function gvjs_dp(a) {
    this.pattern = a || ""
}
gvjs_dp.prototype.format = function(a, b, c, d) {
    var e = b[0];
    null != c && typeof c === gvjs_f && (e = c);
    d = d || null;
    for (c = 0; c < a.getNumberOfRows(); c++) {
        var f = this.pattern.replace(/{(\d+)}/g, function(g) {
            return function(h, k, l, m) {
                return 0 < l && "\\" === m[l - 1] ? h : a.getFormattedValue(g, b[Number(k)])
            }
        }(c));
        f = f.replace(/\\(.)/g, "$1");
        d ? a.setProperty(c, e, d, f) : a.setFormattedValue(c, e, f)
    }
};
gvjs_dp.prototype.fl = function(a) {
    return a
};
var gvjs_uda = RegExp("[A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0900-\u1fff\u200e\u2c00-\ud801\ud804-\ud839\ud83c-\udbff\uf900-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]"),
    gvjs_vda = RegExp("^[^A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0900-\u1fff\u200e\u2c00-\ud801\ud804-\ud839\ud83c-\udbff\uf900-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]*[\u0591-\u06ef\u06fa-\u08ff\u200f\ud802-\ud803\ud83a-\ud83b\ufb1d-\ufdff\ufe70-\ufefc]"),
    gvjs_wda = RegExp("^(ar|ckb|dv|he|iw|fa|nqo|ps|sd|ug|ur|yi|.*[-_](Adlm|Arab|Hebr|Nkoo|Rohg|Thaa))(?!.*[-_](Latn|Cyrl)($|-|_))($|-|_)",
        "i");

function gvjs_ep(a, b) {
    gvjs_1o(a).draw(b)
};
gvjs_t("google.visualization.drawChart", gvjs_ep);
gvjs_t("google.visualization.createUrl", function(a, b) {
    typeof a === gvjs_m && (a = gvjs_Jg(a));
    var c = [],
        d;
    for (d in a)
        if ("options" == d) {
            var e = a[d],
                f;
            for (f in e) {
                var g = e[f];
                typeof g !== gvjs_m && (g = gvjs_Gg(g));
                c.push(f + "=" + encodeURIComponent(String(g)))
            }
        } else g = a[d], typeof g !== gvjs_m && (g = typeof g.toJSON === gvjs_c ? g.toJSON() : gvjs_Gg(g)), c.push(d + "=" + encodeURIComponent(String(g)));
    a = gvjs_nn() + "/chart.html";
    a = a.replace(/^https?:/, "");
    b = b || a;
    c = b + "?" + c.join("&");
    c = c.replace(/'/g, "%27");
    return c = c.replace(/"/g, "%22")
});
gvjs_t("google.visualization.createSnippet", function(a) {
    var b = gvjs_nn() + "/chart.js";
    b = b.replace(/^https?:/, "");
    b = '<script type="text/javascript" src="' + b + '">\n';
    a = gvjs_1o(a).toJSON();
    a = a.replace(/</g, gvjs_ha);
    a = a.replace(/>/g, "&gt;");
    return b + a + "\n\x3c/script>"
});
gvjs_t("google.visualization.createWrapper", gvjs_1o);
gvjs_t("google.visualization.ChartWrapper", gvjs_Q);
gvjs_Q.prototype.clear = gvjs_Q.prototype.clear;
gvjs_Q.prototype.draw = gvjs_Q.prototype.draw;
gvjs_Q.prototype.clone = gvjs_Q.prototype.clone;
gvjs_Q.prototype.toJSON = gvjs_Q.prototype.toJSON;
gvjs_Q.prototype.getSnapshot = gvjs_Q.prototype.getSnapshot;
gvjs_Q.prototype.getDataSourceUrl = gvjs_Q.prototype.getDataSourceUrl;
gvjs_Q.prototype.getDataTable = gvjs_Q.prototype.getDataTable;
gvjs_Q.prototype.getChartName = gvjs_Q.prototype.getChartName;
gvjs_Q.prototype.getChartType = gvjs_Q.prototype.getChartType;
gvjs_Q.prototype.getChart = gvjs_Q.prototype.getChart;
gvjs_Q.prototype.getContainerId = gvjs_Q.prototype.getContainerId;
gvjs_Q.prototype.getPackages = gvjs_Q.prototype.getPackages;
gvjs_Q.prototype.getQuery = gvjs_Q.prototype.getQuery;
gvjs_Q.prototype.getRefreshInterval = gvjs_Q.prototype.getRefreshInterval;
gvjs_Q.prototype.getView = gvjs_Q.prototype.getView;
gvjs_Q.prototype.getOption = gvjs_Q.prototype.getOption;
gvjs_Q.prototype.getOptions = gvjs_Q.prototype.getOptions;
gvjs_Q.prototype.getState = gvjs_Q.prototype.getState;
gvjs_Q.prototype.getCustomRequestHandler = gvjs_Q.prototype.getCustomRequestHandler;
gvjs_Q.prototype.isDefaultVisualization = gvjs_Q.prototype.isDefaultVisualization;
gvjs_Q.prototype.pushView = gvjs_Q.prototype.pushView;
gvjs_Q.prototype.safeDraw = gvjs_Q.prototype.draw;
gvjs_Q.prototype.sendQuery = gvjs_Q.prototype.sendQuery;
gvjs_Q.prototype.setDataSourceUrl = gvjs_Q.prototype.setDataSourceUrl;
gvjs_Q.prototype.setDataTable = gvjs_Q.prototype.setDataTable;
gvjs_Q.prototype.setChart = gvjs_Q.prototype.setChart;
gvjs_Q.prototype.setChartName = gvjs_Q.prototype.setChartName;
gvjs_Q.prototype.setChartType = gvjs_Q.prototype.setChartType;
gvjs_Q.prototype.setContainerId = gvjs_Q.prototype.setContainerId;
gvjs_Q.prototype.setIsDefaultVisualization = gvjs_Q.prototype.setIsDefaultVisualization;
gvjs_Q.prototype.setPackages = gvjs_Q.prototype.setPackages;
gvjs_Q.prototype.setQuery = gvjs_Q.prototype.setQuery;
gvjs_Q.prototype.setRefreshInterval = gvjs_Q.prototype.setRefreshInterval;
gvjs_Q.prototype.setView = gvjs_Q.prototype.setView;
gvjs_Q.prototype.setOption = gvjs_Q.prototype.setOption;
gvjs_Q.prototype.setOptions = gvjs_Q.prototype.setOptions;
gvjs_Q.prototype.setState = gvjs_Q.prototype.setState;
gvjs_Q.prototype.setCustomRequestHandler = gvjs_Q.prototype.setCustomRequestHandler;
gvjs_t("google.visualization.ControlWrapper", gvjs_O);
gvjs_O.prototype.clear = gvjs_O.prototype.clear;
gvjs_O.prototype.draw = gvjs_O.prototype.draw;
gvjs_O.prototype.toJSON = gvjs_O.prototype.toJSON;
gvjs_O.prototype.getSnapshot = gvjs_O.prototype.getSnapshot;
gvjs_O.prototype.getDataSourceUrl = gvjs_O.prototype.getDataSourceUrl;
gvjs_O.prototype.getDataTable = gvjs_O.prototype.getDataTable;
gvjs_O.prototype.getControlName = gvjs_O.prototype.getControlName;
gvjs_O.prototype.getControlType = gvjs_O.prototype.getControlType;
gvjs_O.prototype.getControl = gvjs_O.prototype.getControl;
gvjs_O.prototype.getContainerId = gvjs_O.prototype.getContainerId;
gvjs_O.prototype.getPackages = gvjs_O.prototype.getPackages;
gvjs_O.prototype.getQuery = gvjs_O.prototype.getQuery;
gvjs_O.prototype.getRefreshInterval = gvjs_O.prototype.getRefreshInterval;
gvjs_O.prototype.getView = gvjs_O.prototype.getView;
gvjs_O.prototype.getOption = gvjs_O.prototype.getOption;
gvjs_O.prototype.getOptions = gvjs_O.prototype.getOptions;
gvjs_O.prototype.getState = gvjs_O.prototype.getState;
gvjs_O.prototype.sendQuery = gvjs_O.prototype.sendQuery;
gvjs_O.prototype.setDataSourceUrl = gvjs_O.prototype.setDataSourceUrl;
gvjs_O.prototype.setDataTable = gvjs_O.prototype.setDataTable;
gvjs_O.prototype.setControlName = gvjs_O.prototype.setControlName;
gvjs_O.prototype.setControlType = gvjs_O.prototype.setControlType;
gvjs_O.prototype.setContainerId = gvjs_O.prototype.setContainerId;
gvjs_O.prototype.setPackages = gvjs_O.prototype.setPackages;
gvjs_O.prototype.setQuery = gvjs_O.prototype.setQuery;
gvjs_O.prototype.setRefreshInterval = gvjs_O.prototype.setRefreshInterval;
gvjs_O.prototype.setView = gvjs_O.prototype.setView;
gvjs_O.prototype.setOption = gvjs_O.prototype.setOption;
gvjs_O.prototype.setOptions = gvjs_O.prototype.setOptions;
gvjs_O.prototype.setState = gvjs_O.prototype.setState;
gvjs_t(gvjs_yc, gvjs_2o);
gvjs_2o.prototype.clear = gvjs_2o.prototype.clear;
gvjs_2o.prototype.draw = gvjs_2o.prototype.draw;
gvjs_2o.prototype.toJSON = gvjs_2o.prototype.toJSON;
gvjs_2o.prototype.getBindings = gvjs_2o.prototype.getBindings;
gvjs_2o.prototype.getDataSourceUrl = gvjs_2o.prototype.getDataSourceUrl;
gvjs_2o.prototype.getDataTable = gvjs_2o.prototype.getDataTable;
gvjs_2o.prototype.getDashboard = gvjs_2o.prototype.getDashboard;
gvjs_2o.prototype.getDashboardName = gvjs_2o.prototype.getDashboardName;
gvjs_2o.prototype.getContainerId = gvjs_2o.prototype.getContainerId;
gvjs_2o.prototype.getPackages = gvjs_2o.prototype.getPackages;
gvjs_2o.prototype.getQuery = gvjs_2o.prototype.getQuery;
gvjs_2o.prototype.getRefreshInterval = gvjs_2o.prototype.getRefreshInterval;
gvjs_2o.prototype.getView = gvjs_2o.prototype.getView;
gvjs_2o.prototype.getWrappers = gvjs_2o.prototype.getWrappers;
gvjs_2o.prototype.setBindings = gvjs_2o.prototype.setBindings;
gvjs_2o.prototype.setDataSourceUrl = gvjs_2o.prototype.setDataSourceUrl;
gvjs_2o.prototype.setDataTable = gvjs_2o.prototype.setDataTable;
gvjs_2o.prototype.setDashboardName = gvjs_2o.prototype.setDashboardName;
gvjs_2o.prototype.setContainerId = gvjs_2o.prototype.setContainerId;
gvjs_2o.prototype.setPackages = gvjs_2o.prototype.setPackages;
gvjs_2o.prototype.setQuery = gvjs_2o.prototype.setQuery;
gvjs_2o.prototype.setRefreshInterval = gvjs_2o.prototype.setRefreshInterval;
gvjs_2o.prototype.setView = gvjs_2o.prototype.setView;
gvjs_2o.prototype.getSnapshot = gvjs_2o.prototype.getSnapshot;
gvjs_2o.prototype.setWrappers = gvjs_2o.prototype.setWrappers;

function gvjs_fp(a) {
    for (var b = 0, c = 0; c < a.length; c++) b += a[c];
    return b
}

function gvjs_gp(a) {
    return a.length
}

function gvjs_hp(a) {
    return gvjs_fp(a) / a.length
};

function gvjs_ip(a, b, c) {
    c = void 0 === c ? [] : c;
    for (var d = [], e = [], f = {}, g = gvjs_q(b), h = g.next(); !h.done; f = {
            MG: f.MG,
            Fk: f.Fk
        }, h = g.next()) f.Fk = h.value, typeof f.Fk === gvjs_f ? d.push(f.Fk) : typeof f.Fk === gvjs_g && (f.MG = a.getColumnIndex(f.Fk.column), "modifier" in f.Fk && e.push({
        Eba: {
            calc: function(q) {
                return function(r, t) {
                    return (0, q.Fk.modifier)(r.getValue(t, q.MG))
                }
            }(f),
            type: f.Fk.type,
            label: f.Fk.label,
            id: f.Fk.id
        },
        Sia: d.length
    }), d.push(f.MG));
    if (0 < e.length) {
        a = new gvjs_G(a);
        f = a.getViewColumns();
        e = gvjs_q(e);
        for (g = e.next(); !g.done; g =
            e.next()) g = g.value, h = f.length, f[h] = g.Eba, d[g.Sia] = h;
        a.setColumns(f)
    }
    e = new gvjs_F;
    f = [];
    for (g = 0; g < d.length; g++) {
        var k = b[g],
            l = d[g];
        h = a.getColumnType(l);
        var m = typeof k === gvjs_g && null != k.label ? k.label : a.getColumnLabel(l);
        k = typeof k === gvjs_g && null != k.id ? k.id : a.getColumnId(l);
        e.addColumn(h, m, k);
        f.push(h)
    }
    g = gvjs_q(c);
    for (h = g.next(); !h.done; h = g.next()) h = h.value, k = a.getColumnIndex(h.column), m = h.label || a.getColumnLabel(k), k = null != h.id ? h.id : a.getColumnId(k), e.addColumn(h.type, m, k);
    g = d.map(function(q) {
        return {
            column: q
        }
    });
    g = a.getSortedRows(g);
    h = [];
    for (m = 0; m < c.length; m++) h.push([]);
    for (m = 0; m < g.length; m++) {
        for (k = 0; k < c.length; k++) h[k].push(a.getValue(g[m], a.getColumnIndex(c[k].column)));
        k = !1;
        if (m < g.length - 1)
            for (k = !0, l = 0; l < d.length; l++) {
                var n = a.getValue(g[m], d[l]),
                    p = a.getValue(g[m + 1], d[l]);
                if (0 !== gvjs_Sj(f[l], n, p)) {
                    k = !1;
                    break
                }
            }
        if (!k) {
            k = e.addRow();
            for (l = 0; l < d.length; l++) e.setValue(k, l, a.getValue(g[m], d[l]));
            l = b.length;
            for (n = 0; n < c.length; n++) p = (0, c[n].aggregation)(h[n]), e.setValue(k, l + n, p);
            for (k = 0; k < c.length; k++) h[k] = []
        }
    }
    return e
};

function gvjs_jp(a, b, c) {
    var d = b.getColumnType(c),
        e = b.getColumnId(c),
        f = b.getColumnLabel(c);
    d = a.addColumn(d, f, e);
    a.setColumnProperties(d, b.getColumnProperties(c))
};
gvjs_t("google.visualization.data.avg", gvjs_hp);
gvjs_t("google.visualization.data.count", gvjs_gp);
gvjs_t("google.visualization.data.group", gvjs_ip);
gvjs_t("google.visualization.data.join", function(a, b, c, d, e, f) {
    d = d.map(function(B) {
        return [a.getColumnIndex(B[0]), b.getColumnIndex(B[1])]
    });
    e = e.map(a.getColumnIndex.bind(a));
    f = f.map(b.getColumnIndex.bind(b));
    for (var g = c === gvjs_sd || c === gvjs_9b, h = c === gvjs_i || c === gvjs_9b, k = new gvjs_F, l = d.map(function(B) {
            var D = a.getColumnType(B[0]),
                F = b.getColumnType(B[1]);
            if (D !== F) throw Error("Key types do not match:" + D + gvjs_ja + F);
            gvjs_jp(k, a, B[0]);
            return D
        }), m = [], n = [], p = gvjs_q(d), q = p.next(); !q.done; q = p.next()) {
        var r = q.value;
        m.push({
            column: r[0]
        });
        n.push({
            column: r[1]
        })
    }
    m = a.getSortedRows(m);
    n = b.getSortedRows(n);
    p = gvjs_q(e);
    for (q = p.next(); !q.done; q = p.next()) gvjs_jp(k, a, q.value);
    p = gvjs_q(f);
    for (q = p.next(); !q.done; q = p.next()) gvjs_jp(k, b, q.value);
    p = !1;
    for (var t = r = 0, u = 0; r < m.length || t < n.length;) {
        var v = 0,
            w = [];
        if (t >= n.length)
            if (g) w[0] = m[r], v = -1;
            else break;
        else if (r >= m.length)
            if (h) w[1] = n[t], v = 1;
            else break;
        else {
            w[0] = m[r];
            w[1] = n[t];
            for (var x = 0; x < d.length && (v = a.getValue(w[0], d[x][0]), q = b.getValue(w[1], d[x][1]), v = gvjs_Sj(l[x], v, q),
                    0 === v); x++);
        }
        if (p && 0 !== v) p = !1, t++;
        else {
            if (-1 === v && g || 1 === v && h || 0 === v) {
                k.addRow();
                var y = void 0,
                    z = void 0; - 1 === v && g || 0 === v && c !== gvjs_i ? (y = a, z = 0) : (y = b, z = 1);
                x = 0;
                var A = gvjs_q(d);
                for (q = A.next(); !q.done; q = A.next()) q = q.value, c === gvjs_9b ? k.setValue(u, x, y.getValue(w[z], q[z])) : k.setCell(u, x, y.getValue(w[z], q[z]), y.getFormattedValue(w[z], q[z]), y.getProperties(w[z], q[z])), x++;
                if (-1 === v && g || 0 === v)
                    for (y = d.length, x = 0, z = gvjs_q(e), q = z.next(); !q.done; q = z.next()) q = q.value, k.setCell(u, x + y, a.getValue(w[0], q), a.getFormattedValue(w[0],
                        q), a.getProperties(w[0], q)), x++;
                if (1 === v && h || 0 === v)
                    for (y = e.length + d.length, x = 0, z = gvjs_q(f), q = z.next(); !q.done; q = z.next()) q = q.value, k.setCell(u, x + y, b.getValue(w[1], q), b.getFormattedValue(w[1], q), b.getProperties(w[1], q)), x++;
                u++
            }
            1 === v ? t++ : r++;
            0 === v && (p = !0)
        }
    }
    return k
});
gvjs_t("google.visualization.data.max", function(a) {
    if (0 === a.length) return null;
    for (var b = a[0], c = 1; c < a.length; c++) {
        var d = a[c];
        null != d && d > b && (b = d)
    }
    return b
});
gvjs_t("google.visualization.data.min", function(a) {
    if (0 === a.length) return null;
    for (var b = a[0], c = 1; c < a.length; c++) {
        var d = a[c];
        null != d && d < b && (b = d)
    }
    return b
});
gvjs_t("google.visualization.data.month", function(a) {
    return a.getMonth() + 1
});
gvjs_t("google.visualization.data.sum", gvjs_fp);
gvjs_t(gvjs_Uc, gvjs_Aj);
gvjs_Aj.prototype.format = gvjs_Aj.prototype.format;
gvjs_Aj.prototype.formatValue = gvjs_Aj.prototype.formatValue;
gvjs_t("google.visualization.NumberFormat.useNativeCharactersIfAvailable", function(a) {
    gvjs_Fj = a
});
gvjs_t("google.visualization.NumberFormat.DECIMAL_SEP", gvjs_Bj);
gvjs_t("google.visualization.NumberFormat.GROUP_SEP", gvjs_Cj);
gvjs_t("google.visualization.NumberFormat.DECIMAL_PATTERN", gvjs_Gj);
gvjs_t("google.visualization.ColorFormat", gvjs_cp);
gvjs_cp.prototype.format = gvjs_cp.prototype.format;
gvjs_cp.prototype.addRange = gvjs_cp.prototype.addRange;
gvjs_cp.prototype.addGradientRange = gvjs_cp.prototype.addGradientRange;
gvjs_t("google.visualization.BarFormat", gvjs_7o);
gvjs_7o.prototype.format = gvjs_7o.prototype.format;
gvjs_t("google.visualization.ArrowFormat", gvjs_6o);
gvjs_6o.prototype.format = gvjs_6o.prototype.format;
gvjs_t("google.visualization.PatternFormat", gvjs_dp);
gvjs_dp.prototype.format = gvjs_dp.prototype.format;
gvjs_t("google.visualization.DateFormat", gvjs_$i);
gvjs_$i.prototype.format = gvjs_$i.prototype.format;
gvjs_$i.prototype.formatValue = gvjs_$i.prototype.formatValue;
gvjs_t(gvjs_Uc, gvjs_Aj);
gvjs_Aj.prototype.format = gvjs_Aj.prototype.format;
gvjs_t("google.visualization.TableColorFormat", gvjs_cp);
gvjs_t("google.visualization.TableBarFormat", gvjs_7o);
gvjs_7o.prototype.format = gvjs_7o.prototype.format;
gvjs_t("google.visualization.TableArrowFormat", gvjs_6o);
gvjs_6o.prototype.format = gvjs_6o.prototype.format;
gvjs_t("google.visualization.TablePatternFormat", gvjs_dp);
gvjs_dp.prototype.format = gvjs_dp.prototype.format;
gvjs_t("google.visualization.TableDateFormat", gvjs_$i);