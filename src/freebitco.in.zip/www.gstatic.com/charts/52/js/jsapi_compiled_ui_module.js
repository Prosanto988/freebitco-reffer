/*
 SWFObject v2.2 <http://code.google.com/p/swfobject/> 
 is released under the MIT License <http://www.opensource.org/licenses/mit-license.php> 
*/
/*
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
/*

Copyright 2014 David Bau.
Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:
The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/*

 Copyright 2022 Google LLC
 This code is released under the MIT license.
 SPDX-License-Identifier: MIT

*/
var gvjs_1p = " - ",
    gvjs_2p = " but expected type is ",
    gvjs_3p = ' class="',
    gvjs_4p = " does not have a domain column.",
    gvjs_5p = " is of type ",
    gvjs_6p = '" id="',
    gvjs_7p = '" value="',
    gvjs_8p = "#000",
    gvjs_9p = "#109618",
    gvjs_$p = "#222222",
    gvjs_aq = "#333333",
    gvjs_bq = "#666666",
    gvjs_cq = "#757575",
    gvjs_dq = "#994499",
    gvjs_eq = "#999999",
    gvjs_fq = "#DC3912",
    gvjs_gq = "#FF9900",
    gvjs_hq = "#FFFFFF",
    gvjs_iq = "#ccc",
    gvjs_jq = "#cccccc",
    gvjs_kq = "#e0e0e0",
    gvjs_lq = "#fff",
    gvjs_mq = "&up__table_query_url=",
    gvjs_nq = "-caption",
    gvjs_oq = "-content",
    gvjs_pq = "-default",
    gvjs_qq = "-disabled",
    gvjs_rq = "-dropdown",
    gvjs_sq = "-inner-box",
    gvjs_tq = "-outer-box",
    gvjs_uq = "...",
    gvjs_vq = ".values must not contain nulls",
    gvjs_wq = "0%",
    gvjs_xq = "100",
    gvjs_yq = "100%",
    gvjs_zq = "1px solid infotext",
    gvjs_Aq = "400",
    gvjs_Bq = "500",
    gvjs_Cq = "600",
    gvjs_Dq = "700",
    gvjs_Eq = "800",
    gvjs_Fq = "900",
    gvjs_Gq = ";stop-opacity:",
    gvjs_Hq = "All data columns targeting the same axis must be of the same data type.  Column #",
    gvjs_Iq = "All domains must be of the same data type",
    gvjs_Jq = "Arial",
    gvjs_Kq =
    "Color",
    gvjs_Lq = "Component already rendered",
    gvjs_Mq = "Copy-Paste this code to an HTML page",
    gvjs_Nq = "Data must contain at least two columns.",
    gvjs_Oq = "Data table is not defined",
    gvjs_Pq = "Drawing_Frame_",
    gvjs_Qq = "Google_Visualization",
    gvjs_Rq = "Invalid format in ",
    gvjs_Sq = "Invalid orientation.",
    gvjs_Tq = "Last domain does not have enough data columns (missing ",
    gvjs_Uq = "Lines",
    gvjs_Vq = "No data",
    gvjs_Wq = "ROW",
    gvjs_Xq = "ROW_INDEX",
    gvjs_Yq = "Roboto",
    gvjs_Zq = "SUBTYPE",
    gvjs__q = "Unable to set parent component",
    gvjs_0q = "Unexpected domain column (column #",
    gvjs_1q = "Your browser does not support charts",
    gvjs_2q = "_default_",
    gvjs_3q = "_focusedLabels",
    gvjs_4q = "_selectedLabels",
    gvjs_5q = "aAAaGVIZSENTINELaAAa-button",
    gvjs_6q = "aAAaGVIZSENTINELaAAa-checkbox",
    gvjs_7q = "aAAaGVIZSENTINELaAAa-control",
    gvjs_8q = "aAAaGVIZSENTINELaAAa-custom-button",
    gvjs_9q = "aAAaGVIZSENTINELaAAa-inline-block ",
    gvjs_V = "aAAaGVIZSENTINELaAAa-menu",
    gvjs_$q = "aAAaGVIZSENTINELaAAa-menu-button",
    gvjs_ar = "aAAaGVIZSENTINELaAAa-menuheader",
    gvjs_W = "aAAaGVIZSENTINELaAAa-menuitem",
    gvjs_br = "aAAaGVIZSENTINELaAAa-menuseparator",
    gvjs_cr = "aAAaGVIZSENTINELaAAa-option",
    gvjs_dr = "aAAaGVIZSENTINELaAAa-option-selected",
    gvjs_er = "aAAaGVIZSENTINELaAAa-select",
    gvjs_fr = "aAAaGVIZSENTINELaAAa-submenu",
    gvjs_gr = "aAAaGVIZSENTINELaAAa-submenu-arrow",
    gvjs_hr = "aAAaGVIZSENTINELaAAa-submenu-arrow-rtl",
    gvjs_ir = "action",
    gvjs_jr = "activedescendant",
    gvjs_kr = "allowHtml",
    gvjs_lr = "alternatingRowStyle",
    gvjs_mr = "animation.duration",
    gvjs_nr = "annotation",
    gvjs_or = "annotations.boxStyle",
    gvjs_pr = "annotations.domain.stemColor",
    gvjs_qr = "annotations.domain.style",
    gvjs_rr = "annotations.domain.textStyle",
    gvjs_sr = "annotations.highContrast",
    gvjs_tr = "annotations.stem.color",
    gvjs_ur = "annotations.stem.length",
    gvjs_vr = "annotations.stemColor",
    gvjs_wr = "annotations.stemLength",
    gvjs_xr = "annotations.style",
    gvjs_yr = "annotations.textStyle",
    gvjs_zr = "annotationtext",
    gvjs_Ar = "area",
    gvjs_Br = "areaOpacity",
    gvjs_Cr = "aria-activedescendant",
    gvjs_Dr = "backgroundColor",
    gvjs_Er = "backgroundColor.fill",
    gvjs_Fr = "bar.groupWidth",
    gvjs_Gr = "bar.width",
    gvjs_Hr =
    "bars",
    gvjs_Ir = "baseline",
    gvjs_Jr = "baselineColor",
    gvjs_Kr = "beforedrag",
    gvjs_Lr = "beforehide",
    gvjs_Mr = "beforeshow",
    gvjs_Nr = "below",
    gvjs_Or = "black",
    gvjs_Pr = "blur",
    gvjs_Qr = "bold",
    gvjs_Rr = "border-box",
    gvjs_Sr = "both",
    gvjs_Tr = "bottom",
    gvjs_Ur = "bottom-space",
    gvjs_Vr = "bottom-vert",
    gvjs_Wr = "bubble",
    gvjs_Xr = "bubble.opacity",
    gvjs_Yr = "bubbles",
    gvjs_Zr = "button",
    gvjs__r = "candlestick",
    gvjs_0r = "candlestick.fallingColor",
    gvjs_1r = "candlestick.risingColor",
    gvjs_2r = "candlesticks",
    gvjs_3r = "category",
    gvjs_4r = "categorypoint",
    gvjs_5r = "categorysensitivityarea",
    gvjs_X = "center",
    gvjs_6r = "change",
    gvjs_7r = "chartArea",
    gvjs_8r = "chartArea.backgroundColor",
    gvjs_9r = "chartDragStart",
    gvjs_$r = "chartMouseDown",
    gvjs_as = "chartMouseMove",
    gvjs_bs = "chartRightClick",
    gvjs_cs = "chartarea",
    gvjs_ds = "checkbox",
    gvjs_es = "circle",
    gvjs_fs = "click",
    gvjs_gs = "clip-path",
    gvjs_hs = "clipped",
    gvjs_is = "close",
    gvjs_js = "closedPhase",
    gvjs_ks = "colorBar",
    gvjs_ls = "colors",
    gvjs_ms = "contextmenu",
    gvjs_ns = "crosshair.color",
    gvjs_os = "crosshair.opacity",
    gvjs_ps = "crosshair.orientation",
    gvjs_qs = "curve",
    gvjs_rs = "curveType",
    gvjs_ss = "dash",
    gvjs_ts = "data",
    gvjs_us = "data-logicalname",
    gvjs_vs = "dataOpacity",
    gvjs_ws = "dblclick",
    gvjs_xs = "default",
    gvjs_ys = "defs",
    gvjs_zs = "dialogselect",
    gvjs_As = "diff.newData.opacity",
    gvjs_Bs = "diff.oldData.opacity",
    gvjs_Cs = "direction",
    gvjs_Ds = "disable",
    gvjs_Es = "display",
    gvjs_Fs = "dive",
    gvjs_Gs = "domain",
    gvjs_Hs = "drag",
    gvjs_Is = "dragend",
    gvjs_Js = "dragstart",
    gvjs_Ks = "ellipse",
    gvjs_Ls = "enable",
    gvjs_Ms = "enableInteractivity",
    gvjs_Y = "end",
    gvjs_Ns = "explicit",
    gvjs_Os = "explorer",
    gvjs_Ps = "explorer.actions",
    gvjs_Qs = "feComponentTransfer",
    gvjs_Rs = "feGaussianBlur",
    gvjs_Ss = "feMergeNode",
    gvjs_Ts = "fill",
    gvjs_Us = "fill-opacity",
    gvjs_Vs = "fill.color",
    gvjs_Ws = "fill.opacity",
    gvjs_Xs = "fillColor",
    gvjs_Ys = "fillOpacity",
    gvjs_Zs = "filter",
    gvjs__s = "finish",
    gvjs_0s = "fixed",
    gvjs_1s = "focus",
    gvjs_2s = "focusTarget",
    gvjs_3s = "focusin",
    gvjs_4s = "focusout",
    gvjs_5s = "font-size",
    gvjs_6s = "font-weight",
    gvjs_7s = "font.family",
    gvjs_8s = "font.size",
    gvjs_9s = "fontColor",
    gvjs_$s = "fontFamily",
    gvjs_at = "fontName",
    gvjs_bt =
    "fontSize",
    gvjs_ct = "forceIFrame",
    gvjs_dt = "format",
    gvjs_et = "formatOptions.prefix",
    gvjs_ft = "formatOptions.scaleFactor",
    gvjs_gt = "formatOptions.suffix",
    gvjs_ht = "global",
    gvjs_it = "google-visualization-toolbar-html-code-explanation",
    gvjs_jt = "google-visualization-tooltip",
    gvjs_kt = "gotpointercapture",
    gvjs_lt = "gradient",
    gvjs_mt = "grid",
    gvjs_nt = "gridlineColor",
    gvjs_ot = "gridlines",
    gvjs_pt = "gridlines.color",
    gvjs_qt = "gridlines.count",
    gvjs_rt = "gridlines.interval",
    gvjs_st = "gridlines.minSpacing",
    gvjs_tt = "gridlines.multiple",
    gvjs_ut = "hAxis",
    gvjs_vt = "haspopup",
    gvjs_wt = "headerColor",
    gvjs_xt = "headerHeight",
    gvjs_yt = "hide",
    gvjs_zt = "highContrast",
    gvjs_At = "highlight",
    gvjs_Bt = "histogram",
    gvjs_Ct = "histogram.bucketSize",
    gvjs_Dt = "histogram.hideBucketItems",
    gvjs_Et = "histogram.lastBucketPercentile",
    gvjs_Ft = "histogramBuckets",
    gvjs_Gt = "hoverIn",
    gvjs_Ht = "hoverOut",
    gvjs_It = "html",
    gvjs_Jt = "http://www.w3.org/2000/svg",
    gvjs_Kt = "in",
    gvjs_Lt = "inAndOut",
    gvjs_Mt = "infobackground",
    gvjs_Nt = "inline",
    gvjs_Ot = "input",
    gvjs_Pt = "inside",
    gvjs_Qt = "interpolateNulls",
    gvjs_Rt = "interval",
    gvjs_St = "isStacked",
    gvjs_Tt = "italic",
    gvjs_Ut = "key",
    gvjs_Vt = "keydown",
    gvjs_Wt = "keyup",
    gvjs_Xt = "labelInLegend",
    gvjs_Yt = "labeled",
    gvjs_Zt = "labelledby",
    gvjs__t = "legend",
    gvjs_0t = "legend.alignment",
    gvjs_1t = "legend.maxLines",
    gvjs_2t = "legend.position",
    gvjs_3t = "legend.textStyle",
    gvjs_4t = "legendTextStyle",
    gvjs_5t = "legendentry",
    gvjs_6t = "legendscrollbutton",
    gvjs_7t = "lineWidth",
    gvjs_8t = "linear",
    gvjs_9t = "linearGradient",
    gvjs_$t = "logScale",
    gvjs_au = "margin",
    gvjs_bu = "material",
    gvjs_cu = "max-width",
    gvjs_du = "maxAlternation",
    gvjs_eu = "maxColor",
    gvjs_fu = "maxDepth",
    gvjs_gu = "maximized",
    gvjs_hu = "midColor",
    gvjs_iu = "minColor",
    gvjs_ju = "minorGridlines.color",
    gvjs_ku = "minorGridlines.count",
    gvjs_lu = "minorGridlines.interval",
    gvjs_mu = "minorGridlines.minSpacing",
    gvjs_nu = "minorGridlines.multiple",
    gvjs_ou = "mirrorLog",
    gvjs_pu = "mousedown",
    gvjs_qu = "mouseenter",
    gvjs_ru = "mouseleave",
    gvjs_su = "mousemove",
    gvjs_tu = "mouseup",
    gvjs_uu = "mousewheel",
    gvjs_vu = "move",
    gvjs_wu = "move_offscreen",
    gvjs_xu = "name",
    gvjs_yu = "nonNegative",
    gvjs_zu = "normal",
    gvjs_Au = "nowrap",
    gvjs_Bu = "null position for value of '",
    gvjs_Cu = "numberOrString",
    gvjs_Du = "offset",
    gvjs_Eu = "old-data",
    gvjs_Fu = "onmousedown",
    gvjs_Gu = "onmousemove",
    gvjs_Hu = "onmouseout",
    gvjs_Iu = "onmouseover",
    gvjs_Ju = "opacity",
    gvjs_Ku = "opacity 1s linear",
    gvjs_Lu = "orientation",
    gvjs_Mu = "orientationchange",
    gvjs_Nu = "out",
    gvjs_Ou = "outside",
    gvjs_Pu = "overlaybox",
    gvjs_Qu = "path",
    gvjs_Ru = "pie",
    gvjs_Su = "piecewiseLinear",
    gvjs_Tu = "pointSize",
    gvjs_Uu = "pointer-events",
    gvjs_Vu = "points",
    gvjs_Wu = "pointsVisible",
    gvjs_Xu = "pointsensitivityarea",
    gvjs_Yu = "polygon",
    gvjs_Zu = "polynomial",
    gvjs__u = "pretty",
    gvjs_0u = "primarydiagonalstripes",
    gvjs_Z = "px",
    gvjs_1u = "range",
    gvjs_2u = "ratio",
    gvjs_3u = "removeseriebutton",
    gvjs_4u = "resize",
    gvjs_5u = "return",
    gvjs_6u = "reverseCategories",
    gvjs_7u = "rgba(0,0,0,0)",
    gvjs_8u = "right-space",
    gvjs_9u = "rightclick",
    gvjs_$u = "rowlabels",
    gvjs_av = "sans-serif",
    gvjs_bv = "scaleType",
    gvjs_cv = "screen",
    gvjs_dv = "scroll",
    gvjs_ev = "secondarydiagonalstripes",
    gvjs_fv = "selection",
    gvjs_gv = "selectionMode",
    gvjs_hv =
    "separator",
    gvjs_iv = "series",
    gvjs_jv = "series-color",
    gvjs_kv = "series-color-dark",
    gvjs_lv = "series-color-light",
    gvjs_mv = "series.",
    gvjs_nv = "show",
    gvjs_ov = "showChartButtons",
    gvjs_pv = "showTooltip",
    gvjs_qv = "showTooltips",
    gvjs_rv = "single",
    gvjs_sv = "smoothingFactor",
    gvjs_tv = "solid",
    gvjs_uv = "square",
    gvjs_vv = "stack",
    gvjs_wv = "star",
    gvjs_xv = "steppedArea",
    gvjs_yv = "steppedareabar",
    gvjs_zv = "stop",
    gvjs_Av = "stop-color:",
    gvjs_Bv = "stroke",
    gvjs_Cv = "stroke-dasharray",
    gvjs_Dv = "stroke-linecap",
    gvjs_Ev = "stroke-opacity",
    gvjs_Fv =
    "stroke-width",
    gvjs_Gv = "stroke.color",
    gvjs_Hv = "stroke.opacity",
    gvjs_Iv = "stroke.width",
    gvjs_Jv = "strokeColor",
    gvjs_Kv = "strokeOpacity",
    gvjs_Lv = "tabindex",
    gvjs_Mv = "targetAxisIndex",
    gvjs_Nv = "text-anchor",
    gvjs_Ov = "text-decoration",
    gvjs_Pv = "textStyle",
    gvjs_Qv = "tick",
    gvjs_Rv = "ticks",
    gvjs_Sv = "titleFontSize",
    gvjs_Tv = "titleTextStyle",
    gvjs_Uv = "toggle_display",
    gvjs_Vv = "tooltip.bounds",
    gvjs_Wv = "tooltip.ignoreBounds",
    gvjs_Xv = "tooltip.isHtml",
    gvjs_Yv = "tooltip.showColorCode",
    gvjs_Zv = "tooltip.textStyle",
    gvjs__v = "tooltip.trigger",
    gvjs_0v = "tooltipTextStyle",
    gvjs_1v = "top",
    gvjs_2v = "top-space",
    gvjs_3v = "transform",
    gvjs_4v = "trendlines.",
    gvjs_5v = "underline",
    gvjs_6v = "unhighlight",
    gvjs_7v = "url(#",
    gvjs_8v = "userSpaceOnUse",
    gvjs_9v = "v-text-align",
    gvjs_$v = "v:fill",
    gvjs_aw = "v:oval",
    gvjs_bw = "v:path",
    gvjs_cw = "v:shape",
    gvjs_dw = "vAxes",
    gvjs_ew = "viewWindow.max",
    gvjs_fw = "viewWindow.min",
    gvjs_gw = "viewWindowMode",
    gvjs_hw = "visible",
    gvjs_iw = "visibleInLegend",
    gvjs_jw = "white";

function gvjs_kw(a, b) {
    var c = b || document;
    return c.querySelectorAll && c.querySelector ? c.querySelectorAll("." + a) : gvjs_mi(document, "*", a, b)
}

function gvjs_lw(a) {
    a = a.tabIndex;
    return typeof a === gvjs_f && 0 <= a && 32768 > a
}

function gvjs_mw(a) {
    return a.hasAttribute(gvjs_Lv) && gvjs_lw(a)
}

function gvjs_nw(a) {
    try {
        var b = a && a.activeElement;
        return b && b.nodeName ? b : null
    } catch (c) {
        return null
    }
}

function gvjs_ow(a, b, c, d, e) {
    b = e[b];
    d === gvjs_Ru ? (c = b.Fo, d = null) : d = b.Fo;
    return {
        type: a,
        data: {
            row: c,
            column: d
        }
    }
}
gvjs_Zp.prototype.ar = gvjs_T(31, function(a, b, c, d) {
    var e = [],
        f = b.focused,
        g = a.focused;
    if (f.Ua !== g.Ua || f.datum !== g.datum) null != g.Ua && e.push(gvjs_ow(gvjs_Hu, g.Ua, g.datum, c, d)), null != f.Ua && e.push(gvjs_ow(gvjs_Iu, f.Ua, f.datum, c, d));
    f.category !== g.category && (null != g.category && e.push({
        type: gvjs_Hu,
        data: {
            row: g.category,
            column: null
        }
    }), null != f.category && e.push({
        type: gvjs_Iu,
        data: {
            row: f.category,
            column: null
        }
    }));
    f = b.annotations.focused;
    g = a.annotations.focused;
    !g || f && f.row === g.row && f.column === g.column || e.push({
        type: gvjs_Hu,
        data: {
            row: g.row,
            column: g.column
        }
    });
    !f || g && f.row === g.row && f.column === g.column || e.push({
        type: gvjs_Iu,
        data: {
            row: f.row,
            column: f.column
        }
    });
    f = b.legend.focused;
    g = a.legend.focused;
    f.Ob !== g.Ob && (null != g.Ob && e.push(gvjs_ow(gvjs_Hu, g.Ob, null, c, d)), null != f.Ob && e.push(gvjs_ow(gvjs_Iu, f.Ob, null, c, d)));
    b.selected.equals(a.selected) || e.push({
        type: gvjs_k
    });
    b.legend.Dg === a.legend.Dg && b.legend.sA === a.legend.sA || e.push({
        type: "legendpagination",
        data: {
            currentPageIndex: b.legend.Dg,
            totalPages: b.legend.sA
        }
    });
    a = gvjs_q(e);
    for (b = a.next(); !b.done; b = a.next()) b = b.value, this.dispatchEvent(b.type, b.data)
});
gvjs_Vp.prototype.lA = gvjs_T(30, function() {
    if (this.tm !== gvjs_Up) throw Error("Sanitized content was not of kind HTML.");
    return gvjs_zh(this.toString())
});
gvjs_Sp.prototype.IS = gvjs_T(29, function(a) {
    var b = new gvjs_Sp;
    a = gvjs_vn(a);
    for (var c = 0; c < a.length; c++) {
        var d = a[c];
        this.contains(d) && b.add(d)
    }
});
gvjs_$l.prototype.dm = gvjs_T(23, function(a, b) {
    gvjs_bm(this, a, gvjs_ke, void 0 === b ? !0 : b)
});
gvjs_7k.prototype.Lv = gvjs_T(20, function(a) {
    this.LU = a
});
gvjs_F.prototype.Hm = gvjs_T(14, function() {
    return gvjs_yg(this.Ud)
});
gvjs_G.prototype.Hm = gvjs_T(13, function() {
    return this.getViewColumns()
});
gvjs_P.prototype.Hm = gvjs_T(12, function() {
    return this.Sb.Hm()
});
gvjs_Ij.prototype.eN = gvjs_T(11, function(a) {
    this.x -= a.x;
    this.y -= a.y;
    return this
});
gvjs_ji.prototype.Sm = gvjs_T(10, function(a) {
    var b;
    (b = "A" == a.tagName && a.hasAttribute("href") || a.tagName == gvjs_Oa || a.tagName == gvjs_lp || a.tagName == gvjs_9a || a.tagName == gvjs_kp ? !a.disabled && (!a.hasAttribute(gvjs_Lv) || gvjs_lw(a)) : gvjs_mw(a)) && gvjs_x ? (a = typeof a.getBoundingClientRect !== gvjs_c || gvjs_x && null == a.parentElement ? {
        height: a.offsetHeight,
        width: a.offsetWidth
    } : a.getBoundingClientRect(), a = null != a && 0 < a.height && 0 < a.width) : a = b;
    return a
});
gvjs_ji.prototype.lu = gvjs_T(8, function() {
    return gvjs_nw(this.ac)
});
gvjs_ji.prototype.Im = gvjs_T(2, function(a, b) {
    return gvjs_kw(a, b || this.ac)
});

function gvjs_pw(a) {
    return a
}
var gvjs_Cda = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/;

function gvjs_qw(a, b, c) {
    if (null == c) return b;
    if (typeof c === gvjs_m) return c ? a + encodeURIComponent(c) : "";
    for (var d in c)
        if (Object.prototype.hasOwnProperty.call(c, d)) {
            var e = c[d];
            e = Array.isArray(e) ? e : [e];
            for (var f = 0; f < e.length; f++) {
                var g = e[f];
                null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
            }
        }
    return b
}

function gvjs_rw(a) {
    a = a.document;
    a = gvjs_ui(a) ? a.documentElement : a.body;
    return new gvjs_B(a.clientWidth, a.clientHeight)
}

function gvjs_sw(a) {
    return a.scrollingElement ? a.scrollingElement : !gvjs_If && gvjs_ui(a) ? a.documentElement : a.body || a.documentElement
}

function gvjs_tw(a) {
    var b = gvjs_sw(a);
    a = a.parentWindow || a.defaultView;
    return gvjs_x && a.pageYOffset != b.scrollTop ? new gvjs_A(b.scrollLeft, b.scrollTop) : new gvjs_A(a.pageXOffset || b.scrollLeft, a.pageYOffset || b.scrollTop)
}

function gvjs_uw(a) {
    return a ? a.parentWindow || a.defaultView : window
}

function gvjs_vw(a, b) {
    var c = gvjs_qi(a, gvjs_b);
    gvjs_x ? (b = gvjs_Dh(gvjs_Gh, b), gvjs_Hh(c, b), c.removeChild(c.firstChild)) : gvjs_Hh(c, b);
    if (1 == c.childNodes.length) c = c.removeChild(c.firstChild);
    else {
        for (a = a.createDocumentFragment(); c.firstChild;) a.appendChild(c.firstChild);
        c = a
    }
    return c
}

function gvjs_ww(a) {
    if (a === gvjs_e) return gvjs_e;
    a = gvjs_ei(a);
    a = Math.round((a[0] + a[1] + a[2]) / 3);
    return gvjs_fi(a, a, a)
}

function gvjs_xw(a, b, c) {
    this.style = a;
    this.color = gvjs_Qi(b);
    this.hm = gvjs_Qi(null != c ? c : gvjs_ga)
}
gvjs_ = gvjs_xw.prototype;
gvjs_.getStyle = function() {
    return this.style
};
gvjs_.Gm = function() {
    return this.color
};
gvjs_.getBackgroundColor = function() {
    return this.hm
};
gvjs_.clone = function() {
    return new gvjs_xw(this.style, this.color, this.hm)
};
gvjs_.lD = function() {
    return new gvjs_xw(this.style, gvjs_ww(this.color), gvjs_ww(this.hm))
};

function gvjs_yw(a, b) {
    null != b && (a.strokeOpacity = gvjs_7h(Number(b), 0, 1))
}

function gvjs_zw(a, b) {
    b && (a.pattern = b instanceof gvjs_xw ? b.clone() : new gvjs_xw(b.style, b.color, b.hm))
}

function gvjs_Aw(a, b) {
    null === a.gradient ? a.gradient = gvjs_yg(b || null) : null != b && (Object.assign(a.gradient, b), b.color1 = gvjs_Qi(b.color1 || "", !0), b.color2 = gvjs_Qi(b.color2 || "", !0), null === b.ik && delete b.ik, null === b.jk && delete b.jk, null === b.useObjectBoundingBoxUnits && delete b.useObjectBoundingBoxUnits, null === b.Hl && delete b.Hl)
}

function gvjs__(a) {
    a = void 0 === a ? {} : a;
    this.xs = this.pattern = this.gradient = this.radiusY = this.radiusX = null;
    this.fill = gvjs_e;
    this.fillOpacity = 1;
    this.stroke = gvjs_e;
    this.strokeOpacity = this.strokeWidth = 1;
    this.tg = gvjs_tv;
    this.setProperties(a)
}
gvjs_ = gvjs__.prototype;
gvjs_.setProperties = function(a) {
    (a = void 0 === a ? {} : a) || (a = {});
    this.ie(a.fill);
    this.Qd(a.fillOpacity);
    this.Jc(a.stroke);
    this.vi(a.strokeWidth);
    gvjs_yw(this, a.strokeOpacity);
    var b = a.tg;
    null != b && (this.tg = b);
    b = a.rx;
    null != b && (this.radiusX = b);
    b = a.ry;
    null != b && (this.radiusY = b);
    gvjs_zw(this, a.pattern);
    gvjs_Aw(this, a.gradient);
    this.xs = a.xs || null;
    return this
};
gvjs_.getProperties = function() {
    var a = this.pattern,
        b = null;
    a && (b = {
        style: a.getStyle(),
        color: a.Gm(),
        hm: a.getBackgroundColor()
    });
    return {
        fill: this.fill,
        fillOpacity: this.fillOpacity,
        stroke: this.stroke,
        strokeWidth: this.strokeWidth,
        strokeOpacity: this.strokeOpacity,
        tg: this.tg,
        rx: this.radiusX,
        ry: this.radiusY,
        pattern: b,
        gradient: gvjs_yg(this.gradient),
        xs: gvjs_yg(this.xs)
    }
};
gvjs_.toJSON = function() {
    var a = this.gradient;
    a && (a = {
        color1: a.color1,
        color2: a.color2,
        opacity1: a.ik,
        opacity2: a.jk,
        x1: a.x1,
        y1: a.y1,
        x2: a.x2,
        y2: a.y2,
        useObjectBoundingBoxUnits: a.useObjectBoundingBoxUnits,
        sharpTransition: a.Hl
    });
    var b = this.pattern ? {
            style: this.pattern.getStyle(),
            color: this.pattern.Gm(),
            hm: this.pattern.getBackgroundColor()
        } : {},
        c = this.xs;
    c && (c = {
        radius: c.radius,
        opacity: c.opacity,
        xOffset: c.xOffset,
        yOffset: c.yOffset
    });
    return gvjs_Fg({
        fill: this.fill,
        fillOpacity: this.fillOpacity,
        stroke: this.stroke,
        strokeWidth: this.strokeWidth,
        strokeOpacity: this.strokeOpacity,
        strokeDashStyle: this.tg,
        rx: this.radiusX,
        ry: this.radiusY,
        gradient: a,
        pattern: b,
        shadow: c
    })
};
gvjs_.clone = function() {
    return new gvjs__(this.getProperties())
};
gvjs_.lD = function() {
    var a = this.clone();
    a.ie(gvjs_ww(this.fill));
    a.Jc(gvjs_ww(this.stroke));
    var b = this.gradient;
    if (b) {
        var c = Object.assign({}, b);
        c.color1 = gvjs_ww(b.color1);
        c.color2 = gvjs_ww(b.color2);
        gvjs_Aw(a, c)
    }
    this.pattern && gvjs_zw(a, this.pattern.lD());
    return a
};
gvjs_.ie = function(a) {
    null != a && (this.fill = gvjs_Qi(a, !0));
    return this
};
gvjs_.Qd = function(a) {
    null != a && (this.fillOpacity = gvjs_7h(a, 0, 1));
    return this
};
gvjs_.Jc = function(a, b) {
    null != a && (this.stroke = gvjs_Qi(a, !0));
    this.vi(b)
};
gvjs_.vi = function(a) {
    if (null != a && (typeof a === gvjs_m && (a = Number(a)), typeof a === gvjs_f && !isNaN(a))) {
        if (0 > a) throw Error("Negative strokeWidth not allowed.");
        0 <= a && (this.strokeWidth = a)
    }
};
gvjs_.equals = function(a) {
    var b;
    if (b = this.fill === a.fill && this.fillOpacity === a.fillOpacity && this.stroke === a.stroke && this.strokeWidth === a.strokeWidth && this.strokeOpacity === a.strokeOpacity && this.tg === a.tg && this.radiusX === a.radiusX && this.radiusY === a.radiusY) {
        b = this.gradient;
        var c = a.gradient;
        b = b === c ? !0 : null === b || null === c ? !1 : b.color1 === c.color1 && b.color2 === c.color2 && b.x1 === c.x1 && b.y1 === c.y1 && b.x2 === c.x2 && b.y2 === c.y2 && b.useObjectBoundingBoxUnits === c.useObjectBoundingBoxUnits && b.Hl === c.Hl
    }
    b && (b = this.pattern ||
        null, a = a.pattern || null, b = b === a ? !0 : null == b || null == a ? !1 : b.hm === a.hm && b.color === a.color && b.style === a.style);
    return b
};

function gvjs_Bw(a) {
    return null === a || "" === a || a === gvjs_e || gvjs_pg(a) && gvjs_Bw(a.color)
}

function gvjs_Cw(a) {
    return 0 < a.strokeWidth && 0 < a.strokeOpacity && !gvjs_Bw(a.stroke)
}

function gvjs_Dw(a) {
    return gvjs_Cw(a) ? a.strokeWidth : 0
}

function gvjs_Ew(a) {
    return 0 < a.fillOpacity && (!gvjs_Bw(a.fill) || null != a.gradient || null != a.pattern)
}

function gvjs_Fw(a) {
    return gvjs_Ew(a) && 1 <= a.fillOpacity
}

function gvjs_Gw(a) {
    return gvjs_Cw(a) && 1 <= a.strokeOpacity
}
var gvjs_Hw = {
    stroke: gvjs_jw,
    strokeOpacity: 0,
    fill: gvjs_jw,
    fillOpacity: 0
};

function gvjs_Iw(a, b) {
    null != b && (a.italic = b);
    return a
}

function gvjs_Jw(a) {
    this.fontName = gvjs_av;
    this.fontSize = Number(10);
    this.color = gvjs_Or;
    this.opacity = 1;
    this.auraColor = "";
    this.DB = 3;
    this.zd = this.italic = this.bold = !1;
    this.setProperties(a || {})
}
gvjs_ = gvjs_Jw.prototype;
gvjs_.setProperties = function(a) {
    a = a || {};
    this.ts(a.fontName);
    this.lj(a.fontSize);
    this.setColor(a.color);
    this.setOpacity(a.opacity);
    var b = a.auraColor;
    null != b && (this.auraColor = b);
    b = a.DB;
    null != b && (this.DB = b);
    this.uk(a.bold);
    gvjs_Iw(this, a.italic);
    a = a.zd;
    null != a && (this.zd = a);
    return this
};
gvjs_.getProperties = function() {
    return {
        fontName: this.fontName,
        fontSize: this.fontSize,
        color: this.color,
        auraColor: this.auraColor,
        auraWidth: this.DB,
        bold: this.bold,
        italic: this.italic,
        underline: this.zd,
        opacity: this.opacity
    }
};
gvjs_.toJSON = function() {
    return gvjs_Fg(this.getProperties())
};
gvjs_.ts = function(a) {
    null != a && "" !== a && (this.fontName = a);
    return this
};
gvjs_.lj = function(a) {
    if (null != a && (typeof a === gvjs_m && (a = Number(a)), typeof a === gvjs_f)) {
        if (0 > a) throw Error("Negative fontSize not allowed.");
        0 < a && (this.fontSize = a)
    }
    return this
};
gvjs_.setColor = function(a) {
    null != a && (this.color = a);
    return this
};
gvjs_.setOpacity = function(a) {
    null != a && (this.opacity = a);
    return this
};
gvjs_.uk = function(a) {
    null != a && (this.bold = a);
    return this
};
var gvjs_Dda = {
        fill: {
            name: gvjs_Ts,
            type: gvjs_Sb
        },
        fillOpacity: {
            name: gvjs_Ys,
            type: gvjs_2u
        },
        stroke: {
            name: gvjs_Bv,
            type: gvjs_Sb
        },
        strokeOpacity: {
            name: gvjs_Kv,
            type: gvjs_2u
        },
        strokeWidth: {
            name: gvjs_Bp,
            type: gvjs_yu
        },
        tg: {
            name: "strokeDashStyle",
            type: ["arrayOfNumber", {
                type: gvjs_m,
                eq: {
                    waa: gvjs_tv,
                    foa: gvjs_ss
                }
            }]
        },
        rx: {
            name: "rx",
            type: gvjs_f
        },
        ry: {
            name: "ry",
            type: gvjs_f
        },
        gradient: {
            name: gvjs_lt,
            type: gvjs_g,
            properties: {
                color1: {
                    name: "color1",
                    type: gvjs_Sb
                },
                color2: {
                    name: "color2",
                    type: gvjs_Sb
                },
                ik: {
                    name: "opacity1",
                    type: gvjs_2u
                },
                jk: {
                    name: "opacity2",
                    type: gvjs_2u
                },
                x1: {
                    name: "x1",
                    type: gvjs_Cu
                },
                y1: {
                    name: "y1",
                    type: gvjs_Cu
                },
                x2: {
                    name: "x2",
                    type: gvjs_Cu
                },
                y2: {
                    name: "y2",
                    type: gvjs_Cu
                },
                Hl: {
                    name: "sharpTransition",
                    type: gvjs_Lb
                },
                useObjectBoundingBoxUnits: {
                    name: "useObjectBoundingBoxUnits",
                    type: gvjs_Lb
                }
            }
        },
        xs: {
            name: "shadow",
            type: gvjs_g,
            properties: {
                radius: {
                    name: "radius",
                    type: gvjs_f
                },
                opacity: {
                    name: gvjs_Ju,
                    type: gvjs_2u
                },
                xOffset: {
                    name: "xOffset",
                    type: gvjs_f
                },
                yOffset: {
                    name: "yOffset",
                    type: gvjs_f
                }
            }
        },
        pattern: {
            name: gvjs_Md,
            type: gvjs_g,
            properties: {
                color: {
                    name: gvjs_Sb,
                    type: gvjs_Sb
                },
                backgroundColor: {
                    name: gvjs_Dr,
                    type: gvjs_Sb
                },
                style: {
                    name: gvjs_6d,
                    type: {
                        type: gvjs_m,
                        eq: {
                            Zoa: gvjs_0u,
                            hpa: gvjs_ev
                        }
                    }
                }
            }
        }
    },
    gvjs_Eda = {
        color: {
            name: gvjs_Sb,
            type: gvjs_Sb
        },
        opacity: {
            name: gvjs_Ju,
            type: gvjs_2u
        },
        auraColor: {
            name: "auraColor",
            type: gvjs_Sb
        },
        DB: {
            name: "auraWidth",
            type: gvjs_yu
        },
        fontName: {
            name: gvjs_at,
            type: gvjs_m
        },
        fontSize: {
            name: gvjs_bt,
            type: gvjs_yu
        },
        bold: {
            name: gvjs_Qr,
            type: gvjs_Lb
        },
        italic: {
            name: gvjs_Tt,
            type: gvjs_Lb
        },
        zd: {
            name: gvjs_5v,
            type: gvjs_Lb
        }
    };

function gvjs_Fda(a, b) {
    b && (a = b(a));
    return gvjs_Ag(a)
}

function gvjs_Kw(a, b, c, d) {
    return gvjs_Xi(a, gvjs_Fda, {}, b, c || {}, d)
}

function gvjs_Lw(a, b, c) {
    return gvjs_Xi(a, gvjs_6i, 0, b, c)
}

function gvjs_Mw(a, b, c, d) {
    return gvjs_Xi(a, gvjs_7i, gvjs_e, b, c, d)
}

function gvjs_Nw(a, b, c) {
    function d(h, k, l) {
        function m() {
            var p = h.type;
            p === gvjs_g ? (p = h.properties, n = gvjs_Nw(a.view(k), p, l)) : n = d(p, k || h.name, l || h.eq)
        }
        var n = null;
        Array.isArray(h) ? h.find(function(p) {
            n = d(p, k, l);
            return null != n
        }) : gvjs_Ag(h) ? m() : typeof h === gvjs_m ? n = d(gvjs_Ri[h], k, l) : typeof h === gvjs_c && (n = h.call(a, k, l));
        return n
    }
    var e = null,
        f;
    for (f in b)
        if (b.hasOwnProperty(f)) {
            var g = b[f];
            g = d(g, g.name, c && c[f]);
            null != g && (null == e && (e = {}), e[f] = g)
        }
    return e
}

function gvjs_Ow(a, b, c) {
    var d = null,
        e = null;
    c instanceof gvjs__ ? d = new gvjs__(c.getProperties()) : typeof c === gvjs_g ? d = new gvjs__(c) : e = c;
    a = a.Wb(b, e);
    a = a.map(function(f) {
        typeof f === gvjs_m && (f = {
            fill: gvjs_7i(f)
        });
        return f
    });
    a = gvjs_Nw(new gvjs_Si(a), gvjs_Dda);
    d = d || new gvjs__;
    d.setProperties(a);
    gvjs_Ew(d) || (d.ie(gvjs_Hw.fill), d.Qd(gvjs_Hw.fillOpacity));
    gvjs_Cw(d) || (d.Jc(gvjs_Hw.stroke), gvjs_yw(d, gvjs_Hw.strokeOpacity));
    return d
}

function gvjs_Pw(a, b, c, d) {
    a = a.Wb(b);
    d = gvjs_Nw(new gvjs_Si(a), gvjs_Eda, {
        color: d,
        auraColor: d
    });
    c = new gvjs_Jw(c || {});
    c.setProperties(d);
    return c
}

function gvjs_Qw(a, b) {
    a.left = Math.min(a.left, b.left);
    a.top = Math.min(a.top, b.top);
    a.right = Math.max(a.right, b.right);
    a.bottom = Math.max(a.bottom, b.bottom)
}

function gvjs_Rw(a, b) {
    b = gvjs_Te(gvjs_K, b);
    a.Ue ? b() : (a.mv || (a.mv = []), a.mv.push(b))
}

function gvjs_Sw(a) {
    return 0 == a.fi.button && !(gvjs_Jf && a.ctrlKey)
}

function gvjs_Tw(a, b) {
    a.wh && (a.wh.reject = b)
}

function gvjs_Uw(a, b, c) {
    var d = gvjs_Ko(a, b);
    c && a.clear();
    d ? a.removeRow(b) : a.addRow(b)
}

function gvjs_Vw(a, b, c) {
    var d = gvjs_Lo(a, b);
    c && a.clear();
    d ? a.removeColumn(b) : a.addColumn(b)
}

function gvjs_Ww(a, b, c, d) {
    var e = gvjs_Mo(a, b, c);
    d && a.clear();
    e ? a.oF(b, c) : gvjs_No(a, b, c)
}

function gvjs_Xw() {
    this.RS = !1;
    this.Os = null;
    this.vX = void 0;
    this.og = 1;
    this.Wo = this.zt = 0;
    this.rR = this.xj = null
}

function gvjs_Yw(a) {
    if (a.RS) throw new TypeError("Generator is already running");
    a.RS = !0
}
gvjs_ = gvjs_Xw.prototype;
gvjs_.Uv = function() {
    this.RS = !1
};
gvjs_.ME = function(a) {
    this.vX = a
};
gvjs_.aG = function(a) {
    this.xj = {
        D2: a,
        b5: !0
    };
    this.og = this.zt || this.Wo
};
gvjs_.return = function(a) {
    this.xj = {
        return: a
    };
    this.og = this.Wo
};

function gvjs_Zw(a, b, c) {
    a.og = c;
    return {
        value: b
    }
}
gvjs_.uf = function(a) {
    this.og = a
};

function gvjs__w(a) {
    this.Fb = new gvjs_Xw;
    this.gka = a
}
gvjs__w.prototype.ME = function(a) {
    gvjs_Yw(this.Fb);
    if (this.Fb.Os) return gvjs_0w(this, this.Fb.Os.next, a, this.Fb.ME);
    this.Fb.ME(a);
    return gvjs_1w(this)
};

function gvjs_Gda(a, b) {
    gvjs_Yw(a.Fb);
    var c = a.Fb.Os;
    if (c) return gvjs_0w(a, gvjs_5u in c ? c[gvjs_5u] : function(d) {
        return {
            value: d,
            done: !0
        }
    }, b, a.Fb.return);
    a.Fb.return(b);
    return gvjs_1w(a)
}
gvjs__w.prototype.aG = function(a) {
    gvjs_Yw(this.Fb);
    if (this.Fb.Os) return gvjs_0w(this, this.Fb.Os["throw"], a, this.Fb.ME);
    this.Fb.aG(a);
    return gvjs_1w(this)
};

function gvjs_0w(a, b, c, d) {
    try {
        var e = b.call(a.Fb.Os, c);
        if (!(e instanceof Object)) throw new TypeError("Iterator result " + e + " is not an object");
        if (!e.done) return a.Fb.Uv(), e;
        var f = e.value
    } catch (g) {
        return a.Fb.Os = null, a.Fb.aG(g), gvjs_1w(a)
    }
    a.Fb.Os = null;
    d.call(a.Fb, f);
    return gvjs_1w(a)
}

function gvjs_1w(a) {
    for (; a.Fb.og;) try {
        var b = a.gka(a.Fb);
        if (b) return a.Fb.Uv(), {
            value: b.value,
            done: !1
        }
    } catch (c) {
        a.Fb.vX = void 0, a.Fb.aG(c)
    }
    a.Fb.Uv();
    if (a.Fb.xj) {
        b = a.Fb.xj;
        a.Fb.xj = null;
        if (b.b5) throw b.D2;
        return {
            value: b.return,
            done: !0
        }
    }
    return {
        value: void 0,
        done: !0
    }
}

function gvjs_2w(a) {
    this.next = function(b) {
        return a.ME(b)
    };
    this.throw = function(b) {
        return a.aG(b)
    };
    this.return = function(b) {
        return gvjs_Gda(a, b)
    };
    this[Symbol.iterator] = function() {
        return this
    }
}

function gvjs_3w(a, b) {
    b = new gvjs_2w(new gvjs__w(b));
    gvjs_Be && a.prototype && gvjs_Be(b, a.prototype);
    return b
}

function gvjs_4w(a, b) {
    return a < b ? -1 : a > b ? 1 : 0
}

function gvjs_5w(a, b) {
    var c = 0;
    a = gvjs_2e(String(a)).split(".");
    b = gvjs_2e(String(b)).split(".");
    for (var d = Math.max(a.length, b.length), e = 0; 0 == c && e < d; e++) {
        var f = a[e] || "",
            g = b[e] || "";
        do {
            f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
            g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
            if (0 == f[0].length && 0 == g[0].length) break;
            c = gvjs_4w(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == g[1].length ? 0 : parseInt(g[1], 10)) || gvjs_4w(0 == f[2].length, 0 == g[2].length) || gvjs_4w(f[2], g[2]);
            f = f[3];
            g = g[3]
        } while (0 == c)
    }
    return c
}

function gvjs_6w(a, b) {
    for (var c = typeof a === gvjs_m ? a.split("") : a, d = a.length - 1; 0 <= d; --d) d in c && b.call(void 0, c[d], d, a)
}

function gvjs_7w(a, b) {
    for (var c = a.length, d = typeof a === gvjs_m ? a.split("") : a, e = 0; e < c; e++)
        if (e in d && b.call(void 0, d[e], e, a)) return e;
    return -1
}

function gvjs_8w(a, b) {
    b = gvjs_7w(a, b);
    return 0 > b ? null : typeof a === gvjs_m ? a.charAt(b) : a[b]
}

function gvjs_9w(a, b) {
    a: {
        for (var c = typeof a === gvjs_m ? a.split("") : a, d = a.length - 1; 0 <= d; d--)
            if (d in c && b.call(void 0, c[d], d, a)) {
                b = d;
                break a
            }
        b = -1
    }
    return 0 > b ? null : typeof a === gvjs_m ? a.charAt(b) : a[b]
}

function gvjs_$w(a) {
    if (!Array.isArray(a))
        for (var b = a.length - 1; 0 <= b; b--) delete a[b];
    a.length = 0
}

function gvjs_ax(a, b) {
    gvjs_tf(a, b) || a.push(b)
}

function gvjs_Hda(a, b, c, d) {
    Array.prototype.splice.apply(a, gvjs_yf(arguments, 1))
}

function gvjs_bx(a, b, c) {
    gvjs_Hda(a, c, 0, b)
}

function gvjs_cx(a, b, c, d, e) {
    for (var f = 0, g = a.length, h; f < g;) {
        var k = f + (g - f >>> 1);
        var l = c ? b.call(e, a[k], k, a) : b(d, a[k]);
        0 < l ? f = k + 1 : (g = k, h = !l)
    }
    return h ? f : -f - 1
}

function gvjs_dx(a, b, c) {
    return gvjs_cx(a, c || gvjs_Bf, !1, b)
}

function gvjs_ex(a, b) {
    if (!gvjs_Ne(a) || !gvjs_Ne(b) || a.length != b.length) return !1;
    for (var c = a.length, d = 0; d < c; d++)
        if (a[d] !== b[d]) return !1;
    return !0
}

function gvjs_fx(a) {
    var b = [];
    if (0 > a - 0) return [];
    for (var c = 0; c < a; c += 1) b.push(c);
    return b
}

function gvjs_gx(a, b) {
    for (var c = [], d = 0; d < b; d++) c[d] = a;
    return c
}

function gvjs_hx(a) {
    for (var b = [], c = 0; c < arguments.length; c++) {
        var d = arguments[c];
        if (Array.isArray(d))
            for (var e = 0; e < d.length; e += 8192) {
                var f = gvjs_yf(d, e, e + 8192);
                f = gvjs_hx.apply(null, f);
                for (var g = 0; g < f.length; g++) b.push(f[g])
            } else b.push(d)
    }
    return b
}

function gvjs_ix(a) {
    if (!arguments.length) return [];
    for (var b = [], c = arguments[0].length, d = 1; d < arguments.length; d++) arguments[d].length < c && (c = arguments[d].length);
    for (d = 0; d < c; d++) {
        for (var e = [], f = 0; f < arguments.length; f++) e.push(arguments[f][d]);
        b.push(e)
    }
    return b
}

function gvjs_jx(a, b, c) {
    return Object.prototype.hasOwnProperty.call(a, b) ? a[b] : a[b] = c(b)
}
var gvjs_Ida = {};

function gvjs_kx(a) {
    return gvjs_jx(gvjs_Ida, a, function() {
        return 0 <= gvjs_5w(gvjs_Sf, a)
    })
}

function gvjs_Jda(a, b) {
    a = [a];
    for (var c = b.length - 1; 0 <= c; --c) a.push(typeof b[c], b[c]);
    return a.join("\v")
}

function gvjs_lx(a) {
    this.wE = Math.max(1, a || Infinity);
    this.cache = new Map
}
gvjs_ = gvjs_lx.prototype;
gvjs_.hla = function(a) {
    this.wE = Math.max(a, 1);
    null != this.wE && this.truncate(this.wE)
};
gvjs_.clear = function() {
    this.cache.clear()
};
gvjs_.contains = function(a) {
    return this.cache.has(a)
};
gvjs_.get = function(a) {
    var b = this.cache.get(a);
    if ("undefined" === typeof b) throw Error('Cache does not contain key "' + a + '"');
    this.cache.delete(a);
    this.cache.set(a, b);
    return b
};
gvjs_.put = function(a, b) {
    this.cache.delete(a);
    if ("undefined" !== typeof b) return this.cache.set(a, b), null != this.wE && this.truncate(this.wE), b
};
gvjs_.size = function() {
    return this.cache.size
};
gvjs_.truncate = function(a) {
    for (var b = gvjs_q(this.cache), c = b.next(); !c.done; c = b.next()) {
        c = gvjs_q(c.value).next().value;
        if (this.cache.size <= a) break;
        this.cache.delete(c)
    }
};

function gvjs_mx(a, b) {
    b = void 0 === b ? {} : b;
    var c = b.wM || gvjs_Jda,
        d = b.size || 1E3,
        e = b.cache || new gvjs_lx(d);
    return Object.assign(function() {
        var f = gvjs_Ce.apply(0, arguments),
            g = c(gvjs_Qe(a), [].concat(gvjs_we(f)));
        return e.contains(g) ? e.get(g) : e.put(g, a.apply(null, gvjs_we(f)))
    }, {
        clear: function() {
            e.clear()
        },
        hla: function(f) {
            e.clear();
            e = b.cache || new gvjs_lx(f)
        }
    })
}

function gvjs_nx(a) {
    for (var b = 0, c = 0; c < a.length; ++c) b = 31 * b + a.charCodeAt(c) >>> 0;
    return b
}

function gvjs_ox(a, b) {
    if (null == a && null == b) return a === b;
    if (a === b) return !0;
    var c = gvjs_Me(a),
        d = gvjs_Me(b);
    if (c !== d) return !1;
    d = gvjs_xg(a);
    var e = gvjs_xg(b);
    if (d !== e) return !1;
    switch (c) {
        case gvjs_g:
            if (d && e) return 0 === a.getTime() - b.getTime();
            for (var f in a)
                if (a.hasOwnProperty(f) && (!b.hasOwnProperty(f) || !gvjs_ox(a[f], b[f]))) return !1;
            for (var g in b)
                if (b.hasOwnProperty(g) && !a.hasOwnProperty(g)) return !1;
            return !0;
        case gvjs_Db:
            if (a.length !== b.length) return !1;
            for (c = 0; c < a.length; ++c)
                if (!gvjs_ox(a[c], b[c])) return !1;
            return !0;
        case gvjs_c:
            return !0;
        case gvjs_m:
        case gvjs_f:
        case gvjs_Lb:
            return !1;
        default:
            throw Error("Error while comparing " + a + " and " + b + ": unexpected type of obj1 " + c);
    }
}

function gvjs_px(a, b) {
    function c(d, e, f) {
        for (var g in d) d.hasOwnProperty(g) && (typeof d[g] === gvjs_g ? c(d[g], e, f) : b.call(void 0, d[g], g, d) && f.push(d[g]));
        return f
    }
    return c(a, gvjs_mx(b), [])
}

function gvjs_Kda(a) {
    a = Object.keys(a);
    a.sort(function(d, e) {
        return d > e ? 1 : d < e ? -1 : 0
    });
    for (var b = {}, c = 0; c < a.length; c++) b[a[c]] = !0;
    return b
}

function gvjs_qx(a, b) {
    var c = gvjs_Me(a);
    b = (31 * b + gvjs_nx(c)) % 67108864;
    switch (c) {
        case gvjs_g:
            if (a.constructor === Date) b = (31 * b + gvjs_nx(gvjs_1b)) % 67108864, b = gvjs_qx(a.getTime(), b);
            else {
                c = gvjs_Kda(a);
                for (var d in c) c.hasOwnProperty(d) && (b = gvjs_qx(a[d], gvjs_qx(d, b)))
            }
            break;
        case gvjs_Db:
            for (d = 0; d < a.length; d++) b = gvjs_qx(a[d], gvjs_qx(String(d), b));
            break;
        default:
            b = (31 * b + gvjs_nx(String(a))) % 67108864
    }
    return b
}

function gvjs_rx(a, b) {
    return a.size === b.size && [].concat(gvjs_we(gvjs_Cg(a))).every(function(c) {
        return b.has(c)
    })
}

function gvjs_sx(a, b) {
    var c = new Set(a);
    b = gvjs_Cg(b);
    for (var d = 0; d < b.length; d++) {
        var e = b[d];
        a.has(e) && c.delete(e)
    }
    return c
}

function gvjs_tx(a, b, c) {
    var d = {},
        e;
    for (e in a) d[e] = b.call(c, a[e], e, a);
    return d
}

function gvjs_ux(a) {
    for (var b in a) return a[b]
}

function gvjs_vx(a, b) {
    return null !== a && b in a
}

function gvjs_wx(a) {
    for (var b in a) return !1;
    return !0
}

function gvjs_xx(a, b) {
    b in a && delete a[b]
}

function gvjs_yx(a, b, c) {
    if (null !== a && b in a) throw Error('The object already contains the key "' + b + '"');
    a[b] = c
}

function gvjs_zx(a, b) {
    return null !== a && b in a ? a[b] : void 0
}

function gvjs_Ax(a, b, c) {
    return b in a ? a[b] : a[b] = c
}

function gvjs_Bx(a) {
    if (!a || typeof a !== gvjs_g) return a;
    if (typeof a.clone === gvjs_c) return a.clone();
    if ("undefined" !== typeof Map && a instanceof Map) return new Map(a);
    if ("undefined" !== typeof Set && a instanceof Set) return new Set(a);
    if (a instanceof Date) return new Date(a.getTime());
    var b = Array.isArray(a) ? [] : typeof ArrayBuffer !== gvjs_c || typeof ArrayBuffer.isView !== gvjs_c || !ArrayBuffer.isView(a) || a instanceof DataView ? {} : new a.constructor(a.length),
        c;
    for (c in a) b[c] = gvjs_Bx(a[c]);
    return b
}
var gvjs_Lda = /%{(\w+)}/g;

function gvjs_Mda(a, b) {
    var c = gvjs_1g(a);
    if (!gvjs_Jaa.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
    a = c.replace(gvjs_Lda, function(d, e) {
        if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
        d = b[e];
        return d instanceof gvjs_Zg ? gvjs_1g(d) : encodeURIComponent(String(d))
    });
    return gvjs_ah(a)
}

function gvjs_Cx(a, b, c) {
    a = gvjs_Mda(a, b);
    a = gvjs_9g(a);
    a = gvjs_Cda.exec(a);
    b = a[3] || "";
    return gvjs_ah(a[1] + gvjs_qw("?", a[2] || "", c) + gvjs_qw("#", b))
}

function gvjs_Dx(a) {
    if (a instanceof gvjs_bh) return a;
    a = typeof a == gvjs_g && a.jl ? a.Wi() : String(a);
    a: {
        var b = a;
        if (gvjs_Maa) {
            try {
                var c = new URL(b)
            } catch (d) {
                b = gvjs_md;
                break a
            }
            b = c.protocol
        } else b: {
            c = document.createElement("a");
            try {
                c.href = b
            } catch (d) {
                b = void 0;
                break b
            }
            b = c.protocol;b = ":" === b || "" === b ? gvjs_md : b
        }
    }
    "javascript:" === b && (a = gvjs_wb);
    return gvjs_fh(a)
}

function gvjs_Ex(a, b, c) {
    a = a instanceof gvjs_bh ? a : gvjs_Dx(a);
    c = c instanceof gvjs_Zg ? gvjs_1g(c) : c || "";
    (b || gvjs_s).open(gvjs_dh(a), c)
}

function gvjs_Fx(a) {
    return !/[^0-9]/.test(a)
}

function gvjs_Gx(a) {
    return a.replace(/[\t\r\n ]+/g, " ").replace(/^[\t\r\n ]+|[\t\r\n ]+$/g, "")
}

function gvjs_Hx(a) {
    return a = gvjs_3e(a)
}

function gvjs_Nda(a) {
    return a.replace(/&([^;]+);/g, function(b, c) {
        switch (c) {
            case "amp":
                return "&";
            case "lt":
                return "<";
            case "gt":
                return ">";
            case "quot":
                return '"';
            default:
                return "#" != c.charAt(0) || (c = Number("0" + c.slice(1)), isNaN(c)) ? b : String.fromCharCode(c)
        }
    })
}
var gvjs_Oda = /&([^;\s<&]+);?/g;

function gvjs_Pda(a) {
    var b = {
        "&amp;": "&",
        "&lt;": "<",
        "&gt;": ">",
        "&quot;": '"'
    };
    var c = gvjs_s.document.createElement(gvjs_5b);
    return a.replace(gvjs_Oda, function(d, e) {
        var f = b[d];
        if (f) return f;
        "#" == e.charAt(0) && (e = Number("0" + e.slice(1)), isNaN(e) || (f = String.fromCharCode(e)));
        f || (f = gvjs_zh(d + " "), gvjs_Hh(c, f), f = c.firstChild.nodeValue.slice(0, -1));
        return b[d] = f
    })
}

function gvjs_Ix(a) {
    return gvjs_4e(a, "&") ? "document" in gvjs_s ? gvjs_Pda(a) : gvjs_Nda(a) : a
}

function gvjs_Jx(a, b) {
    a.length > b && (a = a.substring(0, b - 3) + gvjs_uq);
    return a
}

function gvjs_Kx(a) {
    var b = Number(a);
    return 0 == b && gvjs_1e(a) ? NaN : b
}

function gvjs_Lx(a) {
    return String(a).replace(/([A-Z])/g, "-$1").toLowerCase()
}

function gvjs_Mx(a, b) {
    a %= b;
    return 0 > a * b ? a + b : a
}

function gvjs_Nx(a, b, c) {
    return a + c * (b - a)
}

function gvjs_Ox(a) {
    return a * Math.PI / 180
}

function gvjs_Px(a) {
    return 180 * a / Math.PI
}

function gvjs_Qx(a, b) {
    return b * Math.cos(gvjs_Ox(a))
}

function gvjs_Rx(a, b) {
    return b * Math.sin(gvjs_Ox(a))
}

function gvjs_Sx(a) {
    return 0 < a ? 1 : 0 > a ? -1 : a
}

function gvjs_Tx(a) {
    return Array.prototype.reduce.call(arguments, function(b, c) {
        return b + c
    }, 0)
}

function gvjs_Ux(a) {
    return gvjs_Tx.apply(null, arguments) / arguments.length
}

function gvjs_Vx(a, b, c) {
    0 > c ? c += 1 : 1 < c && --c;
    return 1 > 6 * c ? a + 6 * (b - a) * c : 1 > 2 * c ? b : 2 > 3 * c ? a + (b - a) * (2 / 3 - c) * 6 : a
}

function gvjs_Wx(a, b, c) {
    a /= 360;
    if (0 == b) c = b = a = 255 * c;
    else {
        var d = .5 > c ? c * (1 + b) : c + b - b * c;
        var e = 2 * c - d;
        c = 255 * gvjs_Vx(e, d, a + 1 / 3);
        b = 255 * gvjs_Vx(e, d, a);
        a = 255 * gvjs_Vx(e, d, a - 1 / 3)
    }
    return [Math.round(c), Math.round(b), Math.round(a)]
}

function gvjs_Xx(a) {
    return !!(gvjs_ai.test("#" == a.charAt(0) ? a : "#" + a) || gvjs_ci(a).length || gvjs_9h && gvjs_9h[a.toLowerCase()])
}

function gvjs_Yx(a, b) {
    return gvjs_gi([0, 0, 0], a, b)
}

function gvjs_Zx(a, b) {
    return gvjs_gi([255, 255, 255], a, b)
}

function gvjs_Qda(a, b) {
    return Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) + Math.abs(a[2] - b[2])
}

function gvjs__x(a) {
    return Math.round((299 * a[0] + 587 * a[1] + 114 * a[2]) / 1E3)
}

function gvjs_0x(a, b) {
    for (var c = [], d = 0; d < b.length; d++) c.push({
        color: b[d],
        Uk: Math.abs(gvjs__x(b[d]) - gvjs__x(a)) + gvjs_Qda(b[d], a)
    });
    c.sort(function(e, f) {
        return f.Uk - e.Uk
    });
    return c[0].color
}

function gvjs_1x(a, b) {
    var c = a.x - b.x;
    a = a.y - b.y;
    return Math.sqrt(c * c + a * a)
}

function gvjs_2x(a, b) {
    return new gvjs_A(a.x - b.x, a.y - b.y)
}

function gvjs_3x(a, b) {
    return new gvjs_A(a.x + b.x, a.y + b.y)
}

function gvjs_4x(a, b) {
    return a == b ? !0 : a && b ? a.width == b.width && a.height == b.height : !1
}

function gvjs_5x(a, b, c) {
    return gvjs_pi(document, arguments)
}

function gvjs_6x(a, b) {
    for (; b = b.previousSibling;)
        if (b == a) return -1;
    return 1
}

function gvjs_7x(a, b) {
    var c = a.parentNode;
    if (c == b) return -1;
    for (; b.parentNode != c;) b = b.parentNode;
    return gvjs_6x(b, a)
}

function gvjs_Rda(a, b) {
    if (a == b) return 0;
    if (a.compareDocumentPosition) return a.compareDocumentPosition(b) & 2 ? 1 : -1;
    if (gvjs_x && !gvjs_Tf(9)) {
        if (9 == a.nodeType) return -1;
        if (9 == b.nodeType) return 1
    }
    if ("sourceIndex" in a || a.parentNode && "sourceIndex" in a.parentNode) {
        var c = 1 == a.nodeType,
            d = 1 == b.nodeType;
        if (c && d) return a.sourceIndex - b.sourceIndex;
        var e = a.parentNode,
            f = b.parentNode;
        return e == f ? gvjs_6x(a, b) : !c && gvjs_Hi(e, b) ? -1 * gvjs_7x(a, b) : !d && gvjs_Hi(f, a) ? gvjs_7x(b, a) : (c ? a.sourceIndex : e.sourceIndex) - (d ? b.sourceIndex :
            f.sourceIndex)
    }
    d = gvjs_ki(a);
    c = d.createRange();
    c.selectNode(a);
    c.collapse(!0);
    a = d.createRange();
    a.selectNode(b);
    a.collapse(!0);
    return c.compareBoundaryPoints(gvjs_s.Range.START_TO_END, a)
}

function gvjs_8x(a, b) {
    b ? a.tabIndex = 0 : (a.tabIndex = -1, a.removeAttribute("tabIndex"))
}

function gvjs_9x(a) {
    var b = [];
    gvjs_Ni(a, b, !1);
    return b.join("")
}

function gvjs_$x(a, b) {
    a && (a.logicalname = b)
}

function gvjs_ay(a) {
    return (a = gvjs_Oi(a, function(b) {
        return null != b.logicalname
    }, !0)) ? a.logicalname : gvjs_2q
}

function gvjs_by(a, b, c) {
    return a && a !== gvjs_e ? b && b !== gvjs_e ? gvjs_di(gvjs_gi(gvjs_ei(a), gvjs_ei(b), c)) : a : b
}

function gvjs_Sda(a, b) {
    a = gvjs_vw(a.ac, b);
    var c = [];
    a.hasAttribute(gvjs_us) && c.push(a);
    Array.from(a.querySelectorAll("[data-logicalname]")).forEach(function(d) {
        c.push(d)
    });
    c.forEach(function(d) {
        var e = d.getAttribute(gvjs_us);
        gvjs_$x(d, e)
    });
    return a
}

function gvjs_cy(a, b) {
    return new gvjs__({
        stroke: gvjs_e,
        fill: a,
        fillOpacity: void 0 === b ? 1 : b
    })
}

function gvjs_dy(a, b, c, d) {
    return new gvjs__({
        stroke: a,
        strokeWidth: b,
        strokeOpacity: null != d ? d : 1,
        fill: null != c && c ? gvjs_lq : gvjs_e
    })
}

function gvjs_ey(a, b) {
    return a === b ? !0 : null === a || null === b ? !1 : a.equals(b)
}

function gvjs_fy(a, b) {
    var c = gvjs_Gj.lastIndexOf(".");
    if (0 > a || 0 >= b) return gvjs_Gj.substr(0, c);
    a > b && (b = gvjs_q([b, a]), a = b.next().value, b = b.next().value);
    c = gvjs_Gj.substr(0, c + 1);
    a = "0".repeat(a) + "#".repeat(b - a);
    return c + a
}

function gvjs_gy(a, b, c, d) {
    this.x0 = a;
    this.y0 = b;
    this.x1 = c;
    this.y1 = d
}
gvjs_gy.prototype.clone = function() {
    return new gvjs_gy(this.x0, this.y0, this.x1, this.y1)
};
gvjs_gy.prototype.equals = function(a) {
    return this.x0 == a.x0 && this.y0 == a.y0 && this.x1 == a.x1 && this.y1 == a.y1
};

function gvjs_hy(a) {
    var b = a.x1 - a.x0;
    a = a.y1 - a.y0;
    return b * b + a * a
}

function gvjs_iy(a, b) {
    return new gvjs_A(gvjs_Nx(a.x0, a.x1, b), gvjs_Nx(a.y0, a.y1, b))
}

function gvjs_jy(a, b) {
    return new gvjs_Ij(a.x + b.x, a.y + b.y)
}

function gvjs_ky(a, b) {
    return new gvjs_Ij(a.x - b.x, a.y - b.y)
}

function gvjs_ly(a) {
    return null == a || "" === a ? null : Number(a)
}

function gvjs_Tda(a, b, c) {
    if (0 === a.x || 0 === b.x) return {
        x: 0,
        y: (0 === a.x && 0 === b.x ? 0 : 0 === a.x ? a.y : b.y) * c / 6
    };
    c = c / 3 * Math.min(Math.abs(a.x), Math.abs(b.x));
    b = (a.y / a.x + b.y / b.x) / 2;
    return 0 < a.x ? {
        x: c,
        y: c * b
    } : {
        x: -c,
        y: -c * b
    }
}

function gvjs_Uda(a, b, c) {
    var d = a.magnitude(),
        e = b.magnitude();
    if (0 === d || 0 === e) return new gvjs_Ij(0, 0);
    d = Math.sqrt(d / e);
    a = gvjs_jy(a.clone().scale(1 / d), b.clone().scale(d));
    a.scale(c / 6);
    return a
}

function gvjs_my(a, b, c, d) {
    var e = b + c;
    for (d && (e = (e + a.length) % a.length); e !== b && 0 <= e && e < a.length;) {
        if (null != a[e]) return e;
        e += c;
        d && (e = (e + a.length) % a.length)
    }
    return null
}

function gvjs_ny(a, b, c, d, e) {
    c = c ? gvjs_Tda : gvjs_Uda;
    for (var f = [], g = 0; g < a.length; ++g) {
        if (e) {
            var h = gvjs_my(a, g, 1, d);
            var k = gvjs_my(a, g, -1, d)
        } else h = d ? (g + 1) % a.length : g + 1, k = d ? (a.length + g - 1) % a.length : g - 1;
        null != h && null != k && null != a[g] && null != a[k] && null != a[h] ? (h = c(gvjs_ky(a[g], a[k]), gvjs_ky(a[h], a[g]), b), f.push([gvjs_ky(a[g], h), gvjs_jy(a[g], h)])) : null != a[g] ? f.push([a[g].clone(), a[g].clone()]) : f.push(null)
    }
    return f
}

function gvjs_oy(a, b, c) {
    c = void 0 === c ? 0 : c;
    var d = b.findIndex(function(e) {
        return e[c] > a
    });
    return -1 === d ? b.length - 1 : 0 === d ? 0 : b[d][c] - a < a - b[d - 1][c] ? d : d - 1
}

function gvjs_Vda(a, b, c) {
    c = void 0 === c ? 0 : c;
    var d = void 0 === d ? 0 : d;
    if (0 < b.length && a <= b[b.length - 1][d]) return c = gvjs_oy(a, b, d), [c, b[c][d]];
    var e = b.length - 1 - c,
        f = b[b.length - 1][d],
        g = b[e][d],
        h = f - g,
        k = Math.floor((a - f) / h);
    a = a - f - k * h;
    e = b.slice(e).map(function(l) {
        return [l[d] - g]
    });
    a = gvjs_oy(a, e, 0);
    return [b.length - 1 + k * c + a, f + k * h + e[a][0]]
}

function gvjs_py(a, b) {
    for (var c = [], d = 0; d < a; d++) c[d] = b.call(void 0, d);
    return c
}

function gvjs_qy(a) {
    return null != a.max ? a.max : a.min
}

function gvjs_Wda(a, b) {
    var c = void 0,
        d = void 0;
    void 0 === c && (c = 0);
    void 0 === d && (d = a.length);
    c = b - c;
    for (var e = 0, f = 0 <= c ? 0 : null, g = 0, h = 0, k = null, l = null; e < a.length;) {
        var m = a[e].min,
            n = gvjs_qy(a[e]) - m;
        g += m;
        g <= c && (f = e + 1, l = Math.min(c - g, n), h = g + l, l = m + l);
        if (g > b) return e >= d ? {
            jU: e,
            dT: k,
            nF: b - (g - m)
        } : null == f ? null : {
            jU: f,
            dT: l,
            nF: c - h
        };
        k = Math.min(b - g, n);
        g += k;
        k = m + k;
        e++
    }
    return {
        jU: e,
        dT: k,
        nF: b - g
    }
}

function gvjs_Xda(a, b, c) {
    c = c || gvjs_pw;
    a = a.map(c);
    a.sort(function(g, h) {
        return g > h ? 1 : g < h ? -1 : 0
    });
    for (var d = c = 0; d < a.length; d++) {
        var e = a.length - d,
            f = (a[d] - c) * e;
        if (f <= b) c = a[d], b -= f;
        else {
            c += b / e;
            b = 0;
            break
        }
    }
    return {
        tna: c,
        nF: b
    }
}

function gvjs_ry(a, b) {
    var c = gvjs_Wda(a, b);
    if (!c) return null;
    b = c.nF;
    var d = a.slice(0, c.jU),
        e = d.reduce(function(k, l) {
            return Math.max(k, l.extra.length)
        }, 0),
        f = d.map(gvjs_qy);
    0 < f.length && (f[f.length - 1] = c.dT);
    for (c = {
            xw: 0
        }; c.xw < e; c = {
            xw: c.xw
        }, c.xw++) {
        var g = gvjs_Xda(d, b, function(k) {
            return function(l) {
                return l.extra[k.xw] || 0
            }
        }(c));
        b = g.nF;
        for (var h = 0; h < f.length; h++) f[h] += Math.min(g.tna, a[h].extra[c.xw] || 0);
        if (0 === b) break
    }
    return f
}

function gvjs_sy(a, b) {
    b = gvjs_ry(a, b);
    var c = {};
    if (null != b) {
        a = gvjs_q(a.entries());
        for (var d = a.next(); !d.done; d = a.next()) {
            var e = gvjs_q(d.value);
            d = e.next().value;
            e = e.next().value;
            e = e.key;
            null == c[e] && (c[e] = []);
            d < b.length && c[e].push(b[d])
        }
    }
    return c
}

function gvjs_Yda(a) {
    for (var b = gvjs_Ce.apply(1, arguments), c = [], d = 0; d < b.length; d += 2) {
        var e = a.slice(Math.min(b[d], a.length), Math.min(b[d + 1], a.length));
        c.push.apply(c, gvjs_we(e))
    }
    return c
}

function gvjs_ty(a) {
    if (0 === a) return 0;
    a = Math.abs(a);
    for (var b = 0; 16 > b; ++b) {
        if (Math.abs(a - Math.round(a)) < 1E-15 * a) return b;
        a *= 10
    }
    return 16
}

function gvjs_uy(a, b) {
    if (0 === b || 1E-290 > Math.abs(b)) return b;
    var c = Math.floor(Math.log10(Math.abs(b))) + 1;
    if (c > a) return a = Math.pow(10, c - a), Math.round(b / a) * a;
    a = Math.pow(10, a - c);
    return Math.round(b * a) / a
}

function gvjs_vy(a, b, c) {
    return 0 > b || 0 > c ? null : a[b][c]
}

function gvjs_Zda(a, b, c, d, e, f) {
    var g = [],
        h = gvjs_vy(c, d - 1, e);
    h && g.push({
        tL: h,
        rn: h.rn + 1,
        gE: d - 1,
        FN: null,
        hE: null,
        GN: null
    });
    (h = gvjs_vy(c, d, e - 1)) && g.push({
        tL: h,
        rn: h.rn + 1,
        gE: null,
        FN: null,
        hE: e - 1,
        GN: null
    });
    (c = gvjs_vy(c, d - 1, e - 1)) && f(a[d - 1], b[e - 1]) && g.push({
        tL: c,
        rn: c.rn,
        gE: d - 1,
        FN: e - 1,
        hE: e - 1,
        GN: d - 1
    });
    g.sort(function(k, l) {
        return k.rn - l.rn
    });
    return 0 < g.length ? g[0] : {
        tL: null,
        rn: 0,
        gE: null,
        FN: null,
        hE: null,
        GN: null
    }
}

function gvjs_wy(a, b, c) {
    c = c || function(k, l) {
        return k === l
    };
    for (var d = [], e = a.length, f = b.length, g = 0; g <= e; g++) {
        d[g] = d[g] || [];
        for (var h = 0; h <= f; h++) d[g][h] = gvjs_Zda(a, b, d, g, h, c)
    }
    a = {};
    b = {};
    d = d[e][f];
    for (e = d.rn; d;) null != d.gE && (a[d.gE] = d.FN), null != d.hE && (b[d.hE] = d.GN), d = d.tL;
    return {
        rn: e,
        R5: a,
        S5: b
    }
}

function gvjs__da(a, b, c) {
    function d(l, m, n) {
        if (null == n) return 0;
        if (n === m.length - 1 || null == l) return n;
        var p = c(m[n]);
        if (null == p) return n + 1;
        m = c(m[n + 1]);
        return null == m ? n : Math.abs(l - p) <= Math.abs(l - m) ? n : n + 1
    }
    if (!a || !b || 0 === a.length || 0 === b.length) return null;
    var e = [];
    c || (c = gvjs_pw);
    for (var f = 0, g = 0, h, k; f < a.length || g < b.length;) f < a.length && (h = c(a[f])), g < b.length && (k = c(b[g])), f < a.length && g < b.length && h === k ? (e.push({
        value: h,
        ax: f,
        bx: g
    }), f++, g++) : f < a.length && (null == h || g === b.length || h < k) ? (e.push({
            value: h,
            ax: f,
            bx: void 0
        }),
        f++) : g < b.length && (null == k || f === a.length || k < h) && (e.push({
        value: k,
        ax: void 0,
        bx: g
    }), g++);
    g = f = null;
    h = gvjs_q(e);
    for (k = h.next(); !k.done; k = h.next()) k = k.value, null == k.ax ? k.ax = d(k.value, a, f) : f = k.ax, null == k.bx ? k.bx = d(k.value, b, g) : g = k.bx;
    return e
}

function gvjs_xy(a, b) {
    for (var c in a)
        if (!b.includes(c)) return !1;
    return !0
}

function gvjs_0da(a, b, c) {
    for (var d = 0, e = a.length - 1; d <= e;) {
        var f = Math.floor((e + d) / 2),
            g = c(b, a[f]);
        if (0 < g) d = f + 1;
        else if (0 > g) e = f - 1;
        else {
            for (; 0 < f && 0 === c(b, a[f - 1]);) --f;
            return f
        }
    }
    return -d - 1
}

function gvjs_yy(a, b) {
    var c = gvjs_0da(a, b, function(e, f) {
        f = f.x;
        return e > f ? 1 : e < f ? -1 : 0
    });
    if (0 <= c) return a[c].y;
    var d = -(c + 1);
    if (0 === d || d === a.length) return null;
    c = a[d - 1];
    a = a[d];
    return gvjs_iy(new gvjs_gy(c.x, c.y, a.x, a.y), (b - c.x) / (a.x - c.x)).y
}

function gvjs_zy(a, b, c) {
    if (c) return gvjs_yy(a.filter(function(e) {
        return null != e
    }), b);
    var d = -1;
    for (c = 0; c < a.length; c++)
        if (null == a[c]) {
            d = a.slice(d + 1, c);
            d = gvjs_yy(d, b);
            if (null !== d) return d;
            d = c
        }
    a = a.slice(d + 1);
    return gvjs_yy(a, b)
}
var gvjs_Ay = "Milliseconds Seconds Minutes Hours Date Month FullYear".split(" "),
    gvjs_1da = [0, 0, 0, 0, 1, 0, 0];

function gvjs_By(a, b) {
    for (var c = new Date(a.getTime()), d = !1, e = b.length, f = Math.floor, g = 0; g < e; ++g) {
        var h = a["set" + gvjs_Ay[g]],
            k = a["get" + gvjs_Ay[g]].apply(a),
            l = b[g],
            m = gvjs_1da[g];
        if (0 === l) d = d || 0 !== k && !1, h.apply(c, [m]);
        else {
            d ? h.apply(c, [m + l * (1 + Math.floor((k - m) / l))]) : h.apply(c, [m + l * f((k - m) / l)]);
            break
        }
    }
    return c
}
var gvjs_2da = [500, 30, 30, 12, 15, 6, 0];

function gvjs_3da(a, b) {
    var c = Math.round,
        d = Array.from(a),
        e;
    for (e = 0; e < d.length && 0 === b[e]; ++e) d[e] = 0;
    if (0 === e) return d[0] = c(a[0] / b[0]) * b[0], d;
    var f = 0;
    a[e - 1] >= gvjs_2da[e - 1] ? f = .7 : 0 < a[e - 1] && (f = .1);
    d[e] = c((a[e] + f) / b[e]) * b[e];
    return d
}

function gvjs_Cy(a, b) {
    a = new Date(a.getTime());
    var c;
    a: {
        for (c = 0; c < b.length; ++c)
            if (0 !== b[c]) {
                c = !1;
                break a
            }
        c = !0
    }
    if (c) return a;
    for (c = 0; c < b.length; ++c)
        if (0 !== b[c]) {
            var d = gvjs_Ay[c],
                e = a["set" + d];
            d = a["get" + d].apply(a, []);
            e.apply(a, [d + -1 * b[c]])
        }
    return a
}

function gvjs_Dy(a, b, c, d) {
    this.eR = b;
    this.kka = d;
    this.Y8 = a.getTime();
    this.aX = a["get" + gvjs_Ay[c]].apply(a, []);
    this.ola = a["set" + gvjs_Ay[c]];
    this.gv = new Date(this.Y8)
}
gvjs_Dy.prototype.next = function() {
    var a = this.gv;
    this.gv = new Date(this.Y8);
    this.aX += this.kka;
    this.ola.apply(this.gv, [this.aX]);
    return a
};
gvjs_Dy.prototype.peek = function() {
    return this.gv <= this.eR ? this.gv : null
};

function gvjs_Ey(a) {
    a = a.findIndex(function(b) {
        return 0 !== b
    });
    return Math.max(0, a)
}
var gvjs_Fy = [1, 1E3, 6E4, 36E5, 864E5, 2629743830, 31556926E3];

function gvjs_Gy(a) {
    for (var b = [], c = gvjs_Fy.length - 1; 0 <= c; c--) b[c] = Math.floor(a / gvjs_Fy[c]), a -= b[c] * gvjs_Fy[c];
    return b
}

function gvjs_Hy(a) {
    if (null == a) return -1;
    for (var b = 0, c = a.length, d = 0; d < c; ++d) b += a[d] * gvjs_Fy[d];
    return b
}

function gvjs_4da(a, b, c) {
    var d = b.map(function(e) {
        return [Math.log(gvjs_Hy(e))]
    });
    if (!c) return d = gvjs_oy(Math.log(a), d), b[d];
    a = gvjs_Vda(Math.log(a), d, c);
    c = a[0];
    return c <= d.length - 1 ? b[c] : gvjs_3da(gvjs_Gy(Math.exp(a[1])), b[b.length - 1])
}

function gvjs_Iy(a) {
    a = gvjs_Jj(a);
    return gvjs_Hy(a)
}

function gvjs_5da(a, b) {
    return a.map(function(c) {
        return c * b
    })
}
var gvjs_Jy = [
    [1],
    [0, 1],
    [0, 0, 1],
    [0, 0, 0, 1],
    [0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 0, 1]
];

function gvjs_Ky(a, b) {
    return a.left <= b.right && b.left <= a.right && a.top <= b.bottom && b.top <= a.bottom
}

function gvjs_Ly(a, b, c) {
    return a.left <= b.right + c && b.left <= a.right + c && a.top <= b.bottom + c && b.top <= a.bottom + c
}

function gvjs_My(a, b) {
    return a == b ? !0 : a && b ? a.left == b.left && a.width == b.width && a.top == b.top && a.height == b.height : !1
}

function gvjs_0(a, b, c, d) {
    this.left = a;
    this.top = b;
    this.width = c;
    this.height = d
}
gvjs_ = gvjs_0.prototype;
gvjs_.clone = function() {
    return new gvjs_0(this.left, this.top, this.width, this.height)
};

function gvjs_Ny(a) {
    return new gvjs_H(a.top, a.left + a.width, a.top + a.height, a.left)
}
gvjs_.IS = function(a) {
    var b = Math.max(this.left, a.left),
        c = Math.min(this.left + this.width, a.left + a.width);
    if (b <= c) {
        var d = Math.max(this.top, a.top);
        a = Math.min(this.top + this.height, a.top + a.height);
        d <= a && (this.left = b, this.top = d, this.width = c - b, this.height = a - d)
    }
};
gvjs_.intersects = function(a) {
    return this.left <= a.left + a.width && a.left <= this.left + this.width && this.top <= a.top + a.height && a.top <= this.top + this.height
};
gvjs_.contains = function(a) {
    return a instanceof gvjs_A ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
};
gvjs_.distance = function(a) {
    var b = a.x < this.left ? this.left - a.x : Math.max(a.x - (this.left + this.width), 0);
    a = a.y < this.top ? this.top - a.y : Math.max(a.y - (this.top + this.height), 0);
    return Math.sqrt(b * b + a * a)
};
gvjs_.getSize = function() {
    return new gvjs_B(this.width, this.height)
};
gvjs_.getCenter = function() {
    return new gvjs_A(this.left + this.width / 2, this.top + this.height / 2)
};
gvjs_.ceil = function() {
    this.left = Math.ceil(this.left);
    this.top = Math.ceil(this.top);
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this
};
gvjs_.floor = function() {
    this.left = Math.floor(this.left);
    this.top = Math.floor(this.top);
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this
};
gvjs_.round = function() {
    this.left = Math.round(this.left);
    this.top = Math.round(this.top);
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this
};
gvjs_.translate = function(a, b) {
    a instanceof gvjs_A ? (this.left += a.x, this.top += a.y) : (this.left += a, typeof b === gvjs_f && (this.top += b));
    return this
};
gvjs_.scale = function(a, b) {
    b = typeof b === gvjs_f ? b : a;
    this.left *= a;
    this.width *= a;
    this.top *= b;
    this.height *= b;
    return this
};

function gvjs_Oy(a) {
    return new gvjs_0(a.left, a.top, a.right - a.left, a.bottom - a.top)
}

function gvjs_Py(a, b) {
    var c = a.style[gvjs_Nh(b)];
    return "undefined" !== typeof c ? c : a.style[gvjs_ik(a, b)] || ""
}

function gvjs_Qy(a, b) {
    typeof a == gvjs_f && (a = (b ? Math.round(a) : a) + gvjs_Z);
    return a
}

function gvjs_Ry(a, b, c) {
    if (b instanceof gvjs_A) {
        var d = b.x;
        b = b.y
    } else d = b, b = c;
    a.style.left = gvjs_Qy(d, !1);
    a.style.top = gvjs_Qy(b, !1)
}

function gvjs_Sy(a) {
    a = a ? gvjs_ki(a) : document;
    return !gvjs_x || gvjs_Tf(9) || gvjs_ui(gvjs_ii(a).ac) ? a.documentElement : a.body
}

function gvjs_Ty(a) {
    try {
        return a.getBoundingClientRect()
    } catch (b) {
        return {
            left: 0,
            top: 0,
            right: 0,
            bottom: 0
        }
    }
}

function gvjs_6da(a) {
    if (gvjs_x && !gvjs_Tf(8)) return a.offsetParent;
    var b = gvjs_ki(a),
        c = gvjs_lk(a, gvjs_Pd),
        d = c == gvjs_0s || c == gvjs_xb;
    for (a = a.parentNode; a && a != b; a = a.parentNode)
        if (11 == a.nodeType && a.host && (a = a.host), c = gvjs_lk(a, gvjs_Pd), d = d && "static" == c && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || c == gvjs_0s || c == gvjs_xb || c == gvjs_Td)) return a;
    return null
}

function gvjs_Uy(a) {
    var b = gvjs_ki(a),
        c = new gvjs_A(0, 0),
        d = gvjs_Sy(b);
    if (a == d) return c;
    a = gvjs_Ty(a);
    b = gvjs_tw(gvjs_ii(b).ac);
    c.x = a.left + b.x;
    c.y = a.top + b.y;
    return c
}

function gvjs_Vy(a) {
    for (var b = new gvjs_H(0, Infinity, Infinity, 0), c = gvjs_ii(a), d = c.Hb().body, e = c.Hb().documentElement, f = gvjs_sw(c.ac); a = gvjs_6da(a);)
        if (!(gvjs_x && 0 == a.clientWidth || gvjs_If && 0 == a.clientHeight && a == d) && a != d && a != e && gvjs_lk(a, "overflow") != gvjs_hw) {
            var g = gvjs_Uy(a),
                h = new gvjs_A(a.clientLeft, a.clientTop);
            g.x += h.x;
            g.y += h.y;
            b.top = Math.max(b.top, g.y);
            b.right = Math.min(b.right, g.x + a.clientWidth);
            b.bottom = Math.min(b.bottom, g.y + a.clientHeight);
            b.left = Math.max(b.left, g.x)
        }
    d = f.scrollLeft;
    f = f.scrollTop;
    b.left = Math.max(b.left, d);
    b.top = Math.max(b.top, f);
    c = c.Yi();
    c = gvjs_rw(c || window);
    b.right = Math.min(b.right, d + c.width);
    b.bottom = Math.min(b.bottom, f + c.height);
    return 0 <= b.top && 0 <= b.left && b.bottom > b.top && b.right > b.left ? b : null
}

function gvjs_Wy(a) {
    var b = a.offsetWidth,
        c = a.offsetHeight,
        d = gvjs_If && !b && !c;
    return (void 0 === b || d) && a.getBoundingClientRect ? (a = gvjs_Ty(a), new gvjs_B(a.right - a.left, a.bottom - a.top)) : new gvjs_B(b, c)
}

function gvjs_Xy(a) {
    a = gvjs_Ty(a);
    return new gvjs_A(a.left, a.top)
}

function gvjs_Yy(a) {
    if (1 == a.nodeType) return gvjs_Xy(a);
    a = a.changedTouches ? a.changedTouches[0] : a;
    return new gvjs_A(a.clientX, a.clientY)
}

function gvjs_Zy(a, b) {
    a = gvjs_Yy(a);
    b = gvjs_Yy(b);
    return new gvjs_A(a.x - b.x, a.y - b.y)
}

function gvjs__y(a, b) {
    a.style.width = gvjs_Qy(b, !0)
}

function gvjs_0y(a, b, c) {
    if (b instanceof gvjs_B) c = b.height, b = b.width;
    else if (void 0 == c) throw Error("missing height argument");
    gvjs__y(a, b);
    a.style.height = gvjs_Qy(c, !0)
}

function gvjs_1y(a) {
    if (gvjs_lk(a, gvjs_Es) != gvjs_e) return gvjs_Wy(a);
    var b = a.style,
        c = b.display,
        d = b.visibility,
        e = b.position;
    b.visibility = gvjs_kd;
    b.position = gvjs_xb;
    b.display = gvjs_Nt;
    a = gvjs_Wy(a);
    b.display = c;
    b.position = e;
    b.visibility = d;
    return a
}

function gvjs_2y(a) {
    var b = gvjs_Uy(a);
    a = gvjs_1y(a);
    return new gvjs_0(b.x, b.y, a.width, a.height)
}

function gvjs_3y(a, b) {
    a = a.style;
    gvjs_Ju in a ? a.opacity = b : "MozOpacity" in a ? a.MozOpacity = b : gvjs_Zs in a && (a.filter = "" === b ? "" : "alpha(opacity=" + 100 * Number(b) + ")")
}

function gvjs_4y(a, b) {
    a.style.display = b ? "" : gvjs_e
}

function gvjs_5y(a) {
    return gvjs_Zd == gvjs_lk(a, gvjs_Cs)
}

function gvjs_6y(a, b, c) {
    c = c ? null : a.getElementsByTagName("*");
    if (gvjs_nk) {
        if (b = b ? gvjs_e : "", a.style && (a.style[gvjs_nk] = b), c) {
            a = 0;
            for (var d; d = c[a]; a++) d.style && (d.style[gvjs_nk] = b)
        }
    } else if (gvjs_x && (b = b ? "on" : "", a.setAttribute("unselectable", b), c))
        for (a = 0; d = c[a]; a++) d.setAttribute("unselectable", b)
}

function gvjs_7y(a, b) {
    b = b || gvjs_sw(document);
    var c = b || gvjs_sw(document);
    var d = gvjs_Uy(a),
        e = gvjs_Uy(c),
        f = gvjs_rk(c);
    if (c == gvjs_sw(document)) {
        var g = d.x - c.scrollLeft;
        d = d.y - c.scrollTop;
        gvjs_x && !gvjs_Tf(10) && (g += f.left, d += f.top)
    } else g = d.x - e.x - f.left, d = d.y - e.y - f.top;
    a = gvjs_Wy(a);
    f = c.clientHeight - a.height;
    e = c.scrollLeft;
    var h = c.scrollTop;
    e += Math.min(g, Math.max(g - (c.clientWidth - a.width), 0));
    h += Math.min(d, Math.max(d - f, 0));
    c = new gvjs_A(e, h);
    b.scrollLeft = c.x;
    b.scrollTop = c.y
}

function gvjs_8y(a) {
    var b = {};
    a.split(/\s*;\s*/).forEach(function(c) {
        var d = c.match(/\s*([\w-]+)\s*:(.+)/);
        d && (c = d[1], d = gvjs_2e(d[2]), b[gvjs_Nh(c.toLowerCase())] = d)
    });
    return b
}

function gvjs_9y(a) {
    var b = [];
    gvjs_y(a, function(c, d) {
        b.push(gvjs_Lx(d), ":", c, ";")
    });
    return b.join("")
}

function gvjs_$y(a) {
    a.preventDefault()
}

function gvjs_az(a, b) {
    gvjs_7k.call(this);
    this.Ky = a || 1;
    this.cG = b || gvjs_s;
    this.z0 = gvjs_Se(this.FW, this);
    this.lE = gvjs_Ue()
}
gvjs_u(gvjs_az, gvjs_7k);
gvjs_ = gvjs_az.prototype;
gvjs_.enabled = !1;
gvjs_.gd = null;
gvjs_.setInterval = function(a) {
    this.Ky = a;
    this.gd && this.enabled ? (this.stop(), this.start()) : this.gd && this.stop()
};
gvjs_.FW = function() {
    if (this.enabled) {
        var a = gvjs_Ue() - this.lE;
        0 < a && a < .8 * this.Ky ? this.gd = this.cG.setTimeout(this.z0, this.Ky - a) : (this.gd && (this.cG.clearTimeout(this.gd), this.gd = null), this.dispatchEvent(gvjs_Qv), this.enabled && (this.stop(), this.start()))
    }
};
gvjs_.start = function() {
    this.enabled = !0;
    this.gd || (this.gd = this.cG.setTimeout(this.z0, this.Ky), this.lE = gvjs_Ue())
};
gvjs_.stop = function() {
    this.enabled = !1;
    this.gd && (this.cG.clearTimeout(this.gd), this.gd = null)
};
gvjs_.J = function() {
    gvjs_az.G.J.call(this);
    this.stop();
    delete this.cG
};

function gvjs_bz(a) {
    if (a instanceof gvjs_tm) return a;
    if (typeof a.Di == gvjs_c) return a.Di(!1);
    if (gvjs_Ne(a)) {
        var b = 0,
            c = new gvjs_tm;
        c.next = function() {
            for (;;) {
                if (b >= a.length) return gvjs_um;
                if (b in a) return gvjs_Jp(a[b++]);
                b++
            }
        };
        return c
    }
    throw Error("Not implemented");
}

function gvjs_cz(a, b, c) {
    if (gvjs_Ne(a)) gvjs_v(a, b, c);
    else
        for (a = gvjs_bz(a);;) {
            var d = a.next();
            if (d.done) break;
            b.call(c, d.value, void 0, a)
        }
}

function gvjs_dz(a, b, c) {
    var d = 0,
        e = a,
        f = c || 1;
    1 < arguments.length && (d = a, e = +b);
    if (0 == f) throw Error("Range step argument must not be zero");
    var g = new gvjs_tm;
    g.next = function() {
        if (0 < f && d >= e || 0 > f && d <= e) return gvjs_um;
        var h = d;
        d += f;
        return gvjs_Jp(h)
    };
    return g
}

function gvjs_ez(a) {
    return null === a ? gvjs_Kd : void 0 === a ? "undefined" : a
}

function gvjs_fz(a) {
    a = gvjs_ez(a);
    return gvjs_zh(a)
}

function gvjs_gz(a) {
    return gvjs_9m ? gvjs_wca.sanitize(a) : gvjs_fz(a)
}

function gvjs_hz(a) {
    if (gvjs_9m)
        if (gvjs_x && 10 > document.documentMode) a = gvjs_oh;
        else {
            var b = document;
            typeof HTMLTemplateElement === gvjs_c && (b = gvjs_ti("TEMPLATE").content.ownerDocument);
            b = b.implementation.createHTMLDocument("").createElement(gvjs_b);
            b.style.cssText = a;
            a = gvjs_Qm(b.style)
        }
    else a = new gvjs_kh(gvjs_ez(a), gvjs_jh);
    return a
}
var gvjs_iz = {},
    gvjs_7da = /<[^>]*>|&[^;]+;/g,
    gvjs_8da = /^http:\/\/.*/,
    gvjs_9da = /\s+/,
    gvjs_$da = /[\d\u06f0-\u06f9]/;

function gvjs_jz(a, b) {
    var c = 0,
        d = 0,
        e = !1;
    a = (b ? a.replace(gvjs_7da, "") : a).split(gvjs_9da);
    for (b = 0; b < a.length; b++) {
        var f = a[b];
        gvjs_vda.test(f) ? (c++, d++) : gvjs_8da.test(f) ? e = !0 : gvjs_uda.test(f) ? d++ : gvjs_$da.test(f) && (e = !0)
    }
    return 0 == d ? e ? 1 : 0 : .4 < c / d ? -1 : 1
}

function gvjs_kz(a, b, c, d) {
    this.magnitude = b;
    this.Kla = c;
    this.aka = d;
    this.Za = new gvjs_Aj({
        pattern: a
    })
}
gvjs_kz.prototype.format = function(a) {
    a /= this.magnitude;
    return this.Za.formatValue(a) + " " + (2 > Math.abs(a) ? this.Kla : this.aka)
};
var gvjs_lz = [];

function gvjs_mz(a) {
    gvjs_L.call(this);
    this.Pd = a;
    this.Rb = {}
}
gvjs_u(gvjs_mz, gvjs_L);
gvjs_ = gvjs_mz.prototype;
gvjs_.o = function(a, b, c, d) {
    return gvjs_nz(this, a, b, c, d)
};

function gvjs_nz(a, b, c, d, e, f) {
    Array.isArray(c) || (c && (gvjs_lz[0] = c.toString()), c = gvjs_lz);
    for (var g = 0; g < c.length; g++) {
        var h = gvjs_M(b, c[g], d || a.handleEvent, e || !1, f || a.Pd || a);
        if (!h) break;
        a.Rb[h.key] = h
    }
    return a
}
gvjs_.Uy = function(a, b, c, d) {
    return gvjs_oz(this, a, b, c, d)
};

function gvjs_oz(a, b, c, d, e, f) {
    if (Array.isArray(c))
        for (var g = 0; g < c.length; g++) gvjs_oz(a, b, c[g], d, e, f);
    else {
        b = gvjs_Zk(b, c, d || a.handleEvent, e, f || a.Pd || a);
        if (!b) return a;
        a.Rb[b.key] = b
    }
    return a
}
gvjs_.Ta = function(a, b, c, d, e) {
    if (Array.isArray(b))
        for (var f = 0; f < b.length; f++) this.Ta(a, b[f], c, d, e);
    else c = c || this.handleEvent, d = gvjs_Pe(d) ? !!d.capture : !!d, e = e || this.Pd || this, c = gvjs__k(c), d = !!d, b = gvjs_Rk(a) ? a.hD(b, c, d, e) : a ? (a = gvjs_1k(a)) ? a.hD(b, c, d, e) : null : null, b && (gvjs_4k(b), delete this.Rb[b.key]);
    return this
};
gvjs_.removeAll = function() {
    gvjs_y(this.Rb, function(a, b) {
        this.Rb.hasOwnProperty(b) && gvjs_4k(a)
    }, this);
    this.Rb = {}
};
gvjs_.J = function() {
    gvjs_mz.G.J.call(this);
    this.removeAll()
};
gvjs_.handleEvent = function() {
    throw Error("EventHandler.handleEvent not implemented");
};

function gvjs_pz(a) {
    gvjs_L.call(this);
    this.container = a;
    this.Pb = new gvjs_mz
}
gvjs_r(gvjs_pz, gvjs_L);
gvjs_ = gvjs_pz.prototype;
gvjs_.getContainer = function() {
    return this.container
};
gvjs_.clear = function() {
    this.Wc();
    this.Pb = new gvjs_mz
};
gvjs_.Wc = function() {
    gvjs_xi(this.container);
    this.Pb.removeAll();
    gvjs_K(this.Pb)
};
gvjs_.J = function() {
    this.Wc();
    gvjs_L.prototype.J.call(this)
};
gvjs_.qb = function(a, b, c) {
    this.Pb.o(a, b, c)
};

function gvjs_qz(a, b, c) {
    switch (c) {
        case gvjs_l:
            c = a;
            a += b;
            break;
        case gvjs_Y:
            c = a - b;
            break;
        case gvjs_X:
            c = a - b / 2;
            a += b / 2;
            break;
        default:
            c = a = NaN
    }
    return {
        start: c,
        end: a
    }
}

function gvjs_rz(a, b, c, d) {
    d && (c = c === gvjs_l ? gvjs_Y : c === gvjs_Y ? gvjs_l : c);
    switch (c) {
        case gvjs_Y:
            return b;
        case gvjs_X:
            return gvjs_Ux(a, b);
        default:
            return a
    }
}

function gvjs_sz(a) {
    var b = this.IK = null,
        c = null;
    typeof a === gvjs_c ? b = a : c = a;
    this.ta = b;
    this.element = c
}
gvjs_sz.prototype.Cl = function(a) {
    this.IK = a;
    this.element && gvjs_$x(this.element, a)
};
gvjs_sz.prototype.sr = function() {
    return this.element ? gvjs_ay(this.element) : this.IK
};
gvjs_sz.prototype.j = function() {
    !this.element && this.ta && (this.element = this.ta(), null !== this.IK && gvjs_$x(this.element, this.IK));
    if (!this.element) throw Error("Failed to get element for DrawingGroup.");
    return this.element
};

function gvjs_tz(a, b) {
    return {
        type: gvjs_vu,
        data: {
            x: a,
            y: b
        }
    }
}

function gvjs_uz() {
    this.Cb = []
}
gvjs_ = gvjs_uz.prototype;
gvjs_.kh = function(a) {
    this.Cb.push(a)
};
gvjs_.move = function(a, b) {
    this.kh(gvjs_tz(a, b))
};
gvjs_.na = function(a, b) {
    this.kh({
        type: gvjs_d,
        data: {
            x: a,
            y: b
        }
    })
};
gvjs_.am = function(a, b, c, d, e, f) {
    this.kh({
        type: gvjs_qs,
        data: {
            x1: a,
            y1: b,
            x2: c,
            y2: d,
            x: e,
            y: f
        }
    })
};
gvjs_.ke = function(a, b, c, d, e, f, g) {
    this.kh({
        type: "arc",
        data: {
            cx: a,
            cy: b,
            rx: c,
            ry: d,
            gu: e,
            nq: f,
            Z4: g
        }
    })
};

function gvjs_vz(a, b, c) {
    if (0 !== b.length)
        if (0 === a.Cb.length ? a.move(b[0].x, b[0].y) : a.na(b[0].x, b[0].y), c)
            for (var d = 1; d < b.length; ++d) a.am(c[d - 1][1].x, c[d - 1][1].y, c[d][0].x, c[d][0].y, b[d].x, b[d].y);
        else
            for (c = 1; c < b.length; ++c) a.na(b[c].x, b[c].y)
}
gvjs_.close = function() {
    this.kh({
        type: gvjs_is,
        data: null
    })
};

function gvjs_wz(a, b) {
    var c = new gvjs_uz;
    0 < a.length && (gvjs_vz(c, a), b || c.close());
    return c
}

function gvjs_xz(a, b) {
    gvjs_L.call(this);
    var c = this;
    this.container = a;
    this.jA = b;
    this.ss = this.Xr = null;
    this.height = this.width = 0;
    this.ud = gvjs_mx(function(d, e, f) {
        return c.ny(d, e, f)
    }, {
        wM: function(d, e) {
            var f = [d, e[0]];
            gvjs_y(e[1], function(g, h) {
                f.push(g);
                f.push(h)
            });
            f.push(+e[2]);
            return "getTextSize_" + f.join("_")
        }
    })
}
gvjs_r(gvjs_xz, gvjs_L);
gvjs_ = gvjs_xz.prototype;
gvjs_.Rk = function(a, b) {
    a = this.rI(a, b);
    a.Cl(gvjs_2q);
    return this.Xr = a
};
gvjs_.deleteContents = function() {
    this.LQ()
};
gvjs_.flush = function() {};
gvjs_.clear = function() {
    this.Wc()
};
gvjs_.Wc = function() {
    this.Xr = null
};
gvjs_.J = function() {
    this.Wc();
    gvjs_L.prototype.J.call(this)
};
gvjs_.getContainer = function() {
    return this.container
};
gvjs_.Cl = function(a, b) {
    a && (a instanceof gvjs_sz ? a.Cl(b) : gvjs_$x(a, b))
};
gvjs_.sr = function(a) {
    return gvjs_ay(a)
};
gvjs_.appendChild = function(a, b) {
    if (b) {
        if (b instanceof gvjs_sz) {
            if (!b.element) return;
            b = b.j()
        }
        a.j().appendChild(b)
    }
};

function gvjs_yz(a, b) {
    for (b instanceof gvjs_sz && (b = b.j()); b.firstChild;) gvjs_yz(a, b.firstChild);
    b.parentElement.removeChild(b)
}
gvjs_.replaceChild = function(a, b, c) {
    a = a.j();
    gvjs_Gi(c) !== a ? (gvjs_yz(this, c), a.appendChild(b)) : a.replaceChild(b, c)
};
gvjs_.xb = function(a) {
    if (a.element) {
        var b = a.j();
        this.cr.xb(b);
        a.j()
    }
};
gvjs_.ta = function(a) {
    a = null != a ? a : !1;
    var b = new gvjs_sz(this.jQ.bind(this));
    a || b.j();
    return b
};
gvjs_.Kx = function() {};
gvjs_.zC = function() {
    return null
};

function gvjs_zz(a, b, c, d, e, f) {
    var g = new gvjs_uz;
    g.move(b, c);
    g.na(d, e);
    return a.Jb(g, f)
}
gvjs_.Jb = function(a, b, c) {
    for (var d = [], e = 0; e < a.Cb.length; e++) {
        var f = a.Cb[e];
        switch (f.type) {
            case gvjs_vu:
                f = f.data;
                this.Zb(d, f.x, f.y);
                break;
            case gvjs_d:
                f = f.data;
                this.pa(d, f.x, f.y);
                break;
            case gvjs_qs:
                f = f.data;
                this.bm(d, f.x1, f.y1, f.x2, f.y2, f.x, f.y);
                break;
            case "arc":
                f = f.data;
                this.yj(d, f.cx, f.cy, f.rx, f.ry, f.gu, f.nq, f.Z4);
                break;
            case gvjs_is:
                this.wg(d);
                break;
            default:
                throw Error("Unexpected segment.type " + f.type + ".");
        }
    }
    return this.mQ(d, b, c)
};
gvjs_.kQ = gvjs_p(32);
gvjs_.ei = function(a, b, c, d, e) {
    a = this.Ex(a, b, c, d);
    this.appendChild(e, a);
    return a
};
gvjs_.No = function(a, b, c, d, e, f) {
    a = this.iQ(a, b, c, d, e);
    this.appendChild(f, a);
    return a
};
gvjs_.bb = function(a, b, c, d, e, f) {
    a = this.Ii(a, b, c, d, e);
    this.appendChild(f, a);
    return a
};
gvjs_.WQ = function(a, b, c, d, e, f) {
    a = gvjs_zz(this, a, b, c, d, e);
    this.appendChild(f, a)
};
gvjs_.Ba = function(a, b, c, d) {
    a = this.Jb(a, b, d);
    this.appendChild(c, a);
    return a
};
gvjs_.Oc = function(a, b, c, d, e, f, g, h, k) {
    a = this.Yq(a, b, c, d, e, f, g, k);
    this.appendChild(h, a);
    return a
};
gvjs_.Mj = function(a, b, c, d, e, f, g, h, k, l) {
    a = this.mC(a, b, c, d, e, f, g, h, l);
    this.appendChild(k, a);
    return a
};

function gvjs_aea(a, b, c, d, e, f, g, h, k, l) {
    b = a.Bo(b, c, d, e, f, g, h, k);
    a.appendChild(l, b)
}
gvjs_.el = function(a, b) {
    return this.ud(a, b).width
};
gvjs_.Qr = gvjs_p(34);
gvjs_.qb = function() {};
gvjs_.Jt = function() {
    return null
};

function gvjs_Az() {
    var a = gvjs_fk().Yi();
    a.__googleVisualizationAbstractRendererElementsCount__ = a.__googleVisualizationAbstractRendererElementsCount__ || 0;
    var b = "_ABSTRACT_RENDERER_ID_" + a.__googleVisualizationAbstractRendererElementsCount__.toString();
    a.__googleVisualizationAbstractRendererElementsCount__ = Number(a.__googleVisualizationAbstractRendererElementsCount__) + 1;
    return b
}

function gvjs_Bz(a) {
    return gvjs_Oi(a, function(b) {
        return b[gvjs_Pp]
    }, !0)
}

function gvjs_Cz(a) {
    gvjs_7k.call(this);
    this.O = a;
    a = gvjs_x ? gvjs_4s : gvjs_Pr;
    this.gia = gvjs_M(this.O, gvjs_x ? gvjs_3s : gvjs_1s, this, !gvjs_x);
    this.hia = gvjs_M(this.O, a, this, !gvjs_x)
}
gvjs_u(gvjs_Cz, gvjs_7k);
gvjs_Cz.prototype.handleEvent = function(a) {
    var b = new gvjs_Pk(a.fi);
    b.type = a.type == gvjs_3s || a.type == gvjs_1s ? gvjs_3s : gvjs_4s;
    this.dispatchEvent(b)
};
gvjs_Cz.prototype.J = function() {
    gvjs_Cz.G.J.call(this);
    gvjs_4k(this.gia);
    gvjs_4k(this.hia);
    delete this.O
};

function gvjs_Dz() {}
gvjs_Dz.prototype.ge = function() {};

function gvjs_Ez(a) {
    var b = a.offsetLeft,
        c = a.offsetParent;
    c || gvjs_mk(a) != gvjs_0s || (c = gvjs_ki(a).documentElement);
    if (!c) return b;
    if (gvjs_Hf && !gvjs_kx(58)) {
        var d = gvjs_rk(c);
        b += d.left
    } else gvjs_Tf(8) && !gvjs_Tf(9) && (d = gvjs_rk(c), b -= d.left);
    return gvjs_5y(c) ? c.clientWidth - (b + a.offsetWidth) : b
}

function gvjs_Fz(a) {
    if (a = a.offsetParent) {
        var b = "HTML" == a.tagName || "BODY" == a.tagName;
        if (!b || "static" != gvjs_mk(a)) {
            var c = gvjs_Uy(a);
            if (!b) {
                b = gvjs_5y(a);
                var d;
                if (d = b) {
                    d = gvjs_Xf && 0 <= gvjs_5w(gvjs_Rp, 10);
                    var e = gvjs_waa && 0 <= gvjs_5w(gvjs_Ada, 10),
                        f = gvjs_Wf && 0 <= gvjs_5w(gvjs_Rp, 85);
                    d = gvjs_Hf || d || e || f
                }
                b = d ? -a.scrollLeft : b && !gvjs_qaa && gvjs_lk(a, "overflowX") != gvjs_hw ? a.scrollWidth - a.clientWidth - a.scrollLeft : a.scrollLeft;
                c = gvjs_2x(c, new gvjs_A(b, a.scrollTop))
            }
        }
    }
    return c || new gvjs_A
}

function gvjs_Gz(a, b) {
    return (b & 8 && gvjs_5y(a) ? b ^ 4 : b) & -9
}

function gvjs_Hz(a, b, c, d, e, f, g) {
    a = a.clone();
    var h = gvjs_Gz(b, c);
    c = gvjs_1y(b);
    g = g ? g.clone() : c.clone();
    a = a.clone();
    g = g.clone();
    var k = 0;
    if (d || 0 != h) h & 4 ? a.x -= g.width + (d ? d.right : 0) : h & 2 ? a.x -= g.width / 2 : d && (a.x += d.left), h & 1 ? a.y -= g.height + (d ? d.bottom : 0) : d && (a.y += d.top);
    f && (e ? (d = g, h = 0, 65 == (f & 65) && (a.x < e.left || a.x >= e.right) && (f &= -2), 132 == (f & 132) && (a.y < e.top || a.y >= e.bottom) && (f &= -5), a.x < e.left && f & 1 && (a.x = e.left, h |= 1), f & 16 && (k = a.x, a.x < e.left && (a.x = e.left, h |= 4), a.x + d.width > e.right && (d.width = Math.min(e.right - a.x,
            k + d.width - e.left), d.width = Math.max(d.width, 0), h |= 4)), a.x + d.width > e.right && f & 1 && (a.x = Math.max(e.right - d.width, e.left), h |= 1), f & 2 && (h |= (a.x < e.left ? 16 : 0) | (a.x + d.width > e.right ? 32 : 0)), a.y < e.top && f & 4 && (a.y = e.top, h |= 2), f & 32 && (k = a.y, a.y < e.top && (a.y = e.top, h |= 8), a.y + d.height > e.bottom && (d.height = Math.min(e.bottom - a.y, k + d.height - e.top), d.height = Math.max(d.height, 0), h |= 8)), a.y + d.height > e.bottom && f & 4 && (a.y = Math.max(e.bottom - d.height, e.top), h |= 2), f & 8 && (h |= (a.y < e.top ? 64 : 0) | (a.y + d.height > e.bottom ? 128 : 0)), e = h) : e = 256,
        k = e);
    f = new gvjs_0(0, 0, 0, 0);
    f.left = a.x;
    f.top = a.y;
    f.width = g.width;
    f.height = g.height;
    e = k;
    if (e & 496) return e;
    gvjs_Ry(b, new gvjs_A(f.left, f.top));
    g = f.getSize();
    gvjs_4x(c, g) || (c = g, b = b.style, gvjs_Hf ? b.MozBoxSizing = gvjs_Rr : gvjs_If ? b.WebkitBoxSizing = gvjs_Rr : b.boxSizing = gvjs_Rr, b.width = Math.max(c.width, 0) + gvjs_Z, b.height = Math.max(c.height, 0) + gvjs_Z);
    return e
}

function gvjs_Iz(a, b, c, d, e, f, g, h, k) {
    var l = gvjs_Fz(c),
        m = gvjs_2y(a),
        n = gvjs_Vy(a);
    n && m.IS(gvjs_Oy(n));
    n = gvjs_ii(a);
    var p = gvjs_ii(c);
    if (n.Hb() != p.Hb()) {
        var q = n.Hb().body;
        p = p.Yi();
        var r = new gvjs_A(0, 0),
            t = gvjs_uw(gvjs_ki(q));
        if (gvjs_Ef(t, "parent")) {
            var u = q;
            do {
                var v = t == p ? gvjs_Uy(u) : gvjs_Xy(u);
                r.x += v.x;
                r.y += v.y
            } while (t && t != p && t != t.parent && (u = t.frameElement) && (t = t.parent))
        }
        q = gvjs_2x(r, gvjs_Uy(q));
        !gvjs_x || gvjs_Tf(9) || gvjs_ui(n.ac) || (q = gvjs_2x(q, gvjs_tw(n.ac)));
        m.left += q.x;
        m.top += q.y
    }
    a = gvjs_Gz(a, b);
    b = m.left;
    a & 4 ? b += m.width : a & 2 && (b += m.width / 2);
    m = new gvjs_A(b, m.top + (a & 1 ? m.height : 0));
    m = gvjs_2x(m, l);
    e && (m.x += (a & 4 ? -1 : 1) * e.x, m.y += (a & 1 ? -1 : 1) * e.y);
    if (g)
        if (k) var w = k;
        else if (w = gvjs_Vy(c)) w.top -= l.y, w.right -= l.x, w.bottom -= l.y, w.left -= l.x;
    return gvjs_Hz(m, c, d, f, w, g, h)
}

function gvjs_Jz(a, b, c) {
    this.element = a;
    this.jC = b;
    this.Pja = c
}
gvjs_u(gvjs_Jz, gvjs_Dz);
gvjs_Jz.prototype.ge = function(a, b, c) {
    gvjs_Iz(this.element, this.jC, a, b, void 0, c, this.Pja)
};

function gvjs_Kz(a, b) {
    this.oa = a instanceof gvjs_A ? a : new gvjs_A(a, b)
}
gvjs_u(gvjs_Kz, gvjs_Dz);
gvjs_Kz.prototype.ge = function(a, b, c, d) {
    gvjs_Iz(gvjs_Sy(a), 0, a, b, this.oa, c, null, d)
};

function gvjs_Lz(a) {
    if (48 <= a && 57 >= a || 96 <= a && 106 >= a || 65 <= a && 90 >= a || (gvjs_If || gvjs_Gf) && 0 == a) return !0;
    switch (a) {
        case 32:
        case 43:
        case 63:
        case 64:
        case 107:
        case 109:
        case 110:
        case 111:
        case 186:
        case 59:
        case 189:
        case 187:
        case 61:
        case 188:
        case 190:
        case 191:
        case 192:
        case 222:
        case 219:
        case 220:
        case 221:
        case 163:
        case 58:
            return !0;
        case 173:
            return gvjs_Hf;
        default:
            return !1
    }
}

function gvjs_bea(a) {
    switch (a) {
        case 61:
            return 187;
        case 59:
            return 186;
        case 173:
            return 189;
        case 224:
            return 91;
        case 0:
            return 224;
        default:
            return a
    }
}

function gvjs_Mz(a) {
    if (gvjs_Hf) a = gvjs_bea(a);
    else if (gvjs_Jf && gvjs_If) switch (a) {
        case 93:
            a = 91
    }
    return a
}

function gvjs_Nz(a, b, c, d, e, f) {
    if (gvjs_Jf && e) return gvjs_Lz(a);
    if (e && !d) return !1;
    if (!gvjs_Hf) {
        typeof b === gvjs_f && (b = gvjs_Mz(b));
        var g = 17 == b || 18 == b || gvjs_Jf && 91 == b;
        if ((!c || gvjs_Jf) && g || gvjs_Jf && 16 == b && (d || f)) return !1
    }
    if ((gvjs_If || gvjs_Gf) && d && c) switch (a) {
        case 220:
        case 219:
        case 221:
        case 192:
        case 186:
        case 189:
        case 187:
        case 188:
        case 190:
        case 191:
        case 192:
        case 222:
            return !1
    }
    if (gvjs_x && d && b == a) return !1;
    switch (a) {
        case 13:
            return gvjs_Hf ? f || e ? !1 : !(c && d) : !0;
        case 27:
            return !(gvjs_If || gvjs_Gf || gvjs_Hf)
    }
    return gvjs_Hf &&
        (d || e || f) ? !1 : gvjs_Lz(a)
}

function gvjs_Oz(a, b) {
    gvjs_7k.call(this);
    this.Pd = new gvjs_mz(this);
    this.Iv(a || null);
    b && this.Gl(b)
}
gvjs_u(gvjs_Oz, gvjs_7k);
gvjs_ = gvjs_Oz.prototype;
gvjs_.O = null;
gvjs_.g0 = !0;
gvjs_.e0 = null;
gvjs_.f0 = null;
gvjs_.Ny = !1;
gvjs_.wla = !1;
gvjs_.hT = -1;
gvjs_.Nga = !1;
gvjs_.xda = !0;
gvjs_.Ff = gvjs_Uv;
gvjs_.getType = function() {
    return this.Ff
};
gvjs_.Gl = function(a) {
    this.Ff = a
};
gvjs_.j = function() {
    return this.O
};
gvjs_.Iv = function(a) {
    gvjs_Pz(this);
    this.O = a
};
gvjs_.yM = gvjs_p(35);
gvjs_.Xz = gvjs_p(37);
gvjs_.ob = function() {
    return this.Pd
};

function gvjs_Pz(a) {
    if (a.Ny) throw Error("Can not change this state of the popup while showing.");
}
gvjs_.isVisible = function() {
    return this.Ny
};
gvjs_.setVisible = function(a) {
    this.Yz && this.Yz.stop();
    this.By && this.By.stop();
    a ? this.fW() : this.Cy()
};
gvjs_.ge = function() {};
gvjs_.fW = function() {
    if (!this.Ny && this.sU()) {
        if (!this.O) throw Error("Caller must call setElement before trying to show the popup");
        this.ge();
        var a = gvjs_ki(this.O);
        this.Nga && this.Pd.o(a, gvjs_Vt, this.uja, !0);
        if (this.g0)
            if (this.Pd.o(a, gvjs_pu, this.S6, !0), gvjs_x) {
                try {
                    var b = a.activeElement
                } catch (d) {}
                for (; b && b.nodeName == gvjs_Na;) {
                    try {
                        var c = gvjs_Ii(b)
                    } catch (d) {
                        break
                    }
                    a = c;
                    b = a.activeElement
                }
                this.Pd.o(a, gvjs_pu, this.S6, !0);
                this.Pd.o(a, "deactivate", this.R6)
            } else this.Pd.o(a, gvjs_Pr, this.R6);
        this.Ff == gvjs_Uv ? (this.O.style.visibility =
            gvjs_hw, gvjs_4y(this.O, !0)) : this.Ff == gvjs_wu && this.ge();
        this.Ny = !0;
        this.hT = Date.now();
        this.Yz ? (gvjs_Zk(this.Yz, gvjs_Y, this.pv, !1, this), this.Yz.play()) : this.pv()
    }
};
gvjs_.Cy = function(a) {
    if (!this.Ny || !this.dispatchEvent({
            type: gvjs_Lr,
            target: a
        })) return !1;
    this.Pd && this.Pd.removeAll();
    this.Ny = !1;
    Date.now();
    this.By ? (gvjs_Zk(this.By, gvjs_Y, gvjs_Te(this.j1, a), !1, this), this.By.play()) : this.j1(a);
    return !0
};
gvjs_.j1 = function(a) {
    this.Ff == gvjs_Uv ? this.wla ? gvjs_yl(this.y4, 0, this) : this.y4() : this.Ff == gvjs_wu && (this.O.style.top = "-10000px");
    this.ms(a)
};
gvjs_.y4 = function() {
    this.O.style.visibility = gvjs_kd;
    gvjs_4y(this.O, !1)
};
gvjs_.sU = function() {
    return this.dispatchEvent(gvjs_Mr)
};
gvjs_.pv = function() {
    this.dispatchEvent(gvjs_nv)
};
gvjs_.ms = function(a) {
    this.dispatchEvent({
        type: gvjs_yt,
        target: a
    })
};
gvjs_.S6 = function(a) {
    a = a.target;
    gvjs_Hi(this.O, a) || gvjs_Qz(this, a) || this.f0 && !gvjs_Hi(this.f0, a) || 150 > Date.now() - this.hT || this.Cy(a)
};
gvjs_.uja = function(a) {
    27 == a.keyCode && this.Cy(a.target) && (a.preventDefault(), a.stopPropagation())
};
gvjs_.R6 = function(a) {
    if (this.xda) {
        var b = gvjs_ki(this.O);
        if ("undefined" != typeof document.activeElement) {
            if (a = b.activeElement, !a || gvjs_Hi(this.O, a) || "BODY" == a.tagName || gvjs_Qz(this, a)) return
        } else if (a.target != b) return;
        150 > Date.now() - this.hT || this.Cy()
    }
};

function gvjs_Qz(a, b) {
    return gvjs_rf(a.e0 || [], function(c) {
        return b === c || gvjs_Hi(c, b)
    })
}
gvjs_.J = function() {
    gvjs_Oz.G.J.call(this);
    this.Pd.xa();
    gvjs_K(this.Yz);
    gvjs_K(this.By);
    delete this.O;
    delete this.Pd;
    delete this.e0
};

function gvjs_Rz(a, b) {
    this.bka = 8;
    this.ef = b || void 0;
    gvjs_Oz.call(this, a)
}
gvjs_u(gvjs_Rz, gvjs_Oz);
gvjs_Rz.prototype.getPosition = function() {
    return this.ef || null
};
gvjs_Rz.prototype.setPosition = function(a) {
    this.ef = a || void 0;
    this.isVisible() && this.ge()
};
gvjs_Rz.prototype.ge = function() {
    if (this.ef) {
        var a = !this.isVisible() && this.getType() != gvjs_wu,
            b = this.j();
        a && (b.style.visibility = gvjs_kd, gvjs_4y(b, !0));
        this.ef.ge(b, this.bka, this.Csa);
        a && gvjs_4y(b, !1)
    }
};
var gvjs_Sz = [];

function gvjs_Tz(a, b) {
    gvjs_Kz.call(this, a, b)
}
gvjs_u(gvjs_Tz, gvjs_Kz);
gvjs_Tz.prototype.ge = function(a, b, c) {
    b = gvjs_Sy(a);
    b = gvjs_Vy(b);
    c = c ? new gvjs_H(c.top + 10, c.right, c.bottom, c.left + 10) : new gvjs_H(10, 0, 0, 10);
    gvjs_Hz(this.oa, a, 8, c, b, 9) & 496 && gvjs_Hz(this.oa, a, 8, c, b, 5)
};

function gvjs_Uz(a) {
    gvjs_Jz.call(this, a, 5)
}
gvjs_u(gvjs_Uz, gvjs_Jz);
gvjs_Uz.prototype.ge = function(a, b, c) {
    var d = new gvjs_A(10, 0);
    gvjs_Iz(this.element, this.jC, a, b, d, c, 9) & 496 && gvjs_Iz(this.element, 4, a, 1, d, c, 5)
};

function gvjs_Vz(a, b, c) {
    this.C = c || (a ? gvjs_ii(gvjs_li(document, a)) : gvjs_ii());
    gvjs_Rz.call(this, this.C.F(gvjs_b, {
        style: "position:absolute;display:none;"
    }));
    this.Pa = new gvjs_A(1, 1);
    this.Nb = new gvjs_Sp;
    this.fw = null;
    a && this.gx(a);
    null != b && this.Vz(b)
}
gvjs_u(gvjs_Vz, gvjs_Rz);
gvjs_ = gvjs_Vz.prototype;
gvjs_.Rd = null;
gvjs_.className = "aAAaGVIZSENTINELaAAa-tooltip";
gvjs_.VM = 500;
gvjs_.x4 = 0;
gvjs_.fa = function() {
    return this.C
};
gvjs_.gx = function(a) {
    a = gvjs_li(document, a);
    this.Nb.add(a);
    gvjs_M(a, gvjs_Dd, this.gl, !1, this);
    gvjs_M(a, gvjs_Cd, this.NJ, !1, this);
    gvjs_M(a, gvjs_su, this.Y3, !1, this);
    gvjs_M(a, gvjs_1s, this.zr, !1, this);
    gvjs_M(a, gvjs_Pr, this.NJ, !1, this)
};
gvjs_.detach = function(a) {
    if (a) a = gvjs_li(document, a), gvjs_Wz(this, a), this.Nb.remove(a);
    else {
        for (var b = this.Nb.Wb(), c = 0; a = b[c]; c++) gvjs_Wz(this, a);
        this.Nb.clear()
    }
};

function gvjs_Wz(a, b) {
    gvjs_3k(b, gvjs_Dd, a.gl, !1, a);
    gvjs_3k(b, gvjs_Cd, a.NJ, !1, a);
    gvjs_3k(b, gvjs_su, a.Y3, !1, a);
    gvjs_3k(b, gvjs_1s, a.zr, !1, a);
    gvjs_3k(b, gvjs_Pr, a.NJ, !1, a)
}
gvjs_.Vz = function(a) {
    gvjs_Ji(this.j(), a)
};
gvjs_.NM = gvjs_p(38);
gvjs_.Iv = function(a) {
    var b = this.j();
    b && gvjs_Ai(b);
    gvjs_Vz.G.Iv.call(this, a);
    a ? (b = this.C.Hb().body, b.insertBefore(a, b.lastChild), gvjs_K(this.fw), this.fw = new gvjs_Cz(this.j()), gvjs_Rw(this, this.fw), gvjs_M(this.fw, gvjs_3s, this.ZB, void 0, this), gvjs_M(this.fw, gvjs_4s, this.cN, void 0, this)) : (gvjs_K(this.fw), this.fw = null)
};
gvjs_.wJ = function() {
    return this.j().innerHTML
};
gvjs_.getState = function() {
    return this.ys ? this.isVisible() ? 4 : 1 : this.CD ? 3 : this.isVisible() ? 2 : 0
};
gvjs_.sU = function() {
    if (!gvjs_Oz.prototype.sU.call(this)) return !1;
    if (this.anchor)
        for (var a, b = 0; a = gvjs_Sz[b]; b++) gvjs_Hi(a.j(), this.anchor) || a.setVisible(!1);
    gvjs_ax(gvjs_Sz, this);
    a = this.j();
    a.className = this.className;
    this.ZB();
    gvjs_M(a, gvjs_Dd, this.l4, !1, this);
    gvjs_M(a, gvjs_Cd, this.j4, !1, this);
    gvjs_Xz(this);
    return !0
};
gvjs_.ms = function() {
    gvjs_uf(gvjs_Sz, this);
    for (var a = this.j(), b, c = 0; b = gvjs_Sz[c]; c++) b.anchor && gvjs_Hi(a, b.anchor) && b.setVisible(!1);
    this.j7 && this.j7.cN();
    gvjs_3k(a, gvjs_Dd, this.l4, !1, this);
    gvjs_3k(a, gvjs_Cd, this.j4, !1, this);
    this.anchor = void 0;
    0 == this.getState() && (this.oM = !1);
    gvjs_Oz.prototype.ms.call(this)
};
gvjs_.g6 = function(a, b) {
    this.anchor == a && this.Nb.contains(this.anchor) && (this.oM || !this.Vsa ? (this.setVisible(!1), this.isVisible() || (this.anchor = a, this.setPosition(b || this.AJ(0)), this.setVisible(!0))) : this.anchor = void 0);
    this.ys = void 0
};
gvjs_.fD = function() {
    return this.Nb
};
gvjs_.lu = function() {
    return this.Rd
};
gvjs_.tia = function(a) {
    this.CD = void 0;
    if (a == this.anchor) {
        a = this.fa();
        var b = a.lu();
        a = b && this.j() && a.contains(this.j(), b);
        null != this.Rd && (this.Rd == this.j() || this.Nb.contains(this.Rd)) || a || this.R0 && this.R0.Rd || this.setVisible(!1)
    }
};

function gvjs_Yz(a, b) {
    var c = gvjs_tw(a.C.ac);
    a.Pa.x = b.clientX + c.x;
    a.Pa.y = b.clientY + c.y
}
gvjs_.gl = function(a) {
    var b = gvjs_Zz(this, a.target);
    this.Rd = b;
    this.ZB();
    b != this.anchor && (this.anchor = b, this.ys || (this.ys = gvjs_yl(gvjs_Se(this.g6, this, b, void 0), this.VM)), gvjs__z(this), gvjs_Yz(this, a))
};

function gvjs_Zz(a, b) {
    try {
        for (; b && !a.Nb.contains(b);) b = b.parentNode;
        return b
    } catch (c) {
        return null
    }
}
gvjs_.Y3 = function(a) {
    gvjs_Yz(this, a);
    this.oM = !0
};
gvjs_.zr = function(a) {
    this.Rd = a = gvjs_Zz(this, a.target);
    this.oM = !0;
    if (this.anchor != a) {
        this.anchor = a;
        var b = this.AJ(1);
        this.ZB();
        this.ys || (this.ys = gvjs_yl(gvjs_Se(this.g6, this, a, b), this.VM));
        gvjs__z(this)
    }
};
gvjs_.AJ = function(a) {
    return 0 == a ? (a = this.Pa.clone(), new gvjs_Tz(a)) : new gvjs_Uz(this.Rd)
};

function gvjs__z(a) {
    if (a.anchor)
        for (var b, c = 0; b = gvjs_Sz[c]; c++) gvjs_Hi(b.j(), a.anchor) && (b.R0 = a, a.j7 = b)
}
gvjs_.NJ = function(a) {
    var b = gvjs_Zz(this, a.target),
        c = gvjs_Zz(this, a.relatedTarget);
    b != c && (b == this.Rd && (this.Rd = null), gvjs_Xz(this), this.oM = !1, !this.isVisible() || a.relatedTarget && gvjs_Hi(this.j(), a.relatedTarget) ? this.anchor = void 0 : this.cN())
};
gvjs_.l4 = function() {
    var a = this.j();
    this.Rd != a && (this.ZB(), this.Rd = a)
};
gvjs_.j4 = function(a) {
    var b = this.j();
    this.Rd != b || a.relatedTarget && gvjs_Hi(b, a.relatedTarget) || (this.Rd = null, this.cN())
};

function gvjs_Xz(a) {
    a.ys && (gvjs_zl(a.ys), a.ys = void 0)
}
gvjs_.cN = function() {
    2 == this.getState() && (this.CD = gvjs_yl(gvjs_Se(this.tia, this, this.anchor), this.x4))
};
gvjs_.ZB = function() {
    this.CD && (gvjs_zl(this.CD), this.CD = void 0)
};
gvjs_.J = function() {
    this.setVisible(!1);
    gvjs_Xz(this);
    this.detach();
    this.j() && gvjs_Ai(this.j());
    this.Rd = null;
    delete this.C;
    gvjs_Vz.G.J.call(this)
};

function gvjs_0z(a, b) {
    gvjs_xz.call(this, a, b);
    this.cr = gvjs_ii(a);
    this.Kj = this.cr.Hb();
    this.pq = [];
    this.aa = new gvjs_mz
}
gvjs_r(gvjs_0z, gvjs_xz);

function gvjs_cea(a, b, c, d) {
    b = new gvjs_Vz(b);
    var e = a.cr.F(gvjs_b);
    c = c.split("\n");
    e.appendChild(a.cr.createTextNode(c[0]));
    for (var f = 1; f < c.length; ++f) e.appendChild(a.cr.F("BR")), e.appendChild(a.cr.createTextNode(c[f]));
    gvjs_I(e, d);
    b.j().appendChild(e);
    b.VM = 100;
    b.x4 = 100;
    a.pq.push(b)
}
gvjs_ = gvjs_0z.prototype;
gvjs_.gf = function(a) {
    this.cr.removeNode(a);
    gvjs_5k(a)
};
gvjs_.clear = function() {
    this.aa.removeAll();
    gvjs_K(this.aa);
    this.aa = new gvjs_mz;
    gvjs_xz.prototype.clear.call(this)
};
gvjs_.Wc = function() {
    gvjs_xz.prototype.Wc.call(this);
    this.pq.forEach(function(a) {
        gvjs_K(a)
    });
    gvjs_$w(this.pq);
    this.cr.xb(this.container);
    this.aa.removeAll();
    gvjs_K(this.aa)
};
gvjs_.getBoundingBox = function(a) {
    var b = gvjs_Bz(a);
    return b ? (b = gvjs_Zy(a, b), a = gvjs_1y(a), new gvjs_H(b.y, b.x + a.width, b.y + a.height, b.x)) : null
};
gvjs_.Vj = function(a) {
    for (var b = a.target; b.parentNode;) b = b.parentNode;
    9 === b.nodeType || 11 === b.nodeType ? (b = gvjs_Bz(a.target), a = gvjs_Zy(a, b)) : a = null;
    return a
};
gvjs_.qb = function(a, b, c) {
    a instanceof gvjs_sz && (a = a.j());
    this.aa.o(a, b, c)
};
gvjs_.replaceChild = function(a, b, c) {
    gvjs_xz.prototype.replaceChild.call(this, a, b, c);
    gvjs_5k(c)
};

function gvjs_1z(a, b) {
    gvjs_0z.call(this, a, b);
    this.za = null;
    a = gvjs_ii(b).createElement("canvas");
    this.jA.appendChild(a);
    this.g9 = a.getContext("2d");
    this.lk = this.wa = this.eI = null;
    this.OU = !1
}
gvjs_r(gvjs_1z, gvjs_0z);

function gvjs_2z(a) {
    a.OU || (a.za.beginPath(), a.lk = new gvjs_H(Infinity, -Infinity, -Infinity, Infinity), a.OU = !0)
}

function gvjs_3z(a, b, c) {
    a.lk && (a.lk.left = Math.min(a.lk.left, b), a.lk.top = Math.min(a.lk.top, c), a.lk.right = Math.max(a.lk.right, b), a.lk.bottom = Math.max(a.lk.bottom, c))
}
gvjs_ = gvjs_1z.prototype;
gvjs_.rI = function(a, b) {
    var c = gvjs_ii(this.container).createElement("canvas");
    c.setAttribute(gvjs_le, a);
    c.setAttribute(gvjs_jd, b);
    this.wa = new gvjs_B(a, b);
    this.container.appendChild(c);
    this.za = c.getContext("2d");
    return new gvjs_sz(c)
};
gvjs_.LQ = function() {
    var a = this.Xr.j();
    this.za.clearRect(0, 0, a.width, a.height)
};

function gvjs_4z(a) {
    return gvjs_ii(a.container).createElement("empty")
}

function gvjs_5z(a, b) {
    if (a == gvjs_e) return gvjs_7u;
    b == gvjs_e && (b = 1);
    return "rgba(" + gvjs_ei(gvjs_$h(a).hex) + "," + b + ")"
}

function gvjs_6z(a, b) {
    "undefined" !== typeof a.setLineDash && a.setLineDash(b)
}

function gvjs_7z(a, b, c, d, e) {
    var f = /^(\d+(\.\d*)?)%$/;
    typeof b === gvjs_m && f.test(b) ? (b = parseFloat(f.exec(b)[1]) / 100, c && null != e ? b = d ? e.height * b + e.top : e.width * b + e.left : null != a.wa && (b = d ? a.wa.height * b : a.wa.width * b)) : b = +b;
    return b
}
gvjs_.sg = function(a, b) {
    this.za.strokeStyle = gvjs_5z(a.stroke, a.strokeOpacity);
    this.za.fillStyle = gvjs_5z(a.fill, a.fillOpacity);
    var c = a.tg;
    null != c && c == gvjs_ss ? gvjs_6z(this.za, [8, 2]) : Array.isArray(c) ? gvjs_6z(this.za, c) : gvjs_6z(this.za, []);
    var d = a.pattern;
    c = a.gradient;
    if (null != d) {
        c = null;
        switch (d.getStyle()) {
            case gvjs_0u:
                c = this.Kj.createElement("canvas"), c.setAttribute(gvjs_le, 4), c.setAttribute(gvjs_jd, 4), b = c.getContext("2d"), b.fillStyle = d.getBackgroundColor(), b.fillRect(0, 0, 4, 4), b.strokeStyle = d.Gm(), b.beginPath(),
                    b.lineWidth = 2, b.lineCap = gvjs_uv, b.moveTo(2, 0), b.lineTo(4, 2), b.moveTo(0, 2), b.lineTo(2, 4), b.stroke()
        }
        this.za.fillStyle = this.za.createPattern(c, "repeat")
    } else if (null != c) {
        var e = c.useObjectBoundingBoxUnits || !1;
        d = gvjs_7z(this, c.x1, e, !1, b);
        var f = gvjs_7z(this, c.y1, e, !0, b),
            g = gvjs_7z(this, c.x2, e, !1, b);
        b = gvjs_7z(this, c.y2, e, !0, b);
        b = this.za.createLinearGradient(d, f, g, b);
        b.addColorStop(0, c.color1);
        b.addColorStop(1, c.color2);
        this.za.fillStyle = b
    }
    this.za.lineWidth = a.strokeWidth
};

function gvjs_8z(a, b) {
    b.auraColor && b.auraColor != gvjs_e ? (a.strokeStyle = b.auraColor, a.lineWidth = 3) : a.strokeStyle = gvjs_7u;
    a.fillStyle = gvjs_5z(b.color, b.opacity ? b.opacity : 1);
    gvjs_6z(a, []);
    var c = "";
    b.italic && (c = "italic ");
    b.bold && (c += "bold ");
    c += b.fontSize + "px " + b.fontName;
    a.font = c
}
gvjs_.Ex = function(a, b, c, d) {
    this.za.beginPath();
    this.sg(d, new gvjs_0(a - c, b - c, 2 * c, 2 * c));
    this.za.arc(a, b, c, 0, 2 * Math.PI);
    this.za.closePath();
    this.za.fill();
    this.za.stroke();
    return gvjs_4z(this)
};
gvjs_.iQ = function(a, b, c, d, e) {
    this.za.save();
    this.sg(e, new gvjs_0(a - c, b - d, 2 * c, 2 * d));
    this.za.translate(a, b);
    c > d ? (this.za.scale(1, d / c), a = c) : (this.za.scale(c / d, 1), a = d);
    this.za.arc(0, 0, a, 0, 2 * Math.PI, !1);
    this.za.fill();
    this.za.stroke();
    this.za.restore();
    return gvjs_4z(this)
};
gvjs_.Ii = function(a, b, c, d, e) {
    this.sg(e, new gvjs_0(a, b, c, d));
    this.za.fillRect(a, b, c, d);
    this.za.strokeRect(a, b, c, d);
    return gvjs_4z(this)
};
gvjs_.Yy = gvjs_p(41);
gvjs_.mQ = function(a, b) {
    this.sg(b, gvjs_Oy(this.lk));
    this.za.fill();
    this.za.stroke();
    this.OU = !1;
    this.lk = null;
    return gvjs_4z(this)
};
gvjs_.Yq = function(a, b, c, d, e, f, g) {
    return this.Bo(a, b, c, d, 0, e, f, g)
};
gvjs_.mC = function(a, b, c, d, e, f, g, h) {
    var k = gvjs_rz(b, d, f),
        l = gvjs_rz(c, e, f);
    return this.Bo(a, k, l, Math.sqrt(gvjs_hy(new gvjs_gy(b, c, d, e))), gvjs_Mx(gvjs_Px(Math.atan2(e - c, d - b)), 360), f, g, h)
};
gvjs_.Bo = function(a, b, c, d, e, f, g, h) {
    gvjs_8z(this.za, h);
    this.za.save();
    e = gvjs_Ox(e);
    d = b * Math.sin(-e) + c * Math.cos(-e);
    b = b * Math.cos(-e) - c * Math.sin(-e);
    this.za.rotate(e);
    g == gvjs_l ? d += 4 * h.fontSize / 5 : g == gvjs_X ? d += h.fontSize / 3 : g == gvjs_Y && (d -= h.fontSize / 5);
    f != gvjs_l && (f == gvjs_X ? b -= this.ny(a, h).width / 2 : f == gvjs_Y && (b -= this.ny(a, h).width));
    this.za.strokeText(a, b, d);
    this.za.fillText(a, b, d);
    h.zd && (this.za.beginPath(), e = h.fontSize / 15, d += e + 1, 1 > e && (e = 1), this.za.lineWidth = e, this.za.moveTo(b, d), this.za.lineTo(this.za.measureText(a).width +
        b, d), this.za.strokeStyle = this.za.fillStyle, this.za.stroke());
    this.za.restore();
    return gvjs_4z(this)
};
gvjs_.jQ = function() {
    return gvjs_4z(this)
};
gvjs_.Kx = function(a) {
    null !== a && (this.eI = a, this.za.save(), this.za.beginPath(), this.za.fillStyle = gvjs_7u, this.za.rect(a.left, a.top, a.width, a.height), this.za.clip())
};
gvjs_.zC = function() {
    var a = this.eI;
    this.eI && (this.eI = null, this.za.restore());
    return a
};
gvjs_.aC = function() {
    return gvjs_4z(this)
};
gvjs_.Zb = function(a, b, c) {
    gvjs_2z(this);
    this.za.moveTo(b, c);
    gvjs_3z(this, b, c)
};
gvjs_.pa = function(a, b, c) {
    gvjs_2z(this);
    this.za.lineTo(b, c);
    gvjs_3z(this, b, c)
};
gvjs_.bm = function(a, b, c, d, e, f, g) {
    gvjs_2z(this);
    this.za.bezierCurveTo(b, c, d, e, f, g);
    gvjs_3z(this, b, c);
    gvjs_3z(this, d, e);
    gvjs_3z(this, f, g)
};
gvjs_.wg = function() {
    gvjs_2z(this);
    this.za.closePath()
};
gvjs_.yj = function(a, b, c, d, e, f, g, h) {
    gvjs_2z(this);
    f = gvjs_Ox(f - 90);
    g = gvjs_Ox(g - 90);
    a = Math.max(d, e);
    this.za.save();
    this.za.translate(b, c);
    this.za.scale(d / a, e / a);
    this.za.arc(0, 0, a, f, g, !h);
    this.za.restore()
};
gvjs_.El = function() {};
gvjs_.ag = function() {};
gvjs_.si = function() {};
gvjs_.Jv = gvjs_p(44);
gvjs_.Ov = gvjs_p(47);
gvjs_.Jc = function() {};
gvjs_.ny = function(a, b) {
    gvjs_8z(this.g9, b);
    return new gvjs_B(this.g9.measureText(a).width, b.fontSize)
};
gvjs_.ly = gvjs_p(50);
gvjs_.Vg = function() {};

function gvjs_9z() {
    var a = [0, 10, 1, 2, 1, 18, 95, 33, 13, 1, 594, 112, 275, 7, 263, 45, 1, 1, 1, 2, 1, 2, 1, 1, 56, 6, 10, 11, 1, 1, 46, 21, 16, 1, 101, 7, 1, 1, 6, 2, 2, 1, 4, 33, 1, 1, 1, 30, 27, 91, 11, 58, 9, 34, 4, 1, 9, 1, 3, 1, 5, 43, 3, 120, 14, 1, 32, 1, 17, 37, 1, 1, 1, 1, 3, 8, 4, 1, 2, 1, 7, 8, 2, 2, 21, 7, 1, 1, 2, 17, 39, 1, 1, 1, 2, 6, 6, 1, 9, 5, 4, 2, 2, 12, 2, 15, 2, 1, 17, 39, 2, 3, 12, 4, 8, 6, 17, 2, 3, 14, 1, 17, 39, 1, 1, 3, 8, 4, 1, 20, 2, 29, 1, 2, 17, 39, 1, 1, 2, 1, 6, 6, 9, 6, 4, 2, 2, 13, 1, 16, 1, 18, 41, 1, 1, 1, 12, 1, 9, 1, 40, 1, 3, 17, 31, 1, 5, 4, 3, 5, 7, 8, 3, 2, 8, 2, 29, 1, 2, 17, 39, 1, 1, 1, 1, 2, 1, 3, 1, 5, 1, 8, 9, 1, 3, 2, 29, 1, 2, 17, 38, 3, 1, 2, 5,
        7, 1, 1, 8, 1, 10, 2, 30, 2, 22, 48, 5, 1, 2, 6, 7, 1, 18, 2, 13, 46, 2, 1, 1, 1, 6, 1, 12, 8, 50, 46, 2, 1, 1, 1, 9, 11, 6, 14, 2, 58, 2, 27, 1, 1, 1, 1, 1, 4, 2, 49, 14, 1, 4, 1, 1, 2, 5, 48, 9, 1, 57, 33, 12, 4, 1, 6, 1, 2, 2, 2, 1, 16, 2, 4, 2, 2, 4, 3, 1, 3, 2, 7, 3, 4, 13, 1, 1, 1, 2, 6, 1, 1, 14, 1, 98, 96, 72, 88, 349, 3, 931, 15, 2, 1, 14, 15, 2, 1, 14, 15, 2, 15, 15, 14, 35, 17, 2, 1, 7, 8, 1, 2, 9, 1, 1, 9, 1, 45, 3, 1, 118, 2, 34, 1, 87, 28, 3, 3, 4, 2, 9, 1, 6, 3, 20, 19, 29, 44, 84, 23, 2, 2, 1, 4, 45, 6, 2, 1, 1, 1, 8, 1, 1, 1, 2, 8, 6, 13, 48, 84, 1, 14, 33, 1, 1, 5, 1, 1, 5, 1, 1, 1, 7, 31, 9, 12, 2, 1, 7, 23, 1, 4, 2, 2, 2, 2, 2, 11, 3, 2, 36, 2, 1, 1, 2, 3, 1, 1, 3, 2, 12, 36, 8, 8, 2, 2, 21,
        3, 128, 3, 1, 13, 1, 7, 4, 1, 4, 2, 1, 3, 2, 198, 64, 523, 1, 1, 1, 2, 24, 7, 49, 16, 96, 33, 1324, 1, 34, 1, 1, 1, 82, 2, 98, 1, 14, 1, 1, 4, 86, 1, 1418, 3, 141, 1, 96, 32, 554, 6, 105, 2, 30164, 4, 1, 10, 32, 2, 80, 2, 272, 1, 3, 1, 4, 1, 23, 2, 2, 1, 24, 30, 4, 4, 3, 8, 1, 1, 13, 2, 16, 34, 16, 1, 1, 26, 18, 24, 24, 4, 8, 2, 23, 11, 1, 1, 12, 32, 3, 1, 5, 3, 3, 36, 1, 2, 4, 2, 1, 3, 1, 36, 1, 32, 35, 6, 2, 2, 2, 2, 12, 1, 8, 1, 1, 18, 16, 1, 3, 6, 1, 1, 1, 3, 48, 1, 1, 3, 2, 2, 5, 2, 1, 1, 32, 9, 1, 2, 2, 5, 1, 1, 201, 14, 2, 1, 1, 9, 8, 2, 1, 2, 1, 2, 1, 1, 1, 18, 11184, 27, 49, 1028, 1024, 6942, 1, 737, 16, 16, 16, 207, 1, 158, 2, 89, 3, 513, 1, 226, 1, 149, 5, 1670, 15, 40, 7, 1, 165,
        2, 1305, 1, 1, 1, 53, 14, 1, 56, 1, 2, 1, 45, 3, 4, 2, 1, 1, 2, 1, 66, 3, 36, 5, 1, 6, 2, 62, 1, 12, 2, 1, 48, 3, 9, 1, 1, 1, 2, 6, 3, 95, 3, 3, 2, 1, 1, 2, 6, 1, 160, 1, 3, 7, 1, 21, 2, 2, 56, 1, 1, 1, 1, 1, 12, 1, 9, 1, 10, 4, 15, 192, 3, 8, 2, 1, 2, 1, 1, 105, 1, 2, 6, 1, 1, 2, 1, 1, 2, 1, 1, 1, 235, 1, 2, 6, 4, 2, 1, 1, 1, 27, 2, 82, 3, 8, 2, 1, 1, 1, 1, 106, 1, 1, 1, 2, 6, 1, 1, 101, 3, 2, 4, 1, 4, 1, 1283, 1, 14, 1, 1, 82, 23, 1, 7, 1, 2, 1, 2, 20025, 5, 59, 7, 1050, 62, 4, 19722, 2, 1, 4, 5313, 1, 1, 3, 3, 1, 5, 8, 8, 2, 7, 30, 4, 148, 3, 1979, 55, 4, 50, 8, 1, 14, 1, 22, 1424, 2213, 7, 109, 7, 2203, 26, 264, 1, 53, 1, 52, 1, 17, 1, 13, 1, 16, 1, 3, 1, 25, 3, 2, 1, 2, 3, 30, 1, 1, 1, 13, 5, 66,
        2, 2, 11, 21, 4, 4, 1, 1, 9, 3, 1, 4, 3, 1, 3, 3, 1, 30, 1, 16, 2, 106, 1, 4, 1, 71, 2, 4, 1, 21, 1, 4, 2, 81, 1, 92, 3, 3, 5, 48, 1, 17, 1, 16, 1, 16, 3, 9, 1, 11, 1, 587, 5, 1, 1, 7, 1, 9, 10, 3, 2, 788162, 31
    ];
    this.nka = a;
    for (var b = 1; b < a.length; b++) null == a[b] ? a[b] = a[b - 1] + 1 : a[b] += a[b - 1];
    this.values = [1, 13, 1, 12, 1, 0, 1, 0, 1, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 3, 0, 2, 0, 1, 0, 2, 0, 2, 0, 2, 3, 0, 2, 0, 2, 0, 2, 0, 3, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 3, 2, 4, 0, 5, 2, 4, 2, 0, 4, 2, 4, 6, 4, 0, 2, 5, 0, 2, 0, 5, 0, 2, 4, 0, 5, 2, 0, 2, 4, 2, 4, 6, 0, 2, 5, 0, 2, 0, 5, 0, 2, 4, 0, 5, 2, 4, 2, 6, 2, 5, 0, 2, 0, 2, 4, 0, 5, 2, 0, 4, 2, 4, 6, 0, 2,
        0, 2, 4, 0, 5, 2, 0, 2, 4, 2, 4, 6, 2, 5, 0, 2, 0, 5, 0, 2, 0, 5, 2, 4, 2, 4, 6, 0, 2, 0, 2, 4, 0, 5, 0, 5, 0, 2, 4, 2, 6, 2, 5, 0, 2, 0, 2, 4, 0, 5, 2, 0, 4, 2, 4, 2, 4, 2, 4, 2, 6, 2, 5, 0, 2, 0, 2, 4, 0, 5, 0, 2, 4, 2, 4, 6, 3, 0, 2, 0, 2, 0, 4, 0, 5, 6, 2, 4, 2, 4, 2, 0, 4, 0, 5, 0, 2, 0, 4, 2, 6, 0, 2, 0, 5, 0, 2, 0, 4, 2, 0, 2, 0, 5, 0, 2, 0, 2, 0, 2, 0, 2, 0, 4, 5, 2, 4, 2, 6, 0, 2, 0, 2, 0, 2, 0, 5, 0, 2, 4, 2, 0, 6, 4, 2, 5, 0, 5, 0, 4, 2, 5, 2, 5, 0, 5, 0, 5, 2, 5, 2, 0, 4, 2, 0, 2, 5, 0, 2, 0, 7, 8, 9, 0, 2, 0, 5, 2, 6, 0, 5, 2, 6, 0, 5, 2, 0, 5, 2, 5, 0, 2, 4, 2, 4, 2, 4, 2, 6, 2, 0, 2, 0, 2, 1, 0, 2, 0, 2, 0, 5, 0, 2, 4, 2, 4, 2, 4, 2, 0, 5, 0, 5, 0, 5, 2, 4, 2, 0, 5, 0, 5, 4, 2, 4, 2, 6, 0, 2, 0, 2, 4, 2, 0, 2, 4, 0, 5, 2, 4, 2,
        4, 2, 4, 2, 4, 6, 5, 0, 2, 0, 2, 4, 0, 5, 4, 2, 4, 2, 6, 2, 5, 0, 5, 0, 5, 0, 2, 4, 2, 4, 2, 4, 2, 6, 0, 5, 4, 2, 4, 2, 0, 5, 0, 2, 0, 2, 4, 2, 0, 2, 0, 4, 2, 0, 2, 0, 2, 0, 1, 2, 15, 1, 0, 1, 0, 1, 0, 2, 0, 16, 0, 17, 0, 17, 0, 17, 0, 16, 0, 17, 0, 16, 0, 17, 0, 2, 0, 6, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 6, 5, 2, 5, 4, 2, 4, 0, 5, 0, 5, 0, 5, 0, 5, 0, 4, 0, 5, 4, 6, 2, 0, 2, 0, 5, 0, 2, 0, 5, 2, 4, 6, 0, 7, 2, 4, 0, 5, 0, 5, 2, 4, 2, 4, 2, 4, 6, 0, 2, 0, 5, 2, 4, 2, 4, 2, 0, 2, 0, 2, 4, 0, 5, 0, 5, 0, 5, 0, 2, 0, 5, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 5, 4, 2, 4, 0, 4, 6, 0, 5, 0, 5, 0, 5, 0, 4, 2, 4, 2, 4, 0, 4, 6, 0, 11, 8, 9, 0, 2, 0, 2, 0, 2, 0, 2, 0, 1, 0, 2, 0, 1, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 6, 0, 2, 0, 4, 2, 4, 0, 2,
        6, 0, 6, 2, 4, 0, 4, 2, 4, 6, 2, 0, 3, 0, 2, 0, 2, 4, 2, 6, 0, 2, 0, 2, 4, 0, 4, 2, 4, 6, 0, 3, 0, 2, 0, 4, 2, 4, 2, 6, 2, 0, 2, 0, 2, 4, 2, 6, 0, 2, 4, 0, 2, 0, 2, 4, 2, 4, 6, 0, 2, 0, 4, 2, 0, 4, 2, 4, 6, 2, 4, 2, 0, 2, 4, 2, 4, 2, 4, 2, 4, 2, 4, 6, 2, 0, 2, 4, 2, 4, 2, 4, 6, 2, 0, 2, 0, 4, 2, 4, 2, 4, 6, 2, 0, 2, 4, 2, 4, 2, 6, 2, 0, 2, 4, 2, 4, 2, 6, 0, 4, 2, 4, 6, 0, 2, 4, 2, 4, 2, 4, 2, 0, 2, 0, 2, 0, 4, 2, 0, 2, 0, 1, 0, 2, 4, 2, 0, 4, 2, 1, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 14, 0, 17, 0, 17, 0, 17, 0, 16, 0, 17, 0, 17, 0, 17, 0, 16, 0, 16, 0, 16, 0, 17, 0, 17, 0, 18, 0, 16, 0, 16, 0, 19, 0, 16, 0, 16, 0, 16, 0, 16, 0, 16, 0, 17, 0, 16, 0, 17, 0, 17, 0, 17, 0, 16, 0, 16, 0, 16, 0, 16, 0,
        17, 0, 16, 0, 16, 0, 17, 0, 17, 0, 16, 0, 16, 0, 16, 0, 16, 0, 16, 0, 16, 0, 16, 0, 16, 0, 16, 0, 1, 2
    ]
}
gvjs_9z.prototype.at = function(a) {
    for (var b = this.nka, c = 0, d = b.length; 8 < d - c;) {
        var e = d + c >> 1;
        b[e] <= a ? c = e : d = e
    }
    for (; c < d && !(a < b[c]); ++c);
    a = c - 1;
    return 0 > a ? null : this.values[a]
};
var gvjs_$z = null;

function gvjs_aA(a, b) {
    var c = a.charCodeAt(b);
    55296 <= c && 56319 >= c && b + 1 < a.length ? (a = a.charCodeAt(b + 1), 56320 <= a && 57343 >= a && (c = 55296 <= c && 56319 >= c && 56320 <= a && 57343 >= a ? (c << 10) - 56623104 + (a - 56320 + 65536) : null)) : 56320 <= c && 57343 >= c && 0 < b && (a = a.charCodeAt(b - 1), 55296 <= a && 56319 >= a && (c = -(55296 <= a && 56319 >= a && 56320 <= c && 57343 >= c ? (a << 10) - 56623104 + (c - 56320 + 65536) : 0)));
    return 0 > c ? -c : c
}

function gvjs_bA(a) {
    if (44032 <= a && 55203 >= a) return 16 === a % 28 ? 10 : 11;
    gvjs_$z || (gvjs_$z = new gvjs_9z);
    return gvjs_$z.at(a)
}

function gvjs_dea(a, b) {
    var c = typeof a === gvjs_m ? gvjs_aA(a, a.length - 1) : a,
        d = typeof b === gvjs_m ? gvjs_aA(b, 0) : b;
    b = gvjs_bA(c);
    var e = gvjs_bA(d),
        f = typeof a === gvjs_m;
    if (12 === b && 13 === e) return !1;
    if (1 === b || 12 === b || 13 === b || 1 === e || 12 === e || 13 === e) return !0;
    if (7 === b && (7 === e || 8 === e || 10 === e || 11 === e) || !(10 !== b && 8 !== b || 8 !== e && 9 !== e) || (11 === b || 9 === b) && 9 === e || 2 === e || 15 === e || 6 === e) return !1;
    var g;
    if (f) {
        if (18 === e) {
            d = a;
            var h = d.length - 1;
            var k = c;
            for (g = b; 0 < h && 2 === g;) h -= 65536 <= k && 1114111 >= k ? 2 : 1, k = gvjs_aA(d, h), g = gvjs_bA(k);
            if (16 ===
                g || 19 === g) return !1
        }
    } else if ((16 === b || 19 === b) && 18 === e) return !1;
    if (15 === b && (17 === e || 19 === e)) return !1;
    if (f) {
        if (14 === e) {
            e = 0;
            d = a;
            h = d.length - 1;
            k = c;
            for (g = b; 0 < h && 14 === g;) e++, h -= 65536 <= k && 1114111 >= k ? 2 : 1, k = gvjs_aA(d, h), g = gvjs_bA(k);
            14 === g && e++;
            if (1 === e % 2) return !1
        }
    } else if (14 === b && 14 === e) return !1;
    return !0
}

function gvjs_eea(a) {
    if (null != a) switch (a.fQ) {
        case 1:
            return 1;
        case -1:
            return -1;
        case 0:
            return 0
    }
    return null
}
var gvjs_fea = /<(?:!|\/?([a-zA-Z][a-zA-Z0-9:\-]*))(?:[^>'"]|"[^"]*"|'[^']*')*>/g,
    gvjs_gea = /</g,
    gvjs_hea = {
        "\x00": "&#0;",
        "\t": "&#9;",
        "\n": "&#10;",
        "\v": "&#11;",
        "\f": "&#12;",
        "\r": "&#13;",
        " ": "&#32;",
        '"': gvjs_ia,
        "&": "&amp;",
        "'": "&#39;",
        "-": "&#45;",
        "/": "&#47;",
        "<": gvjs_ha,
        "=": "&#61;",
        ">": "&gt;",
        "`": "&#96;",
        "\u0085": "&#133;",
        "\u00a0": "&#160;",
        "\u2028": "&#8232;",
        "\u2029": "&#8233;"
    };

function gvjs_cA(a) {
    return gvjs_hea[a]
}
var gvjs_dA = /[\x00\x22\x26\x27\x3c\x3e]/g;

function gvjs_eA(a) {
    return null != a && a.tm === gvjs_Up ? a : a instanceof gvjs_vh ? gvjs_U(gvjs_wh(a)) : a instanceof gvjs_vh ? gvjs_U(gvjs_xh(a).toString()) : gvjs_U(String(String(a)).replace(gvjs_dA, gvjs_cA), gvjs_eea(a))
}
var gvjs_iea = /[\x00\x22\x27\x3c\x3e]/g;

function gvjs_fA(a) {
    return String(a).replace(gvjs_iea, gvjs_cA)
}

function gvjs_1(a) {
    null != a && a.tm === gvjs_Up ? (a = a.getContent(), a = String(a).replace(gvjs_fea, "").replace(gvjs_gea, gvjs_ha), a = gvjs_fA(a)) : a = String(a).replace(gvjs_dA, gvjs_cA);
    return a
}
var gvjs_jea = /^[a-zA-Z0-9+\/_-]+={0,2}$/;

function gvjs_gA(a) {
    a = String(a);
    return gvjs_jea.test(a) ? a : "zSoyz"
}
var gvjs_hA = {};

function gvjs_iA(a) {
    return gvjs_Pe(a) ? a.lA && (a = a.lA(), a instanceof gvjs_vh) ? a : gvjs_yh("zSoyz") : gvjs_yh(String(a))
}

function gvjs_jA(a, b, c, d) {
    a = a(b || gvjs_hA, c);
    d = d || gvjs_ii();
    a && a.oV ? d = a.oV() : (d = d.createElement(gvjs_b), a = gvjs_iA(a), gvjs_Hh(d, a));
    1 == d.childNodes.length && (a = d.firstChild, 1 == a.nodeType && (d = a));
    return d
}

function gvjs_kea(a, b) {
    var c = a.usa,
        d = a.frameId,
        e = a.width;
    a = a.height;
    d = '<iframe name="' + gvjs_1(d) + gvjs_6p + gvjs_1(d) + '" type="' + (c ? "" : "image/svg+xml") + '" frameBorder="0" scrolling="no" marginHeight="0" marginWidth="0" width="' + gvjs_1(e) + '" height="' + gvjs_1(a) + '" allowTransparency="true" srcdoc="';
    e = b && b.Dqa;
    b = b && b.Eqa;
    c = gvjs_U((c ? '<html xmlns:v="urn:schemas-microsoft-com:vml"><head>\n          <style' + (b ? gvjs_da + gvjs_1(gvjs_gA(b)) + '"' : "") + ">\n            v\\:* {\n              behavior:url(#default#VML);\n            }\n          </style>\n        </head>" :
        '<?xml version="1.0"?><html xmlns="http://www.w3.org/1999/xhtml" xmlns:svg="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><head></head>') + '<body marginwidth="0" marginheight="0" style="background:transparent"><div id="renderers"></div>\n      <script' + (e ? gvjs_da + gvjs_1(gvjs_gA(e)) + '"' : "") + ">\n        var _loaded = false;\n        function CHART_loaded() {\n          _loaded = true;\n        }\n        document.body.onload = CHART_loaded;\n      \x3c/script>\n      </body></html>");
    return gvjs_U(d + gvjs_1(String(gvjs_eA(c))) + '"></iframe>')
}

function gvjs_kA(a, b) {
    var c = Array.prototype.slice.call(arguments),
        d = c.shift();
    if ("undefined" == typeof d) throw Error("[goog.string.format] Template required");
    return d.replace(/%([0\- \+]*)(\d+)?(\.(\d+))?([%sfdiu])/g, function(e, f, g, h, k, l, m, n) {
        if ("%" == l) return "%";
        var p = c.shift();
        if ("undefined" == typeof p) throw Error("[goog.string.format] Not enough arguments");
        arguments[0] = p;
        return gvjs_Yp[l].apply(null, arguments)
    })
}

function gvjs_lA(a, b) {
    if (Array.isArray(a)) return a.join(",");
    switch (a) {
        case gvjs_tv:
            return "0";
        case gvjs_ss:
            return String(4 * b) + "," + String(b);
        default:
            return gvjs_lA(gvjs_tv, b)
    }
}

function gvjs_mA(a, b) {
    gvjs_0z.call(this, a, b);
    this.St = null;
    this.vL = {};
    this.XR = {};
    this.VV = {};
    this.ny("-._.-*^*-._.-*^*-._.-", {
        fontSize: 8,
        fontName: gvjs_Jq,
        bold: !1,
        italic: !1
    });
    this.sK = !1;
    for (a = this.container.parentElement.parentElement; a;) {
        if (null != a.getAttribute("dir")) {
            this.sK = a.getAttribute("dir") === gvjs_Zd;
            break
        }
        a = a.parentElement
    }
}
gvjs_r(gvjs_mA, gvjs_0z);

function gvjs_nA(a, b) {
    a.St = a.Wa(gvjs_ys);
    var c = gvjs_Az();
    a.St.setAttribute(gvjs_nd, c);
    a.vL = {};
    a.XR = {};
    a.VV = {};
    b.appendChild(a.St)
}
gvjs_ = gvjs_mA.prototype;
gvjs_.rI = function(a, b) {
    this.width = a;
    this.height = b;
    var c = this.Wa(gvjs_Cp);
    c.setAttribute(gvjs_le, a);
    c.setAttribute(gvjs_jd, b);
    c.style.overflow = gvjs_kd;
    c.setAttribute(gvjs_Cb, "A chart.");
    this.container.appendChild(c);
    gvjs_nA(this, c);
    return new gvjs_sz(c)
};
gvjs_.getBoundingBox = function(a) {
    var b = gvjs_fk().Yi().SVGElement;
    return typeof b === gvjs_g && a instanceof b && a.tagName.toLowerCase() !== gvjs_Qu && a.tagName.toLowerCase() !== gvjs_Cp ? (b = a.getBBox(), b.y | b.x | b.height | b.width ? new gvjs_H(b.y, b.x + b.width, b.y + b.height, b.x) : gvjs_0z.prototype.getBoundingBox.call(this, a)) : gvjs_0z.prototype.getBoundingBox.call(this, a)
};
gvjs_.LQ = function() {
    for (var a = this.Xr.j(), b = a.childNodes, c = b.length; 1 < c;) a.removeChild(b[0]), c--;
    gvjs_nA(this, a)
};
gvjs_.round = function(a) {
    return Math.round(100 * a) / 100
};
gvjs_.Ex = function(a, b, c, d) {
    var e = this.Wa(gvjs_es);
    e.setAttribute("cx", a);
    e.setAttribute("cy", b);
    e.setAttribute("r", c);
    this.Vg(e, d);
    return e
};
gvjs_.iQ = function(a, b, c, d, e) {
    var f = this.Wa(gvjs_Ks);
    f.setAttribute("cx", a);
    f.setAttribute("cy", b);
    f.setAttribute("rx", c);
    f.setAttribute("ry", d);
    this.Vg(f, e);
    return f
};
gvjs_.Ii = function(a, b, c, d, e) {
    var f = this.Wa(gvjs_zp);
    f.setAttribute("x", a);
    f.setAttribute("y", b);
    f.setAttribute(gvjs_le, c);
    f.setAttribute(gvjs_jd, d);
    this.Vg(f, e);
    return f
};
gvjs_.Yy = gvjs_p(40);
gvjs_.mQ = function(a, b, c) {
    var d = this.Wa(gvjs_Qu);
    0 < a.length && d.setAttribute("d", a.join(""));
    this.Vg(d, b, c);
    return d
};
gvjs_.Yq = function(a, b, c, d, e, f, g, h) {
    return this.Bo(a, b, c, d, 0, e, f, g, h)
};
gvjs_.mC = function(a, b, c, d, e, f, g, h, k) {
    var l = gvjs_rz(b, d, f, k),
        m = gvjs_rz(c, e, f, k);
    return this.Bo(a, l, m, Math.sqrt(gvjs_hy(new gvjs_gy(b, c, d, e))), gvjs_Mx(gvjs_Px(Math.atan2(e - c, d - b)), 360), f, g, h, k)
};
gvjs_.Bo = function(a, b, c, d, e, f, g, h, k) {
    var l = void 0 !== h.opacity ? h.opacity : 1,
        m = new gvjs__({
            fill: h.color,
            fillOpacity: l
        });
    if (h.color && h.color != gvjs_e && h.auraColor && h.auraColor != gvjs_e) {
        l = new gvjs__({
            fill: h.color,
            fillOpacity: l,
            stroke: h.auraColor,
            strokeOpacity: l,
            strokeWidth: h.DB
        });
        var n = this.ta();
        this.HC(a, b, c, d, e, f, g, h, l, n, k).setAttribute(gvjs_Bb, gvjs_fe);
        this.HC(a, b, c, d, e, f, g, h, m, n, k);
        return n.j()
    }
    return this.lC(a, b, c, d, e, f, g, h, m, k)
};
gvjs_.lC = function(a, b, c, d, e, f, g, h, k, l) {
    d = this.Wa(gvjs_n);
    g = gvjs_qz(0, h.fontSize, g);
    g = gvjs_rz(g.start, g.end, gvjs_Y);
    g -= .15 * h.fontSize;
    g = new gvjs_Ij(0, g);
    g.rotate(gvjs_Ox(e));
    c = new gvjs_Ij(b, c);
    c.add(g);
    b = c.x;
    c = c.y;
    d.appendChild(this.Kj.createTextNode(a));
    switch (f) {
        case gvjs_l:
            d.setAttribute(gvjs_Nv, gvjs_l);
            break;
        case gvjs_X:
            d.setAttribute(gvjs_Nv, "middle");
            break;
        case gvjs_Y:
            d.setAttribute(gvjs_Nv, gvjs_Y)
    }
    d.setAttribute("x", b);
    d.setAttribute("y", c);
    d.setAttribute("font-family", h.fontName);
    d.setAttribute(gvjs_5s,
        h.fontSize || 0);
    h.bold && d.setAttribute(gvjs_6s, gvjs_Qr);
    h.italic && d.setAttribute("font-style", gvjs_Tt);
    h.zd && d.setAttribute(gvjs_Ov, gvjs_5v);
    l && d.setAttribute(gvjs_Cs, gvjs_Zd);
    0 != e && d.setAttribute(gvjs_3v, "rotate(" + e + " " + b + " " + c + ")");
    this.Vg(d, k);
    return d
};
gvjs_.HC = function(a, b, c, d, e, f, g, h, k, l, m) {
    a = this.lC(a, b, c, d, e, f, g, h, k, m);
    this.appendChild(l, a);
    return a
};
gvjs_.jQ = function() {
    return this.Wa("g")
};
gvjs_.aC = function(a, b, c) {
    var d = gvjs_Az(),
        e = this.Wa("clipPath");
    c ? (c = this.Wa(gvjs_Ks), c.setAttribute("cx", b.left + b.width / 2), c.setAttribute("cy", b.top + b.height / 2), c.setAttribute("rx", b.width / 2), c.setAttribute("ry", b.height / 2), e.appendChild(c)) : (c = this.Wa(gvjs_zp), c.setAttribute("x", b.left), c.setAttribute("y", b.top), c.setAttribute(gvjs_le, b.width), c.setAttribute(gvjs_jd, b.height), e.appendChild(c));
    e.setAttribute(gvjs_nd, d);
    this.St.appendChild(e);
    a = a.j();
    a.setAttribute(gvjs_gs, gvjs_oA(d));
    return a
};

function gvjs_oA(a, b) {
    var c = "";
    b || gvjs_x && "9.0" === gvjs_Sf || (c = window.location.href.split("#")[0]);
    return "url(" + c + "#" + a + ")"
}
gvjs_.Zb = function(a, b, c) {
    a.push("M" + b + "," + c)
};
gvjs_.pa = function(a, b, c) {
    a.push("L" + b + "," + c)
};
gvjs_.bm = function(a, b, c, d, e, f, g) {
    a.push("C" + b + "," + c + "," + d + "," + e + "," + f + "," + g)
};
gvjs_.wg = function(a) {
    a.push("Z")
};
gvjs_.yj = function(a, b, c, d, e, f, g, h) {
    if (0 < d && 0 < e) {
        var k = gvjs_Mx(g, 360) - gvjs_Mx(f, 360);
        180 < k ? k -= 360 : -180 >= k && (k = 360 + k);
        var l = 2 * Math.PI * Math.min(d, e);
        .1 > Math.abs(k / 360 * l) && (k = (.1 / l * 360 - Math.abs(k)) * gvjs_Sx(k) / 2, f -= k, g += k)
    }
    f = gvjs_Mx(f, 360);
    g = gvjs_Mx(g, 360);
    k = gvjs_Qx(g - 90, d);
    l = gvjs_Rx(g - 90, e);
    f = h ? g - f : f - g;
    0 > f && (f += 360);
    a.push("A" + d + "," + e + ",0," + (180 < f ? 1 : 0) + "," + (h ? 1 : 0) + "," + (b + k) + "," + (c + l))
};
gvjs_.El = function(a, b, c) {
    a.setAttribute(gvjs_3v, "translate(" + b + gvjs_ja + c + ")")
};
gvjs_.ag = function(a, b) {
    a.setAttribute(gvjs_le, b)
};
gvjs_.si = function(a, b) {
    a.setAttribute(gvjs_jd, b)
};
gvjs_.Jv = gvjs_p(43);
gvjs_.Ov = gvjs_p(46);
gvjs_.Jc = function(a, b, c) {
    a.setAttribute(gvjs_Fv, c);
    b && a.setAttribute(gvjs_Bv, b)
};
gvjs_.ny = function(a, b, c) {
    var d = this.jA;
    if (3 === d.firstChild.nodeType) d.firstChild.data = a;
    else throw Error("Unexpected type of text node " + d.firstChild.nodeType);
    a = d.style;
    a.fontFamily = b.fontName;
    a.fontSize = b.fontSize + gvjs_Z;
    a.fontWeight = b.bold ? gvjs_Qr : "";
    a.fontStyle = b.italic ? gvjs_Tt : "";
    a.display = gvjs_Jb;
    null != c && (b = gvjs_kA("rotate(%ddeg)", c), a.transform = b, a.transformOrigin = "0 0", a.WebkitTransform = b, a.WebkitTransformOrigin = "0 0", a.MozTransform = b, a.MozTransformOrigin = "0 0");
    b = d.clientWidth;
    d = d.clientHeight;
    a.display = gvjs_e;
    return new gvjs_B(b, d)
};
gvjs_.ly = gvjs_p(49);
gvjs_.Wa = function(a) {
    return this.Kj.createElementNS(gvjs_Jt, a)
};
gvjs_.Vg = function(a, b, c) {
    gvjs_Cw(b) ? (a.setAttribute(gvjs_Bv, b.stroke), a.setAttribute(gvjs_Fv, b.strokeWidth), gvjs_Gw(b) ? a.removeAttribute(gvjs_Ev) : a.setAttribute(gvjs_Ev, b.strokeOpacity), b.tg !== gvjs_tv ? a.setAttribute(gvjs_Cv, gvjs_lA(b.tg, b.strokeWidth)) : a.removeAttribute(gvjs_Cv)) : (a.setAttribute(gvjs_Bv, gvjs_e), a.setAttribute(gvjs_Fv, 0));
    gvjs_Fw(b) ? a.removeAttribute(gvjs_Us) : a.setAttribute(gvjs_Us, b.fillOpacity);
    var d = b.radiusX;
    typeof d === gvjs_f && a.setAttribute("rx", d);
    d = b.radiusY;
    typeof d === gvjs_f &&
        a.setAttribute("ry", d);
    var e = b.gradient,
        f = b.pattern;
    if (e) {
        f = gvjs_qx(e, 1).toString();
        d = this.XR[f];
        if (!d) {
            d = gvjs_Az();
            this.XR[f] = d;
            f = this.Wa(gvjs_9t);
            var g = e.x1,
                h = e.x2,
                k = e.y1,
                l = e.y2,
                m = e.color1,
                n = e.color2,
                p = 1;
            if (0 === e.ik || e.ik) p = e.ik;
            var q = 1;
            if (0 === e.jk || e.jk) q = e.jk;
            var r = e.useObjectBoundingBoxUnits ? "objectBoundingBox" : gvjs_8v;
            f.setAttribute(gvjs_nd, d);
            f.setAttribute("x1", g);
            f.setAttribute("y1", k);
            f.setAttribute("x2", h);
            f.setAttribute("y2", l);
            f.setAttribute("gradientUnits", r);
            g = gvjs_Av + m + gvjs_Gq + p;
            n =
                gvjs_Av + n + gvjs_Gq + q;
            q = this.Wa(gvjs_zv);
            q.setAttribute(gvjs_Du, gvjs_wq);
            q.style.cssText = g;
            f.appendChild(q);
            e.Hl && (e = this.Wa(gvjs_zv), e.setAttribute(gvjs_Du, "49.99%"), e.style.cssText = g, f.appendChild(e), e = this.Wa(gvjs_zv), e.setAttribute(gvjs_Du, "50%"), e.style.cssText = n, f.appendChild(e));
            e = this.Wa(gvjs_zv);
            e.setAttribute(gvjs_Du, gvjs_yq);
            e.style.cssText = n;
            f.appendChild(e);
            this.St.appendChild(f)
        }
        a.setAttribute(gvjs_Ts, gvjs_oA(d, c))
    } else if (f) {
        d = f.getStyle() + "_" + f.Gm() + "_" + f.getBackgroundColor();
        if (!(d in
                this.vL)) {
            e = null;
            switch (f.getStyle()) {
                case gvjs_0u:
                    e = this.Wa(gvjs_Md);
                    e.setAttribute("patternUnits", gvjs_8v);
                    e.setAttribute("x", "0");
                    e.setAttribute("y", "0");
                    e.setAttribute(gvjs_le, "4");
                    e.setAttribute(gvjs_jd, "4");
                    e.setAttribute("viewBox", "0 0 4 4");
                    n = this.Wa(gvjs_zp);
                    n.setAttribute("x", "0");
                    n.setAttribute("y", "0");
                    n.setAttribute(gvjs_le, "4");
                    n.setAttribute(gvjs_jd, "4");
                    n.setAttribute(gvjs_Ts, f.getBackgroundColor());
                    e.appendChild(n);
                    n = this.Wa("g");
                    n.setAttribute(gvjs_Bv, f.Gm());
                    n.setAttribute(gvjs_Dv,
                        gvjs_uv);
                    f = this.Wa(gvjs_d);
                    f.setAttribute("x1", "2");
                    f.setAttribute("y1", "0");
                    f.setAttribute("x2", "4");
                    f.setAttribute("y2", "2");
                    f.setAttribute(gvjs_Fv, "2");
                    n.appendChild(f);
                    f = this.Wa(gvjs_d);
                    f.setAttribute("x1", "0");
                    f.setAttribute("y1", "2");
                    f.setAttribute("x2", "2");
                    f.setAttribute("y2", "4");
                    f.setAttribute(gvjs_Fv, "2");
                    n.appendChild(f);
                    e.appendChild(n);
                    break;
                case gvjs_ev:
                    e = this.Wa(gvjs_Md), e.setAttribute("patternUnits", gvjs_8v), e.setAttribute("x", "0"), e.setAttribute("y", "0"), e.setAttribute(gvjs_le, "6"),
                        e.setAttribute(gvjs_jd, "6"), e.setAttribute("viewBox", "0 0 4 4"), n = this.Wa(gvjs_zp), n.setAttribute("x", "0"), n.setAttribute("y", "0"), n.setAttribute(gvjs_le, "4"), n.setAttribute(gvjs_jd, "4"), n.setAttribute(gvjs_Ts, f.getBackgroundColor()), e.appendChild(n), n = this.Wa("g"), n.setAttribute(gvjs_Bv, f.Gm()), n.setAttribute(gvjs_Dv, gvjs_uv), f = this.Wa(gvjs_d), f.setAttribute("x1", "2"), f.setAttribute("y1", "0"), f.setAttribute("x2", "0"), f.setAttribute("y2", "2"), f.setAttribute(gvjs_Fv, "2"), n.appendChild(f), f = this.Wa(gvjs_d),
                        f.setAttribute("x1", "4"), f.setAttribute("y1", "2"), f.setAttribute("x2", "2"), f.setAttribute("y2", "4"), f.setAttribute(gvjs_Fv, "2"), n.appendChild(f), e.appendChild(n)
            }
            f = gvjs_Az();
            e.setAttribute(gvjs_nd, f);
            this.St.appendChild(e);
            this.vL[d] = f
        }
        d = this.vL[d];
        a.setAttribute(gvjs_Ts, gvjs_oA(d, c))
    } else a.setAttribute(gvjs_Ts, b.fill);
    null != b.xs && (f = b.xs, d = gvjs_qx(f, 1).toString(), b = this.VV[d], b || (b = gvjs_Az(), this.VV[d] = b, d = this.Wa(gvjs_Zs), d.setAttribute(gvjs_nd, b), e = this.Wa(gvjs_Rs), e.setAttribute(gvjs_Kt, "SourceAlpha"),
        e.setAttribute("stdDeviation", f.radius || 0), d.appendChild(e), e = this.Wa("feOffset"), e.setAttribute("dx", f.xOffset || 0), e.setAttribute("dy", f.yOffset || 0), d.appendChild(e), null != f.opacity && (e = this.Wa(gvjs_Qs), n = this.Wa("feFuncA"), n.setAttribute(gvjs_ge, gvjs_8t), n.setAttribute("slope", f.opacity), e.appendChild(n), d.appendChild(e)), f = this.Wa("feMerge"), e = this.Wa(gvjs_Ss), f.appendChild(e), e = this.Wa(gvjs_Ss), e.setAttribute(gvjs_Kt, "SourceGraphic"), f.appendChild(e), d.appendChild(f), this.St.appendChild(d)), a.setAttribute(gvjs_Zs,
        gvjs_oA(b, c)))
};
gvjs_.Jt = function() {
    var a = gvjs_5x(gvjs_b, {
        "aria-label": "A tabular representation of the data in the chart.",
        style: "position:absolute;left:" + (this.sK ? 1E4 : -1E4) + "px;top:auto;width:1px;height:1px;overflow:hidden"
    });
    this.container.appendChild(a);
    this.container.setAttribute(gvjs_Cb, "A chart.");
    return a
};

function gvjs_pA(a) {
    if (Array.isArray(a)) return a.join(" ");
    switch (a) {
        case gvjs_tv:
            return gvjs_tv;
        case gvjs_ss:
            return "shortdash";
        default:
            return gvjs_pA(gvjs_tv)
    }
}

function gvjs_qA(a, b) {
    gvjs_0z.call(this, a, b);
    this.Cs = null
}
gvjs_r(gvjs_qA, gvjs_0z);
gvjs_ = gvjs_qA.prototype;
gvjs_.rI = function(a, b) {
    this.width = a;
    this.height = b;
    var c = this.oc(gvjs_5b);
    this.Lh(c, -5E4, -5E4, this.width + 1E5, this.height + 1E5);
    this.container.appendChild(c);
    var d = this.ta(),
        e = d.j();
    e.coordorigin = "0 0";
    e.coordsize = a + " " + b;
    e.style.top = this.Gc(5E4);
    e.style.left = this.Gc(5E4);
    c.appendChild(e);
    return d
};
gvjs_.LQ = function() {
    for (var a = this.Xr.j(), b = a.childNodes, c = b.length; 1 < c;) a.removeChild(b[0]), c--
};
gvjs_.round = function(a) {
    return Math.round(a)
};
gvjs_.Ex = function(a, b, c, d) {
    var e = this.oc(gvjs_aw),
        f = 2 * c;
    this.Lh(e, a - c, b - c, f, f);
    this.Vg(e, d, !1);
    return e
};
gvjs_.iQ = function(a, b, c, d, e) {
    var f = this.oc(gvjs_aw);
    this.Lh(f, a - c, b - d, 2 * c, 2 * d);
    this.Vg(f, e, !1);
    return f
};
gvjs_.Ii = function(a, b, c, d, e) {
    var f = this.oc("v:rect"),
        g = gvjs_Fw(e) && 1 <= d && 1 <= c && null == e.gradient;
    this.Vg(f, e, g);
    if (gvjs_Cw(e) || g) c = Math.max(c - 1, 0), d = Math.max(d - 1, 0);
    this.Lh(f, a, b, c, d);
    return f
};
gvjs_.Yy = gvjs_p(39);
gvjs_.mQ = function(a, b) {
    for (var c = this.oc(gvjs_cw), d = this.oc(gvjs_bw); 0 < a.length && gvjs_0e(gvjs_nf(a), "M");) a = a.slice(0, a.length - 1);
    d.setAttribute("v", a.join(""));
    this.Lh(c, 0, 0, this.width, this.height);
    c.appendChild(d);
    this.Vg(c, b, !1);
    return c
};
gvjs_.Yq = function(a, b, c, d, e, f, g) {
    b = gvjs_qz(b, d, e);
    c = gvjs_qz(c, g.fontSize, f);
    f = gvjs_X;
    c = gvjs_rz(c.start, c.end, f);
    return this.mC(a, b.start, c, b.end, c, e, f, g)
};
gvjs_.mC = function(a, b, c, d, e, f, g, h) {
    var k = new gvjs__({
        fill: h.color
    });
    if (h.color && h.color != gvjs_e && h.auraColor && h.auraColor != gvjs_e) {
        var l = new gvjs__({
                fill: h.color,
                stroke: h.auraColor,
                strokeWidth: 2
            }),
            m = this.ta();
        this.HC(a, b, c, d, e, f, g, h, l, m);
        this.HC(a, b, c, d, e, f, g, h, k, m);
        return m.j()
    }
    return this.lC(a, b, c, d, e, f, g, h, k)
};
gvjs_.Bo = function(a, b, c, d, e, f, g, h) {
    e = gvjs_Ox(e);
    d = gvjs_qz(b, d, f);
    b = new gvjs_Ij(b, c);
    var k = new gvjs_Ij(d.start, c);
    k = k.clone().eN(b).rotate(e).add(b);
    c = new gvjs_Ij(d.end, c);
    c = c.clone().eN(b).rotate(e).add(b);
    return this.mC(a, k.x, k.y, c.x, c.y, f, g, h)
};
gvjs_.lC = function(a, b, c, d, e, f, g, h, k) {
    var l = this.oc(gvjs_cw);
    this.Lh(l, 0, 0, this.width, this.height);
    g != gvjs_X && (g = gvjs_qz(0, h.fontSize, g), g = gvjs_rz(g.start, g.end, gvjs_X), g = new gvjs_Ij(0, g), g.rotate(gvjs_Ox(gvjs_Mx(gvjs_Px(Math.atan2(e - c, d - b)), 360))), c = new gvjs_Ij(b, c), e = new gvjs_Ij(d, e), c.add(g), e.add(g), b = c.x, c = c.y, d = e.x, e = e.y);
    b = Math.round(b);
    c = Math.round(c);
    d = Math.round(d);
    e = Math.round(e);
    g = this.oc(gvjs_bw);
    g.setAttribute("v", "M" + b + "," + c + "L" + d + "," + e + "E");
    g.setAttribute("textpathok", gvjs_fe);
    b = this.oc("v:textpath");
    b.setAttribute("on", gvjs_fe);
    d = b.style;
    d.fontSize = h.fontSize || "";
    d.fontFamily = h.fontName || "";
    switch (f) {
        case gvjs_l:
            d.setAttribute(gvjs_9v, gvjs_sd);
            break;
        case gvjs_X:
            d.setAttribute(gvjs_9v, gvjs_X);
            break;
        case gvjs_Y:
            d.setAttribute(gvjs_9v, gvjs_i)
    }
    h.bold && (d.fontWeight = gvjs_Qr);
    h.italic && (d.fontStyle = gvjs_Tt);
    b.setAttribute(gvjs_m, a);
    l.appendChild(g);
    l.appendChild(b);
    this.Vg(l, k, !1);
    return l
};
gvjs_.HC = function(a, b, c, d, e, f, g, h, k, l) {
    a = this.lC(a, b, c, d, e, f, g, h, k);
    this.appendChild(l, a);
    return a
};
gvjs_.jQ = function() {
    var a = this.oc("v:group");
    this.Lh(a, 0, 0, this.width, this.height);
    return a
};
gvjs_.aC = function(a, b) {
    var c = this.oc(gvjs_5b);
    c.style.clip = "rect(" + [this.Gc(5E4 + b.top), this.Gc(5E4 + b.left + b.width), this.Gc(5E4 + b.top + b.height), this.Gc(5E4 + b.left)].join(gvjs_ja) + ")";
    this.Lh(c, 0, 0, this.width + 1E5, this.height + 1E5);
    a.j();
    b = new gvjs_sz(c);
    this.appendChild(b, a);
    this.bb(1, 1, 1, 1, new gvjs__({
        fill: gvjs_jw
    }), b);
    return c
};
gvjs_.Zb = function(a, b, c) {
    a.push("M" + Math.round(b) + "," + Math.round(c))
};
gvjs_.pa = function(a, b, c) {
    a.push("L" + Math.round(b) + "," + Math.round(c))
};
gvjs_.bm = function(a, b, c, d, e, f, g) {
    a.push("C" + Math.round(b) + "," + Math.round(c) + "," + Math.round(d) + "," + Math.round(e) + "," + Math.round(f) + "," + Math.round(g))
};
gvjs_.wg = function(a) {
    a.push("X")
};
gvjs_.yj = function(a, b, c, d, e, f, g, h) {
    f = gvjs_Mx(f, 360);
    g = gvjs_Mx(g, 360);
    var k = Math.round(gvjs_Qx(f - 90, d)),
        l = Math.round(gvjs_Rx(f - 90, e)),
        m = Math.round(gvjs_Qx(g - 90, d)),
        n = Math.round(gvjs_Rx(g - 90, e));
    d = Math.round(d);
    e = Math.round(e);
    b = Math.round(b);
    c = Math.round(c);
    k === m && l === n && (h && 180 > gvjs_Mx(g - f, 360) || !h && 180 > gvjs_Mx(f - g, 360)) || a.push((h ? "WA" : "AT") + (b - d) + "," + (c - e) + "," + (b + d) + "," + (c + e) + "," + (b + k) + "," + (c + l) + "," + (b + m) + "," + (c + n))
};
gvjs_.El = function(a, b, c) {
    a.style.top = this.Gc(c);
    a.style.left = this.Gc(b)
};
gvjs_.ag = function(a, b) {
    a.style.width = this.Gc(b)
};
gvjs_.si = function(a, b) {
    a.style.height = this.Gc(b)
};
gvjs_.Jv = gvjs_p(42);
gvjs_.Ov = gvjs_p(45);
gvjs_.Jc = function(a, b, c) {
    0 == c ? a.stroked = !1 : (a.stroked = !0, b && (a.strokecolor = b), a.strokeweight = c)
};
gvjs_.ny = function(a, b) {
    var c = this.jA;
    c.firstChild.data = a;
    a = c.style;
    a.fontFamily = b.fontName;
    a.fontSize = this.Gc(b.fontSize || 0);
    a.fontWeight = b.bold ? gvjs_Qr : "";
    a.fontStyle = b.italic ? gvjs_Tt : "";
    a.display = gvjs_Jb;
    var d = c.clientWidth;
    c = c.clientHeight;
    a.display = gvjs_e;
    b.bold && (d *= 1.1);
    b.italic && (d *= .9);
    return new gvjs_B(d, c)
};
gvjs_.ly = gvjs_p(48);
gvjs_.Gc = function(a) {
    return Math.round(a) + gvjs_Z
};
gvjs_.oc = function(a) {
    return this.Kj.createElement(a)
};
gvjs_.Vg = function(a, b, c) {
    for (var d = a.children, e = 0; e < d.length; e++) a.children[e].tagName != gvjs_Ts && a.children[e].tagName != gvjs_Bv || a.removeChild(d[e]);
    c = null != c ? c : !0;
    if (gvjs_Cw(b)) {
        if (a.stroked = !0, a.strokeweight = b.strokeWidth, a.strokecolor = b.stroke, c = !gvjs_Gw(b), d = b.tg !== gvjs_tv, c || d) e = this.oc("v:stroke"), c && e.setAttribute(gvjs_Ju, Math.round(100 * b.strokeOpacity) + "%"), d && (e.dashstyle = gvjs_pA(b.tg)), a.appendChild(e)
    } else c && gvjs_Fw(b) ? (a.stroked = !0, a.strokeweight = 1, a.strokecolor = b.fill) : a.stroked = !1;
    void 0 !== a.filled && (a.filled = !0);
    c = b.gradient;
    if (null != c) {
        b = this.oc(gvjs_$v);
        b.setAttribute(gvjs_Sb, c.color1);
        b.setAttribute("color2", c.color2);
        b.setAttribute(gvjs_Ju, c.ik || 1);
        b.setAttribute("opacity2", c.jk || 1);
        d = c.x1;
        e = c.y1;
        var f = c.x2;
        c = c.y2;
        typeof d == gvjs_m && (d = parseInt(d, 10));
        typeof e == gvjs_m && (e = parseInt(e, 10));
        typeof f == gvjs_m && (f = parseInt(f, 10));
        typeof c == gvjs_m && (c = parseInt(c, 10));
        c = gvjs_Mx(gvjs_Px(Math.atan2(c - e, f - d)), 360);
        c = gvjs_Mx(270 - c, 360);
        b.setAttribute("angle", c);
        b.setAttribute(gvjs_ge,
            gvjs_lt);
        a.appendChild(b)
    } else b.pattern ? (c = b.pattern, b = this.oc(gvjs_$v), b.setAttribute(gvjs_ge, gvjs_Md), b.setAttribute(gvjs_Sb, c.Gm()), b.setAttribute("color2", c.getBackgroundColor()), c = gvjs_Ke("google.charts.loader.makeCssUrl")({
        subdir1: "core",
        subdir2: "patterns",
        filename: c.getStyle() + ".gif"
    }), b.setAttribute("src", c), a.appendChild(b)) : b.fill == gvjs_e ? a.filled = !1 : gvjs_Fw(b) ? a.fillcolor = b.fill : (c = this.oc(gvjs_$v), c.setAttribute(gvjs_Ju, Math.round(100 * b.fillOpacity) + "%"), c.setAttribute(gvjs_Sb, b.fill),
        a.appendChild(c))
};
gvjs_.Lh = function(a, b, c, d, e) {
    a = a.style;
    a.position = gvjs_xb;
    a.left = this.Gc(b);
    a.top = this.Gc(c);
    a.width = this.Gc(d);
    a.height = this.Gc(e)
};
gvjs_.Qr = gvjs_p(33);
var gvjs_rA;

function gvjs_sA(a, b) {
    b ? a.setAttribute(gvjs_Vd, b) : a.removeAttribute(gvjs_Vd)
}

function gvjs_tA(a, b, c) {
    Array.isArray(c) && (c = c.join(" "));
    var d = "aria-" + b;
    "" === c || void 0 == c ? (gvjs_rA || (c = {}, gvjs_rA = (c.atomic = !1, c.autocomplete = gvjs_e, c.dropeffect = gvjs_e, c.haspopup = !1, c.live = "off", c.multiline = !1, c.multiselectable = !1, c.orientation = gvjs_S, c.readonly = !1, c.relevant = "additions text", c.required = !1, c.sort = gvjs_e, c.busy = !1, c.disabled = !1, c.hidden = !1, c.invalid = gvjs_8b, c)), c = gvjs_rA, b in c ? a.setAttribute(d, c[b]) : a.removeAttribute(d)) : a.setAttribute(d, c)
}

function gvjs_uA(a, b) {
    a = a.getAttribute("aria-" + b);
    return null == a || void 0 == a ? "" : String(a)
}

function gvjs_vA(a) {
    var b = gvjs_uA(a, gvjs_jr);
    return gvjs_ki(a).getElementById(b)
}

function gvjs_wA(a, b) {
    var c = "";
    b && (c = b.id);
    gvjs_tA(a, gvjs_jr, c)
}

function gvjs_xA(a) {
    return gvjs_uA(a, gvjs_qd)
}

function gvjs_yA(a, b) {
    gvjs_tA(a, gvjs_qd, b)
}

function gvjs_zA(a, b) {
    var c = gvjs_ii(a),
        d = c.createElement(gvjs_5b),
        e = d.style,
        f = b ? b.height + 10 : 0;
    b = b ? b.width + 10 : 0;
    e.display = gvjs_e;
    e.position = gvjs_xb;
    e.top = f + gvjs_Z;
    e.left = b + gvjs_Z;
    e.whiteSpace = gvjs_Au;
    gvjs_tA(d, gvjs_kd, !0);
    d.setAttribute(gvjs_Bb, !0);
    c.appendChild(d, c.createTextNode(" "));
    c.appendChild(a, d);
    return d
}

function gvjs_AA(a, b, c, d) {
    a.call() ? b.call() : gvjs_lea(a, b, c, d)
}

function gvjs_lea(a, b, c, d) {
    d = null != d ? d : 10;
    setTimeout(c(function() {
        gvjs_AA(a, b, c, d)
    }), d)
}

function gvjs_BA(a, b, c, d) {
    gvjs_L.call(this);
    if (!(gvjs_x ? 0 <= gvjs_5w(gvjs_Sf, "5.5") : gvjs_Hf ? 0 <= gvjs_5w(gvjs_Sf, "1.8") : gvjs_Ff ? 0 <= gvjs_5w(gvjs_Sf, "9.0") : gvjs_If ? 0 <= gvjs_5w(gvjs_Sf, "420+") : gvjs_Gf)) throw Error("Graphics is not supported");
    for (var e = Math.floor(1E5 * Math.random()); window.frames[gvjs_Pq + e];) e++;
    this.Ri = gvjs_Pq + e;
    (a = this.vG = a) && (a[gvjs_Pp] = !0);
    gvjs_xi(this.vG);
    this.Ki = gvjs_ii(this.vG);
    this.container = this.Ki.createElement(gvjs_5b);
    this.container.style.position = gvjs_Td;
    this.vG.appendChild(this.container);
    this.dimensions = b;
    this.DW = this.hj = null;
    this.XD = !1;
    this.Fz = [];
    this.kk = null;
    b = gvjs_gk();
    this.wka = (b = gvjs_x ? null != b.documentMode ? 9 > b.documentMode : !gvjs_kx("9") : !1) ? gvjs_qA : gvjs_mA;
    if (this.CN = b || d) a = d = "", this.dimensions && (d = this.dimensions.width.toString() + gvjs_Z, a = this.dimensions.height.toString() + gvjs_Z), d = gvjs_jA(gvjs_kea, {
        isVml: b,
        frameId: this.Ri,
        width: d,
        height: a
    }), this.Ki.appendChild(this.container, d);
    gvjs_CA(this, c)
}
gvjs_r(gvjs_BA, gvjs_L);

function gvjs_CA(a, b) {
    var c = a.xha.bind(a);
    a = a.wja.bind(a);
    gvjs_AA(c, a, b)
}
gvjs_ = gvjs_BA.prototype;
gvjs_.wja = function() {
    if (this.CN) {
        var a = (a = this.Ki.j(this.Ri)) ? this.Ki.qea(a) : null;
        var b = this.hj = a.getElementById("renderers");
        b && (b[gvjs_Pp] = !0);
        this.DW = gvjs_zA(a.body, this.dimensions)
    } else this.hj = this.Ki.createElement(gvjs_5b), gvjs_I(this.hj, gvjs_Pd, gvjs_Td), this.dimensions && gvjs_0y(this.hj, this.dimensions), this.hj.dir = gvjs_td, this.container.appendChild(this.hj), this.DW = gvjs_zA(this.container, this.dimensions);
    this.XD = !0
};
gvjs_.xha = function() {
    if (!this.CN) return !0;
    var a = this.Ki.j(this.Ri);
    if (a) a: {
        try {
            var b = a.contentWindow || (a.contentDocument ? gvjs_uw(a.contentDocument) : null);
            break a
        } catch (c) {}
        b = null
    }
    else b = null;
    return (a = b) ? 1 == a._loaded : !1
};
gvjs_.ya = function(a) {
    var b = void 0 === b ? !0 : b;
    if (!this.XD) return null;
    for (a = null != a ? a : 0; this.Fz.length <= a;) {
        var c = b;
        c = void 0 === c ? !0 : c;
        var d = gvjs_ii(this.hj).createElement(gvjs_5b);
        c && (gvjs_I(d, gvjs_Pd, gvjs_xb), gvjs_Ry(d, 0, 0));
        gvjs_0y(d, gvjs_yq, gvjs_yq);
        this.hj.appendChild(d);
        c = new this.wka(d, this.DW);
        gvjs_Rw(this, c);
        this.Fz.push(c)
    }
    return this.Fz[a]
};
gvjs_.nu = function() {
    if (!this.XD) return null;
    if (!this.kk) {
        var a = this.Ki.createElement(gvjs_5b);
        this.kk = new gvjs_pz(a);
        this.Ki.appendChild(this.container, this.kk.getContainer())
    }
    return this.kk
};
gvjs_.Vl = function(a, b) {
    var c = this;
    gvjs_AA(function() {
        return null != c.hj
    }, a, b)
};
gvjs_.update = function(a, b) {
    if (null != a && !gvjs_4x(this.dimensions, a))
        if (this.dimensions = a, this.CN) {
            if (a = this.Ki.j(this.Ri)) a.width = this.dimensions.width.toString(), a.height = this.dimensions.height.toString()
        } else this.XD && gvjs_0y(this.hj, this.dimensions);
    this.XD || gvjs_CA(this, b)
};
gvjs_.J = function() {
    try {
        this.Ki.xb(this.vG), gvjs_K(this.kk), gvjs_v(this.Fz, function(a) {
            gvjs_K(a)
        })
    } catch (a) {}
    gvjs_L.prototype.J.call(this)
};

function gvjs_DA(a, b) {
    if (null == b) return a;
    b = new gvjs_Lk(b, b);
    return a ? new gvjs_Lk(Math.min(a.start, b.start), Math.max(a.end, b.end)) : b
}

function gvjs_EA(a, b, c) {
    var d = null != b ? b : a && null != c && c < a.start ? c : a ? a.start : null;
    a = null != c ? c : a && null != b && b > a.end ? b : a ? a.end : null;
    return null != d && null != a ? new gvjs_Lk(d, a) : null
}

function gvjs_FA(a) {
    if (0 === a.length) return null;
    for (var b = a[0].clone(), c = 1; c < a.length; c++) gvjs_Qw(b, a[c]);
    return b
}

function gvjs_GA(a, b) {
    var c = a.dj,
        d = b.dj;
    a = a.n;
    b = b.n;
    isFinite(c) || (c = Infinity);
    isFinite(d) || (d = Infinity);
    if (c === d || 1E-5 >= Math.abs(c - d)) return a === b || 1E-5 >= Math.abs(a - b) ? Infinity : null;
    if (Infinity === c) return new gvjs_A(a, d * a + b);
    if (Infinity === d) return new gvjs_A(b, c * b + a);
    var e = d - c;
    return new gvjs_A(-(b - a) / e, (a * d - c * b) / e)
}

function gvjs_HA(a, b) {
    b = (a.x - b.x) / (b.y - a.y);
    isFinite(b) ? a = a.y - b * a.x : (b = Infinity, a = a.x);
    return {
        dj: b,
        n: a
    }
}

function gvjs_IA(a, b) {
    var c = new gvjs_uz;
    a = a.Cb;
    if (0 === a.length || 1 === a.length) return c;
    for (var d = [null], e = 0; e < a.length; e++) {
        var f = a[e];
        f.data && (f = f.data, d.push(new gvjs_A(f.x, f.y)))
    }
    d.push(null);
    e = a[a.length - 1].type === gvjs_is;
    f = d[1].clone();
    var g = d[2].clone(),
        h = d[d.length - 3].clone(),
        k = d[d.length - 2].clone();
    e ? (d[0] = k, d[d.length - 1] = f) : gvjs_hi(f, k) ? (d[0] = h, d[d.length - 1] = g) : (d[0] = gvjs_iy(new gvjs_gy(f.x, f.y, g.x, g.y), -1), d[d.length - 1] = gvjs_iy(new gvjs_gy(k.x, k.y, h.x, h.y), -1));
    f = 0 > b;
    var l = null,
        m = null,
        n =
        null;
    g = d.length - 2;
    for (h = 0; h <= g; h++)
        if (!gvjs_hi(d[h], d[h + 1])) {
            k = d[h];
            var p = d[h + 1],
                q = (p.y - k.y) / (p.x - k.x);
            var r = isFinite(q) ? {
                dj: q,
                n: k.y - q * k.x
            } : {
                dj: Infinity,
                n: k.x
            };
            q = r.dj;
            r = r.n;
            if (Infinity === q) k = {
                dj: Infinity,
                n: 0 > p.y - k.y ? r + b : r - b
            };
            else {
                var t = b * Math.sqrt(1 + q * q);
                k = {
                    dj: q,
                    n: 0 < p.x - k.x ? r + t : r - t
                }
            }
            if (l) {
                q = gvjs_GA(l, k);
                gvjs_Pe(q) ? (p = gvjs_GA(gvjs_HA(m, d[h]), l), r = gvjs_GA(gvjs_HA(d[h], m), l), p = gvjs_Mk(new gvjs_Lk(p.x, r.x), q.x) && gvjs_Mk(new gvjs_Lk(p.y, r.y), q.y)) : p = Infinity === q;
                l = p && Infinity !== q ? q : gvjs_GA(gvjs_HA(d[h],
                    m), l);
                m = c;
                q = m.kh;
                var u = n;
                r = l;
                n = gvjs_Bx(u);
                switch (u.type) {
                    case gvjs_vu:
                    case gvjs_d:
                        t = n.data;
                        t.x = r.x;
                        t.y = r.y;
                        break;
                    case gvjs_qs:
                        t = n.data;
                        var v = u.data;
                        t.x = r.x;
                        t.y = r.y;
                        u = r.x - v.x;
                        r = r.y - v.y;
                        t.x1 += u;
                        t.y1 += r;
                        t.x2 += u;
                        t.y2 += r
                }
                q.call(m, n);
                p || (n = gvjs_GA(gvjs_HA(d[h], d[h + 1]), k), c.ke(d[h].x, d[h].y, Math.abs(b), Math.abs(b), 180 - gvjs_Px(Math.atan2(l.x - d[h].x, l.y - d[h].y)), 180 - gvjs_Px(Math.atan2(n.x - d[h].x, n.y - d[h].y)), f));
                l = k;
                m = d[h];
                n = a[h]
            } else l = k, m = d[h], k = a[h].data, n = gvjs_tz(k.x, k.y)
        }
    e && c.close();
    return c
}

function gvjs_JA() {}
gvjs_JA.prototype.o = function(a, b) {
    gvjs_KA(this, a);
    this.UC[a].push(b);
    return this
};
gvjs_JA.prototype.Ta = function(a, b) {
    gvjs_KA(this, a);
    a = this.UC[a];
    for (var c = null, d = 0, e = a.length; d < e; d++)
        if (a[d] === b) {
            c = d;
            break
        }
    return null != c ? (a.splice(c, 1), !0) : !1
};
gvjs_JA.prototype.fireEvent = function(a, b) {
    gvjs_KA(this, a);
    var c = this.UC[a];
    a = [];
    for (var d = c.length, e = 0; e < d; e++) a.push(c[e]);
    for (c = 0; c < d; c++) a[c].apply(this, b);
    return 0 < d
};

function gvjs_KA(a, b) {
    if (!a.UC.hasOwnProperty(b)) throw Error('event type "' + b + '" unknown.');
}

function gvjs_LA(a, b, c) {
    this.J0 = b;
    this.I0 = c;
    this.UC = {
        add: [],
        click: [],
        mousemove: [],
        mouseenter: [],
        mouseleave: [],
        redraw: [],
        remove: []
    }
}
gvjs_r(gvjs_LA, gvjs_JA);
gvjs_LA.prototype.width = function() {
    return this.J0
};
gvjs_LA.prototype.height = function() {
    return this.I0
};
var gvjs_MA = {
        NONE: gvjs_e,
        sO: gvjs_Ru,
        eZ: gvjs_c,
        tO: gvjs_j,
        Tna: gvjs_Wr,
        F$: gvjs_Bt
    },
    gvjs_NA = {
        NONE: gvjs_e,
        LINE: gvjs_d,
        AREA: gvjs_Ar,
        npa: gvjs_xv,
        fO: gvjs_Hr,
        Wna: gvjs_2r,
        tO: gvjs_j,
        Una: gvjs_Yr
    },
    gvjs_OA = {
        fO: gvjs_Hr,
        ppa: "sticks",
        Sna: "boxes",
        POINTS: gvjs_Vu,
        LINE: gvjs_d,
        AREA: gvjs_Ar,
        NONE: gvjs_e
    },
    gvjs_PA = {
        eoa: gvjs_kv,
        Coa: gvjs_lv,
        COLOR: gvjs_jv
    },
    gvjs_mea = {
        gO: gvjs_3r,
        E_: gvjs_o,
        Yna: gvjs_4r
    },
    gvjs_nea = {
        Yoa: gvjs__u,
        Hoa: gvjs_gu,
        C$: gvjs_Ns
    },
    gvjs_oea = {
        NONE: gvjs_e,
        hH: gvjs_i,
        L$: gvjs_sd,
        x_: gvjs_1v,
        zX: gvjs_Tr,
        INSIDE: gvjs_Kt,
        zoa: gvjs_Yt,
        Pna: gvjs_Vr
    },
    gvjs_pea = {
        NONE: gvjs_e,
        x_: gvjs_1v,
        zX: gvjs_Tr,
        INSIDE: gvjs_Kt
    },
    gvjs_QA = {
        oH: gvjs_S,
        cH: gvjs_R
    },
    gvjs_qea = {
        yaa: gvjs_l,
        CENTER: gvjs_X,
        A$: gvjs_Y
    },
    gvjs_RA = {
        NONE: gvjs_e,
        INSIDE: gvjs_Kt,
        OUTSIDE: gvjs_Nu
    },
    gvjs_rea = {
        Qna: "bound",
        ypa: "unbound"
    },
    gvjs_sea = {
        roa: "high",
        Eoa: "low"
    },
    gvjs_SA = {
        Ooa: gvjs_Fd,
        ipa: gvjs_rv
    },
    gvjs_TA = {
        NONE: gvjs_e,
        E$: gvjs_1s,
        vaa: gvjs_fv,
        VG: gvjs_Sr
    },
    gvjs_tea = {
        NONE: gvjs_e,
        E$: gvjs_1s,
        vaa: gvjs_fv,
        VG: gvjs_Sr
    },
    gvjs_UA = {
        cH: gvjs_R,
        oH: gvjs_S,
        VG: gvjs_Sr
    },
    gvjs_uea = {
        DEFAULT: gvjs_xs,
        joa: gvjs_Fs
    },
    gvjs_vea = {
        ioa: gvjs_vp,
        gO: gvjs_3r,
        iH: gvjs_iv
    },
    gvjs_wea = {
        TA: gvjs_Gb,
        gO: gvjs_3r,
        iH: gvjs_iv,
        NONE: gvjs_e
    },
    gvjs_VA = {
        NONE: gvjs_e,
        eZ: gvjs_c,
        Uoa: "phase",
        aoa: gvjs_js
    },
    gvjs_xea = {
        Ina: "attachToStart",
        Hna: "attachToEnd"
    },
    gvjs_WA = {
        Boa: "letter",
        POINT: gvjs_xp,
        LINE: gvjs_d
    };

function gvjs_XA(a, b, c, d, e) {
    this.Je = !!b;
    this.node = null;
    this.Yg = 0;
    this.sW = !1;
    this.hI = !c;
    a && this.setPosition(a, d);
    this.depth = void 0 != e ? e : this.Yg || 0;
    this.Je && (this.depth *= -1)
}
gvjs_u(gvjs_XA, gvjs_tm);
gvjs_ = gvjs_XA.prototype;
gvjs_.setPosition = function(a, b, c) {
    if (this.node = a) this.Yg = typeof b === gvjs_f ? b : 1 != this.node.nodeType ? 0 : this.Je ? -1 : 1;
    typeof c === gvjs_f && (this.depth = c)
};
gvjs_.hQ = function(a) {
    this.node = a.node;
    this.Yg = a.Yg;
    this.depth = a.depth;
    this.Je = a.Je;
    this.hI = a.hI
};
gvjs_.clone = function() {
    return new gvjs_XA(this.node, this.Je, !this.hI, this.Yg, this.depth)
};
gvjs_.next = function() {
    if (this.sW) {
        if (!this.node || this.hI && 0 == this.depth) return gvjs_um;
        var a = this.node;
        var b = this.Je ? -1 : 1;
        if (this.Yg == b) {
            var c = this.Je ? a.lastChild : a.firstChild;
            c ? this.setPosition(c) : this.setPosition(a, -1 * b)
        } else(c = this.Je ? a.previousSibling : a.nextSibling) ? this.setPosition(c) : this.setPosition(a.parentNode, -1 * b);
        this.depth += this.Yg * (this.Je ? -1 : 1)
    } else this.sW = !0;
    return (a = this.node) ? gvjs_Jp(a) : gvjs_um
};
gvjs_.equals = function(a) {
    return a.node == this.node && (!this.node || a.Yg == this.Yg)
};
gvjs_.splice = function(a) {
    var b = this.node,
        c = this.Je ? 1 : -1;
    this.Yg == c && (this.Yg = -1 * c, this.depth += this.Yg * (this.Je ? -1 : 1));
    this.Je = !this.Je;
    gvjs_XA.prototype.next.call(this);
    this.Je = !this.Je;
    c = gvjs_Ne(arguments[0]) ? arguments[0] : arguments;
    for (var d = c.length - 1; 0 <= d; d--) gvjs_zi(c[d], b);
    gvjs_Ai(b)
};

function gvjs_YA() {}
gvjs_YA.prototype.l5 = function() {
    return !1
};
gvjs_YA.prototype.Hb = function() {
    return gvjs_ki(gvjs_x ? this.getContainer() : this.dl())
};
gvjs_YA.prototype.Yi = function() {
    return gvjs_uw(this.Hb())
};

function gvjs_ZA(a, b) {
    gvjs_XA.call(this, a, b, !0)
}
gvjs_u(gvjs_ZA, gvjs_XA);

function gvjs__A(a, b, c, d, e) {
    this.Be = this.lf = null;
    this.Nf = this.bg = 0;
    this.Og = !!e;
    if (a) {
        this.lf = a;
        this.bg = b;
        this.Be = c;
        this.Nf = d;
        if (1 == a.nodeType && "BR" != a.tagName)
            if (a = a.childNodes, b = a[b]) this.lf = b, this.bg = 0;
            else {
                a.length && (this.lf = gvjs_nf(a));
                var f = !0
            }
        1 == c.nodeType && ((this.Be = c.childNodes[d]) ? this.Nf = 0 : this.Be = c)
    }
    gvjs_XA.call(this, this.Og ? this.Be : this.lf, this.Og, !0);
    f && this.next()
}
gvjs_u(gvjs__A, gvjs_ZA);
gvjs_ = gvjs__A.prototype;
gvjs_.Kga = !1;
gvjs_.dl = function() {
    return this.lf
};
gvjs_.ep = function() {
    return this.Be
};
gvjs_.next = function() {
    return this.sW && (this.node != (this.Og ? this.lf : this.Be) ? 0 : this.Og ? this.bg ? -1 != this.Yg : 1 == this.Yg : !this.Nf || 1 != this.Yg) || this.Kga ? gvjs_um : gvjs__A.G.next.call(this)
};
gvjs_.hQ = function(a) {
    this.lf = a.lf;
    this.Be = a.Be;
    this.bg = a.bg;
    this.Nf = a.Nf;
    this.Og = a.Og;
    gvjs__A.G.hQ.call(this, a)
};
gvjs_.clone = function() {
    var a = new gvjs__A(this.lf, this.bg, this.Be, this.Nf, this.Og);
    a.hQ(this);
    return a
};

function gvjs_0A() {}
gvjs_0A.prototype.jI = function(a, b) {
    b = b && !a.isCollapsed();
    a = a.gb;
    try {
        return b ? 0 <= this.Cx(a, 0, 1) && 0 >= this.Cx(a, 1, 0) : 0 <= this.Cx(a, 0, 0) && 0 >= this.Cx(a, 1, 1)
    } catch (c) {
        if (!gvjs_x) throw c;
        return !1
    }
};
gvjs_0A.prototype.containsNode = function(a, b) {
    return this.jI(gvjs_1A(a), b)
};
gvjs_0A.prototype.Di = function() {
    return new gvjs__A(this.dl(), this.vr(), this.ep(), this.rr())
};

function gvjs_2A(a) {
    this.gb = a
}
gvjs_u(gvjs_2A, gvjs_0A);

function gvjs_3A(a) {
    var b = gvjs_ki(a).createRange();
    if (3 == a.nodeType) b.setStart(a, 0), b.setEnd(a, a.length);
    else if (gvjs_vi(a) || 3 == a.nodeType) {
        for (var c, d = a;
            (c = d.firstChild) && (gvjs_vi(c) || 3 == c.nodeType);) d = c;
        b.setStart(d, 0);
        for (d = a;
            (c = d.lastChild) && (gvjs_vi(c) || 3 == c.nodeType);) d = c;
        b.setEnd(d, 1 == d.nodeType ? d.childNodes.length : d.length)
    } else c = a.parentNode, a = Array.prototype.indexOf.call(c.childNodes, a), b.setStart(c, a), b.setEnd(c, a + 1);
    return b
}

function gvjs_4A(a, b, c, d) {
    var e = gvjs_ki(a).createRange();
    e.setStart(a, b);
    e.setEnd(c, d);
    return e
}
gvjs_ = gvjs_2A.prototype;
gvjs_.clone = function() {
    return new this.constructor(this.gb.cloneRange())
};
gvjs_.getContainer = function() {
    return this.gb.commonAncestorContainer
};
gvjs_.dl = function() {
    return this.gb.startContainer
};
gvjs_.vr = function() {
    return this.gb.startOffset
};
gvjs_.ep = function() {
    return this.gb.endContainer
};
gvjs_.rr = function() {
    return this.gb.endOffset
};
gvjs_.Cx = function(a, b, c) {
    return this.gb.compareBoundaryPoints(1 == c ? 1 == b ? gvjs_s.Range.START_TO_START : gvjs_s.Range.START_TO_END : 1 == b ? gvjs_s.Range.END_TO_START : gvjs_s.Range.END_TO_END, a)
};
gvjs_.isCollapsed = function() {
    return this.gb.collapsed
};
gvjs_.select = function(a) {
    var b = gvjs_uw(gvjs_ki(this.dl()));
    this.pM(b.getSelection(), a)
};
gvjs_.pM = function(a) {
    a.removeAllRanges();
    a.addRange(this.gb)
};
gvjs_.surroundContents = function(a) {
    this.gb.surroundContents(a);
    return a
};
gvjs_.insertNode = function(a, b) {
    var c = this.gb.cloneRange();
    c.collapse(b);
    c.insertNode(a);
    c.detach();
    return a
};
gvjs_.collapse = function(a) {
    this.gb.collapse(a)
};

function gvjs_5A(a) {
    this.gb = a
}
gvjs_u(gvjs_5A, gvjs_2A);
gvjs_5A.prototype.pM = function(a, b) {
    !b || this.isCollapsed() ? gvjs_5A.G.pM.call(this, a, b) : (a.collapse(this.ep(), this.rr()), a.extend(this.dl(), this.vr()))
};

function gvjs_6A(a) {
    this.gb = a
}
gvjs_u(gvjs_6A, gvjs_2A);
gvjs_6A.prototype.Cx = function(a, b, c) {
    return gvjs_6A.G.Cx.call(this, a, b, c)
};
gvjs_6A.prototype.pM = function(a, b) {
    b ? a.setBaseAndExtent(this.ep(), this.rr(), this.dl(), this.vr()) : a.setBaseAndExtent(this.dl(), this.vr(), this.ep(), this.rr())
};

function gvjs_1A(a) {
    return gvjs_If ? new gvjs_6A(gvjs_3A(a)) : gvjs_Hf ? new gvjs_5A(gvjs_3A(a)) : new gvjs_2A(gvjs_3A(a))
};

function gvjs_7A() {
    this.Nf = this.Be = this.bg = this.lf = this.Kq = null;
    this.Og = !1
}
gvjs_u(gvjs_7A, gvjs_YA);
gvjs_ = gvjs_7A.prototype;
gvjs_.clone = function() {
    var a = new gvjs_7A;
    a.Kq = this.Kq && this.Kq.clone();
    a.lf = this.lf;
    a.bg = this.bg;
    a.Be = this.Be;
    a.Nf = this.Nf;
    a.Og = this.Og;
    return a
};
gvjs_.getType = function() {
    return gvjs_n
};

function gvjs_8A(a) {
    var b;
    if (!(b = a.Kq)) {
        b = a.dl();
        var c = a.vr(),
            d = a.ep(),
            e = a.rr();
        b = gvjs_If ? new gvjs_6A(gvjs_4A(b, c, d, e)) : gvjs_Hf ? new gvjs_5A(gvjs_4A(b, c, d, e)) : new gvjs_2A(gvjs_4A(b, c, d, e));
        b = a.Kq = b
    }
    return b
}
gvjs_.getContainer = function() {
    return gvjs_8A(this).getContainer()
};
gvjs_.dl = function() {
    return this.lf || (this.lf = gvjs_8A(this).dl())
};
gvjs_.vr = function() {
    return null != this.bg ? this.bg : this.bg = gvjs_8A(this).vr()
};
gvjs_.ep = function() {
    return this.Be || (this.Be = gvjs_8A(this).ep())
};
gvjs_.rr = function() {
    return null != this.Nf ? this.Nf : this.Nf = gvjs_8A(this).rr()
};
gvjs_.l5 = function() {
    return this.Og
};
gvjs_.jI = function(a, b) {
    var c = a.getType();
    return c == gvjs_n ? gvjs_8A(this).jI(gvjs_8A(a), b) : "control" == c ? (a = a.fD(), (b ? gvjs_rf : gvjs_sf)(a, function(d) {
        return this.containsNode(d, b)
    }, this)) : !1
};
gvjs_.containsNode = function(a, b) {
    var c = this.jI;
    a = gvjs_1A(a);
    var d = new gvjs_7A;
    d.Kq = a;
    d.Og = !1;
    return c.call(this, d, b)
};
gvjs_.isCollapsed = function() {
    return gvjs_8A(this).isCollapsed()
};
gvjs_.Di = function() {
    return new gvjs__A(this.dl(), this.vr(), this.ep(), this.rr())
};
gvjs_.select = function() {
    gvjs_8A(this).select(this.Og)
};
gvjs_.surroundContents = function(a) {
    a = gvjs_8A(this).surroundContents(a);
    this.lf = this.bg = this.Be = this.Nf = null;
    return a
};
gvjs_.insertNode = function(a, b) {
    a = gvjs_8A(this).insertNode(a, b);
    this.lf = this.bg = this.Be = this.Nf = null;
    return a
};
gvjs_.collapse = function(a) {
    a = this.l5() ? !a : a;
    this.Kq && this.Kq.collapse(a);
    a ? (this.Be = this.lf, this.Nf = this.bg) : (this.lf = this.Be, this.bg = this.Nf);
    this.Og = !1
};

function gvjs_yea(a, b, c, d) {
    if (a == c) return d < b;
    var e;
    if (1 == a.nodeType && b)
        if (e = a.childNodes[b]) a = e, b = 0;
        else if (gvjs_Hi(a, c)) return !0;
    if (1 == c.nodeType && d)
        if (e = c.childNodes[d]) c = e, d = 0;
        else if (gvjs_Hi(c, a)) return !1;
    return 0 < (gvjs_Rda(a, c) || b - d)
};

function gvjs_9A() {}
gvjs_Le(gvjs_9A);
gvjs_9A.prototype.Uia = 0;
gvjs_9A.prototype.Xga = "";

function gvjs_$A(a) {
    return a.Xga + ":" + (a.Uia++).toString(36)
};

function gvjs_aB(a) {
    gvjs_7k.call(this);
    this.C = a || gvjs_ii();
    this.nn = gvjs_zea;
    this.vd = null;
    this.fb = !1;
    this.O = null;
    this.xr = void 0;
    this.Nk = this.ye = this.Fc = this.vl = null;
    this.uv = this.Z9 = !1
}
gvjs_u(gvjs_aB, gvjs_7k);
gvjs_aB.prototype.Wga = gvjs_9A.eb();
var gvjs_zea = null;

function gvjs_bB(a, b) {
    switch (a) {
        case 1:
            return b ? gvjs_Ds : gvjs_Ls;
        case 2:
            return b ? gvjs_At : gvjs_6v;
        case 4:
            return b ? "activate" : "deactivate";
        case 8:
            return b ? gvjs_k : "unselect";
        case 16:
            return b ? "check" : "uncheck";
        case 32:
            return b ? gvjs_1s : gvjs_Pr;
        case 64:
            return b ? "open" : gvjs_is
    }
    throw Error("Invalid component state");
}
gvjs_ = gvjs_aB.prototype;
gvjs_.getId = function() {
    return this.vd || (this.vd = gvjs_$A(this.Wga))
};
gvjs_.EF = function(a) {
    this.Fc && this.Fc.Nk && (gvjs_xx(this.Fc.Nk, this.vd), gvjs_yx(this.Fc.Nk, a, this));
    this.vd = a
};
gvjs_.j = function() {
    return this.O
};
gvjs_.Im = function(a) {
    return this.O ? this.C.Im(a, this.O) : []
};
gvjs_.Vb = gvjs_p(3);
gvjs_.BJ = gvjs_p(5);
gvjs_.ob = function() {
    this.xr || (this.xr = new gvjs_mz(this));
    return this.xr
};
gvjs_.Kv = function(a) {
    if (this == a) throw Error(gvjs__q);
    if (a && this.Fc && this.vd && this.Fc.Uj(this.vd) && this.Fc != a) throw Error(gvjs__q);
    this.Fc = a;
    gvjs_aB.G.Lv.call(this, a)
};
gvjs_.getParent = function() {
    return this.Fc
};
gvjs_.Lv = function(a) {
    if (this.Fc && this.Fc != a) throw Error("Method not supported");
    gvjs_aB.G.Lv.call(this, a)
};
gvjs_.fa = function() {
    return this.C
};
gvjs_.F = function() {
    this.O = this.C.createElement(gvjs_b)
};
gvjs_.K = function(a) {
    gvjs_cB(this, a)
};

function gvjs_cB(a, b, c) {
    if (a.fb) throw Error(gvjs_Lq);
    a.O || a.F();
    b ? b.insertBefore(a.O, c || null) : a.C.Hb().body.appendChild(a.O);
    a.Fc && !a.Fc.fb || a.sb()
}
gvjs_.ra = gvjs_p(62);
gvjs_.Uc = gvjs_p(71);
gvjs_.pc = gvjs_p(78);
gvjs_.sb = function() {
    this.fb = !0;
    gvjs_dB(this, function(a) {
        !a.fb && a.j() && a.sb()
    })
};
gvjs_.Hd = function() {
    gvjs_dB(this, function(a) {
        a.fb && a.Hd()
    });
    this.xr && this.xr.removeAll();
    this.fb = !1
};
gvjs_.J = function() {
    this.fb && this.Hd();
    this.xr && (this.xr.xa(), delete this.xr);
    gvjs_dB(this, function(a) {
        a.xa()
    });
    !this.Z9 && this.O && gvjs_Ai(this.O);
    this.Fc = this.vl = this.O = this.Nk = this.ye = null;
    gvjs_aB.G.J.call(this)
};
gvjs_.addChild = function(a, b) {
    this.it(a, this.Cc(), b)
};
gvjs_.it = function(a, b, c) {
    if (a.fb && (c || !this.fb)) throw Error(gvjs_Lq);
    if (0 > b || b > this.Cc()) throw Error("Child component index out of bounds");
    this.Nk && this.ye || (this.Nk = {}, this.ye = []);
    if (a.getParent() == this) {
        var d = a.getId();
        this.Nk[d] = a;
        gvjs_uf(this.ye, a)
    } else gvjs_yx(this.Nk, a.getId(), a);
    a.Kv(this);
    gvjs_bx(this.ye, a, b);
    a.fb && this.fb && a.getParent() == this ? (c = this.Ga(), (c.childNodes[b] || null) != a.j() && (a.j().parentElement == c && c.removeChild(a.j()), b = c.childNodes[b] || null, c.insertBefore(a.j(), b))) : c ? (this.O ||
        this.F(), b = this.td(b + 1), gvjs_cB(a, this.Ga(), b ? b.O : null)) : this.fb && !a.fb && a.O && a.O.parentNode && 1 == a.O.parentNode.nodeType && a.sb()
};
gvjs_.Ga = function() {
    return this.O
};
gvjs_.tf = function() {
    null == this.nn && (this.nn = gvjs_5y(this.fb ? this.O : this.C.Hb().body));
    return this.nn
};
gvjs_.Mv = function(a) {
    if (this.fb) throw Error(gvjs_Lq);
    this.nn = a
};
gvjs_.Cc = function() {
    return this.ye ? this.ye.length : 0
};
gvjs_.Uj = function(a) {
    return this.Nk && a ? gvjs_zx(this.Nk, a) || null : null
};
gvjs_.td = function(a) {
    return this.ye ? this.ye[a] || null : null
};

function gvjs_dB(a, b, c) {
    a.ye && a.ye.forEach(b, c)
}

function gvjs_eB(a, b) {
    return a.ye && b ? a.ye.indexOf(b) : -1
}
gvjs_.removeChild = function(a, b) {
    if (a) {
        var c = typeof a === gvjs_m ? a : a.getId();
        a = this.Uj(c);
        c && a && (gvjs_xx(this.Nk, c), gvjs_uf(this.ye, a), b && (a.Hd(), a.O && gvjs_Ai(a.O)), a.Kv(null))
    }
    if (!a) throw Error("Child is not in parent component");
    return a
};
gvjs_.xb = function(a) {
    for (var b = []; this.ye && 0 != this.ye.length;) {
        var c = b,
            d = c.push;
        var e = a;
        e = this.removeChild(this.td(0), e);
        d.call(c, e)
    }
    return b
};

function gvjs_fB(a) {
    return typeof a.className == gvjs_m ? a.className : a.getAttribute && a.getAttribute(gvjs_Qb) || ""
}

function gvjs_gB(a) {
    return a.classList ? a.classList : gvjs_fB(a).match(/\S+/g) || []
}

function gvjs_hB(a, b) {
    typeof a.className == gvjs_m ? a.className = b : a.setAttribute && a.setAttribute(gvjs_Qb, b)
}

function gvjs_iB(a, b) {
    return a.classList ? a.classList.contains(b) : gvjs_tf(gvjs_gB(a), b)
}

function gvjs_jB(a, b) {
    if (a.classList) a.classList.add(b);
    else if (!gvjs_iB(a, b)) {
        var c = gvjs_fB(a);
        gvjs_hB(a, c + (0 < c.length ? " " + b : b))
    }
}

function gvjs_kB(a, b) {
    if (a.classList) Array.prototype.forEach.call(b, function(e) {
        gvjs_jB(a, e)
    });
    else {
        var c = {};
        Array.prototype.forEach.call(gvjs_gB(a), function(e) {
            c[e] = !0
        });
        Array.prototype.forEach.call(b, function(e) {
            c[e] = !0
        });
        b = "";
        for (var d in c) b += 0 < b.length ? " " + d : d;
        gvjs_hB(a, b)
    }
}

function gvjs_lB(a, b) {
    a.classList ? a.classList.remove(b) : gvjs_iB(a, b) && gvjs_hB(a, Array.prototype.filter.call(gvjs_gB(a), function(c) {
        return c != b
    }).join(" "))
}

function gvjs_mB(a, b) {
    a.classList ? Array.prototype.forEach.call(b, function(c) {
        gvjs_lB(a, c)
    }) : gvjs_hB(a, Array.prototype.filter.call(gvjs_gB(a), function(c) {
        return !gvjs_tf(b, c)
    }).join(" "))
}

function gvjs_nB(a, b, c) {
    c ? gvjs_jB(a, b) : gvjs_lB(a, b)
};

function gvjs_oB(a, b, c) {
    gvjs_7k.call(this);
    this.target = a;
    this.handle = b || a;
    this.qT = c || new gvjs_0(NaN, NaN, NaN, NaN);
    this.ac = gvjs_ki(a);
    this.aa = new gvjs_mz(this);
    gvjs_Rw(this, this.aa);
    this.deltaY = this.deltaX = this.Ll = this.hq = this.screenY = this.screenX = this.clientY = this.clientX = 0;
    this.nf = !0;
    this.Vt = !1;
    this.x7 = !0;
    this.E4 = 0;
    this.lw = this.Yga = !1;
    gvjs_M(this.handle, ["touchstart", gvjs_pu], this.X8, !1, this);
    this.DN = gvjs_Aea
}
gvjs_u(gvjs_oB, gvjs_7k);
var gvjs_Aea = gvjs_s.document && gvjs_s.document.documentElement && !!gvjs_s.document.documentElement.setCapture && !!gvjs_s.document.releaseCapture;
gvjs_ = gvjs_oB.prototype;
gvjs_.Bm = gvjs_p(80);
gvjs_.ob = function() {
    return this.aa
};

function gvjs_pB(a, b) {
    a.qT = b || new gvjs_0(NaN, NaN, NaN, NaN)
}
gvjs_.Sa = function(a) {
    this.nf = a
};
gvjs_.J = function() {
    gvjs_oB.G.J.call(this);
    gvjs_3k(this.handle, ["touchstart", gvjs_pu], this.X8, !1, this);
    this.aa.removeAll();
    this.DN && this.ac.releaseCapture();
    this.handle = this.target = null
};
gvjs_.YD = function() {
    void 0 === this.nn && (this.nn = gvjs_5y(this.target));
    return this.nn
};
gvjs_.X8 = function(a) {
    var b = a.type == gvjs_pu;
    if (!this.nf || this.Vt || b && !gvjs_Sw(a)) this.dispatchEvent("earlycancel");
    else {
        if (0 == this.E4)
            if (this.dispatchEvent(new gvjs_qB(gvjs_l, this, a.clientX, a.clientY, a))) this.Vt = !0, this.x7 && b && a.preventDefault();
            else return;
        else this.x7 && b && a.preventDefault();
        b = this.ac;
        var c = b.documentElement,
            d = !this.DN;
        this.aa.o(b, ["touchmove", gvjs_su], this.QJ, {
            capture: d,
            passive: !1
        });
        this.aa.o(b, ["touchend", gvjs_tu], this.VI, d);
        this.DN ? (c.setCapture(!1), this.aa.o(c, "losecapture", this.VI)) :
            this.aa.o(gvjs_uw(b), gvjs_Pr, this.VI);
        gvjs_x && this.Yga && this.aa.o(b, gvjs_Js, gvjs_$y);
        this.Zka && this.aa.o(this.Zka, gvjs_dv, this.Eja, d);
        this.clientX = this.hq = a.clientX;
        this.clientY = this.Ll = a.clientY;
        this.screenX = a.screenX;
        this.screenY = a.screenY;
        this.deltaX = this.lw ? gvjs_Ez(this.target) : this.target.offsetLeft;
        this.deltaY = this.target.offsetTop;
        this.IU = gvjs_tw(gvjs_ii(this.ac).ac)
    }
};
gvjs_.VI = function(a, b) {
    this.aa.removeAll();
    this.DN && this.ac.releaseCapture();
    this.Vt ? (this.Vt = !1, this.dispatchEvent(new gvjs_qB(gvjs_Y, this, a.clientX, a.clientY, a, gvjs_rB(this, this.deltaX), gvjs_sB(this, this.deltaY), b || "touchcancel" == a.type))) : this.dispatchEvent("earlycancel")
};
gvjs_.QJ = function(a) {
    if (this.nf) {
        var b = (this.lw && this.YD() ? -1 : 1) * (a.clientX - this.clientX),
            c = a.clientY - this.clientY;
        this.clientX = a.clientX;
        this.clientY = a.clientY;
        this.screenX = a.screenX;
        this.screenY = a.screenY;
        if (!this.Vt) {
            var d = this.hq - this.clientX,
                e = this.Ll - this.clientY;
            if (d * d + e * e > this.E4)
                if (this.dispatchEvent(new gvjs_qB(gvjs_l, this, a.clientX, a.clientY, a))) this.Vt = !0;
                else {
                    this.Ue || this.VI(a);
                    return
                }
        }
        c = gvjs_tB(this, b, c);
        b = c.x;
        c = c.y;
        this.Vt && this.dispatchEvent(new gvjs_qB(gvjs_Kr, this, a.clientX, a.clientY,
            a, b, c)) && (gvjs_uB(this, a, b, c), a.preventDefault())
    }
};

function gvjs_tB(a, b, c) {
    var d = gvjs_tw(gvjs_ii(a.ac).ac);
    b += d.x - a.IU.x;
    c += d.y - a.IU.y;
    a.IU = d;
    a.deltaX += b;
    a.deltaY += c;
    return new gvjs_A(gvjs_rB(a, a.deltaX), gvjs_sB(a, a.deltaY))
}
gvjs_.Eja = function(a) {
    var b = gvjs_tB(this, 0, 0);
    a.clientX = this.clientX;
    a.clientY = this.clientY;
    gvjs_uB(this, a, b.x, b.y)
};

function gvjs_uB(a, b, c, d) {
    a.Qt(c, d);
    a.dispatchEvent(new gvjs_qB(gvjs_Hs, a, b.clientX, b.clientY, b, c, d))
}

function gvjs_rB(a, b) {
    var c = a.qT;
    a = isNaN(c.left) ? null : c.left;
    c = isNaN(c.width) ? 0 : c.width;
    return Math.min(null != a ? a + c : Infinity, Math.max(null != a ? a : -Infinity, b))
}

function gvjs_sB(a, b) {
    var c = a.qT;
    a = isNaN(c.top) ? null : c.top;
    c = isNaN(c.height) ? 0 : c.height;
    return Math.min(null != a ? a + c : Infinity, Math.max(null != a ? a : -Infinity, b))
}
gvjs_.Qt = function(a, b) {
    this.lw && this.YD() ? this.target.style.right = a + gvjs_Z : this.target.style.left = a + gvjs_Z;
    this.target.style.top = b + gvjs_Z
};

function gvjs_qB(a, b, c, d, e, f, g) {
    gvjs_Nk.call(this, a);
    this.clientX = c;
    this.clientY = d;
    this.zba = e;
    this.left = void 0 !== f ? f : b.deltaX;
    this.top = void 0 !== g ? g : b.deltaY;
    this.SQ = b
}
gvjs_u(gvjs_qB, gvjs_Nk);

function gvjs_vB(a) {
    this.ma = new Map;
    var b = arguments.length;
    if (1 < b) {
        if (b % 2) throw Error(gvjs_mp);
        for (var c = 0; c < b; c += 2) this.set(arguments[c], arguments[c + 1])
    } else a && this.addAll(a)
}
gvjs_ = gvjs_vB.prototype;
gvjs_.De = function() {
    return this.ma.size
};
gvjs_.Wb = function() {
    return Array.from(this.ma.values())
};
gvjs_.Km = function() {
    return Array.from(this.ma.keys())
};
gvjs_.sm = function(a) {
    return this.ma.has(a)
};
gvjs_.Dx = function(a) {
    return this.Wb().some(function(b) {
        return b == a
    })
};
gvjs_.equals = function(a, b) {
    var c = this;
    b = void 0 === b ? function(d, e) {
        return d === e
    } : b;
    return this === a ? !0 : this.ma.size != a.De() ? !1 : this.Km().every(function(d) {
        return b(c.ma.get(d), a.get(d))
    })
};
gvjs_.isEmpty = function() {
    return 0 == this.ma.size
};
gvjs_.clear = function() {
    this.ma.clear()
};
gvjs_.remove = function(a) {
    return this.ma.delete(a)
};
gvjs_.get = function(a, b) {
    return this.ma.has(a) ? this.ma.get(a) : b
};
gvjs_.set = function(a, b) {
    this.ma.set(a, b);
    return this
};
gvjs_.addAll = function(a) {
    if (a instanceof gvjs_vB) {
        a = gvjs_q(a.ma);
        for (var b = a.next(); !b.done; b = a.next()) {
            var c = gvjs_q(b.value);
            b = c.next().value;
            c = c.next().value;
            this.ma.set(b, c)
        }
    } else if (a)
        for (a = gvjs_q(Object.entries(a)), b = a.next(); !b.done; b = a.next()) c = gvjs_q(b.value), b = c.next().value, c = c.next().value, this.ma.set(b, c)
};
gvjs_.forEach = function(a, b) {
    var c = this;
    b = void 0 === b ? this : b;
    this.ma.forEach(function(d, e) {
        return a.call(b, d, e, c)
    })
};
gvjs_.clone = function() {
    return new gvjs_vB(this)
};
(function() {
    for (var a = ["ms", "moz", "webkit", "o"], b, c = 0; b = a[c] && !gvjs_s.requestAnimationFrame; ++c) gvjs_s.requestAnimationFrame = gvjs_s[b + "RequestAnimationFrame"], gvjs_s.cancelAnimationFrame = gvjs_s[b + "CancelAnimationFrame"] || gvjs_s[b + "CancelRequestAnimationFrame"];
    if (!gvjs_s.requestAnimationFrame) {
        var d = 0;
        gvjs_s.requestAnimationFrame = function(e) {
            var f = (new Date).getTime(),
                g = Math.max(0, 16 - (f - d));
            d = f + g;
            return gvjs_s.setTimeout(function() {
                e(f + g)
            }, g)
        };
        gvjs_s.cancelAnimationFrame || (gvjs_s.cancelAnimationFrame =
            function(e) {
                clearTimeout(e)
            })
    }
})();
var gvjs_wB = [
        [],
        []
    ],
    gvjs_xB = 0,
    gvjs_yB = !1,
    gvjs_Bea = 0;

function gvjs_Cea(a, b) {
    var c = gvjs_Bea++,
        d = {
            via: {
                id: c,
                Yo: a.measure,
                context: b
            },
            Ria: {
                id: c,
                Yo: a.Qia,
                context: b
            },
            state: {},
            Gf: void 0,
            tK: !1
        };
    return function() {
        0 < arguments.length ? (d.Gf || (d.Gf = []), d.Gf.length = 0, d.Gf.push.apply(d.Gf, arguments), d.Gf.push(d.state)) : d.Gf && 0 != d.Gf.length ? (d.Gf[0] = d.state, d.Gf.length = 1) : d.Gf = [d.state];
        d.tK || (d.tK = !0, gvjs_wB[gvjs_xB].push(d));
        gvjs_yB || (gvjs_yB = !0, window.requestAnimationFrame(gvjs_Dea))
    }
}

function gvjs_Dea() {
    gvjs_yB = !1;
    var a = gvjs_wB[gvjs_xB],
        b = a.length;
    gvjs_xB = (gvjs_xB + 1) % 2;
    for (var c, d = 0; d < b; ++d) {
        c = a[d];
        var e = c.via;
        c.tK = !1;
        e.Yo && e.Yo.apply(e.context, c.Gf)
    }
    for (d = 0; d < b; ++d) c = a[d], e = c.Ria, c.tK = !1, e.Yo && e.Yo.apply(e.context, c.Gf), c.state = {};
    a.length = 0
};
var gvjs_zB = gvjs_x ? gvjs_ah(gvjs_1g(gvjs_2g('javascript:""'))) : gvjs_ah(gvjs_1g(gvjs_2g("about:blank")));
gvjs_9g(gvjs_zB);
var gvjs_Eea = gvjs_x ? gvjs_ah(gvjs_1g(gvjs_2g('javascript:""'))) : gvjs_ah(gvjs_1g(gvjs_2g("javascript:undefined")));
gvjs_9g(gvjs_Eea);

function gvjs_Fea(a, b) {
    this.O = a;
    this.C = b
};

function gvjs_AB(a, b) {
    gvjs_aB.call(this, b);
    this.fna = !!a;
    this.Oy = null;
    this.Q7 = gvjs_Cea({
        Qia: this.XL
    }, this)
}
gvjs_u(gvjs_AB, gvjs_aB);
gvjs_ = gvjs_AB.prototype;
gvjs_.tR = null;
gvjs_.Qa = !1;
gvjs_.Ei = null;
gvjs_.yg = null;
gvjs_.Ml = null;
gvjs_.iP = !1;
gvjs_.ea = function() {
    return "aAAaGVIZSENTINELaAAa-modalpopup"
};
gvjs_.gy = function() {
    return this.Ei
};
gvjs_.F = function() {
    gvjs_AB.G.F.call(this);
    var a = this.j(),
        b = gvjs_2e(this.ea()).split(" ");
    gvjs_kB(a, b);
    gvjs_8x(a, !0);
    gvjs_4y(a, !1);
    gvjs_BB(this);
    gvjs_CB(this)
};

function gvjs_BB(a) {
    if (a.fna && !a.yg) {
        var b = a.fa().F(gvjs_Na, {
            frameborder: 0,
            style: "border:0;vertical-align:bottom;"
        });
        b.src = gvjs_9g(gvjs_zB);
        a.yg = b;
        a.yg.className = a.ea() + "-bg";
        gvjs_4y(a.yg, !1);
        gvjs_3y(a.yg, 0)
    }
    a.Ei || (a.Ei = a.fa().F(gvjs_b, a.ea() + "-bg"), gvjs_4y(a.Ei, !1))
}

function gvjs_CB(a) {
    a.Ml || (a.Ml = a.fa().createElement(gvjs_ab), gvjs_4y(a.Ml, !1), gvjs_8x(a.Ml, !0), a.Ml.style.position = gvjs_xb)
}
gvjs_.P7 = function() {
    this.iP = !1
};
gvjs_.Uc = gvjs_p(70);
gvjs_.pc = gvjs_p(77);
gvjs_.sb = function() {
    this.yg && gvjs_yi(this.yg, this.j());
    gvjs_yi(this.Ei, this.j());
    gvjs_AB.G.sb.call(this);
    gvjs_zi(this.Ml, this.j());
    this.tR = new gvjs_Cz(this.fa().Hb());
    this.ob().o(this.tR, gvjs_3s, this.vja);
    gvjs_DB(this, !1)
};
gvjs_.Hd = function() {
    this.isVisible() && this.setVisible(!1);
    gvjs_K(this.tR);
    gvjs_AB.G.Hd.call(this);
    gvjs_Ai(this.yg);
    gvjs_Ai(this.Ei);
    gvjs_Ai(this.Ml)
};
gvjs_.setVisible = function(a) {
    a != this.Qa && (this.wv && this.wv.stop(), this.kx && this.kx.stop(), this.vv && this.vv.stop(), this.jx && this.jx.stop(), this.fb && gvjs_DB(this, a), a ? this.fW() : this.Cy())
};

function gvjs_DB(a, b) {
    a.r6 || (a.r6 = new gvjs_Fea(a.O, a.C));
    a = a.r6;
    if (b) {
        a.Ay || (a.Ay = []);
        b = a.C.getChildren(a.C.Hb().body);
        for (var c = 0; c < b.length; c++) {
            var d = b[c];
            d == a.O || gvjs_uA(d, gvjs_kd) || (gvjs_tA(d, gvjs_kd, !0), a.Ay.push(d))
        }
    } else if (a.Ay) {
        for (c = 0; c < a.Ay.length; c++) a.Ay[c].removeAttribute(gvjs_Bb);
        a.Ay = null
    }
}
gvjs_.Xz = gvjs_p(36);
gvjs_.fW = function() {
    if (this.dispatchEvent(gvjs_Mr)) {
        try {
            this.Oy = this.fa().Hb().activeElement
        } catch (a) {}
        this.XL();
        this.ge();
        this.ob().o(this.fa().Yi(), gvjs_4u, this.XL).o(this.fa().Yi(), gvjs_Mu, this.Q7);
        gvjs_EB(this, !0);
        this.focus();
        this.Qa = !0;
        this.wv && this.kx ? (gvjs_Zk(this.wv, gvjs_Y, this.pv, !1, this), this.kx.play(), this.wv.play()) : this.pv()
    }
};
gvjs_.Cy = function() {
    if (this.dispatchEvent(gvjs_Lr)) {
        this.ob().Ta(this.fa().Yi(), gvjs_4u, this.XL).Ta(this.fa().Yi(), gvjs_Mu, this.Q7);
        this.Qa = !1;
        this.vv && this.jx ? (gvjs_Zk(this.vv, gvjs_Y, this.ms, !1, this), this.jx.play(), this.vv.play()) : this.ms();
        a: {
            try {
                var a = this.fa(),
                    b = a.Hb().body,
                    c = a.Hb().activeElement || b;
                if (!this.Oy || this.Oy == b) {
                    this.Oy = null;
                    break a
                }(c == b || a.contains(this.j(), c)) && this.Oy.focus()
            } catch (d) {}
            this.Oy = null
        }
    }
};

function gvjs_EB(a, b) {
    a.yg && gvjs_4y(a.yg, b);
    a.Ei && gvjs_4y(a.Ei, b);
    gvjs_4y(a.j(), b);
    gvjs_4y(a.Ml, b)
}
gvjs_.pv = function() {
    this.dispatchEvent(gvjs_nv)
};
gvjs_.ms = function() {
    gvjs_EB(this, !1);
    this.dispatchEvent(gvjs_yt)
};
gvjs_.isVisible = function() {
    return this.Qa
};
gvjs_.focus = function() {
    this.V2()
};
gvjs_.XL = function() {
    this.yg && gvjs_4y(this.yg, !1);
    this.Ei && gvjs_4y(this.Ei, !1);
    var a = this.fa().Hb(),
        b = gvjs_rw(gvjs_uw(a) || window || window),
        c = Math.max(b.width, Math.max(a.body.scrollWidth, a.documentElement.scrollWidth));
    a = Math.max(b.height, Math.max(a.body.scrollHeight, a.documentElement.scrollHeight));
    this.yg && (gvjs_4y(this.yg, !0), gvjs_0y(this.yg, c, a));
    this.Ei && (gvjs_4y(this.Ei, !0), gvjs_0y(this.Ei, c, a))
};
gvjs_.ge = function() {
    var a = this.fa().Hb(),
        b = gvjs_uw(a) || window;
    if (gvjs_mk(this.j()) == gvjs_0s) var c = a = 0;
    else c = gvjs_tw(this.fa().ac), a = c.x, c = c.y;
    var d = gvjs_1y(this.j());
    b = gvjs_rw(b || window);
    a = Math.max(a + b.width / 2 - d.width / 2, 0);
    c = Math.max(c + b.height / 2 - d.height / 2, 0);
    gvjs_Ry(this.j(), a, c);
    gvjs_Ry(this.Ml, a, c)
};
gvjs_.vja = function(a) {
    this.iP ? this.P7() : a.target == this.Ml && gvjs_yl(this.V2, 0, this)
};
gvjs_.V2 = function() {
    try {
        gvjs_x && this.fa().Hb().body.focus(), this.j().focus()
    } catch (a) {}
};
gvjs_.J = function() {
    gvjs_K(this.wv);
    this.wv = null;
    gvjs_K(this.vv);
    this.vv = null;
    gvjs_K(this.kx);
    this.kx = null;
    gvjs_K(this.jx);
    this.jx = null;
    gvjs_AB.G.J.call(this)
};

function gvjs_FB(a, b, c) {
    gvjs_AB.call(this, b, c);
    this.ph = a || "modal-dialog";
    this.hg = (new gvjs_GB).vg(gvjs_HB, !0).vg(gvjs_IB, !1, !0)
}
gvjs_u(gvjs_FB, gvjs_AB);
gvjs_ = gvjs_FB.prototype;
gvjs_.Lda = !0;
gvjs_.wD = !0;
gvjs_.DE = !0;
gvjs_.RQ = !0;
gvjs_.Mma = !1;
gvjs_.GH = .5;
gvjs_.zk = "";
gvjs_.Bg = null;
gvjs_.Mo = null;
gvjs_.BC = !1;
gvjs_.yi = null;
gvjs_.Oh = null;
gvjs_.eG = null;
gvjs_.dh = null;
gvjs_.Yh = null;
gvjs_.If = null;
gvjs_.cF = "dialog";
gvjs_.rha = !1;
gvjs_.ea = function() {
    return this.ph
};
gvjs_.setTitle = function(a) {
    this.zk = a;
    this.Oh && gvjs_Ji(this.Oh, a)
};
gvjs_.getTitle = function() {
    return this.zk
};
gvjs_.UV = gvjs_p(9);

function gvjs_JB(a, b) {
    a.Bg = b;
    a.Yh && gvjs_Hh(a.Yh, b)
}
gvjs_.getContent = function() {
    return null != this.Bg ? gvjs_wh(this.Bg) : ""
};
gvjs_.tr = function() {
    return this.cF
};
gvjs_.RV = function(a) {
    this.cF = a
};

function gvjs_KB(a) {
    a.j() || a.K()
}
gvjs_.Ga = function() {
    gvjs_KB(this);
    return this.Yh
};
gvjs_.gy = function() {
    gvjs_KB(this);
    return gvjs_FB.G.gy.call(this)
};

function gvjs_LB(a, b) {
    a.GH = b;
    a.j() && (b = a.gy()) && gvjs_3y(b, a.GH)
}

function gvjs_MB(a, b) {
    a.DE = b;
    if (a.fb) {
        var c = a.fa(),
            d = a.gy(),
            e = a.yg;
        b ? (e && c.FS(e, a.j()), c.FS(d, a.j())) : (c.removeNode(e), c.removeNode(d))
    }
    a.isVisible() && gvjs_DB(a, b)
}
gvjs_.setDraggable = function(a) {
    this.RQ = a;
    gvjs_NB(this, a && this.fb)
};
gvjs_.uy = function() {
    gvjs_OB(this)
};

function gvjs_OB(a) {
    if (a.Mma && (a.fa().Hb(), a.j())) {
        var b = a.O;
        gvjs_1y(b);
        gvjs_mk(b) != gvjs_0s && a.fa()
    }
}
gvjs_.getDraggable = function() {
    return this.RQ
};

function gvjs_NB(a, b) {
    var c = gvjs_2e(a.ph + "-title-draggable").split(" ");
    a.j() && (b ? gvjs_kB(a.yi, c) : gvjs_mB(a.yi, c));
    b && !a.Mo ? (b = new gvjs_oB(a.j(), a.yi), a.Mo = b, gvjs_kB(a.yi, c), gvjs_M(a.Mo, gvjs_l, a.NV, !1, a), gvjs_M(a.Mo, gvjs_Hs, a.uy, !1, a)) : !b && a.Mo && (a.Mo.xa(), a.Mo = null)
}
gvjs_.F = function() {
    gvjs_FB.G.F.call(this);
    var a = this.j(),
        b = this.fa();
    this.eG = this.getId();
    var c = this.getId() + ".contentEl";
    this.yi = b.F(gvjs_b, this.ph + "-title", this.Oh = b.F(gvjs_ab, {
        className: this.ph + "-title-text",
        id: this.eG
    }, this.zk), this.dh = b.F(gvjs_ab, this.ph + "-title-close"));
    gvjs_wi(a, this.yi, this.Yh = b.F(gvjs_b, {
        className: this.ph + gvjs_oq,
        id: c
    }), this.If = b.F(gvjs_b, this.ph + "-buttons"));
    gvjs_sA(this.Oh, "heading");
    gvjs_sA(this.dh, gvjs_Zr);
    gvjs_8x(this.dh, !0);
    gvjs_yA(this.dh, "Close");
    gvjs_sA(a, this.tr());
    gvjs_tA(a, gvjs_Zt, this.eG || "");
    this.Bg && (gvjs_Hh(this.Yh, this.Bg), this.rha && c && gvjs_tA(a, "describedby", c));
    gvjs_4y(this.dh, this.wD);
    this.hg && (a = this.hg, a.O = this.If, a.K());
    gvjs_4y(this.If, !!this.hg);
    gvjs_LB(this, this.GH)
};
gvjs_.pc = gvjs_p(76);
gvjs_.sb = function() {
    gvjs_FB.G.sb.call(this);
    this.ob().o(this.j(), gvjs_Vt, this.T6).o(this.j(), gvjs_pd, this.T6);
    this.ob().o(this.If, gvjs_fs, this.pja);
    gvjs_NB(this, this.RQ);
    this.ob().o(this.dh, gvjs_fs, this.Gja);
    var a = this.j();
    gvjs_sA(a, this.tr());
    "" !== this.Oh.id && gvjs_tA(a, gvjs_Zt, this.Oh.id);
    this.DE || gvjs_MB(this, !1)
};
gvjs_.Hd = function() {
    this.isVisible() && this.setVisible(!1);
    gvjs_NB(this, !1);
    gvjs_FB.G.Hd.call(this)
};
gvjs_.setVisible = function(a) {
    a != this.isVisible() && (this.fb || this.K(), gvjs_FB.G.setVisible.call(this, a))
};
gvjs_.pv = function() {
    gvjs_FB.G.pv.call(this);
    gvjs_OB(this);
    this.dispatchEvent("aftershow")
};
gvjs_.ms = function() {
    gvjs_FB.G.ms.call(this);
    this.dispatchEvent("afterhide");
    this.BC && this.xa()
};
gvjs_.NV = function() {
    var a = this.fa().Hb(),
        b = gvjs_rw(gvjs_uw(a) || window || window),
        c = Math.max(a.body.scrollWidth, b.width);
    a = Math.max(a.body.scrollHeight, b.height);
    var d = gvjs_1y(this.j());
    gvjs_mk(this.j()) == gvjs_0s ? gvjs_pB(this.Mo, new gvjs_0(0, 0, Math.max(0, b.width - d.width), Math.max(0, b.height - d.height))) : gvjs_pB(this.Mo, new gvjs_0(0, 0, c - d.width, a - d.height))
};
gvjs_.Gja = function() {
    gvjs_PB(this)
};

function gvjs_PB(a) {
    if (a.wD) {
        var b = a.hg,
            c = b && b.UH;
        c ? (b = b.get(c), a.dispatchEvent(new gvjs_QB(c, b)) && a.setVisible(!1)) : a.setVisible(!1)
    }
}
gvjs_.BM = gvjs_p(81);
gvjs_.J = function() {
    this.If = this.dh = null;
    gvjs_FB.G.J.call(this)
};
gvjs_.pja = function(a) {
    a: {
        for (a = a.target; null != a && a != this.If;) {
            if (a.tagName == gvjs_kp) break a;
            a = a.parentNode
        }
        a = null
    }
    if (a && !a.disabled) {
        a = a.name;
        var b = this.hg.get(a);
        this.dispatchEvent(new gvjs_QB(a, b)) && this.setVisible(!1)
    }
};
gvjs_.T6 = function(a) {
    var b = !1,
        c = !1,
        d = this.hg,
        e = a.target;
    if (a.type == gvjs_Vt)
        if (this.Lda && 27 == a.keyCode) {
            var f = d && d.UH;
            e = e.tagName == gvjs_9a && !e.disabled;
            f && !e ? (c = !0, b = d.get(f), b = this.dispatchEvent(new gvjs_QB(f, b))) : e || (b = !0)
        } else {
            if (9 == a.keyCode && a.shiftKey && e == this.j()) {
                this.iP = !0;
                try {
                    this.Ml.focus()
                } catch (k) {}
                gvjs_yl(this.P7, 0, this)
            }
        }
    else if (13 == a.keyCode) {
        if (e.tagName == gvjs_kp && !e.disabled) f = e.name;
        else if (e == this.dh) gvjs_PB(this);
        else if (d) {
            var g = d.CI,
                h = g && gvjs_RB(d, g);
            e = (e.tagName == gvjs_lp || e.tagName ==
                gvjs_9a || "A" == e.tagName) && !e.disabled;
            !h || h.disabled || e || (f = g)
        }
        f && d && (c = !0, b = this.dispatchEvent(new gvjs_QB(f, String(d.get(f)))))
    } else e != this.dh || 32 != a.keyCode && " " != a.key || gvjs_PB(this);
    if (b || c) a.stopPropagation(), a.preventDefault();
    b && this.setVisible(!1)
};

function gvjs_QB(a, b) {
    this.type = gvjs_zs;
    this.key = a;
    this.caption = b
}
gvjs_u(gvjs_QB, gvjs_Nk);

function gvjs_GB(a) {
    gvjs_vB.call(this);
    this.C = a || gvjs_ii();
    this.ph = "aAAaGVIZSENTINELaAAa-buttonset";
    this.UH = this.O = this.CI = null
}
gvjs_u(gvjs_GB, gvjs_vB);
gvjs_ = gvjs_GB.prototype;
gvjs_.clear = function() {
    gvjs_vB.prototype.clear.call(this);
    this.CI = this.UH = null
};
gvjs_.set = function(a, b, c, d) {
    gvjs_vB.prototype.set.call(this, a, b);
    c && (this.CI = a);
    d && (this.UH = a);
    return this
};
gvjs_.vg = function(a, b, c) {
    return this.set(a.key, a.caption, b, c)
};
gvjs_.K = function() {
    if (this.O) {
        gvjs_Hh(this.O, gvjs_Fh);
        var a = gvjs_ii(this.O);
        this.forEach(function(b, c) {
            b = a.F(gvjs_kp, {
                name: c
            }, b);
            c == this.CI && (b.className = this.ph + gvjs_pq);
            this.O.appendChild(b)
        }, this)
    }
};
gvjs_.ra = gvjs_p(61);
gvjs_.j = function() {
    return this.O
};
gvjs_.fa = function() {
    return this.C
};

function gvjs_RB(a, b) {
    a = (a.O || document).getElementsByTagName(gvjs_kp);
    for (var c = 0, d; d = a[c]; c++)
        if (d.name == b || d.id == b) return d;
    return null
}
var gvjs_HB = {
        key: "ok",
        caption: "OK"
    },
    gvjs_IB = {
        key: gvjs_Nb,
        caption: "Cancel"
    },
    gvjs_SB = {
        key: "yes",
        caption: "Yes"
    },
    gvjs_TB = {
        key: "no",
        caption: "No"
    },
    gvjs_Gea = {
        key: "save",
        caption: "Save"
    },
    gvjs_Hea = {
        key: "continue",
        caption: "Continue"
    };
"undefined" != typeof document && ((new gvjs_GB).vg(gvjs_HB, !0, !0), (new gvjs_GB).vg(gvjs_HB, !0).vg(gvjs_IB, !1, !0), (new gvjs_GB).vg(gvjs_SB, !0).vg(gvjs_TB, !1, !0), (new gvjs_GB).vg(gvjs_SB).vg(gvjs_TB, !0).vg(gvjs_IB, !1, !0), (new gvjs_GB).vg(gvjs_Hea).vg(gvjs_Gea).vg(gvjs_IB, !0, !0));

function gvjs_UB(a, b, c, d) {
    gvjs_Pk.call(this, d);
    this.type = gvjs_Ut;
    this.keyCode = a;
    this.charCode = b;
    this.repeat = c
}
gvjs_u(gvjs_UB, gvjs_Pk);

function gvjs_VB(a, b) {
    gvjs_7k.call(this);
    a && this.gx(a, b)
}
gvjs_u(gvjs_VB, gvjs_7k);
gvjs_ = gvjs_VB.prototype;
gvjs_.O = null;
gvjs_.vK = null;
gvjs_.ZS = null;
gvjs_.wK = null;
gvjs_.ji = -1;
gvjs_.Sf = -1;
gvjs_.em = !1;
var gvjs_WB = {
        3: 13,
        12: 144,
        63232: 38,
        63233: 40,
        63234: 37,
        63235: 39,
        63236: 112,
        63237: 113,
        63238: 114,
        63239: 115,
        63240: 116,
        63241: 117,
        63242: 118,
        63243: 119,
        63244: 120,
        63245: 121,
        63246: 122,
        63247: 123,
        63248: 44,
        63272: 46,
        63273: 36,
        63275: 35,
        63276: 33,
        63277: 34,
        63289: 144,
        63302: 45
    },
    gvjs_XB = {
        Up: 38,
        Down: 40,
        Left: 37,
        Right: 39,
        Enter: 13,
        F1: 112,
        F2: 113,
        F3: 114,
        F4: 115,
        F5: 116,
        F6: 117,
        F7: 118,
        F8: 119,
        F9: 120,
        F10: 121,
        F11: 122,
        F12: 123,
        "U+007F": 46,
        Home: 36,
        End: 35,
        PageUp: 33,
        PageDown: 34,
        Insert: 45
    },
    gvjs_YB = gvjs_Jf && gvjs_Hf;
gvjs_ = gvjs_VB.prototype;
gvjs_.Xj = function(a) {
    if (gvjs_If || gvjs_Gf)
        if (17 == this.ji && !a.ctrlKey || 18 == this.ji && !a.altKey || gvjs_Jf && 91 == this.ji && !a.metaKey) this.Sf = this.ji = -1; - 1 == this.ji && (a.ctrlKey && 17 != a.keyCode ? this.ji = 17 : a.altKey && 18 != a.keyCode ? this.ji = 18 : a.metaKey && 91 != a.keyCode && (this.ji = 91));
    gvjs_Nz(a.keyCode, this.ji, a.shiftKey, a.ctrlKey, a.altKey, a.metaKey) ? (this.Sf = gvjs_Mz(a.keyCode), gvjs_YB && (this.em = a.altKey)) : this.handleEvent(a)
};
gvjs_.Ifa = function(a) {
    this.Sf = this.ji = -1;
    this.em = a.altKey
};
gvjs_.handleEvent = function(a) {
    var b = a.fi,
        c = b.altKey;
    if (gvjs_x && a.type == gvjs_pd) {
        var d = this.Sf;
        var e = 13 != d && 27 != d ? b.keyCode : 0
    } else(gvjs_If || gvjs_Gf) && a.type == gvjs_pd ? (d = this.Sf, e = 0 <= b.charCode && 63232 > b.charCode && gvjs_Lz(d) ? b.charCode : 0) : (a.type == gvjs_pd ? (gvjs_YB && (c = this.em), b.keyCode == b.charCode ? 32 > b.keyCode ? (d = b.keyCode, e = 0) : (d = this.Sf, e = b.charCode) : (d = b.keyCode || this.Sf, e = b.charCode || 0)) : (d = b.keyCode || this.Sf, e = b.charCode || 0), gvjs_Jf && 63 == e && 224 == d && (d = 191));
    var f = d = gvjs_Mz(d);
    d ? 63232 <= d && d in gvjs_WB ?
        f = gvjs_WB[d] : 25 == d && a.shiftKey && (f = 9) : b.keyIdentifier && b.keyIdentifier in gvjs_XB && (f = gvjs_XB[b.keyIdentifier]);
    if (!gvjs_Hf || a.type != gvjs_pd || gvjs_Nz(f, this.ji, a.shiftKey, a.ctrlKey, c, a.metaKey)) a = f == this.ji, this.ji = f, b = new gvjs_UB(f, e, a, b), b.altKey = c, this.dispatchEvent(b)
};
gvjs_.j = function() {
    return this.O
};
gvjs_.gx = function(a, b) {
    this.wK && this.detach();
    this.O = a;
    this.vK = gvjs_M(this.O, gvjs_pd, this, b);
    this.ZS = gvjs_M(this.O, gvjs_Vt, this.Xj, b, this);
    this.wK = gvjs_M(this.O, gvjs_Wt, this.Ifa, b, this)
};
gvjs_.detach = function() {
    this.vK && (gvjs_4k(this.vK), gvjs_4k(this.ZS), gvjs_4k(this.wK), this.wK = this.ZS = this.vK = null);
    this.O = null;
    this.Sf = this.ji = -1
};
gvjs_.J = function() {
    gvjs_VB.G.J.call(this);
    this.detach()
};
var gvjs_ZB = {
    Zs: gvjs_pu,
    bt: gvjs_tu,
    Iw: "mousecancel",
    daa: gvjs_su,
    faa: gvjs_Dd,
    eaa: gvjs_Cd,
    baa: gvjs_qu,
    caa: gvjs_ru
};
var gvjs__B = {
    Zs: gvjs_Ok ? "pointerdown" : gvjs_pu,
    bt: gvjs_Ok ? "pointerup" : gvjs_tu,
    Iw: gvjs_Ok ? "pointercancel" : "mousecancel",
    daa: gvjs_Ok ? "pointermove" : gvjs_su,
    faa: gvjs_Ok ? "pointerover" : gvjs_Dd,
    eaa: gvjs_Ok ? "pointerout" : gvjs_Cd,
    baa: gvjs_Ok ? "pointerenter" : gvjs_qu,
    caa: gvjs_Ok ? "pointerleave" : gvjs_ru
};

function gvjs_0B() {}
var gvjs_1B;
gvjs_Le(gvjs_0B);
var gvjs_Iea = {
    button: "pressed",
    checkbox: gvjs_Pb,
    menuitem: gvjs__d,
    menuitemcheckbox: gvjs_Pb,
    menuitemradio: gvjs_Pb,
    radio: gvjs_Pb,
    tab: gvjs__d,
    treeitem: gvjs__d
};
gvjs_ = gvjs_0B.prototype;
gvjs_.gi = function() {};
gvjs_.F = function(a) {
    return a.fa().F(gvjs_b, this.Ti(a).join(" "), a.getContent())
};
gvjs_.Ga = function(a) {
    return a
};
gvjs_.To = function(a, b, c) {
    (a = a.j ? a.j() : a) && (c ? gvjs_kB : gvjs_mB)(a, [b])
};
gvjs_.Uc = gvjs_p(69);
gvjs_.ra = gvjs_p(60);
gvjs_.bk = function(a) {
    a.tf() && this.Mv(a.j(), !0);
    a.isEnabled() && this.Bl(a, a.isVisible())
};

function gvjs_2B(a, b, c) {
    if (a = c || a.gi()) c = b.getAttribute(gvjs_Vd) || null, a != c && gvjs_sA(b, a)
}

function gvjs_3B(a, b, c) {
    var d = b.Z_;
    null != d && a.KV(c, d);
    b.isVisible() || gvjs_tA(c, gvjs_kd, !b.isVisible());
    b.isEnabled() || a.Nn(c, 1, !b.isEnabled());
    gvjs_4B(b, 8) && a.Nn(c, 8, b.uK());
    gvjs_4B(b, 16) && a.Nn(c, 16, b.ck());
    gvjs_4B(b, 64) && a.Nn(c, 64, gvjs_5B(b, 64))
}
gvjs_.KV = function(a, b) {
    gvjs_yA(a, b)
};
gvjs_.zF = function(a, b) {
    gvjs_6y(a, !b, !gvjs_x)
};
gvjs_.Mv = function(a, b) {
    this.To(a, this.ea() + "-rtl", b)
};
gvjs_.Sm = function(a) {
    var b;
    return gvjs_4B(a, 32) && (b = a.We()) ? gvjs_mw(b) : !1
};
gvjs_.Bl = function(a, b) {
    var c;
    if (gvjs_4B(a, 32) && (c = a.We())) {
        if (!b && gvjs_5B(a, 32)) {
            try {
                c.blur()
            } catch (d) {}
            gvjs_5B(a, 32) && a.ru(null)
        }
        gvjs_mw(c) != b && gvjs_8x(c, b)
    }
};
gvjs_.setVisible = function(a, b) {
    gvjs_4y(a, b);
    a && gvjs_tA(a, gvjs_kd, !b)
};
gvjs_.setState = function(a, b, c) {
    var d = a.j();
    if (d) {
        var e = this.cD(b);
        e && this.To(a, e, c);
        this.Nn(d, b, c)
    }
};
gvjs_.Nn = function(a, b, c) {
    gvjs_1B || (gvjs_1B = {
        1: gvjs_4b,
        8: gvjs__d,
        16: gvjs_Pb,
        64: "expanded"
    });
    b = gvjs_1B[b];
    var d = a.getAttribute(gvjs_Vd) || null;
    d && (d = gvjs_Iea[d] || b, b = b == gvjs_Pb || b == gvjs__d ? d : b);
    b && gvjs_tA(a, b, c)
};
gvjs_.setContent = function(a, b) {
    var c = this.Ga(a);
    c && (gvjs_xi(c), b && (typeof b === gvjs_m ? gvjs_Ji(c, b) : (a = function(d) {
        if (d) {
            var e = gvjs_ki(c);
            c.appendChild(typeof d === gvjs_m ? e.createTextNode(d) : d)
        }
    }, Array.isArray(b) ? b.forEach(a) : !gvjs_Ne(b) || gvjs_Id in b ? a(b) : gvjs_wf(b).forEach(a))))
};
gvjs_.We = function(a) {
    return a.j()
};
gvjs_.ea = function() {
    return gvjs_7q
};
gvjs_.Ti = function(a) {
    var b = this.ea(),
        c = [b],
        d = this.ea();
    d != b && c.push(d);
    b = a.getState();
    for (d = []; b;) {
        var e = b & -b;
        d.push(this.cD(e));
        b &= ~e
    }
    c.push.apply(c, d);
    (a = a.Zk) && c.push.apply(c, a);
    return c
};
gvjs_.cD = function(a) {
    this.ZH || gvjs_6B(this);
    return this.ZH[a]
};
gvjs_.my = gvjs_p(83);

function gvjs_6B(a) {
    var b = a.ea();
    gvjs_4e(b.replace(/\xa0|\s/g, " "), " ");
    a.ZH = {
        1: b + gvjs_qq,
        2: b + "-hover",
        4: b + "-active",
        8: b + "-selected",
        16: b + "-checked",
        32: b + "-focused",
        64: b + "-open"
    }
};

function gvjs_7B(a, b) {
    if (!a) throw Error("Invalid class name " + a);
    if (typeof b !== gvjs_c) throw Error("Invalid decorator function " + b);
    gvjs_8B[a] = b
}
var gvjs_9B = {},
    gvjs_8B = {};

function gvjs_$B(a, b, c) {
    gvjs_aB.call(this, c);
    if (!b) {
        for (b = this.constructor; b;) {
            var d = gvjs_Qe(b);
            if (d = gvjs_9B[d]) break;
            b = (b = Object.getPrototypeOf(b.prototype)) && b.constructor
        }
        b = d ? typeof d.eb === gvjs_c ? d.eb() : new d : null
    }
    this.N = b;
    this.Qz(void 0 !== a ? a : null);
    this.Z_ = null
}
gvjs_u(gvjs_$B, gvjs_aB);
gvjs_ = gvjs_$B.prototype;
gvjs_.Bg = null;
gvjs_.V = 0;
gvjs_.RF = 39;
gvjs_.mo = 255;
gvjs_.iq = 0;
gvjs_.Qa = !0;
gvjs_.Zk = null;
gvjs_.LJ = !0;
gvjs_.AH = !1;
gvjs_.cF = null;

function gvjs_aC(a, b) {
    a.fb && b != a.LJ && gvjs_bC(a, b);
    a.LJ = b
}
gvjs_.We = function() {
    return this.N.We(this)
};
gvjs_.yJ = function() {
    return this.ce || (this.ce = new gvjs_VB)
};
gvjs_.ya = function() {
    return this.N
};
gvjs_.MM = gvjs_p(85);
gvjs_.eo = function(a) {
    a && (this.Zk ? gvjs_tf(this.Zk, a) || this.Zk.push(a) : this.Zk = [a], this.N.To(this, a, !0))
};
gvjs_.To = function(a, b) {
    b ? this.eo(a) : a && this.Zk && gvjs_uf(this.Zk, a) && (0 == this.Zk.length && (this.Zk = null), this.N.To(this, a, !1))
};
gvjs_.F = function() {
    var a = this.N.F(this);
    this.O = a;
    gvjs_2B(this.N, a, this.tr());
    this.AH || this.N.zF(a, !1);
    this.isVisible() || this.N.setVisible(a, !1)
};
gvjs_.tr = function() {
    return this.cF
};
gvjs_.RV = function(a) {
    this.cF = a
};
gvjs_.KV = function(a) {
    this.Z_ = a;
    var b = this.j();
    b && this.N.KV(b, a)
};
gvjs_.Ga = function() {
    return this.N.Ga(this.j())
};
gvjs_.Uc = gvjs_p(68);
gvjs_.pc = gvjs_p(75);
gvjs_.sb = function() {
    gvjs_$B.G.sb.call(this);
    gvjs_3B(this.N, this, this.O);
    this.N.bk(this);
    if (this.RF & -2 && (this.LJ && gvjs_bC(this, !0), gvjs_4B(this, 32))) {
        var a = this.We();
        if (a) {
            var b = this.yJ();
            b.gx(a);
            this.ob().o(b, gvjs_Ut, this.Jg).o(a, gvjs_1s, this.zr).o(a, gvjs_Pr, this.ru)
        }
    }
};

function gvjs_bC(a, b) {
    var c = a.uv ? gvjs__B : gvjs_ZB,
        d = a.ob(),
        e = a.j();
    b ? (d.o(e, c.Zs, a.Zd).o(e, [c.bt, c.Iw], a.hl).o(e, gvjs_Dd, a.gl).o(e, gvjs_Cd, a.MJ), a.uv && d.o(e, gvjs_kt, a.CL), a.pD != gvjs_Og && d.o(e, gvjs_ms, a.pD), gvjs_x && !a.ID && (a.ID = new gvjs_cC(a), gvjs_Rw(a, a.ID))) : (d.Ta(e, c.Zs, a.Zd).Ta(e, [c.bt, c.Iw], a.hl).Ta(e, gvjs_Dd, a.gl).Ta(e, gvjs_Cd, a.MJ), a.uv && d.Ta(e, gvjs_kt, a.CL), a.pD != gvjs_Og && d.Ta(e, gvjs_ms, a.pD), gvjs_x && (gvjs_K(a.ID), a.ID = null))
}
gvjs_.Hd = function() {
    gvjs_$B.G.Hd.call(this);
    this.ce && this.ce.detach();
    this.isVisible() && this.isEnabled() && this.N.Bl(this, !1)
};
gvjs_.J = function() {
    gvjs_$B.G.J.call(this);
    this.ce && (this.ce.xa(), delete this.ce);
    delete this.N;
    this.ID = this.Zk = this.Bg = null
};
gvjs_.getContent = function() {
    return this.Bg
};
gvjs_.setContent = function(a) {
    this.N.setContent(this.j(), a);
    this.Qz(a)
};
gvjs_.Qz = function(a) {
    this.Bg = a
};
gvjs_.Gg = function() {
    var a = this.getContent();
    if (!a) return "";
    a = typeof a === gvjs_m ? a : Array.isArray(a) ? a.map(gvjs_9x).join("") : gvjs_Mi(a);
    return gvjs_Gx(a)
};
gvjs_.Mv = function(a) {
    gvjs_$B.G.Mv.call(this, a);
    var b = this.j();
    b && this.N.Mv(b, a)
};
gvjs_.zF = function(a) {
    this.AH = a;
    var b = this.j();
    b && this.N.zF(b, a)
};
gvjs_.isVisible = function() {
    return this.Qa
};
gvjs_.setVisible = function(a, b) {
    return b || this.Qa != a && this.dispatchEvent(a ? gvjs_nv : gvjs_yt) ? ((b = this.j()) && this.N.setVisible(b, a), this.isEnabled() && this.N.Bl(this, a), this.Qa = a, !0) : !1
};
gvjs_.isEnabled = function() {
    return !gvjs_5B(this, 1)
};
gvjs_.Sa = function(a) {
    var b = this.getParent();
    b && typeof b.isEnabled == gvjs_c && !b.isEnabled() || !gvjs_dC(this, 1, !a) || (a || (this.setActive(!1), this.Zf(!1)), this.isVisible() && this.N.Bl(this, a), this.setState(1, !a, !0))
};
gvjs_.Zf = function(a) {
    gvjs_dC(this, 2, a) && this.setState(2, a)
};
gvjs_.isActive = function() {
    return gvjs_5B(this, 4)
};
gvjs_.setActive = function(a) {
    gvjs_dC(this, 4, a) && this.setState(4, a)
};
gvjs_.uK = function() {
    return gvjs_5B(this, 8)
};
gvjs_.Fl = function(a) {
    gvjs_dC(this, 8, a) && this.setState(8, a)
};
gvjs_.ck = function() {
    return gvjs_5B(this, 16)
};
gvjs_.Wg = function(a) {
    gvjs_dC(this, 16, a) && this.setState(16, a)
};
gvjs_.Sz = function(a) {
    gvjs_dC(this, 32, a) && this.setState(32, a)
};
gvjs_.kc = function(a) {
    gvjs_dC(this, 64, a) && this.setState(64, a)
};
gvjs_.getState = function() {
    return this.V
};

function gvjs_5B(a, b) {
    return !!(a.V & b)
}
gvjs_.setState = function(a, b, c) {
    c || 1 != a ? gvjs_4B(this, a) && b != gvjs_5B(this, a) && (this.N.setState(this, a, b), this.V = b ? this.V | a : this.V & ~a) : this.Sa(!b)
};

function gvjs_4B(a, b) {
    return !!(a.RF & b)
}
gvjs_.we = function(a, b) {
    if (this.fb && gvjs_5B(this, a) && !b) throw Error(gvjs_Lq);
    !b && gvjs_5B(this, a) && this.setState(a, !1);
    this.RF = b ? this.RF | a : this.RF & ~a
};

function gvjs_eC(a, b) {
    return !!(a.mo & b) && gvjs_4B(a, b)
}

function gvjs_dC(a, b, c) {
    return gvjs_4B(a, b) && gvjs_5B(a, b) != c && (!(a.iq & b) || a.dispatchEvent(gvjs_bB(b, c))) && !a.Ue
}
gvjs_.gl = function(a) {
    !gvjs_fC(a, this.j()) && this.dispatchEvent("enter") && this.isEnabled() && gvjs_eC(this, 2) && this.Zf(!0)
};
gvjs_.MJ = function(a) {
    !gvjs_fC(a, this.j()) && this.dispatchEvent("leave") && (gvjs_eC(this, 4) && this.setActive(!1), gvjs_eC(this, 2) && this.Zf(!1))
};
gvjs_.CL = function(a) {
    var b = a.target;
    b.releasePointerCapture && b.releasePointerCapture(a.pointerId)
};
gvjs_.pD = gvjs_Og;

function gvjs_fC(a, b) {
    return !!a.relatedTarget && gvjs_Hi(b, a.relatedTarget)
}
gvjs_.Zd = function(a) {
    this.isEnabled() && (gvjs_eC(this, 2) && this.Zf(!0), gvjs_Sw(a) && (gvjs_eC(this, 4) && this.setActive(!0), this.N && this.N.Sm(this) && this.We().focus()));
    !this.AH && gvjs_Sw(a) && a.preventDefault()
};
gvjs_.hl = function(a) {
    this.isEnabled() && (gvjs_eC(this, 2) && this.Zf(!0), this.isActive() && this.qg(a) && gvjs_eC(this, 4) && this.setActive(!1))
};
gvjs_.qg = function(a) {
    gvjs_eC(this, 16) && this.Wg(!this.ck());
    gvjs_eC(this, 8) && this.Fl(!0);
    gvjs_eC(this, 64) && this.kc(!gvjs_5B(this, 64));
    var b = new gvjs_Nk(gvjs_ir, this);
    a && (b.altKey = a.altKey, b.ctrlKey = a.ctrlKey, b.metaKey = a.metaKey, b.shiftKey = a.shiftKey, b.QU = a.QU);
    return this.dispatchEvent(b)
};
gvjs_.zr = function() {
    gvjs_eC(this, 32) && this.Sz(!0)
};
gvjs_.ru = function() {
    gvjs_eC(this, 4) && this.setActive(!1);
    gvjs_eC(this, 32) && this.Sz(!1)
};
gvjs_.Jg = function(a) {
    return this.isVisible() && this.isEnabled() && this.xh(a) ? (a.preventDefault(), a.stopPropagation(), !0) : !1
};
gvjs_.xh = function(a) {
    return 13 == a.keyCode && this.qg(a)
};
if (typeof gvjs_$B !== gvjs_c) throw Error("Invalid component class " + gvjs_$B);
if (typeof gvjs_0B !== gvjs_c) throw Error("Invalid renderer class " + gvjs_0B);
var gvjs_Jea = gvjs_Qe(gvjs_$B);
gvjs_9B[gvjs_Jea] = gvjs_0B;
gvjs_7B(gvjs_7q, function() {
    return new gvjs_$B(null)
});

function gvjs_cC(a) {
    gvjs_L.call(this);
    this.pI = a;
    this.dI = !1;
    this.Pd = new gvjs_mz(this);
    gvjs_Rw(this, this.Pd);
    var b = this.pI.O;
    a = a.uv ? gvjs__B : gvjs_ZB;
    this.Pd.o(b, a.Zs, this.xy).o(b, a.bt, this.OJ).o(b, gvjs_fs, this.ty)
}
gvjs_u(gvjs_cC, gvjs_L);
var gvjs_gC = !gvjs_x || gvjs_Tf(9);
gvjs_cC.prototype.xy = function() {
    this.dI = !1
};
gvjs_cC.prototype.OJ = function() {
    this.dI = !0
};

function gvjs_hC(a, b) {
    if (!gvjs_gC) return a.button = 0, a.type = b, a;
    var c = document.createEvent("MouseEvents");
    c.initMouseEvent(b, a.bubbles, a.cancelable, a.view || null, a.detail, a.screenX, a.screenY, a.clientX, a.clientY, a.ctrlKey, a.altKey, a.shiftKey, a.metaKey, 0, a.relatedTarget || null);
    return c
}
gvjs_cC.prototype.ty = function(a) {
    if (this.dI) this.dI = !1;
    else {
        var b = a.fi,
            c = b.button,
            d = b.type,
            e = gvjs_hC(b, gvjs_pu);
        this.pI.Zd(new gvjs_Pk(e, a.currentTarget));
        e = gvjs_hC(b, gvjs_tu);
        this.pI.hl(new gvjs_Pk(e, a.currentTarget));
        gvjs_gC || (b.button = c, b.type = d)
    }
};
gvjs_cC.prototype.J = function() {
    this.pI = null;
    gvjs_cC.G.J.call(this)
};

function gvjs_iC() {
    this.TP = []
}
gvjs_u(gvjs_iC, gvjs_0B);
gvjs_Le(gvjs_iC);

function gvjs_jC(a, b) {
    var c = a.TP[b];
    if (!c) {
        switch (b) {
            case 0:
                c = a.ea() + "-highlight";
                break;
            case 1:
                c = a.ea() + "-checkbox";
                break;
            case 2:
                c = a.ea() + gvjs_oq
        }
        a.TP[b] = c
    }
    return c
}
gvjs_ = gvjs_iC.prototype;
gvjs_.gi = function() {
    return "menuitem"
};
gvjs_.F = function(a) {
    var b = a.fa().F(gvjs_b, this.Ti(a).join(" "), gvjs_kC(this, a.getContent(), a.fa()));
    gvjs_lC(this, a, b, gvjs_4B(a, 8) || gvjs_4B(a, 16));
    return b
};
gvjs_.Ga = function(a) {
    return a && a.firstChild
};
gvjs_.ra = gvjs_p(59);
gvjs_.setContent = function(a, b) {
    var c = this.Ga(a),
        d = gvjs_mC(this, a) ? c.firstChild : null;
    gvjs_iC.G.setContent.call(this, a, b);
    d && !gvjs_mC(this, a) && c.insertBefore(d, c.firstChild || null)
};

function gvjs_kC(a, b, c) {
    a = gvjs_jC(a, 2);
    return c.F(gvjs_b, a, b)
}
gvjs_.SV = function(a, b, c) {
    a && b && gvjs_lC(this, a, b, c)
};
gvjs_.zM = function(a, b, c) {
    a && b && gvjs_lC(this, a, b, c)
};

function gvjs_mC(a, b) {
    return (b = a.Ga(b)) ? (b = b.firstChild, a = gvjs_jC(a, 1), !!b && gvjs_Fi(b) && gvjs_iB(b, a)) : !1
}

function gvjs_lC(a, b, c, d) {
    gvjs_2B(a, c, b.tr());
    gvjs_3B(a, b, c);
    d != gvjs_mC(a, c) && (gvjs_nB(c, gvjs_cr, d), c = a.Ga(c), d ? (a = gvjs_jC(a, 1), c.insertBefore(b.fa().F(gvjs_b, a), c.firstChild || null)) : c.removeChild(c.firstChild))
}
gvjs_.cD = function(a) {
    switch (a) {
        case 2:
            return gvjs_jC(this, 0);
        case 16:
        case 8:
            return gvjs_dr;
        default:
            return gvjs_iC.G.cD.call(this, a)
    }
};
gvjs_.my = gvjs_p(82);
gvjs_.ea = function() {
    return gvjs_W
};

function gvjs_nC(a, b, c, d) {
    gvjs_$B.call(this, a, d || gvjs_iC.eb(), c);
    this.setValue(b)
}
gvjs_u(gvjs_nC, gvjs_$B);
gvjs_ = gvjs_nC.prototype;
gvjs_.getValue = function() {
    var a = this.vl;
    return null != a ? a : this.Gg()
};
gvjs_.setValue = function(a) {
    this.vl = a
};
gvjs_.we = function(a, b) {
    gvjs_nC.G.we.call(this, a, b);
    switch (a) {
        case 8:
            this.ck() && !b && this.Wg(!1);
            (a = this.j()) && this.ya().SV(this, a, b);
            break;
        case 16:
            (a = this.j()) && this.ya().zM(this, a, b)
    }
};
gvjs_.SV = function(a) {
    this.we(8, a)
};
gvjs_.zM = function(a) {
    this.we(16, a)
};
gvjs_.Gg = function() {
    var a = this.getContent();
    return Array.isArray(a) ? (a = gvjs_w(a, function(b) {
        return gvjs_Fi(b) && (gvjs_iB(b, "aAAaGVIZSENTINELaAAa-menuitem-accel") || gvjs_iB(b, "aAAaGVIZSENTINELaAAa-menuitem-mnemonic-separator")) ? "" : gvjs_9x(b)
    }).join(""), gvjs_Gx(a)) : gvjs_nC.G.Gg.call(this)
};
gvjs_.hl = function(a) {
    var b = this.getParent();
    if (b) {
        var c = b.a7;
        b.a7 = null;
        if (c && typeof a.clientX === gvjs_f && gvjs_hi(c, new gvjs_A(a.clientX, a.clientY))) return
    }
    gvjs_nC.G.hl.call(this, a)
};
gvjs_.xh = function(a) {
    return a.keyCode == this.VT && this.qg(a) ? !0 : gvjs_nC.G.xh.call(this, a)
};
gvjs_.tea = function() {
    return this.VT
};
gvjs_7B(gvjs_W, function() {
    return new gvjs_nC(null)
});
gvjs_nC.prototype.tr = function() {
    return gvjs_4B(this, 16) ? "menuitemcheckbox" : gvjs_4B(this, 8) ? "menuitemradio" : gvjs_nC.G.tr.call(this)
};
gvjs_nC.prototype.getParent = function() {
    return gvjs_$B.prototype.getParent.call(this)
};
gvjs_nC.prototype.jy = function() {
    return gvjs_$B.prototype.jy.call(this)
};

function gvjs_oC(a, b, c, d) {
    gvjs_Jz.call(this, a, b);
    this.CK = c ? 5 : 0;
    this.EU = d || void 0
}
gvjs_u(gvjs_oC, gvjs_Jz);
gvjs_oC.prototype.sea = function() {
    return this.CK
};
gvjs_oC.prototype.ge = function(a, b, c, d) {
    var e = gvjs_Iz(this.element, this.jC, a, b, null, c, 10, d, this.EU);
    if (e & 496) {
        var f = gvjs_pC(e, this.jC);
        b = gvjs_pC(e, b);
        e = gvjs_Iz(this.element, f, a, b, null, c, 10, d, this.EU);
        e & 496 && (f = gvjs_pC(e, f), b = gvjs_pC(e, b), gvjs_Iz(this.element, f, a, b, null, c, this.CK, d, this.EU))
    }
};

function gvjs_pC(a, b) {
    a & 48 && (b ^= 4);
    a & 192 && (b ^= 1);
    return b
};

function gvjs_qC(a, b, c, d) {
    gvjs_oC.call(this, a, b, c || d);
    if (c || d) this.CK = 65 | (d ? 32 : 132)
}
gvjs_u(gvjs_qC, gvjs_oC);

function gvjs_rC() {}
gvjs_u(gvjs_rC, gvjs_0B);
gvjs_Le(gvjs_rC);
gvjs_ = gvjs_rC.prototype;
gvjs_.gi = function() {
    return gvjs_Zr
};
gvjs_.Nn = function(a, b, c) {
    switch (b) {
        case 8:
        case 16:
            gvjs_tA(a, "pressed", c);
            break;
        default:
        case 64:
        case 1:
            gvjs_rC.G.Nn.call(this, a, b, c)
    }
};
gvjs_.F = function(a) {
    var b = gvjs_rC.G.F.call(this, a);
    this.wi(b, a.Wj());
    var c = a.getValue();
    c && this.setValue(b, c);
    gvjs_4B(a, 16) && this.Nn(b, 16, a.ck());
    return b
};
gvjs_.ra = gvjs_p(58);
gvjs_.getValue = function() {};
gvjs_.setValue = function() {};
gvjs_.Wj = function(a) {
    return a.title
};
gvjs_.wi = function(a, b) {
    a && (b ? a.title = b : a.removeAttribute(gvjs_ce))
};
gvjs_.xn = gvjs_p(88);
gvjs_.ea = function() {
    return gvjs_5q
};

function gvjs_sC() {}
gvjs_u(gvjs_sC, gvjs_rC);
gvjs_Le(gvjs_sC);
gvjs_ = gvjs_sC.prototype;
gvjs_.gi = function() {};
gvjs_.F = function(a) {
    gvjs_aC(a, !1);
    a.mo &= -256;
    a.we(32, !1);
    return a.fa().F(gvjs_kp, {
        "class": this.Ti(a).join(" "),
        disabled: !a.isEnabled(),
        title: a.Wj() || "",
        value: a.getValue() || ""
    }, a.Gg() || "")
};
gvjs_.Uc = gvjs_p(67);
gvjs_.ra = gvjs_p(57);
gvjs_.bk = function(a) {
    a.ob().o(a.j(), gvjs_fs, a.qg)
};
gvjs_.zF = function() {};
gvjs_.Mv = function() {};
gvjs_.Sm = function(a) {
    return a.isEnabled()
};
gvjs_.Bl = function() {};
gvjs_.setState = function(a, b, c) {
    gvjs_sC.G.setState.call(this, a, b, c);
    (a = a.j()) && 1 == b && (a.disabled = c)
};
gvjs_.getValue = function(a) {
    return a.value
};
gvjs_.setValue = function(a, b) {
    a && (a.value = b)
};
gvjs_.Nn = function() {};

function gvjs_tC(a, b, c) {
    gvjs_$B.call(this, a, b || gvjs_sC.eb(), c)
}
gvjs_u(gvjs_tC, gvjs_$B);
gvjs_ = gvjs_tC.prototype;
gvjs_.getValue = function() {
    return this.Pe
};
gvjs_.setValue = function(a) {
    this.Pe = a;
    this.ya().setValue(this.j(), a)
};
gvjs_.Wj = function() {
    return this.sa
};
gvjs_.wi = function(a) {
    this.sa = a;
    this.ya().wi(this.j(), a)
};
gvjs_.Nv = gvjs_p(86);
gvjs_.xn = gvjs_p(87);
gvjs_.J = function() {
    gvjs_tC.G.J.call(this);
    delete this.Pe;
    delete this.sa
};
gvjs_.sb = function() {
    gvjs_tC.G.sb.call(this);
    if (gvjs_4B(this, 32)) {
        var a = this.We();
        a && this.ob().o(a, gvjs_Wt, this.xh)
    }
};
gvjs_.xh = function(a) {
    return 13 == a.keyCode && a.type == gvjs_Ut || 32 == a.keyCode && a.type == gvjs_Wt ? this.qg(a) : 32 == a.keyCode
};
gvjs_7B(gvjs_5q, function() {
    return new gvjs_tC(null)
});

function gvjs_uC(a) {
    this.EH = a
}
gvjs_Le(gvjs_uC);
gvjs_ = gvjs_uC.prototype;
gvjs_.gi = function() {
    return this.EH
};

function gvjs_vC(a, b) {
    a && (a.tabIndex = b ? 0 : -1)
}
gvjs_.F = function(a) {
    return a.fa().F(gvjs_b, this.Ti(a).join(" "))
};
gvjs_.Ga = function(a) {
    return a
};
gvjs_.Uc = gvjs_p(66);
gvjs_.ra = gvjs_p(56);
gvjs_.PM = gvjs_p(89);
gvjs_.dD = gvjs_p(91);
gvjs_.bk = function(a) {
    a = a.j();
    gvjs_6y(a, !0, gvjs_Hf);
    gvjs_x && (a.hideFocus = !0);
    var b = this.gi();
    b && gvjs_sA(a, b)
};
gvjs_.We = function(a) {
    return a.j()
};
gvjs_.ea = function() {
    return "aAAaGVIZSENTINELaAAa-container"
};
gvjs_.Ti = function(a) {
    var b = this.ea(),
        c = a.Ig() == gvjs_R;
    c = [b, c ? b + "-horizontal" : b + "-vertical"];
    a.isEnabled() || c.push(b + gvjs_qq);
    return c
};

function gvjs_wC(a, b, c) {
    gvjs_aB.call(this, c);
    this.N = b || gvjs_uC.eb();
    this.Bb = a || gvjs_S
}
gvjs_u(gvjs_wC, gvjs_aB);
gvjs_ = gvjs_wC.prototype;
gvjs_.aT = null;
gvjs_.ce = null;
gvjs_.N = null;
gvjs_.Bb = null;
gvjs_.Qa = !0;
gvjs_.nf = !0;
gvjs_.uR = !0;
gvjs_.Dc = -1;
gvjs_.bf = null;
gvjs_.cn = !1;
gvjs_.Waa = !1;
gvjs_.Ija = !0;
gvjs_.vo = null;
gvjs_.We = function() {
    return this.aT || this.N.We(this)
};
gvjs_.yJ = function() {
    return this.ce || (this.ce = new gvjs_VB(this.We()))
};
gvjs_.ya = function() {
    return this.N
};
gvjs_.MM = gvjs_p(84);
gvjs_.F = function() {
    this.O = this.N.F(this)
};
gvjs_.Ga = function() {
    return this.N.Ga(this.j())
};
gvjs_.Uc = gvjs_p(65);
gvjs_.pc = gvjs_p(74);
gvjs_.sb = function() {
    gvjs_wC.G.sb.call(this);
    gvjs_dB(this, function(c) {
        c.fb && gvjs_xC(this, c)
    }, this);
    var a = this.j();
    this.N.bk(this);
    this.setVisible(this.Qa, !0);
    var b = this.uv ? gvjs__B : gvjs_ZB;
    this.ob().o(this, "enter", this.hS).o(this, gvjs_At, this.qD).o(this, gvjs_6v, this.mS).o(this, "open", this.aga).o(this, gvjs_is, this.cS).o(a, b.Zs, this.Zd).o(gvjs_ki(a), [b.bt, b.Iw], this.sfa).o(a, [b.Zs, b.bt, b.Iw, gvjs_Dd, gvjs_Cd, gvjs_ms], this.gfa);
    this.uv && this.ob().o(a, gvjs_kt, this.CL);
    this.Sm() && gvjs_yC(this, !0)
};
gvjs_.CL = function(a) {
    var b = a.target;
    b.releasePointerCapture && b.releasePointerCapture(a.pointerId)
};

function gvjs_yC(a, b) {
    var c = a.ob(),
        d = a.We();
    b ? c.o(d, gvjs_1s, a.zr).o(d, gvjs_Pr, a.ru).o(a.yJ(), gvjs_Ut, a.Jg) : c.Ta(d, gvjs_1s, a.zr).Ta(d, gvjs_Pr, a.ru).Ta(a.yJ(), gvjs_Ut, a.Jg)
}
gvjs_.Hd = function() {
    this.jf(-1);
    this.bf && this.bf.kc(!1);
    this.cn = !1;
    gvjs_wC.G.Hd.call(this)
};
gvjs_.J = function() {
    gvjs_wC.G.J.call(this);
    this.ce && (this.ce.xa(), this.ce = null);
    this.N = this.bf = this.vo = this.aT = null
};
gvjs_.hS = function() {
    return !0
};
gvjs_.qD = function(a) {
    var b = gvjs_eB(this, a.target);
    if (-1 < b && b != this.Dc) {
        var c = gvjs_zC(this);
        c && c.Zf(!1);
        this.Dc = b;
        c = gvjs_zC(this);
        this.cn && c.setActive(!0);
        this.Ija && this.bf && c != this.bf && (gvjs_4B(c, 64) ? c.kc(!0) : this.bf.kc(!1))
    }
    b = this.j();
    null != a.target.j() && gvjs_tA(b, gvjs_jr, a.target.j().id)
};
gvjs_.mS = function(a) {
    a.target == gvjs_zC(this) && (this.Dc = -1);
    this.j().removeAttribute(gvjs_Cr)
};
gvjs_.aga = function(a) {
    (a = a.target) && a != this.bf && a.getParent() == this && (this.bf && this.bf.kc(!1), this.bf = a)
};
gvjs_.cS = function(a) {
    a.target == this.bf && (this.bf = null);
    var b = this.j(),
        c = a.target.j();
    b && gvjs_5B(a.target, 2) && c && gvjs_wA(b, c)
};
gvjs_.Zd = function(a) {
    this.nf && (this.cn = !0);
    var b = this.We();
    b && gvjs_mw(b) ? b.focus() : a.preventDefault()
};
gvjs_.sfa = function() {
    this.cn = !1
};
gvjs_.gfa = function(a) {
    var b = this.uv ? gvjs__B : gvjs_ZB;
    a: {
        var c = a.target;
        if (this.vo)
            for (var d = this.j(); c && c !== d;) {
                var e = c.id;
                if (e in this.vo) {
                    c = this.vo[e];
                    break a
                }
                c = c.parentNode
            }
        c = null
    }
    if (c) switch (a.type) {
        case b.Zs:
            c.Zd(a);
            break;
        case b.bt:
        case b.Iw:
            c.hl(a);
            break;
        case gvjs_Dd:
            c.gl(a);
            break;
        case gvjs_Cd:
            c.MJ(a);
            break;
        case gvjs_ms:
            c.pD(a)
    }
};
gvjs_.zr = function() {};
gvjs_.ru = function() {
    this.jf(-1);
    this.cn = !1;
    this.bf && this.bf.kc(!1)
};
gvjs_.Jg = function(a) {
    return this.isEnabled() && this.isVisible() && (0 != this.Cc() || this.aT) && this.xh(a) ? (a.preventDefault(), a.stopPropagation(), !0) : !1
};
gvjs_.xh = function(a) {
    var b = gvjs_zC(this);
    if (b && typeof b.Jg == gvjs_c && b.Jg(a) || this.bf && this.bf != b && typeof this.bf.Jg == gvjs_c && this.bf.Jg(a)) return !0;
    if (a.shiftKey || a.ctrlKey || a.metaKey || a.altKey) return !1;
    switch (a.keyCode) {
        case 27:
            if (this.Sm()) this.We().blur();
            else return !1;
            break;
        case 36:
            gvjs_AC(this);
            break;
        case 35:
            gvjs_Kea(this);
            break;
        case 38:
            if (this.Bb == gvjs_S) gvjs_BC(this);
            else return !1;
            break;
        case 37:
            if (this.Bb == gvjs_R) this.tf() ? gvjs_CC(this) : gvjs_BC(this);
            else return !1;
            break;
        case 40:
            if (this.Bb ==
                gvjs_S) gvjs_CC(this);
            else return !1;
            break;
        case 39:
            if (this.Bb == gvjs_R) this.tf() ? gvjs_BC(this) : gvjs_CC(this);
            else return !1;
            break;
        default:
            return !1
    }
    return !0
};

function gvjs_xC(a, b) {
    var c = b.j();
    c = c.id || (c.id = b.getId());
    a.vo || (a.vo = {});
    a.vo[c] = b
}
gvjs_.addChild = function(a, b) {
    gvjs_wC.G.addChild.call(this, a, b)
};
gvjs_.it = function(a, b, c) {
    a.iq |= 2;
    a.iq |= 64;
    !this.Sm() && this.Waa || a.we(32, !1);
    gvjs_aC(a, !1);
    var d = a.getParent() == this ? gvjs_eB(this, a) : -1;
    gvjs_wC.G.it.call(this, a, b, c);
    a.fb && this.fb && gvjs_xC(this, a);
    a = d; - 1 == a && (a = this.Cc());
    a == this.Dc ? this.Dc = Math.min(this.Cc() - 1, b) : a > this.Dc && b <= this.Dc ? this.Dc++ : a < this.Dc && b > this.Dc && this.Dc--
};
gvjs_.removeChild = function(a, b) {
    if (a = typeof a === gvjs_m ? this.Uj(a) : a) {
        var c = gvjs_eB(this, a); - 1 != c && (c == this.Dc ? (a.Zf(!1), this.Dc = -1) : c < this.Dc && this.Dc--);
        (c = a.j()) && c.id && this.vo && gvjs_xx(this.vo, c.id)
    }
    a = gvjs_wC.G.removeChild.call(this, a, b);
    gvjs_aC(a, !0);
    return a
};
gvjs_.Ig = function() {
    return this.Bb
};
gvjs_.setOrientation = function(a) {
    if (this.j()) throw Error(gvjs_Lq);
    this.Bb = a
};
gvjs_.isVisible = function() {
    return this.Qa
};
gvjs_.setVisible = function(a, b) {
    if (b || this.Qa != a && this.dispatchEvent(a ? gvjs_nv : gvjs_yt)) {
        this.Qa = a;
        var c = this.j();
        c && (gvjs_4y(c, a), this.Sm() && gvjs_vC(this.We(), this.nf && this.Qa), b || this.dispatchEvent(this.Qa ? "aftershow" : "afterhide"));
        return !0
    }
    return !1
};
gvjs_.isEnabled = function() {
    return this.nf
};
gvjs_.Sa = function(a) {
    this.nf != a && this.dispatchEvent(a ? gvjs_Ls : gvjs_Ds) && (a ? (this.nf = !0, gvjs_dB(this, function(b) {
        b.a$ ? delete b.a$ : b.Sa(!0)
    })) : (gvjs_dB(this, function(b) {
        b.isEnabled() ? b.Sa(!1) : b.a$ = !0
    }), this.cn = this.nf = !1), this.Sm() && gvjs_vC(this.We(), a && this.Qa))
};
gvjs_.Sm = function() {
    return this.uR
};
gvjs_.Bl = function(a) {
    a != this.uR && this.fb && gvjs_yC(this, a);
    this.uR = a;
    this.nf && this.Qa && gvjs_vC(this.We(), a)
};
gvjs_.jf = function(a) {
    (a = this.td(a)) ? a.Zf(!0): -1 < this.Dc && gvjs_zC(this).Zf(!1)
};
gvjs_.Zf = function(a) {
    this.jf(gvjs_eB(this, a))
};

function gvjs_zC(a) {
    return a.td(a.Dc)
}

function gvjs_AC(a) {
    gvjs_DC(a, function(b, c) {
        return (b + 1) % c
    }, a.Cc() - 1)
}

function gvjs_Kea(a) {
    gvjs_DC(a, function(b, c) {
        b--;
        return 0 > b ? c - 1 : b
    }, 0)
}

function gvjs_CC(a) {
    gvjs_DC(a, function(b, c) {
        return (b + 1) % c
    }, a.Dc)
}

function gvjs_BC(a) {
    gvjs_DC(a, function(b, c) {
        b--;
        return 0 > b ? c - 1 : b
    }, a.Dc)
}

function gvjs_DC(a, b, c) {
    c = 0 > c ? gvjs_eB(a, a.bf) : c;
    var d = a.Cc();
    c = b.call(a, c, d);
    for (var e = 0; e <= d;) {
        var f = a.td(c);
        if (f && a.H0(f)) {
            a.OV(c);
            break
        }
        e++;
        c = b.call(a, c, d)
    }
}
gvjs_.H0 = function(a) {
    return a.isVisible() && a.isEnabled() && gvjs_4B(a, 2)
};
gvjs_.OV = function(a) {
    this.jf(a)
};

function gvjs_EC() {}
gvjs_u(gvjs_EC, gvjs_0B);
gvjs_Le(gvjs_EC);
gvjs_EC.prototype.ea = function() {
    return gvjs_ar
};

function gvjs_FC(a, b, c) {
    gvjs_$B.call(this, a, c || gvjs_EC.eb(), b);
    this.we(1, !1);
    this.we(2, !1);
    this.we(4, !1);
    this.we(32, !1);
    this.V = 1
}
gvjs_u(gvjs_FC, gvjs_$B);
gvjs_7B(gvjs_ar, function() {
    return new gvjs_FC(null)
});

function gvjs_GC() {}
gvjs_u(gvjs_GC, gvjs_0B);
gvjs_Le(gvjs_GC);
gvjs_GC.prototype.F = function(a) {
    return a.fa().F(gvjs_b, this.ea())
};
gvjs_GC.prototype.ra = gvjs_p(55);
gvjs_GC.prototype.setContent = function() {};
gvjs_GC.prototype.ea = function() {
    return gvjs_br
};

function gvjs_HC(a, b) {
    gvjs_$B.call(this, null, a || gvjs_GC.eb(), b);
    this.we(1, !1);
    this.we(2, !1);
    this.we(4, !1);
    this.we(32, !1);
    this.V = 1
}
gvjs_u(gvjs_HC, gvjs_$B);
gvjs_HC.prototype.sb = function() {
    gvjs_HC.G.sb.call(this);
    var a = this.j();
    gvjs_sA(a, gvjs_hv)
};
gvjs_7B(gvjs_br, function() {
    return new gvjs_HC
});

function gvjs_IC(a) {
    this.EH = a || "menu"
}
gvjs_u(gvjs_IC, gvjs_uC);
gvjs_Le(gvjs_IC);
gvjs_ = gvjs_IC.prototype;
gvjs_.Uc = gvjs_p(64);
gvjs_.dD = gvjs_p(90);
gvjs_.yo = function(a, b) {
    return gvjs_Hi(a.j(), b)
};
gvjs_.ea = function() {
    return gvjs_V
};
gvjs_.bk = function(a) {
    gvjs_IC.G.bk.call(this, a);
    a = a.j();
    gvjs_tA(a, gvjs_vt, gvjs_fe)
};
gvjs_7B(gvjs_br, function() {
    return new gvjs_HC
});

function gvjs_JC(a, b) {
    gvjs_wC.call(this, gvjs_S, b || gvjs_IC.eb(), a);
    this.Bl(!1)
}
gvjs_u(gvjs_JC, gvjs_wC);
gvjs_ = gvjs_JC.prototype;
gvjs_.vB = !0;
gvjs_.N_ = !1;
gvjs_.ea = function() {
    return this.ya().ea()
};
gvjs_.yo = function(a) {
    if (this.ya().yo(this, a)) return !0;
    for (var b = 0, c = this.Cc(); b < c; b++) {
        var d = this.td(b);
        if (typeof d.yo == gvjs_c && d.yo(a)) return !0
    }
    return !1
};
gvjs_.jh = function(a) {
    this.addChild(a, !0)
};
gvjs_.Cq = function(a, b) {
    this.it(a, b, !0)
};
gvjs_.removeItem = function(a) {
    (a = this.removeChild(a, !0)) && a.xa()
};
gvjs_.bc = function(a) {
    return this.td(a)
};
gvjs_.pf = function() {
    return this.Cc()
};
gvjs_.mu = function() {
    var a = [];
    gvjs_dB(this, function(b) {
        a.push(b)
    });
    return a
};
gvjs_.setPosition = function(a, b) {
    var c = this.isVisible();
    c || gvjs_4y(this.j(), !0);
    var d = this.j(),
        e = gvjs_Uy(d);
    a instanceof gvjs_A && (b = a.y, a = a.x);
    gvjs_Ry(d, d.offsetLeft + (a - e.x), d.offsetTop + (Number(b) - e.y));
    c || gvjs_4y(this.j(), !1)
};
gvjs_.getPosition = function() {
    return this.isVisible() ? gvjs_Uy(this.j()) : null
};
gvjs_.setVisible = function(a, b, c) {
    (b = gvjs_JC.G.setVisible.call(this, a, b)) && a && this.fb && this.vB && this.We().focus();
    this.a7 = a && c && typeof c.clientX === gvjs_f ? new gvjs_A(c.clientX, c.clientY) : null;
    return b
};
gvjs_.hS = function(a) {
    this.vB && this.We().focus();
    return gvjs_JC.G.hS.call(this, a)
};
gvjs_.H0 = function(a) {
    return (this.N_ || a.isEnabled()) && a.isVisible() && gvjs_4B(a, 2)
};
gvjs_.pc = gvjs_p(73);
gvjs_.xh = function(a) {
    var b = gvjs_JC.G.xh.call(this, a);
    b || gvjs_dB(this, function(c) {
        !b && c.tea && c.VT == a.keyCode && (this.isEnabled() && this.Zf(c), b = c.Jg(a))
    }, this);
    return b
};
gvjs_.jf = function(a) {
    gvjs_JC.G.jf.call(this, a);
    (a = this.td(a)) && gvjs_7y(a.j(), this.j())
};

function gvjs_KC() {}
gvjs_u(gvjs_KC, gvjs_rC);
gvjs_Le(gvjs_KC);
gvjs_ = gvjs_KC.prototype;
gvjs_.F = function(a) {
    var b = this.Ti(a);
    b = a.fa().F(gvjs_b, gvjs_9q + b.join(" "), this.qI(a.getContent(), a.fa()));
    this.wi(b, a.Wj());
    return b
};
gvjs_.gi = function() {
    return gvjs_Zr
};
gvjs_.Ga = function(a) {
    return a && a.firstChild && a.firstChild.firstChild
};
gvjs_.qI = function(a, b) {
    return b.F(gvjs_b, gvjs_9q + (this.ea() + gvjs_tq), b.F(gvjs_b, gvjs_9q + (this.ea() + gvjs_sq), a))
};
gvjs_.Uc = gvjs_p(63);
gvjs_.ra = gvjs_p(54);
gvjs_.ea = function() {
    return gvjs_8q
};

function gvjs_LC() {}
gvjs_u(gvjs_LC, gvjs_KC);
gvjs_Le(gvjs_LC);
gvjs_ = gvjs_LC.prototype;
gvjs_.Ga = function(a) {
    return gvjs_LC.G.Ga.call(this, a && a.firstChild)
};
gvjs_.ra = gvjs_p(53);
gvjs_.qI = function(a, b) {
    return gvjs_LC.G.qI.call(this, [this.createCaption(a, b), this.sI(b)], b)
};
gvjs_.createCaption = function(a, b) {
    return gvjs_MC(a, this.ea(), b)
};

function gvjs_MC(a, b, c) {
    return c.F(gvjs_b, gvjs_9q + (b + gvjs_nq), a)
}
gvjs_.sI = function(a) {
    return a.F(gvjs_b, gvjs_9q + (this.ea() + gvjs_rq), "\u00a0")
};
gvjs_.ea = function() {
    return gvjs_$q
};

function gvjs_NC() {
    this.TP = []
}
gvjs_u(gvjs_NC, gvjs_iC);
gvjs_Le(gvjs_NC);
gvjs_NC.prototype.F = function(a) {
    var b = gvjs_NC.G.F.call(this, a);
    gvjs_jB(b, gvjs_fr);
    gvjs_OC(this, a, b);
    return b
};
gvjs_NC.prototype.ra = gvjs_p(52);
gvjs_NC.prototype.setContent = function(a, b) {
    var c = this.Ga(a),
        d = c && c.lastChild;
    gvjs_NC.G.setContent.call(this, a, b);
    d && c.lastChild != d && gvjs_iB(d, gvjs_gr) && c.appendChild(d)
};
gvjs_NC.prototype.bk = function(a) {
    gvjs_NC.G.bk.call(this, a);
    var b = a.Ga(),
        c = gvjs_Pi(a.fa(), gvjs_ab, gvjs_gr, b)[0];
    gvjs_PC(a, c);
    c != b.lastChild && b.appendChild(c);
    a = a.j();
    gvjs_tA(a, gvjs_vt, gvjs_fe)
};

function gvjs_OC(a, b, c) {
    var d = b.fa().F(gvjs_ab);
    d.className = gvjs_gr;
    gvjs_PC(b, d);
    a.Ga(c).appendChild(d)
}

function gvjs_PC(a, b) {
    a.tf() ? (gvjs_jB(b, gvjs_hr), gvjs_Ji(b, a.xH ? "\u25c4" : "\u25ba")) : (gvjs_lB(b, gvjs_hr), gvjs_Ji(b, a.xH ? "\u25ba" : "\u25c4"))
};

function gvjs_QC(a, b, c, d) {
    gvjs_nC.call(this, a, b, c, d || gvjs_NC.eb())
}
gvjs_u(gvjs_QC, gvjs_nC);
gvjs_ = gvjs_QC.prototype;
gvjs_.ym = null;
gvjs_.eW = null;
gvjs_.IT = !1;
gvjs_.Ef = null;
gvjs_.eJ = !1;
gvjs_.xH = !0;
gvjs_.Eha = !1;
gvjs_.sb = function() {
    gvjs_QC.G.sb.call(this);
    this.ob().o(this.getParent(), gvjs_yt, this.V6);
    this.Ef && gvjs_RC(this, this.Ef, !0)
};
gvjs_.Hd = function() {
    this.ob().Ta(this.getParent(), gvjs_yt, this.V6);
    this.Ef && (gvjs_RC(this, this.Ef, !1), this.eJ || (this.Ef.Hd(), gvjs_Ai(this.Ef.j())));
    gvjs_QC.G.Hd.call(this)
};
gvjs_.J = function() {
    this.Ef && !this.eJ && this.Ef.xa();
    this.Ef = null;
    gvjs_QC.G.J.call(this)
};
gvjs_.Zf = function(a) {
    gvjs_QC.G.Zf.call(this, a);
    a || (this.ym && gvjs_zl(this.ym), this.ym = gvjs_yl(this.Jo, 218, this))
};
gvjs_.XM = function() {
    var a = this.getParent();
    a && gvjs_zC(a) == this && (gvjs_SC(this, !0), gvjs_TC(this))
};
gvjs_.Jo = function() {
    var a = this.Ef;
    a && a.getParent() == this && (gvjs_SC(this, !1), gvjs_dB(a, function(b) {
        typeof b.Jo == gvjs_c && b.Jo()
    }))
};

function gvjs_UC(a) {
    a.ym && gvjs_zl(a.ym);
    a.eW && gvjs_zl(a.eW)
}
gvjs_.setVisible = function(a, b) {
    (a = gvjs_QC.G.setVisible.call(this, a, b)) && !this.isVisible() && this.Jo();
    return a
};

function gvjs_TC(a) {
    gvjs_dB(a.getParent(), function(b) {
        b != this && typeof b.Jo == gvjs_c && (b.Jo(), gvjs_UC(b))
    }, a)
}
gvjs_.Jg = function(a) {
    var b = a.keyCode,
        c = this.tf() ? 37 : 39,
        d = this.tf() ? 39 : 37;
    if (!this.IT) {
        if (!this.isEnabled() || b != c && 13 != b && b != this.VT) return !1;
        this.XM();
        gvjs_AC(this.qc());
        gvjs_UC(this)
    } else if (!this.qc().Jg(a))
        if (b == d) this.Jo();
        else return !1;
    a.preventDefault();
    return !0
};
gvjs_.rja = function() {
    this.Ef.getParent() == this && (gvjs_UC(this), this.jy().Zf(this), gvjs_TC(this))
};
gvjs_.V6 = function(a) {
    a.target == this.jy() && (this.Jo(), gvjs_UC(this))
};
gvjs_.gl = function(a) {
    this.isEnabled() && (gvjs_UC(this), this.eW = gvjs_yl(this.XM, 218, this));
    gvjs_QC.G.gl.call(this, a)
};
gvjs_.qg = function(a) {
    gvjs_UC(this);
    if (gvjs_4B(this, 8) || gvjs_4B(this, 16)) return gvjs_QC.G.qg.call(this, a);
    this.XM();
    return !0
};

function gvjs_SC(a, b) {
    !b && a.qc() && a.qc().jf(-1);
    a.dispatchEvent(gvjs_bB(64, b));
    var c = a.qc();
    b != a.IT && gvjs_nB(a.j(), "aAAaGVIZSENTINELaAAa-submenu-open", b);
    if (b != c.isVisible() && (b && (c.fb || c.K(), c.jf(-1)), c.setVisible(b), b)) {
        c = new gvjs_oC(a.j(), a.xH ? 12 : 8, a.Eha);
        var d = a.qc(),
            e = d.j();
        d.isVisible() || (e.style.visibility = gvjs_kd, gvjs_4y(e, !0));
        c.ge(e, a.xH ? 8 : 12);
        d.isVisible() || (gvjs_4y(e, !1), e.style.visibility = gvjs_hw)
    }
    a.IT = b
}

function gvjs_RC(a, b, c) {
    var d = a.ob();
    (c ? d.o : d.Ta).call(d, b, "enter", a.rja)
}
gvjs_.jh = function(a) {
    this.qc().addChild(a, !0)
};
gvjs_.Cq = function(a, b) {
    this.qc().it(a, b, !0)
};
gvjs_.removeItem = function(a) {
    (a = this.qc().removeChild(a, !0)) && a.xa()
};
gvjs_.bc = function(a) {
    return this.qc().td(a)
};
gvjs_.pf = function() {
    return this.qc().Cc()
};
gvjs_.mu = function() {
    return this.qc().mu()
};
gvjs_.qc = function() {
    this.Ef ? this.eJ && this.Ef.getParent() != this && this.Ef.Kv(this) : this.Dl(new gvjs_JC(this.fa()), !0);
    this.Ef.j() || this.Ef.F();
    return this.Ef
};
gvjs_.Dl = function(a, b) {
    var c = this.Ef;
    a != c && (c && (this.Jo(), this.fb && gvjs_RC(this, c, !1)), this.Ef = a, this.eJ = !b, a && (a.Kv(this), a.setVisible(!1, !0), a.vB = !1, a.Bl(!1), this.fb && gvjs_RC(this, a, !0)))
};
gvjs_.yo = function(a) {
    return this.qc().yo(a)
};
gvjs_7B(gvjs_fr, function() {
    return new gvjs_QC(null)
});

function gvjs_VC(a, b, c, d, e) {
    gvjs_tC.call(this, a, c || gvjs_LC.eb(), d);
    this.we(64, !0);
    this.QK = new gvjs_qC(null, 9);
    b && this.Dl(b);
    this.wia = null;
    this.gd = new gvjs_az(500);
    this.Zba = !0;
    this.xia = e || gvjs_IC.eb()
}
gvjs_u(gvjs_VC, gvjs_tC);
gvjs_ = gvjs_VC.prototype;
gvjs_.VD = !1;
gvjs_.uka = !1;
gvjs_.bla = !1;
gvjs_.sb = function() {
    gvjs_VC.G.sb.call(this);
    gvjs_WC(this, !0);
    this.Z && gvjs_XC(this, this.Z, !0);
    gvjs_tA(this.O, gvjs_vt, !!this.Z)
};
gvjs_.Hd = function() {
    gvjs_VC.G.Hd.call(this);
    gvjs_WC(this, !1);
    if (this.Z) {
        this.kc(!1);
        this.Z.Hd();
        gvjs_XC(this, this.Z, !1);
        var a = this.Z.j();
        a && gvjs_Ai(a)
    }
};
gvjs_.J = function() {
    gvjs_VC.G.J.call(this);
    this.Z && (this.Z.xa(), delete this.Z);
    delete this.cka;
    this.gd.xa()
};
gvjs_.Zd = function(a) {
    gvjs_VC.G.Zd.call(this, a);
    this.isActive() && (this.kc(!gvjs_5B(this, 64), a), this.Z && (this.Z.cn = gvjs_5B(this, 64)))
};
gvjs_.hl = function(a) {
    gvjs_VC.G.hl.call(this, a);
    this.Z && !this.isActive() && (this.Z.cn = !1)
};
gvjs_.qg = function() {
    this.setActive(!1);
    return !0
};
gvjs_.qfa = function(a) {
    this.Z && this.Z.isVisible() && !this.yo(a.target) && this.kc(!1)
};
gvjs_.yo = function(a) {
    return a && gvjs_Hi(this.j(), a) || this.Z && this.Z.yo(a) || !1
};
gvjs_.xh = function(a) {
    if (32 == a.keyCode) {
        if (a.preventDefault(), a.type != gvjs_Wt) return !0
    } else if (a.type != gvjs_Ut) return !1;
    if (this.Z && this.Z.isVisible()) {
        var b = 13 == a.keyCode || 32 == a.keyCode,
            c = this.Z.Jg(a);
        return c && this.Z && this.Z.bf instanceof gvjs_QC || !(27 == a.keyCode || b && this.Zba) ? c : (this.kc(!1), !0)
    }
    return 40 == a.keyCode || 38 == a.keyCode || 32 == a.keyCode || 13 == a.keyCode ? (this.kc(!0, a), !0) : !1
};
gvjs_.su = function() {
    this.kc(!1)
};
gvjs_.Sfa = function() {
    this.isActive() || this.kc(!1)
};
gvjs_.ru = function(a) {
    this.VD || this.kc(!1);
    gvjs_VC.G.ru.call(this, a)
};
gvjs_.qc = function() {
    this.Z || this.Dl(new gvjs_JC(this.fa(), this.xia));
    return this.Z || null
};
gvjs_.Dl = function(a) {
    var b = this.Z;
    if (a != b && (b && (this.kc(!1), this.fb && gvjs_XC(this, b, !1), delete this.Z), this.fb && gvjs_tA(this.O, gvjs_vt, !!a), a)) {
        this.Z = a;
        a.Kv(this);
        a.setVisible(!1);
        var c = this.VD;
        (a.vB = c) && a.Bl(!0);
        this.fb && gvjs_XC(this, a, !0)
    }
    return b
};
gvjs_.jh = function(a) {
    this.qc().addChild(a, !0)
};
gvjs_.Cq = function(a, b) {
    this.qc().it(a, b, !0)
};
gvjs_.removeItem = function(a) {
    (a = this.qc().removeChild(a, !0)) && a.xa()
};
gvjs_.bc = function(a) {
    return this.Z ? this.Z.td(a) : null
};
gvjs_.pf = function() {
    return this.Z ? this.Z.Cc() : 0
};
gvjs_.setVisible = function(a, b) {
    (a = gvjs_VC.G.setVisible.call(this, a, b)) && !this.isVisible() && this.kc(!1);
    return a
};
gvjs_.Sa = function(a) {
    gvjs_VC.G.Sa.call(this, a);
    this.isEnabled() || this.kc(!1)
};
gvjs_.aW = gvjs_p(92);
gvjs_.Dr = gvjs_p(93);
gvjs_.kc = function(a, b) {
    gvjs_VC.G.kc.call(this, a);
    if (this.Z && gvjs_5B(this, 64) == a) {
        if (a) {
            if (!this.Z.fb)
                if (this.uka) {
                    var c = gvjs_Ei(this.j());
                    c ? gvjs_cB(this.Z, c.parentNode, c) : this.Z.K(this.j().parentNode)
                } else this.Z.K();
            this.HN = gvjs_Vy(this.j());
            this.A0 = gvjs_2y(this.j());
            this.AL();
            c = !!b && (13 == b.keyCode || 32 == b.keyCode);
            b && (40 == b.keyCode || 38 == b.keyCode) || c && this.bla ? gvjs_AC(this.Z) : this.Z.jf(-1)
        } else {
            this.setActive(!1);
            this.Z.cn = !1;
            if (c = this.j()) gvjs_tA(c, gvjs_jr, ""), gvjs_tA(c, "owns", "");
            null != this.qL &&
                (this.qL = void 0, (c = this.Z.j()) && gvjs_0y(c, "", ""))
        }
        this.Z.setVisible(a, !1, b);
        this.Ue || (b = this.ob(), c = a ? b.o : b.Ta, c.call(b, this.fa().Hb(), gvjs_pu, this.qfa, !0), this.VD && c.call(b, this.Z, gvjs_Pr, this.Sfa), c.call(b, this.gd, gvjs_Qv, this.Fja), a ? this.gd.start() : this.gd.stop())
    }
    this.Z && this.Z.j() && this.Z.O.removeAttribute(gvjs_Bb)
};
gvjs_.AL = function() {
    if (this.Z.fb) {
        var a = this.cka || this.j(),
            b = this.QK;
        this.QK.element = a;
        a = this.Z.j();
        this.Z.isVisible() || (a.style.visibility = gvjs_kd, gvjs_4y(a, !0));
        !this.qL && this.QK.sea && this.QK.CK & 32 && (this.qL = gvjs_1y(a));
        b.ge(a, b.jC ^ 1, this.wia, this.qL);
        this.Z.isVisible() || (gvjs_4y(a, !1), a.style.visibility = gvjs_hw)
    }
};
gvjs_.Fja = function() {
    var a = gvjs_2y(this.j()),
        b = gvjs_Vy(this.j()),
        c;
    (c = !gvjs_My(this.A0, a)) || (c = this.HN, c = !(c == b || c && b && c.top == b.top && c.right == b.right && c.bottom == b.bottom && c.left == b.left));
    c && (this.Z.fb && b && this.HN && b.pb() < this.HN.pb() && (c = this.Z.j(), this.Z.isVisible() || (c.style.visibility = gvjs_kd, gvjs_4y(c, !0)), gvjs_Ry(c, new gvjs_A(0, 0))), this.A0 = a, this.HN = b, this.AL())
};

function gvjs_XC(a, b, c) {
    var d = a.ob();
    c = c ? d.o : d.Ta;
    c.call(d, b, gvjs_ir, a.su);
    c.call(d, b, gvjs_is, a.cS);
    c.call(d, b, gvjs_At, a.qD);
    c.call(d, b, gvjs_6v, a.mS)
}

function gvjs_WC(a, b) {
    var c = a.ob();
    (b ? c.o : c.Ta).call(c, a.j(), gvjs_Vt, a.Gfa)
}
gvjs_.qD = function(a) {
    (a = a.target.j()) && gvjs_YC(this, a)
};
gvjs_.Gfa = function(a) {
    gvjs_4B(this, 32) && this.We() && this.Z && this.Z.isVisible() && a.stopPropagation()
};
gvjs_.mS = function() {
    if (!gvjs_zC(this.Z)) {
        var a = this.j();
        gvjs_tA(a, gvjs_jr, "");
        gvjs_tA(a, "owns", "")
    }
};
gvjs_.cS = function(a) {
    if (gvjs_5B(this, 64) && a.target instanceof gvjs_nC) {
        a = a.target;
        var b = a.j();
        a.isVisible() && gvjs_5B(a, 2) && null != b && gvjs_YC(this, b)
    }
};

function gvjs_YC(a, b) {
    a = a.j();
    b = gvjs_vA(b) || b;
    if (!b.id) {
        var c = gvjs_9A.eb();
        b.id = gvjs_$A(c)
    }
    gvjs_wA(a, b);
    gvjs_tA(a, "owns", b.id)
}
gvjs_7B(gvjs_$q, function() {
    return new gvjs_VC(null)
});

function gvjs_ZC(a) {
    gvjs_7k.call(this);
    this.Um = [];
    gvjs__C(this, a)
}
gvjs_u(gvjs_ZC, gvjs_7k);
gvjs_ = gvjs_ZC.prototype;
gvjs_.Tp = null;
gvjs_.rM = null;
gvjs_.pf = function() {
    return this.Um.length
};
gvjs_.bc = function(a) {
    return this.Um[a] || null
};

function gvjs__C(a, b) {
    b && (b.forEach(function(c) {
        this.Kz(c, !1)
    }, a), gvjs_xf(a.Um, b))
}
gvjs_.jh = function(a) {
    this.Cq(a, this.pf())
};
gvjs_.Cq = function(a, b) {
    a && (this.Kz(a, !1), gvjs_bx(this.Um, a, b))
};
gvjs_.removeItem = function(a) {
    a && gvjs_uf(this.Um, a) && a == this.Tp && (this.Tp = null, this.dispatchEvent(gvjs_k))
};
gvjs_.cd = function() {
    return this.Tp
};
gvjs_.mu = function() {
    return gvjs_wf(this.Um)
};
gvjs_.ti = function(a) {
    a != this.Tp && (this.Kz(this.Tp, !1), this.Tp = a, this.Kz(a, !0));
    this.dispatchEvent(gvjs_k)
};
gvjs_.Vi = function() {
    var a = this.Tp;
    return a ? this.Um.indexOf(a) : -1
};
gvjs_.Mh = function(a) {
    this.ti(this.bc(a))
};
gvjs_.clear = function() {
    gvjs_$w(this.Um);
    this.Tp = null
};
gvjs_.J = function() {
    gvjs_ZC.G.J.call(this);
    delete this.Um;
    this.Tp = null
};
gvjs_.Kz = function(a, b) {
    a && (typeof this.rM == gvjs_c ? this.rM(a, b) : typeof a.Fl == gvjs_c && a.Fl(b))
};

function gvjs_0C(a, b, c, d, e) {
    gvjs_VC.call(this, a, b, c, d, e || new gvjs_IC("listbox"));
    this.DI = this.getContent();
    this.AS = null;
    this.RV("listbox")
}
gvjs_u(gvjs_0C, gvjs_VC);
gvjs_ = gvjs_0C.prototype;
gvjs_.ia = null;
gvjs_.sb = function() {
    gvjs_0C.G.sb.call(this);
    gvjs_1C(this);
    gvjs_2C(this)
};
gvjs_.pc = gvjs_p(72);
gvjs_.J = function() {
    gvjs_0C.G.J.call(this);
    this.ia && (this.ia.xa(), this.ia = null);
    this.DI = null
};
gvjs_.su = function(a) {
    this.ti(a.target);
    gvjs_0C.G.su.call(this, a);
    a.stopPropagation();
    this.dispatchEvent(gvjs_ir)
};
gvjs_.lS = function() {
    var a = this.cd();
    gvjs_0C.G.setValue.call(this, a && a.getValue());
    gvjs_1C(this)
};
gvjs_.Dl = function(a) {
    var b = gvjs_0C.G.Dl.call(this, a);
    a != b && (this.ia && this.ia.clear(), a && (this.ia ? gvjs_dB(a, function(c) {
        gvjs_3C(c);
        this.ia.jh(c)
    }, this) : gvjs_4C(this, a)));
    return b
};
gvjs_.jh = function(a) {
    gvjs_3C(a);
    gvjs_0C.G.jh.call(this, a);
    this.ia ? this.ia.jh(a) : gvjs_4C(this, this.qc());
    gvjs_5C(this)
};
gvjs_.Cq = function(a, b) {
    gvjs_3C(a);
    gvjs_0C.G.Cq.call(this, a, b);
    this.ia ? this.ia.Cq(a, b) : gvjs_4C(this, this.qc())
};
gvjs_.removeItem = function(a) {
    gvjs_0C.G.removeItem.call(this, a);
    this.ia && this.ia.removeItem(a)
};
gvjs_.ti = function(a) {
    if (this.ia) {
        var b = this.cd();
        this.ia.ti(a);
        a != b && this.dispatchEvent(gvjs_6r)
    }
};
gvjs_.Mh = function(a) {
    this.ia && this.ti(this.ia.bc(a))
};
gvjs_.setValue = function(a) {
    if (null != a && this.ia)
        for (var b = 0, c; c = this.ia.bc(b); b++)
            if (c && typeof c.getValue == gvjs_c && c.getValue() == a) {
                this.ti(c);
                return
            }
    this.ti(null)
};
gvjs_.getValue = function() {
    var a = this.cd();
    return a ? a.getValue() : null
};
gvjs_.cd = function() {
    return this.ia ? this.ia.cd() : null
};
gvjs_.Vi = function() {
    return this.ia ? this.ia.Vi() : -1
};

function gvjs_4C(a, b) {
    a.ia = new gvjs_ZC;
    b && gvjs_dB(b, function(c) {
        gvjs_3C(c);
        this.ia.jh(c)
    }, a);
    gvjs_2C(a)
}

function gvjs_2C(a) {
    a.ia && a.ob().o(a.ia, gvjs_k, a.lS)
}

function gvjs_1C(a) {
    var b = a.cd();
    a.setContent(b ? b.Gg() : a.DI);
    var c = a.ya().Ga(a.j());
    c && a.fa().NS(c) && (null == a.AS && (a.AS = gvjs_xA(c)), b = b ? b.j() : null, gvjs_yA(c, b ? gvjs_xA(b) : a.AS), gvjs_5C(a))
}

function gvjs_5C(a) {
    var b = a.ya();
    if (b && (b = b.Ga(a.j()))) {
        var c = a.O;
        b.id || (b.id = gvjs_$A(gvjs_9A.eb()));
        gvjs_sA(b, "option");
        gvjs_tA(b, gvjs__d, !0);
        gvjs_tA(c, gvjs_jr, b.id);
        a.ia && (c = a.ia.mu(), gvjs_tA(b, "setsize", gvjs_6C(c)), a = a.ia.Vi(), gvjs_tA(b, "posinset", 0 <= a ? gvjs_6C(c.slice(0, a + 1)) : 0))
    }
}

function gvjs_6C(a) {
    return a.filter(function(b) {
        return b instanceof gvjs_nC
    }).length
}

function gvjs_3C(a) {
    a.RV(a instanceof gvjs_nC ? "option" : gvjs_hv)
}
gvjs_.kc = function(a, b) {
    gvjs_0C.G.kc.call(this, a, b);
    gvjs_5B(this, 64) ? this.qc().jf(this.Vi()) : gvjs_5C(this)
};
gvjs_7B(gvjs_er, function() {
    return new gvjs_0C(null)
});

function gvjs_7C(a, b) {
    this.C = gvjs_fk();
    this.nb = a;
    this.G0 = [];
    this.th(b)
}

function gvjs_8C(a, b) {
    var c = gvjs_fk(),
        d = gvjs_Fh,
        e = null;
    switch (a) {
        case 2:
            var f = new gvjs_FB("google-visualization-toolbar-small-dialog");
            e = gvjs_1u + f.getId();
            d = gvjs_Dh(gvjs_Ah(gvjs_5b, {
                "class": gvjs_it
            }, gvjs_Mq), gvjs_Gh, gvjs_Ah("pre", {}, gvjs_Ah(gvjs_5b, {
                id: e
            }, b.message)));
            break;
        case 3:
            f = new gvjs_FB("google-visualization-toolbar-big-dialog"), d = gvjs_Dh(gvjs_Ah(gvjs_5b, {
                "class": gvjs_it
            }, gvjs_Mq), gvjs_Gh, gvjs_Ah(gvjs_5b, {}, gvjs_Ah("pre", {}, b.message)))
    }
    gvjs_JB(f, d);
    a = f;
    gvjs_KB(a);
    gvjs_Ji(a.Oh, "Google Visualization");
    a = f;
    gvjs_KB(a);
    gvjs_xi(a.If);
    f.setVisible(!0);
    e && (c = f = c.j(e), e = 0, a = 1, b = new gvjs_7A, b.Og = gvjs_yea(c, e, f, a), gvjs_Fi(c) && !gvjs_vi(c) && (d = c.parentNode, e = Array.prototype.indexOf.call(d.childNodes, c), c = d), gvjs_Fi(f) && !gvjs_vi(f) && (d = f.parentNode, a = Array.prototype.indexOf.call(d.childNodes, f), f = d), b.Og ? (b.lf = f, b.bg = a, b.Be = c, b.Nf = e) : (b.lf = c, b.bg = e, b.Be = f, b.Nf = a), b.select())
}
gvjs_7C.prototype.th = function(a) {
    var b = this;
    a = a || [];
    var c = this.nb,
        d = this.C;
    d.xb(c);
    if (!c) throw Error(gvjs_Aa);
    var e = d.F(gvjs_ab, null),
        f = [d.F(gvjs_ab, null, "Chart options")];
    this.Iz = new gvjs_0C(f);
    if (a)
        for (f = 0; f < a.length; f++) {
            var g = null;
            g = a[f];
            var h = g.datasource,
                k = g.gadget,
                l = g.userprefs,
                m = g.visualization,
                n = g["package"],
                p = g.style || "width: 700px; height: 500px;";
            switch (g.type) {
                case "csv":
                    g = gvjs_9C(this, f, function() {
                            gvjs_Ex((new gvjs_En(h)).lc("tqx", "out:csv;").toString(), window, gvjs_2g(gvjs_Qq));
                            return (void 0)()
                        },
                        "Export data as CSV");
                    break;
                case "htmlcode":
                    g = gvjs_9C(this, f, function() {
                        var q = h;
                        q = '<iframe style="' + p + '" src="http://www.google.com/ig/ifr?url=' + encodeURIComponent(k) + gvjs_mq + encodeURIComponent(q) + gvjs_$C(l) + '" />';
                        gvjs_8C(2, {
                            message: q
                        });
                        return (void 0)()
                    }, "Publish to web page");
                    break;
                case "jscode":
                    g = gvjs_9C(this, f, function() {
                            var q = h,
                                r = m;
                            q = '<html>\n <head>\n  <title>Google Visualization API</title>\n  <script type="text/javascript" src="https://www.google.com/jsapi">\x3c/script>\n  <script type="text/javascript">\n   google.load(\'visualization\', \'1\', {packages: [\'' +
                                encodeURIComponent(n) + "']});\n\n   function drawVisualization() {\n    new google.visualization.Query('" + q + "').send(\n     function(response) {\n      new " + encodeURIComponent(r) + '(\n       document.getElementById(\'visualization\')).\n        draw(response.getDataTable(), null);\n      });\n   }\n\n   google.setOnLoadCallback(drawVisualization);\n  \x3c/script>\n </head>\n <body>\n  <div id="visualization" style="width: 500px; height: 500px;"></div>\n </body>\n</html>';
                            gvjs_8C(3, {
                                message: q
                            });
                            return (void 0)()
                        },
                        "Javascript code");
                    break;
                case gvjs_It:
                    g = gvjs_9C(this, f, function() {
                        gvjs_Ex((new gvjs_En(h)).lc("tqx", "out:html;").toString(), window, gvjs_2g(gvjs_Qq));
                        return (void 0)()
                    }, "Export data as HTML");
                    break;
                case "igoogle":
                    g = gvjs_9C(this, f, function() {
                        var q = h,
                            r = l;
                        gvjs_Ex("http://www.google.com/ig/adde?moduleurl=" + encodeURIComponent(k) + gvjs_mq + encodeURIComponent(q) + gvjs_$C(r));
                        return (void 0)()
                    }, "Add to iGoogle");
                    break;
                default:
                    throw Error("No such toolbar component as: " + g.toSource());
            }
            g && this.Iz.jh(g)
        }
    gvjs_M(this.Iz,
        gvjs_ir,
        function() {
            var q = b.Iz.Vi();
            b.G0[q]();
            b.Iz.Mh(-1)
        });
    this.Iz.K(e);
    d.appendChild(c, e)
};

function gvjs_9C(a, b, c, d) {
    d = new gvjs_nC(d);
    a.G0[b] = c;
    return d
}

function gvjs_$C(a) {
    if (!a) return "";
    var b = "",
        c;
    for (c in a) b += "&up_" + c + "=" + encodeURIComponent(a[c]);
    return b
}
gvjs_7C.prototype.Iz = null;

function gvjs_aD() {}
gvjs_u(gvjs_aD, gvjs_0B);
gvjs_Le(gvjs_aD);
gvjs_aD.prototype.F = function(a) {
    var b = a.fa().F(gvjs_ab, this.Ti(a).join(" "));
    gvjs_bD(this, b, a.o3());
    return b
};
gvjs_aD.prototype.ra = gvjs_p(51);
gvjs_aD.prototype.gi = function() {
    return gvjs_ds
};

function gvjs_bD(a, b, c) {
    if (b) {
        var d = gvjs_cD(a, c);
        gvjs_iB(b, d) || (gvjs_y(gvjs_Lea, function(e) {
            e = gvjs_cD(this, e);
            gvjs_nB(b, e, e == d)
        }, a), gvjs_tA(b, gvjs_Pb, null == c ? "mixed" : 1 == c ? gvjs_fe : gvjs_8b))
    }
}
gvjs_aD.prototype.ea = function() {
    return gvjs_6q
};

function gvjs_cD(a, b) {
    a = a.ea();
    if (1 == b) return a + "-checked";
    if (0 == b) return a + "-unchecked";
    if (null == b) return a + "-undetermined";
    throw Error("Invalid checkbox state: " + b);
};

function gvjs_dD(a, b, c) {
    c = c || gvjs_aD.eb();
    gvjs_$B.call(this, null, c, b);
    this.uo = void 0 !== a ? a : !1
}
gvjs_u(gvjs_dD, gvjs_$B);
var gvjs_Lea = {
    Zna: !0,
    zpa: !1,
    Apa: null
};
gvjs_ = gvjs_dD.prototype;
gvjs_.tb = null;
gvjs_.o3 = function() {
    return this.uo
};
gvjs_.ck = function() {
    return 1 == this.uo
};
gvjs_.Wg = function(a) {
    a != this.uo && (this.uo = a, gvjs_bD(this.ya(), this.j(), this.uo))
};
gvjs_.mj = gvjs_p(95);
gvjs_.toggle = function() {
    this.Wg(this.uo ? !1 : !0)
};
gvjs_.sb = function() {
    gvjs_dD.G.sb.call(this);
    if (this.LJ) {
        var a = this.ob();
        this.tb && a.o(this.tb, gvjs_fs, this.bS).o(this.tb, gvjs_Dd, this.gl).o(this.tb, gvjs_Cd, this.MJ).o(this.tb, gvjs_pu, this.Zd).o(this.tb, gvjs_tu, this.hl);
        a.o(this.j(), gvjs_fs, this.bS)
    }
    a = this.O;
    this.tb && a != this.tb && gvjs_1e(gvjs_xA(a)) && (this.tb.id || (this.tb.id = this.getId() + ".lbl"), gvjs_tA(a, gvjs_Zt, this.tb.id))
};
gvjs_.bS = function(a) {
    a.stopPropagation();
    var b = this.uo ? "uncheck" : "check";
    this.isEnabled() && !a.target.href && this.dispatchEvent(b) && (a.preventDefault(), this.toggle(), this.dispatchEvent(gvjs_6r))
};
gvjs_.xh = function(a) {
    32 == a.keyCode && (this.qg(a), this.bS(a));
    return !1
};
gvjs_7B(gvjs_6q, function() {
    return new gvjs_dD
});

function gvjs_eD(a, b, c) {
    gvjs_L.call(this);
    this.qE = a;
    this.Ky = b || 0;
    this.Pd = c;
    this.GP = gvjs_Se(this.hda, this)
}
gvjs_u(gvjs_eD, gvjs_L);
gvjs_ = gvjs_eD.prototype;
gvjs_.vd = 0;
gvjs_.J = function() {
    gvjs_eD.G.J.call(this);
    this.stop();
    delete this.qE;
    delete this.Pd
};
gvjs_.start = function(a) {
    this.stop();
    this.vd = gvjs_yl(this.GP, void 0 !== a ? a : this.Ky)
};
gvjs_.stop = function() {
    this.isActive() && gvjs_zl(this.vd);
    this.vd = 0
};
gvjs_.isActive = function() {
    return 0 != this.vd
};
gvjs_.hda = function() {
    this.vd = 0;
    this.qE && this.qE.call(this.Pd)
};

function gvjs_fD(a, b) {
    gvjs_7k.call(this);
    this.O = a;
    a = gvjs_Fi(this.O) ? this.O : this.O ? this.O.body : null;
    this.sK = !!a && gvjs_5y(a);
    this.K5 = gvjs_M(this.O, gvjs_Hf ? "DOMMouseScroll" : gvjs_uu, this, b)
}
gvjs_u(gvjs_fD, gvjs_7k);
gvjs_fD.prototype.handleEvent = function(a) {
    var b = 0,
        c = 0,
        d = a.fi;
    d.type == gvjs_uu ? (a = gvjs_gD(-d.wheelDelta), void 0 !== d.wheelDeltaX ? (b = gvjs_gD(-d.wheelDeltaX), c = gvjs_gD(-d.wheelDeltaY)) : c = a) : (a = d.detail, 100 < a ? a = 3 : -100 > a && (a = -3), void 0 !== d.axis && d.axis === d.HORIZONTAL_AXIS ? b = a : c = a);
    typeof this.a6 === gvjs_f && (b = gvjs_7h(b, -this.a6, this.a6));
    typeof this.b6 === gvjs_f && (c = gvjs_7h(c, -this.b6, this.b6));
    this.sK && (b = -b);
    b = new gvjs_hD(a, d, b, c);
    this.dispatchEvent(b)
};

function gvjs_gD(a) {
    return gvjs_If && (gvjs_Jf || gvjs_Lf) && 0 != a % 40 ? a : a / 40
}
gvjs_fD.prototype.J = function() {
    gvjs_fD.G.J.call(this);
    gvjs_4k(this.K5);
    this.K5 = null
};

function gvjs_hD(a, b, c, d) {
    gvjs_Pk.call(this, b);
    this.type = gvjs_uu;
    this.detail = a;
    this.deltaX = c;
    this.deltaY = d
}
gvjs_u(gvjs_hD, gvjs_Pk);
var gvjs_iD = {},
    gvjs_jD = null;

function gvjs_kD(a) {
    a = gvjs_Qe(a);
    delete gvjs_iD[a];
    gvjs_wx(gvjs_iD) && gvjs_jD && gvjs_jD.stop()
}

function gvjs_lD() {
    gvjs_jD || (gvjs_jD = new gvjs_eD(function() {
        gvjs_Mea()
    }, 20));
    var a = gvjs_jD;
    a.isActive() || a.start()
}

function gvjs_Mea() {
    var a = gvjs_Ue();
    gvjs_y(gvjs_iD, function(b) {
        gvjs_mD(b, a)
    });
    gvjs_wx(gvjs_iD) || gvjs_lD()
};

function gvjs_nD() {
    gvjs_7k.call(this);
    this.V = 0;
    this.endTime = this.startTime = null
}
gvjs_u(gvjs_nD, gvjs_7k);
gvjs_nD.prototype.se = function() {
    return 0 == this.V
};
gvjs_nD.prototype.SE = function() {
    this.Lf("begin")
};
gvjs_nD.prototype.nv = function() {
    this.Lf(gvjs_Y)
};
gvjs_nD.prototype.Lf = function(a) {
    this.dispatchEvent(a)
};

function gvjs_oD(a, b, c, d) {
    gvjs_nD.call(this);
    if (!Array.isArray(a) || !Array.isArray(b)) throw Error("Start and end parameters must be arrays");
    if (a.length != b.length) throw Error("Start and end points must be the same length");
    this.Kl = a;
    this.PC = b;
    this.duration = c;
    this.F_ = d;
    this.coords = [];
    this.lw = !1;
    this.progress = 0
}
gvjs_u(gvjs_oD, gvjs_nD);
gvjs_ = gvjs_oD.prototype;
gvjs_.Bm = gvjs_p(79);
gvjs_.play = function(a) {
    if (a || this.se()) this.progress = 0, this.coords = this.Kl;
    else if (1 == this.V) return !1;
    gvjs_kD(this);
    this.startTime = a = gvjs_Ue(); - 1 == this.V && (this.startTime -= this.duration * this.progress);
    this.endTime = this.startTime + this.duration;
    this.progress || this.SE();
    this.Lf("play"); - 1 == this.V && this.Lf("resume");
    this.V = 1;
    var b = gvjs_Qe(this);
    b in gvjs_iD || (gvjs_iD[b] = this);
    gvjs_lD();
    gvjs_mD(this, a);
    return !0
};
gvjs_.stop = function(a) {
    gvjs_kD(this);
    this.V = 0;
    a && (this.progress = 1);
    gvjs_pD(this, this.progress);
    this.Lf(gvjs_zv);
    this.nv()
};
gvjs_.pause = function() {
    1 == this.V && (gvjs_kD(this), this.V = -1, this.Lf("pause"))
};
gvjs_.J = function() {
    this.se() || this.stop(!1);
    this.Lf("destroy");
    gvjs_oD.G.J.call(this)
};
gvjs_.destroy = function() {
    this.xa()
};

function gvjs_mD(a, b) {
    b < a.startTime && (a.endTime = b + a.endTime - a.startTime, a.startTime = b);
    a.progress = (b - a.startTime) / (a.endTime - a.startTime);
    1 < a.progress && (a.progress = 1);
    gvjs_pD(a, a.progress);
    1 == a.progress ? (a.V = 0, gvjs_kD(a), a.Lf(gvjs__s), a.nv()) : 1 == a.V && a.rU()
}

function gvjs_pD(a, b) {
    typeof a.F_ === gvjs_c && (b = a.F_(b));
    a.coords = Array(a.Kl.length);
    for (var c = 0; c < a.Kl.length; c++) a.coords[c] = (a.PC[c] - a.Kl[c]) * b + a.Kl[c]
}
gvjs_.rU = function() {
    this.Lf("animate")
};
gvjs_.Lf = function(a) {
    this.dispatchEvent(new gvjs_qD(a, this))
};

function gvjs_qD(a, b) {
    gvjs_Nk.call(this, a);
    this.coords = b.coords;
    this.x = b.coords[0];
    this.y = b.coords[1];
    this.z = b.coords[2];
    this.duration = b.duration;
    this.progress = b.progress;
    this.state = b.V
}
gvjs_u(gvjs_qD, gvjs_Nk);
gvjs_t("google.visualization.drawToolbar", function(a, b) {
    new gvjs_7C(a, b)
});

function gvjs_rD(a) {
    return a.join("#")
}
var gvjs_sD = ["minorgridline", "gridline", gvjs_Ar, gvjs_5r, gvjs_yv, gvjs_Ib, "pathinterval", gvjs_Ir, gvjs_Rt, gvjs_d, gvjs__r, gvjs_Wr, gvjs_nr, gvjs_Xu, gvjs_xp, gvjs_ce, "axistick", "axistitle", gvjs_zr, gvjs__t, gvjs_6t, gvjs_5t, "colorbar", gvjs_de, gvjs_ir];

function gvjs_tD(a) {
    this.cc = Array(a).fill({});
    this.gI = Array(a).fill({})
}
gvjs_tD.prototype.ed = function(a, b) {
    var c = this.cc.length;
    for (this.cc[a] = b; a < c; ++a) this.gI[a] = gvjs_uD(this, 0 === a ? {} : this.gI[a - 1], this.cc[a])
};
gvjs_tD.prototype.Or = function(a) {
    var b = gvjs_Me(a);
    return b !== gvjs_g && b !== gvjs_Db || b === gvjs_g && typeof a.clone === gvjs_c || gvjs_xg(a)
};

function gvjs_uD(a, b, c) {
    if (a.Or(c) || a.Or(b) || Array.isArray(c)) return c;
    if (gvjs_Me(b) === gvjs_g) {
        var d = Object.assign({}, b);
        for (f in c)
            if (c.hasOwnProperty(f)) {
                var e = c[f];
                d[f] = null != b && f in b && null != b[f] ? gvjs_uD(a, b[f], e) : e
            }
        return d
    }
    var f = Array.from(b);
    for (d in c) c.hasOwnProperty(d) && (f[Number(d)] = gvjs_uD(a, b[d], c[d]));
    return f
}
gvjs_tD.prototype.compact = function() {
    return this.gI[this.gI.length - 1]
};

function gvjs_vD(a) {
    this.focused = {
        Ua: null,
        datum: null,
        category: null
    };
    this.annotations = {
        focused: null,
        cJ: null
    };
    this.legend = {
        focused: {
            Ob: null
        },
        Dg: null,
        sA: null
    };
    this.fg = {
        focused: {
            Zt: null
        }
    };
    this.cursor = {
        position: null,
        RU: null
    };
    this.cf = this.wl = null;
    this.selected = new gvjs_Go;
    a && (this.selected.setSelection(a.selected), a.focused && (this.focused = gvjs_wD(this.focused, a.focused)), a.annotations && (this.annotations = gvjs_wD(this.annotations, a.annotations)), a.legend && (this.legend = gvjs_wD(this.legend, a.legend)), a.fg &&
        (this.fg = gvjs_wD(this.fg, a.fg)), a.wl && (this.wl = gvjs_wD(this.wl, a.wl)), a.cf && gvjs_wD(this.cf, a.cf))
}
gvjs_vD.prototype.clone = function() {
    var a = new gvjs_vD;
    a.selected = this.selected.clone();
    a.focused = gvjs_yg(this.focused);
    a.annotations = gvjs_yg(this.annotations);
    a.legend = gvjs_yg(this.legend);
    a.fg = gvjs_yg(this.fg);
    a.cursor = gvjs_yg(this.cursor);
    a.wl = gvjs_yg(this.wl);
    a.cf = gvjs_yg(this.cf);
    return a
};
gvjs_vD.prototype.equals = function(a, b) {
    b = void 0 === b ? !1 : b;
    return this.selected.equals(a.selected) && gvjs_ox(this.focused, a.focused) && gvjs_ox(this.annotations, a.annotations) && gvjs_ox(this.legend, a.legend) && gvjs_ox(this.fg, a.fg) && (b || gvjs_ox(this.cursor, a.cursor)) && gvjs_ox(this.wl, a.wl) && gvjs_ox(this.cf, a.cf)
};

function gvjs_wD(a, b) {
    var c = new gvjs_tD(2);
    c.ed(0, a);
    c.ed(1, b);
    return c.compact()
};

function gvjs_Nea(a) {
    if (0 == a.entries.length) return gvjs_Ah(gvjs_5b, {
        "class": gvjs_jt
    });
    var b = a.entries.findIndex(function(d) {
            return d.type == gvjs_hv
        }),
        c = []; - 1 == b ? c.push(gvjs_xD(a.entries)) : (c.push(gvjs_xD(a.entries.slice(0, b))), c.push(gvjs_Ah(gvjs_5b, {
        "class": "google-visualization-tooltip-separator"
    })), c.push(gvjs_Oea(a.entries.slice(b + 1))));
    return gvjs_Ah(gvjs_5b, {
        "class": gvjs_jt
    }, gvjs_Dh(c))
}

function gvjs_xD(a) {
    a = a.map(function(b) {
        return gvjs_Ah("li", {
            "class": "google-visualization-tooltip-item"
        }, gvjs_Dh(gvjs_yD(b.data)))
    });
    return gvjs_Ah("ul", {
        "class": "google-visualization-tooltip-item-list"
    }, gvjs_Dh(a))
}

function gvjs_Oea(a) {
    a = a.map(function(b) {
        return gvjs_Ah("li", {
            "data-logicalname": gvjs_rD([gvjs_ir, b.data.id]),
            "class": "google-visualization-tooltip-action"
        }, gvjs_Dh(gvjs_yD(b.data)))
    });
    return gvjs_Ah("ul", {
        "class": "google-visualization-tooltip-action-list"
    }, gvjs_Dh(a))
}

function gvjs_yD(a) {
    return a.items.map(function(b, c) {
        switch (b.type) {
            case gvjs_n:
                if (b.html) var d = gvjs_gz(b.data.text);
                else {
                    d = void 0 === d ? {} : d;
                    var e = gvjs_8m(b.data.text);
                    d.Nsa && (e = e.replace(/(^|[\r\n\t ]) /g, "$1&#160;"));
                    d.Msa && (e = e.replace(/(\r\n|\n|\r)/g, "<br>"));
                    d.Osa && (e = e.replace(/(\t+)/g, '<span style="white-space:pre">$1</span>'));
                    d = gvjs_zh(e)
                }
                b = b.data.style;
                e = {
                    "font-family": b.fontName,
                    "font-size": b.fontSize + gvjs_Z,
                    color: b.color,
                    opacity: b.opacity,
                    margin: gvjs_2g("0"),
                    "font-style": b.italic ? gvjs_2g(gvjs_Tt) : gvjs_2g(gvjs_e),
                    "text-decoration": b.zd ? gvjs_2g(gvjs_5v) : gvjs_2g(gvjs_e),
                    "font-weight": b.bold ? gvjs_2g(gvjs_Qr) : gvjs_2g(gvjs_e)
                };
                b.italic && (e["padding-right"] = gvjs_2g("0.04em"));
                b = gvjs_mh(e);
                return gvjs_Ah(gvjs_2d, {
                    style: b
                }, gvjs_Dh(0 == c ? "" : " ", d));
            case gvjs_uv:
                return gvjs_Ah(gvjs_5b, {
                    "class": "google-visualization-tooltip-square",
                    style: {
                        "background-color": b.data.brush && b.data.brush.fill
                    }
                })
        }
    })
};

function gvjs_zD(a, b, c, d, e) {
    var f = b.left + d;
    b = b.right - d;
    if (!(a.box.left >= f && a.box.right <= b)) {
        d = gvjs_Bx(a);
        var g = d.box.left;
        d.box.left = gvjs_Nx(c.x, d.box.right, -1);
        d.box.right = gvjs_Nx(c.x, g, -1);
        if (g = d.Kg) {
            var h = g[0];
            g[0] = g[2];
            g[2] = h;
            g[0].x = gvjs_Nx(c.x, g[0].x, -1);
            g[1].x = gvjs_Nx(c.x, g[1].x, -1);
            g[2].x = gvjs_Nx(c.x, g[2].x, -1)
        }
        d.box.left >= f && d.box.right <= b ? (a.box = d.box, a.Kg = d.Kg) : (a.Kg && (c = new gvjs_Lk(f + e, b - e), e = new gvjs_Lk(d.Kg[0].x, d.Kg[2].x), g = new gvjs_Lk(a.Kg[0].x, a.Kg[2].x), !(c.start <= g.start && c.end >=
            g.end) && c.start <= e.start && c.end >= e.end && (a.box = d.box, a.Kg = d.Kg)), a.box.right > b && (a.box.left -= a.box.right - b, a.box.right = b), a.box.left < f && (a.box.right += f - a.box.left, a.box.left = f))
    }
}

function gvjs_AD(a, b, c, d) {
    var e = b.top + d;
    b = b.bottom - d;
    if (!(a.box.top >= e && a.box.bottom <= b)) {
        d = gvjs_Bx(a);
        var f = d.box.top;
        d.box.top = gvjs_Nx(c.y, d.box.bottom, -1);
        d.box.bottom = gvjs_Nx(c.y, f, -1);
        if (f = d.Kg) {
            var g = f[0];
            f[0] = f[2];
            f[2] = g;
            f[0].y = gvjs_Nx(c.y, f[0].y, -1);
            f[1].y = gvjs_Nx(c.y, f[1].y, -1);
            f[2].y = gvjs_Nx(c.y, f[2].y, -1)
        }
        d.box.top >= e && d.box.bottom <= b ? (a.box = d.box, a.Kg = d.Kg) : (a.box.bottom > b && (a.box.top -= a.box.bottom - b, a.box.bottom = b), a.box.top < e && (a.box.bottom += e - a.box.top, a.box.top = e), delete a.Kg)
    }
};

function gvjs_BD(a, b, c, d, e, f, g, h, k) {
    var l = {
        items: []
    };
    null != e && (e = gvjs_cy(e, f), l.items.push({
        type: gvjs_uv,
        data: {
            size: b.fontSize / 2,
            brush: e
        }
    }));
    null != g && l.items.push(gvjs_CD(g, b));
    if (null != c && "" !== c) {
        if (null == d) throw Error("Line title is specified without a text style.");
        l.items.push(gvjs_CD(c + ":", d))
    }
    l.items.push(gvjs_CD(a, b, h));
    null != k && (l.id = k, l.background = {
        brush: new gvjs__(gvjs_Hw)
    });
    return {
        type: gvjs_d,
        data: l
    }
}

function gvjs_DD() {
    return {
        type: gvjs_hv,
        data: {
            brush: gvjs_dy("#eee", 1)
        }
    }
}

function gvjs_CD(a, b, c) {
    a = {
        type: gvjs_n,
        data: {
            text: a || "",
            style: b
        }
    };
    c && (a.html = !0);
    return a
}

function gvjs_ED(a, b, c, d, e, f, g, h, k, l) {
    if (h) return {
        html: gvjs_Nea(a),
        wI: !1,
        pivot: f,
        anchor: d,
        ut: e,
        spacing: 20,
        margin: 5
    };
    for (var m = h = 0; m < a.entries.length; m++) {
        var n = a.entries[m];
        if (n.type == gvjs_d) {
            n = n.data;
            for (var p = 0; p < n.items.length; p++) {
                var q = n.items[p];
                q.type == gvjs_n && (h = Math.max(h, q.data.style.fontSize))
            }
        }
    }
    g = 0 == h ? g || 0 : h;
    for (n = m = h = 0; n < a.entries.length; n++) switch (p = a.entries[n], p.type) {
        case gvjs_d:
            p = gvjs_FD(p.data, b);
            m += p.height + (0 < n ? p.Gs : 0);
            h = Math.max(h, p.width);
            break;
        case gvjs_hv:
            m += 1.5 * g + p.data.brush.strokeWidth
    }
    h =
        Math.max(h, 2 * g);
    var r = new gvjs_B(Math.round(h + 2 * g / 1.618), Math.round(m + 2 * g / 1.618));
    m = gvjs_Sx(d.x - f.x);
    n = gvjs_Sx(d.y - f.y);
    var t = c ? new gvjs_A(d.x + m * g, d.y + n * (g + r.height / 2)) : new gvjs_A(d.x + m * r.width / 2, d.y + n * r.height / 2);
    p = t.x - r.width / 2;
    q = p + r.width;
    var u = t.y - r.height / 2,
        v = u + r.height;
    h = {};
    c && (c = new gvjs_A(t.x, gvjs_Nx(d.y, t.y, g / (g + r.height / 2))), t = new gvjs_A(gvjs_Nx(t.x, d.x, -1), c.y), c.x = Math.round(c.x), c.y = Math.round(c.y), t.x = Math.round(t.x), t.y = Math.round(t.y), h.Kg = 1 == m * n ? [c, d, t] : [t, d, c]);
    h.box = new gvjs_H(Math.round(u),
        Math.round(q), Math.round(v), Math.round(p));
    gvjs_zD(h, e, f, 5, 4);
    gvjs_AD(h, e, f, 5);
    d = {};
    e = g / 1.618;
    e = new gvjs_H(h.box.top + e, h.box.right - e, h.box.bottom - e, h.box.left + e);
    f = [];
    v = e.top;
    c = a.entries.length;
    r = !1;
    for (m = 0; m < c; m++)
        if (a.entries[m].sB) {
            r = !0;
            break
        }
    t = [];
    n = [];
    for (m = 0; m < c; m++)
        if (p = a.entries[m], p.type === gvjs_d) {
            q = p.data;
            u = [];
            n.push(u);
            for (var w = 0, x = q.items.length; w < x; w++) {
                var y = gvjs_GD(q.items[w], b);
                u.push(y);
                p.sB && (w > t.length - 1 ? t.push(y.width) : t[w] = Math.max(t[w], y.width))
            }
        }
    p = [];
    q = [];
    u = 0;
    if (r)
        for (m = 0; m <
            c; m++)
            if (y = a.entries[m], y.type == gvjs_d) {
                r = [];
                q.push(r);
                w = 0;
                if (y.sB)
                    for (x = 0, y = y.data.items.length; x < y; x++) {
                        var z = t[x] - n[u][x].width;
                        r.push(z);
                        w += z
                    }
                p.push(w);
                u++
            }
    for (m = u = 0; m < c; m++) {
        r = a.entries[m];
        t = {
            Ob: r,
            data: {}
        };
        switch (r.type) {
            case gvjs_d:
                var A = r.data;
                w = t.data;
                x = gvjs_FD(A, b);
                r.sB && (x.width += p[u]);
                0 < m && (v += x.Gs);
                A.background && (w.background = {
                    box: new gvjs_H(v - x.Gs / 2, h.box.right, v + x.height + x.Gs, h.box.left)
                });
                y = [];
                z = e.left;
                var B = 0;
                for (A = A.items.length; B < A; B++) {
                    var D = {},
                        F = n[u][B];
                    r.sB && (F.width += q[u][B]);
                    0 < B && (z += F.Ry);
                    var G = v + (x.height - F.height) / 2;
                    D.box = new gvjs_H(Math.round(G), Math.round(z + F.width), Math.round(G + F.height), Math.round(z));
                    k && (G = e.right - (D.box.left - e.left) - D.box.left - F.width, D.box.left += G, D.box.right += G);
                    y.push(D);
                    z += F.width
                }
                w.items = y;
                v += x.height;
                u++;
                break;
            case gvjs_hv:
                r = r.data, w = v + g + r.brush.strokeWidth / 2, t.data.line = new gvjs_gy(h.box.left, w, h.box.right, w), v += 1.5 * g + r.brush.strokeWidth / 2
        }
        f.push(t)
    }
    d.entries = f;
    d.Y7 = !!k;
    l = l || new gvjs__({
        fill: gvjs_jw,
        stroke: gvjs_iq,
        strokeWidth: 1
    });
    return {
        boxStyle: l,
        outline: h,
        NB: d
    }
}

function gvjs_FD(a, b) {
    for (var c = 0, d = 0, e = 0, f = 0; f < a.items.length; f++) {
        var g = gvjs_GD(a.items[f], b);
        c += g.width + (0 < f ? g.Ry : 0);
        d = Math.max(d, g.height);
        e = Math.max(e, g.height / 2 + g.Gs)
    }
    return {
        width: c,
        height: d,
        Gs: e - d / 2
    }
}

function gvjs_GD(a, b) {
    switch (a.type) {
        case gvjs_n:
            var c = a.data.style;
            return {
                width: b ? b(String(a.data.text), c).width : 0,
                height: c.fontSize,
                Gs: c.fontSize / 3.236,
                Ry: c.fontSize / 3.236
            };
        case gvjs_uv:
            return a = a.data.size, {
                width: a,
                height: a,
                Gs: a,
                Ry: a
            };
        default:
            return a = a.data.size, {
                width: a,
                height: a,
                Gs: a,
                Ry: a
            }
    }
};

function gvjs_HD(a, b) {
    this.WI = {};
    this.zq = {};
    this.Uw = [];
    this.updateOptions(a, b)
}

function gvjs_Pea(a) {
    gvjs_v(a.Uw, function(b) {
        gvjs_ID(this, this.zq[b])
    }, a)
}
gvjs_ = gvjs_HD.prototype;
gvjs_.updateOptions = function(a, b) {
    this.Ea = gvjs_Pw(a, "actionsMenu.textStyle", b);
    this.ada = gvjs_Pw(a, "actionsMenu.disabledTextStyle", b);
    gvjs_Pea(this)
};
gvjs_.getEntries = function() {
    for (var a = [], b = 0, c = this.Uw.length; b < c; b++) {
        var d = this.Uw[b],
            e = this.zq[d];
        if (!e.visible || e.visible()) d = e.enabled && !e.enabled() ? gvjs_BD(e.text || "", this.ada, null, null, null, null, null, !1, null) : gvjs_Bx(this.WI[d]), a.push(d)
    }
    return a
};

function gvjs_ID(a, b) {
    if (!b.id) throw Error("Missing mandatory ID for action.");
    if (a.zq[b.id]) var c = a.zq[b.id];
    else c = a.zq[b.id] = {
        id: b.id,
        text: void 0,
        visible: void 0,
        enabled: void 0,
        action: void 0
    }, a.Uw.push(b.id);
    gvjs_Wg(c, b);
    a.WI[b.id] = gvjs_BD(c.text || "", a.Ea, null, null, null, null, null, !1, c.id)
}
gvjs_.getAction = function(a) {
    (a = this.zq[a]) && (a = gvjs_Bx(a));
    return a
};
gvjs_.removeEntry = function(a) {
    a in this.WI && delete this.WI[a];
    a in this.zq && delete this.zq[a];
    a = gvjs_of(this.Uw, a);
    0 <= a && this.Uw.splice(a, 1)
};

function gvjs_Qea(a, b) {
    a.NB = a.NB || {};
    a = a.NB;
    a.entries = a.entries || {};
    a = a.entries;
    a[b] = a[b] || {};
    b = a[b];
    b.Ob = b.Ob || {};
    return b.Ob
}
gvjs_.Uo = function(a, b, c) {
    if (!a.html) {
        var d = b.focused.Zt;
        null != d && (a = gvjs_7w(a.NB.entries, function(e) {
            return e.Ob.data.id == d
        }), -1 !== a && (c = gvjs_Qea(c, a), c.data = c.data || {}, c.data.background = c.data.background || {}, c.data.background.brush = gvjs_cy("#DDD")))
    }
};

function gvjs_JD(a) {
    var b = a.lines.map(function(c) {
        var d = a.anchor ? a.anchor : {
                x: 0,
                y: 0
            },
            e = gvjs_qz(c.x + d.x, c.length, a.Yb);
        c = gvjs_qz(c.y + d.y, a.textStyle.fontSize, a.Mb);
        return e.start === e.end || c.start === c.end ? null : new gvjs_H(c.start, e.end, c.end, e.start)
    });
    return gvjs_FA(b.filter(function(c) {
        return null != c
    }))
};

function gvjs_KD(a) {
    var b = a[0],
        c = a[1],
        d = a[2];
    a = a[3];
    if (isNaN(b) || 0 > b || 255 < b || isNaN(c) || 0 > c || 255 < c || isNaN(d) || 0 > d || 255 < d || isNaN(a) || 0 > a || 1 < a) throw Error('"(' + b + "," + c + "," + d + "," + a + ')" is not a valid RGBA color');
    b = [b, c, d, a];
    c = b.slice(0);
    c[3] = Math.round(1E3 * b[3]) / 1E3;
    return "rgba(" + c.join(",") + ")"
};
var gvjs_LD = {
        100: "#c6dafc",
        500: "#5e97f6",
        800: "#2a56c6"
    },
    gvjs_MD = {
        100: "#f4c7c3",
        500: "#db4437",
        900: "#a52714"
    },
    gvjs_ND = {
        100: "#fce8b2",
        600: "#f2a600",
        700: "#f09300",
        800: "#ee8100"
    },
    gvjs_OD = {
        100: "#b7e1cd",
        500: "#0f9d58",
        700: "#0b8043"
    },
    gvjs_PD = {
        100: "#e1bee7",
        400: "#ab47bc",
        800: "#6a1b9a"
    },
    gvjs_QD = {
        100: "#b2ebf2",
        600: "#00acc1",
        800: "#00838f"
    },
    gvjs_RD = {
        100: "#ffccbc",
        400: "#ff7043",
        700: "#e64a19"
    },
    gvjs_SD = {
        100: "#f0f4c3",
        800: "#9e9d24",
        900: "#827717"
    },
    gvjs_TD = {
        100: "#c5cae9",
        400: "#5c6bc0",
        600: "#3949ab"
    },
    gvjs_UD = {
        100: "#f8bbd0",
        200: "#f48fb1",
        300: "#f06292",
        500: "#e91e63",
        700: "#c2185b",
        900: "#880e4f"
    },
    gvjs_VD = {
        100: "#b2dfdb",
        700: "#00796b",
        900: "#004d40"
    };
var gvjs_WD = {},
    gvjs_XD = !1;

function gvjs_YD(a) {
    gvjs_XD || (gvjs_WD.classic = {
        colors: [{
            color: "#dea19b",
            dark: "#ad7d79",
            light: "#ffd1c9"
        }, {
            color: "#cdc785",
            dark: "#aea971",
            light: "#eeeeac"
        }, {
            color: "#d6b9db",
            dark: "#a992ad",
            light: "#fff0db"
        }, {
            color: "#a2c488",
            dark: "#7f9a6b",
            light: "#d2feb0"
        }, {
            color: "#ffbc46",
            dark: "#ce9839",
            light: "#eeee5b"
        }, {
            color: "#9bbdde",
            dark: "#7993ad",
            light: "#c991ff"
        }],
        backgroundColor: {
            gradient: {
                color1: "#8080ff",
                color2: "#000020",
                x1: gvjs_wq,
                y1: gvjs_wq,
                x2: gvjs_yq,
                y2: gvjs_yq
            }
        },
        titleTextStyle: {
            color: gvjs_jw
        },
        hAxis: {
            textStyle: {
                color: gvjs_jw
            },
            titleTextStyle: {
                color: gvjs_jw
            }
        },
        vAxis: {
            textStyle: {
                color: gvjs_jw
            },
            titleTextStyle: {
                color: gvjs_jw
            }
        },
        legend: {
            textStyle: {
                color: gvjs_jw
            }
        },
        chartArea: {
            backgroundColor: {
                stroke: gvjs_kq,
                fill: gvjs_e
            }
        },
        areaOpacity: .8
    }, gvjs_WD.maximized = {
        titlePosition: gvjs_Kt,
        axisTitlesPosition: gvjs_Kt,
        legend: {
            position: gvjs_Kt
        },
        chartArea: {
            width: gvjs_yq,
            height: gvjs_yq
        },
        vAxis: {
            textPosition: gvjs_Kt
        },
        hAxis: {
            textPosition: gvjs_Kt
        }
    }, gvjs_WD.sparkline = {
        enableInteractivity: !1,
        legend: {
            position: gvjs_e
        },
        seriesType: gvjs_Ar,
        lineWidth: 1.6,
        chartArea: {
            width: gvjs_yq,
            height: gvjs_yq
        },
        vAxis: {
            textPosition: gvjs_e,
            gridlines: {
                color: gvjs_e
            },
            baselineColor: gvjs_e
        },
        hAxis: {
            textPosition: gvjs_e,
            gridlines: {
                color: gvjs_e
            },
            baselineColor: gvjs_e
        }
    }, gvjs_WD.material = {
        bar: {
            groupWidth: "65%"
        },
        textStyle: {
            color: gvjs_cq,
            fontName: gvjs_Yq
        },
        annotations: {
            textStyle: {
                color: gvjs_cq,
                fontName: gvjs_Yq
            }
        },
        bubble: {
            highContrast: !0,
            textStyle: {
                auraColor: gvjs_e,
                color: "#636363",
                fontName: gvjs_Yq
            }
        },
        tooltip: {
            textStyle: {
                color: gvjs_cq,
                fontName: gvjs_Yq
            },
            boxStyle: {
                stroke: "#b2b2b2",
                strokeOpacity: 1,
                strokeWidth: 1.5,
                fill: gvjs_jw,
                fillOpacity: 1,
                shadow: {
                    radius: 1,
                    opacity: .2,
                    xOffset: 0,
                    yOffset: 2
                }
            }
        },
        vAxis: {
            textStyle: {
                color: gvjs_cq,
                fontName: gvjs_Yq,
                fontSize: 12
            },
            gridlines: {
                color: gvjs_kq
            },
            baselineColor: "#9e9e9e"
        },
        legend: {
            newLegend: !0,
            pagingTextStyle: {
                fontName: gvjs_Yq
            },
            textStyle: {
                auraColor: gvjs_e,
                color: gvjs_cq,
                fontName: gvjs_Yq,
                fontSize: 12
            }
        },
        hAxis: {
            textStyle: {
                color: gvjs_cq,
                fontName: gvjs_Yq,
                fontSize: 12
            },
            gridlines: {
                color: gvjs_kq
            },
            baselineColor: "#9e9e9e"
        },
        pieSliceTextStyle: {
            color: gvjs_ga,
            fontName: gvjs_Yq,
            fontSize: 14
        },
        pieResidueSliceColor: gvjs_cq,
        titleTextStyle: {
            color: gvjs_cq,
            fontName: gvjs_Yq,
            fontSize: 16,
            bold: gvjs_8b
        },
        scatter: {
            dataOpacity: .6
        },
        colorAxis: {
            colors: [],
            "one-sided-colors": [gvjs_ga, gvjs_LD[gvjs_Bq]],
            "two-sided-colors": [gvjs_LD[gvjs_Bq], gvjs_ga, gvjs_ND[gvjs_Cq]],
            legend: {
                textStyle: {
                    color: gvjs_cq,
                    fontName: gvjs_Yq,
                    fontSize: 12
                }
            }
        },
        colors: [{
                color: gvjs_LD[gvjs_Bq],
                dark: gvjs_LD[gvjs_Eq],
                light: gvjs_LD[gvjs_xq]
            }, {
                color: gvjs_MD[gvjs_Bq],
                dark: gvjs_MD[gvjs_Fq],
                light: gvjs_MD[gvjs_xq]
            }, {
                color: gvjs_ND[gvjs_Cq],
                dark: gvjs_ND[gvjs_Eq],
                light: gvjs_ND[gvjs_xq]
            },
            {
                color: gvjs_OD[gvjs_Bq],
                dark: gvjs_OD[gvjs_Dq],
                light: gvjs_OD[gvjs_xq]
            }, {
                color: gvjs_PD[gvjs_Aq],
                dark: gvjs_PD[gvjs_Eq],
                light: gvjs_PD[gvjs_xq]
            }, {
                color: gvjs_QD[gvjs_Cq],
                dark: gvjs_QD[gvjs_Eq],
                light: gvjs_QD[gvjs_xq]
            }, {
                color: gvjs_RD[gvjs_Aq],
                dark: gvjs_RD[gvjs_Dq],
                light: gvjs_RD[gvjs_xq]
            }, {
                color: gvjs_SD[gvjs_Eq],
                dark: gvjs_SD[gvjs_Fq],
                light: gvjs_SD[gvjs_xq]
            }, {
                color: gvjs_TD[gvjs_Aq],
                dark: gvjs_TD[gvjs_Cq],
                light: gvjs_TD[gvjs_xq]
            }, {
                color: gvjs_UD["300"],
                dark: gvjs_UD[gvjs_Bq],
                light: gvjs_UD[gvjs_xq]
            }, {
                color: gvjs_VD[gvjs_Dq],
                dark: gvjs_VD[gvjs_Fq],
                light: gvjs_VD[gvjs_xq]
            }, {
                color: gvjs_UD[gvjs_Dq],
                dark: gvjs_UD[gvjs_Fq],
                light: gvjs_UD["200"]
            }
        ]
    }, gvjs_XD = !0);
    return gvjs_WD[a]
}

function gvjs_Rea(a) {
    return a.replace(/[^\d,.]/g, "").split(",").map(function(b) {
        return Number(b)
    })
}

function gvjs_ZD(a) {
    var b = {};
    typeof a === gvjs_m && (a = {
        color: a
    });
    b.color = a.color;
    var c = gvjs_Qi(b.color);
    c === gvjs_e ? (b.dark = a.darker || c, b.light = a.lighter || c) : c.includes("rgba") ? (c = gvjs_Rea(c), a = c.slice(0, 3), c = c[3] || 1, b.dark = gvjs_KD([].concat(gvjs_we(gvjs_Yx(a, .25)), [c])), b.light = gvjs_KD([].concat(gvjs_we(gvjs_Zx(a, .25)), [c]))) : (c = gvjs_ei(c), b.dark = a.darker || gvjs_di(gvjs_Yx(c, .25)), b.light = a.lighter || gvjs_di(gvjs_Zx(c, .25)));
    return b
};
var gvjs_Sea = {
    NONE: gvjs_e,
    Dna: gvjs_xb,
    dpa: gvjs_Td,
    rO: gvjs_Nd
};

function gvjs__D() {}

function gvjs_0D(a, b, c) {
    b = a.series[b];
    return b.Fe && void 0 !== b.e7 ? (a = a.series[b.e7].points[c], a = null != a ? a.fe.d : a, null != a ? gvjs_dx(b.points, a, function(d, e) {
        return d - e.fe.d
    }) : c) : c
}
gvjs_ = gvjs__D.prototype;
gvjs_.rJ = function(a) {
    var b = a.Ua;
    a = a.category;
    var c = gvjs_0D(this, b, a);
    return this.series[b].points[c].hc.At || (this.Fa[c] ? this.Fa[a].Ds[0] : null)
};

function gvjs_1D(a, b) {
    var c = b.Ua;
    b = gvjs_0D(a, c, b.category);
    a = a.series[c].points[b].hc.sk || a.series[c].title;
    return null == a ? null : a
}
gvjs_.MR = function(a) {
    return a.category
};
gvjs_.NR = function(a) {
    return {
        row: a.category,
        column: this.series[a.Ua].Fo
    }
};
gvjs_.sJ = function(a) {
    var b = this.wm[a.column].yb;
    return null == b ? null : {
        Ua: b,
        category: this.Go[a.row]
    }
};
gvjs_.kD = function(a, b) {
    return this.series[a].points[b].hc
};

function gvjs_2D(a, b, c, d, e) {
    this.Jf = b;
    this.mh = e;
    a = gvjs_3D(this, a);
    this.Tt = (d - c) / (gvjs_3D(this, b) - a);
    this.vF = this.Tt * a - c
}
gvjs_2D.prototype.ld = function(a) {
    return gvjs_3D(this, a) * this.Tt - this.vF
};
gvjs_2D.prototype.Hg = function(a) {
    a: switch (a = (a + this.vF) / this.Tt, this.mh) {
        case 0:
            a = Math.pow(Math.E, a);
            break a;
        case 1:
            break a;
        default:
            a = Math.pow(a * this.mh + 1, 1 / this.mh)
    }
    return isFinite(a) ? a : this.Jf
};

function gvjs_3D(a, b) {
    switch (a.mh) {
        case 0:
            return Math.log(b);
        case 1:
            return b;
        default:
            return (Math.pow(b, a.mh) - 1) / a.mh
    }
};

function gvjs_4D(a, b) {
    return 0 > b ? a / Math.pow(10, -b) : a * Math.pow(10, b)
}

function gvjs_5D(a) {
    return Math.floor(.4342944819032518 * Math.log(a))
}

function gvjs_6D(a) {
    return Math.ceil(.4342944819032518 * Math.log(a))
};

function gvjs_7D(a, b, c, d, e, f) {
    this.Ae = a;
    this.Jf = b;
    this.sn = c;
    this.Rp = d;
    this.w2 = f;
    this.mh = e;
    this.tj = this.Ae === this.Jf ? this.Ae / 2 : isNaN(this.w2) ? gvjs_4D(1, gvjs_5D(this.Jf - this.Ae)) / 1E3 : this.w2 / 2;
    a >= this.tj ? (this.Ra = new gvjs_2D(a, b, c, d, this.mh), this.rg = Math.round(this.Ra.ld(this.tj))) : b <= -this.tj ? (this.Ra = new gvjs_2D(-b, -a, d, c, this.mh), this.rg = Math.round(this.Ra.ld(this.tj)), f = 2 * this.rg - d, e = 2 * this.rg - c, this.Ra = new gvjs_2D(-b, -a, f, e, this.mh)) : a >= -this.tj ? (this.rg = Math.round(c), this.Ra = new gvjs_2D(this.tj,
        b, this.rg, d, this.mh)) : b <= this.tj ? (this.rg = Math.round(d), e = 2 * this.rg - c, this.Ra = new gvjs_2D(this.tj, -a, this.rg, e, this.mh)) : (this.Ra = new gvjs_2D(this.tj, b, 0, 1, this.mh), e = this.Ra.ld(-a), this.rg = Math.round(c + e / (e + 1) * (d - c)), b >= -a ? this.Ra = new gvjs_2D(this.tj, b, this.rg, d, this.mh) : (e = 2 * this.rg - c, this.Ra = new gvjs_2D(this.tj, -a, this.rg, e, this.mh)));
    this.Je = d < c
}
gvjs_7D.prototype.DJ = function() {
    return this.sn
};
gvjs_7D.prototype.CJ = function() {
    return this.Rp
};
gvjs_7D.prototype.Hg = function(a) {
    if (this.Ae === this.Jf) return this.Ae;
    var b = this.Je ? -1 : 1;
    return a * b > this.rg * b ? this.Ra.Hg(a) : a * b < this.rg * b ? -this.Ra.Hg(2 * this.rg - a) : 0
};
gvjs_7D.prototype.ld = function(a) {
    return this.Ae === this.Jf ? Math.abs(this.sn - this.Rp) / 2 : a > this.tj ? this.Ra.ld(a) : a < -this.tj ? 2 * this.rg - this.Ra.ld(-a) : this.rg
};
var gvjs_Tea = {
    Voa: gvjs_Su,
    LOG: "log",
    Loa: gvjs_ou
};

function gvjs_8D() {
    return {
        transform: function(a) {
            return a
        },
        inverse: function(a) {
            return a
        }
    }
}

function gvjs_Uea(a) {
    var b = gvjs_Vea(a);
    return {
        transform: function(c) {
            var d = gvjs_9D(b, c, function(e) {
                return e.source
            });
            return null === d ? c : d.target + (c - d.source) * d.ay
        },
        inverse: function(c) {
            var d = gvjs_9D(b, c, function(e) {
                return e.target
            });
            return null === d ? c : 0 === d.ay ? d.source : d.source + (c - d.target) / d.ay
        }
    }
}

function gvjs_Vea(a) {
    for (var b = [], c = 0, d = null, e = 0; e < a.length; e++) {
        var f = a[e],
            g = f.iea,
            h = f.start;
        f = f.end;
        var k = g / (f - h);
        null === d || d !== h ? b.push({
            source: h,
            target: h + c,
            ay: k
        }) : b[b.length - 1].ay = k;
        b.push({
            source: f,
            target: h + c + g,
            ay: 1
        });
        c += g - (f - h);
        d = f
    }
    return b
}

function gvjs_9D(a, b, c) {
    b = gvjs_dx(a, {
        source: b,
        target: b,
        ay: 0
    }, function(d, e) {
        d = c(d);
        e = c(e);
        return d < e ? -1 : d > e ? 1 : 0
    });
    0 > b && (b = -b - 2);
    return 0 > b ? null : a[b]
}

function gvjs_Wea(a) {
    var b = new gvjs_7D(.5 * a, a, 0, 1, 0);
    return {
        transform: function(c) {
            return null == c ? c : b.ld(c)
        },
        inverse: function(c) {
            return null == c ? c : b.Hg(c)
        }
    }
}

function gvjs_Xea(a) {
    var b = new gvjs_7D(-a, a, -1, 1, 0, a);
    return {
        transform: function(c) {
            return null == c ? c : b.ld(c)
        },
        inverse: function(c) {
            return null == c ? c : b.Hg(c)
        }
    }
}

function gvjs_$D(a, b, c) {
    return (c = a.Ca(c, gvjs_Tea)) ? c : gvjs_D(a, b) ? "log" : gvjs_Su
}

function gvjs_aE(a, b, c) {
    switch (a) {
        case gvjs_Su:
            return 0 == c.length ? gvjs_8D() : gvjs_Uea(c);
        case "log":
            return gvjs_Wea(b);
        case gvjs_ou:
            return gvjs_Xea(b);
        default:
            return gvjs_8D()
    }
};

function gvjs_bE(a, b) {
    this.qa = [];
    this.f6 = a;
    this.g$ = b
}

function gvjs_cE(a, b) {
    if (0 < a.qa.length) {
        var c = a.qa[a.qa.length - 1][0],
            d = b - c;
        if (d > a.f6 && (d = Math.round(d / a.f6), 1 < d))
            for (var e = 1; e < d; e++) {
                var f = e / d * (b - c) + c;
                a.qa.push([f, a.g$(f)])
            }
    }
    a.qa.push([b, a.g$(b)])
}
gvjs_bE.prototype.Sd = function() {
    return this.qa
};

function gvjs_dE() {}
gvjs_dE.prototype.nj = function() {
    return this
};
gvjs_dE.prototype.Ku = function() {
    return !1
};
gvjs_dE.prototype.isNumber = function() {
    return !1
};

function gvjs_eE() {}
gvjs_eE.prototype.Lm = function() {
    return ")"
};

function gvjs_fE() {}
gvjs_fE.prototype.Lm = function() {
    return "("
};

function gvjs_gE(a) {
    this.Te = a
}
gvjs_r(gvjs_gE, gvjs_dE);
gvjs_gE.prototype.join = function(a) {
    var b = [];
    this.Te.forEach(function(c, d) {
        0 < d && b.push(a);
        d = !1;
        c instanceof gvjs_gE && 1 < c.Te.length && this.ky() > c.ky() && (d = !0);
        d && b.push(new gvjs_fE);
        gvjs_xf(b, c.Dj());
        d && b.push(new gvjs_eE)
    }, this);
    return b
};
gvjs_gE.prototype.nj = function() {
    if (1 === this.Te.length) return this.Te[0];
    var a = [];
    this.Te.forEach(function(b) {
        a.push(b.nj())
    });
    this.Te = a;
    return this
};

function gvjs_hE(a) {
    this.value = a
}
gvjs_hE.prototype.Lm = function() {
    return gvjs_f
};

function gvjs_iE(a) {
    this.value = a
}
gvjs_r(gvjs_iE, gvjs_dE);
gvjs_iE.prototype.Dj = function() {
    return [new gvjs_hE(this.value)]
};
gvjs_iE.prototype.Ku = function() {
    return 0 > this.value
};
gvjs_iE.prototype.getValue = function() {
    return this.value
};
gvjs_iE.prototype.isNumber = function() {
    return !0
};

function gvjs_jE() {}
gvjs_jE.prototype.Lm = function() {
    return "--"
};

function gvjs_kE(a) {
    this.Te = [a]
}
gvjs_r(gvjs_kE, gvjs_gE);

function gvjs_lE(a) {
    this.Te = [a]
}
gvjs_r(gvjs_lE, gvjs_kE);
gvjs_lE.prototype.nj = function() {
    var a = this.Te[0].nj();
    if (a.Ku()) {
        if (a instanceof gvjs_lE) return a.Te[0];
        if (a instanceof gvjs_iE) return new gvjs_iE(-a.getValue());
        throw Error("Unknown type of negative.");
    }
    return new gvjs_lE(a)
};
gvjs_lE.prototype.Dj = function() {
    return [new gvjs_jE].concat(this.Te[0].Dj())
};
gvjs_lE.prototype.Ku = function() {
    return this.nj() instanceof gvjs_lE
};
gvjs_lE.prototype.ky = function() {
    return -1
};

function gvjs_mE() {}
gvjs_mE.prototype.Lm = function() {
    return "-"
};

function gvjs_nE() {}
gvjs_nE.prototype.Lm = function() {
    return "+"
};

function gvjs_oE(a) {
    this.Te = a
}
gvjs_r(gvjs_oE, gvjs_gE);
gvjs_oE.prototype.ky = function() {
    return 1
};
gvjs_oE.prototype.Dj = function() {
    for (var a = [], b = 0; b < this.Te.length; b++) {
        var c = this.Te[b];
        0 < a.length && c.Ku() ? (a.push(new gvjs_mE), c = (new gvjs_lE(c)).nj()) : 0 < a.length && a.push(new gvjs_nE);
        a = a.concat(c.Dj())
    }
    return a
};

function gvjs_pE() {}
gvjs_pE.prototype.Lm = function() {
    return "="
};

function gvjs_qE(a) {
    this.Te = a
}
gvjs_r(gvjs_qE, gvjs_gE);
gvjs_qE.prototype.ky = function() {
    return 0
};
gvjs_qE.prototype.Dj = function() {
    return this.join(new gvjs_pE)
};

function gvjs_rE() {}
gvjs_rE.prototype.Lm = function() {
    return "*"
};

function gvjs_sE(a, b) {
    this.Te = a;
    this.W0 = null != b ? b : !1
}
gvjs_r(gvjs_sE, gvjs_gE);
gvjs_sE.prototype.ky = function() {
    return 2
};
gvjs_sE.prototype.nj = function() {
    gvjs_gE.prototype.nj.call(this);
    var a = 0,
        b = [],
        c = 1;
    this.Te.forEach(function(e) {
        e.Ku() && (e = (new gvjs_lE(e)).nj(), a++);
        e.isNumber() && (c *= e.getValue(), e = null);
        e && b.push(e)
    });
    1 !== c && b.splice(0, 0, new gvjs_iE(c));
    var d = new gvjs_sE(b, this.W0);
    a % 2 && (d = new gvjs_lE(d));
    return d
};
gvjs_sE.prototype.Dj = function() {
    return this.W0 ? Array.prototype.concat.apply([], this.Te.map(function(a) {
        return a.Dj()
    })) : this.join(new gvjs_rE)
};
gvjs_sE.prototype.Ku = function() {
    var a = 0;
    this.Te.forEach(function(b) {
        b.Ku() && a++
    });
    return !!(a % 2)
};

function gvjs_tE() {}
gvjs_tE.prototype.Lm = function() {
    return "^"
};

function gvjs_uE(a) {
    this.Te = a
}
gvjs_r(gvjs_uE, gvjs_gE);
gvjs_uE.prototype.ky = function() {
    return 3
};
gvjs_uE.prototype.Dj = function() {
    return this.join(new gvjs_tE)
};

function gvjs_vE(a) {
    this.name = a
}
gvjs_vE.prototype.Lm = function() {
    return "identifier"
};

function gvjs_wE(a) {
    this.name = a
}
gvjs_r(gvjs_wE, gvjs_dE);
gvjs_wE.prototype.Dj = function() {
    return [new gvjs_vE(this.name)]
};
gvjs_wE.prototype.getName = function() {
    return this.name
};

function gvjs_xE(a, b) {
    if (a instanceof gvjs_xE) this.ic = a.uN();
    else {
        var c;
        if (c = gvjs_Ne(a)) a: {
            for (var d = c = 0; d < a.length; d++) {
                if (!gvjs_Ne(a[d]) || 0 < c && a[d].length != c) {
                    c = !1;
                    break a
                }
                for (var e = 0; e < a[d].length; e++)
                    if (typeof a[d][e] !== gvjs_f) {
                        c = !1;
                        break a
                    }
                0 == c && (c = a[d].length)
            }
            c = 0 != c
        }
        if (c) this.ic = gvjs_wf(a);
        else if (a instanceof gvjs_B) this.ic = gvjs_yE(a.height, a.width);
        else if (typeof a === gvjs_f && typeof b === gvjs_f && 0 < a && 0 < b) this.ic = gvjs_yE(a, b);
        else throw Error("Invalid argument(s) for Matrix contructor");
    }
    this.wa =
        new gvjs_B(this.ic[0].length, this.ic.length)
}

function gvjs_zE(a, b, c) {
    for (var d = 0; d < a.getSize().height; d++)
        for (var e = 0; e < a.getSize().width; e++) b.call(c, a.ic[d][e], d, e, a)
}

function gvjs_AE(a, b) {
    var c = new gvjs_xE(a.getSize());
    gvjs_zE(a, function(d, e, f) {
        c.ic[e][f] = b.call(void 0, d, e, f, a)
    });
    return c
}

function gvjs_yE(a, b) {
    for (var c = [], d = 0; d < a; d++) {
        c[d] = [];
        for (var e = 0; e < b; e++) c[d][e] = 0
    }
    return c
}
gvjs_ = gvjs_xE.prototype;
gvjs_.add = function(a) {
    if (!gvjs_4x(this.wa, a.getSize())) throw Error("Matrix summation is only supported on arrays of equal size");
    return gvjs_AE(this, function(b, c, d) {
        return b + a.ic[c][d]
    })
};

function gvjs_Yea(a, b) {
    if (a.wa.height != b.getSize().height) throw Error("The given matrix has height " + b.wa.height + ", but  needs to have height " + a.wa.height + ".");
    var c = new gvjs_xE(a.wa.height, a.wa.width + b.wa.width);
    gvjs_zE(a, function(d, e, f) {
        c.ic[e][f] = d
    });
    gvjs_zE(b, function(d, e, f) {
        c.ic[e][this.wa.width + f] = d
    }, a);
    return c
}
gvjs_.equals = function(a, b) {
    if (this.wa.width != a.wa.width || this.wa.height != a.wa.height) return !1;
    b = b || 0;
    for (var c = 0; c < this.wa.height; c++)
        for (var d = 0; d < this.wa.width; d++)
            if (!(Math.abs(this.ic[c][d] - a.ic[c][d]) <= (b || 1E-6))) return !1;
    return !0
};
gvjs_.xJ = gvjs_p(0);

function gvjs_BE(a) {
    for (var b = new gvjs_xE(a), c = 0, d = 0; d < b.wa.height && !(c >= b.wa.width); d++) {
        for (var e = d; 0 == b.ic[e][c];)
            if (e++, e == b.wa.height && (e = d, c++, c == b.wa.width)) return b;
        var f = a,
            g = d,
            h = f.ic[e];
        f.ic[e] = f.ic[g];
        f.ic[g] = h;
        e = b.ic[d][c];
        for (f = c; f < b.wa.width; f++) b.ic[d][f] /= e;
        for (e = 0; e < b.wa.height; e++)
            if (e != d)
                for (g = b.ic[e][c], f = c; f < b.wa.width; f++) b.ic[e][f] -= g * b.ic[d][f];
        c++
    }
    return b
}
gvjs_.getSize = function() {
    return this.wa
};

function gvjs_CE(a, b, c) {
    return 0 <= b && b < a.wa.height && 0 <= c && c < a.wa.width ? a.ic[b][c] : null
}
gvjs_.multiply = function(a) {
    if (a instanceof gvjs_xE) {
        if (this.wa.width != a.getSize().height) throw Error("Invalid matrices for multiplication. Second matrix should have the same number of rows as the first has columns.");
        return gvjs_Zea(this, a)
    }
    if (typeof a === gvjs_f) return gvjs__ea(this, a);
    throw Error("A matrix can only be multiplied by a number or another matrix.");
};
gvjs_.eN = function(a) {
    if (!gvjs_4x(this.wa, a.getSize())) throw Error("Matrix subtraction is only supported on arrays of equal size.");
    return gvjs_AE(this, function(b, c, d) {
        return b - a.ic[c][d]
    })
};
gvjs_.uN = function() {
    return this.ic
};

function gvjs_DE(a, b, c, d) {
    var e = new gvjs_xE((c ? c : a.wa.height - 1) - 0 + 1, (d ? d : a.wa.width - 1) - b + 1);
    gvjs_zE(e, function(f, g, h) {
        e.ic[g][h] = this.ic[0 + g][b + h]
    }, a);
    return e
}

function gvjs_Zea(a, b) {
    var c = new gvjs_xE(a.wa.height, b.getSize().width);
    gvjs_zE(c, function(d, e, f) {
        for (var g = d = 0; g < this.wa.width; g++) d += gvjs_CE(this, e, g) * gvjs_CE(b, g, f);
        if (!(0 <= e && e < c.wa.height && 0 <= f && f < c.wa.width)) throw Error("Index out of bounds when setting matrix value, (" + e + "," + f + ") in size (" + c.wa.height + "," + c.wa.width + ")");
        c.ic[e][f] = d
    }, a);
    return c
}

function gvjs__ea(a, b) {
    return gvjs_AE(a, function(c) {
        return c * b
    })
};

function gvjs_EE(a) {
    this.EI = a.degree + 1;
    this.gb = a.range;
    this.qia = a.c6;
    this.GR = 0;
    this.er = a.er || gvjs_8D();
    this.sX = 0;
    this.qa = []
}
gvjs_EE.prototype.add = function(a, b) {
    if (isFinite(this.er.transform(a))) {
        if (0 < this.qa.length) {
            var c = a - this.qa[this.qa.length - 1].x;
            0 < c && (this.GR += c)
        }
        this.sX += b;
        this.qa.push({
            x: a,
            y: b
        })
    }
};

function gvjs_0ea(a) {
    var b = a.qia;
    b || (b = null != a.gb && null != a.gb.min && isFinite(a.gb.min) && null != a.gb.max && isFinite(a.gb.max) ? (a.gb.max - a.gb.min) / 100 : void 0);
    null != b && isFinite(b) || (b = a.GR / (a.qa.length - 1));
    return b
}

function gvjs_1ea(a, b) {
    return a.qa.reduce(function(c, d) {
        return c + Math.pow(a.er.inverse(d.x), b)
    }, 0)
}

function gvjs_2ea(a, b) {
    return a.qa.reduce(function(c, d) {
        return c + Math.pow(a.er.inverse(d.x), b) * d.y
    }, 0)
}

function gvjs_3ea(a) {
    for (var b = [], c = a.EI, d = 0; d < c; d++) {
        for (var e = Array(c + 1), f = 0; f <= c; f++) e[f] = f < c ? gvjs_1ea(a, d + f) : gvjs_2ea(a, d);
        b.push(e)
    }
    return new gvjs_xE(b)
}

function gvjs_4ea(a) {
    var b = gvjs_BE(gvjs_3ea(a));
    return gvjs_fx(a.EI).map(function(c) {
        return gvjs_CE(b, c, this.EI)
    }, a)
}

function gvjs_5ea(a, b) {
    var c = a.EI;
    return function(d) {
        d = a.er.inverse(d);
        for (var e = 0, f = 0; f < c; f++) e += b[f] * Math.pow(d, f);
        return e
    }
}

function gvjs_6ea(a, b) {
    b = gvjs_5ea(a, b);
    var c = gvjs_0ea(a);
    if (null == c || isNaN(c) || !isFinite(c) || 0 === c) return null;
    c = new gvjs_bE(c, b);
    var d = a.qa;
    d.sort(function(q, r) {
        return q.x > r.x ? 1 : q.x < r.x ? -1 : 0
    });
    var e = a.sX / d.length,
        f = a.gb;
    null != a.gb && null != a.gb.min && isFinite(a.gb.min) && 0 < d.length && f.min < d[0].x && gvjs_cE(c, f.min);
    for (var g = 0, h = 0, k = !0, l = 0; l < d.length; l++) {
        var m = d[l].x,
            n = d[l].y,
            p = b(m);
        k = k && p === n;
        gvjs_cE(c, m);
        g += Math.pow(n - p, 2);
        h += Math.pow(n - e, 2)
    }
    b = k ? 1 : 1 - g / h;
    null != a.gb && null != a.gb.max && isFinite(a.gb.max) &&
        1 < d.length && f.max > d[d.length - 1].x && gvjs_cE(c, f.max);
    return {
        data: c.Sd(),
        r2: b
    }
}

function gvjs_7ea(a) {
    function b(d, e) {
        for (var f = [], g = c.length - 1; 0 <= g; g--) {
            var h = c[g];
            if (null != h && 0 !== h) {
                h = new gvjs_iE(h);
                if (0 < g) {
                    var k = new gvjs_wE(d || "x");
                    1 < g && (k = new gvjs_uE([k, new gvjs_iE(g)]));
                    h = new gvjs_sE([h, k], !0)
                }
                f.push(h)
            }
        }
        return new gvjs_qE([new gvjs_wE(e || "y"), new gvjs_oE(f)])
    }
    var c = gvjs_4ea(a);
    a = gvjs_6ea(a, c);
    return null == a || 0 === a.data.length ? null : {
        qm: c,
        data: a.data,
        r2: a.r2,
        lr: b().nj(),
        KK: b
    }
};

function gvjs_FE(a, b, c, d) {
    d = new gvjs_EE(d);
    for (var e = 0; e < a; e++) {
        var f = b(e),
            g = c(e);
        null != f && isFinite(f) && null != g && isFinite(g) && d.add(f, g)
    }
    return gvjs_7ea(d)
};

function gvjs_GE(a, b, c, d) {
    a = gvjs_FE(a, b, c, {
        range: d.range,
        c6: d.c6,
        degree: 1,
        er: d.er
    });
    return null === a || isNaN(a.r2) ? null : {
        data: a.data,
        r2: a.r2,
        lr: {
            offset: a.qm[0],
            slope: a.qm[1]
        }
    }
};
var gvjs_8ea = {
        LINEAR: gvjs_8t,
        loa: "exponential",
        Xoa: gvjs_Zu
    },
    gvjs_HE = {
        linear: function(a, b, c, d) {
            function e(g, h) {
                return new gvjs_qE([new gvjs_wE(h || "y"), new gvjs_oE([new gvjs_sE([new gvjs_iE(f.lr.slope), new gvjs_wE(g || "x")]), new gvjs_iE(f.lr.offset)])])
            }
            var f = gvjs_GE(a, b, c, d);
            return null === f ? null : {
                data: f.data,
                r2: f.r2,
                lr: e().nj(),
                KK: e
            }
        },
        exponential: function(a, b, c, d) {
            function e(l, m) {
                l = new gvjs_sE([new gvjs_iE(Math.exp(k.lr.offset)), new gvjs_uE([new gvjs_wE("e"), new gvjs_sE([new gvjs_iE(k.lr.slope), new gvjs_wE(l ||
                    "x")])])], !0);
                null !== f && (l = new gvjs_oE([l, new gvjs_iE(f)]));
                return l = new gvjs_qE([new gvjs_wE(m || "y"), l])
            }
            for (var f = Infinity, g = 0; g < a; g++) {
                var h = c(g);
                null != h && h < f && (f = h)
            }
            f = 0 < f ? null : f - 1;
            var k = gvjs_GE(a, b, function(l) {
                l = c(l);
                if (null == l) return null;
                null != f && (l -= f);
                return Math.log(l)
            }, d);
            if (null === k) return null;
            a = [];
            for (b = 0; b < k.data.length; b++) d = k.data[b][0], g = Math.exp(k.data[b][1]), null != f && (g += f), a.push([d, g]);
            return {
                data: a,
                r2: k.r2,
                lr: e().nj(),
                KK: e
            }
        }
    };
gvjs_HE.polynomial = gvjs_FE;
var gvjs_IE = [{
            color: "#3366CC",
            lighter: "#45AFE2"
        }, {
            color: gvjs_fq,
            lighter: "#FF3300"
        }, {
            color: gvjs_gq,
            lighter: "#FFCC00"
        }, {
            color: gvjs_9p,
            lighter: "#14C21D"
        }, {
            color: "#990099",
            lighter: "#DF51FD"
        }, {
            color: "#0099C6",
            lighter: "#15CBFF"
        }, {
            color: "#DD4477",
            lighter: "#FF97D2"
        }, {
            color: "#66AA00",
            lighter: "#97FB00"
        }, {
            color: "#B82E2E",
            lighter: "#DB6651"
        }, {
            color: "#316395",
            lighter: "#518BC6"
        }, {
            color: gvjs_dq,
            lighter: "#BD6CBD"
        }, {
            color: "#22AA99",
            lighter: "#35D7C2"
        }, {
            color: "#AAAA11",
            lighter: "#E9E91F"
        }, {
            color: "#6633CC",
            lighter: "#9877DD"
        },
        {
            color: "#E67300",
            lighter: "#FF8F20"
        }, {
            color: "#8B0707",
            lighter: "#D20B0B"
        }, {
            color: "#651067",
            lighter: "#B61DBA"
        }, {
            color: "#329262",
            lighter: "#40BD7E"
        }, {
            color: "#5574A6",
            lighter: "#6AA7C4"
        }, {
            color: "#3B3EAC",
            lighter: "#6D70CD"
        }, {
            color: "#B77322",
            lighter: "#DA9136"
        }, {
            color: "#16D620",
            lighter: "#2DEA36"
        }, {
            color: "#B91383",
            lighter: "#E81EA6"
        }, {
            color: "#F4359E",
            lighter: "#F558AE"
        }, {
            color: "#9C5935",
            lighter: "#C07145"
        }, {
            color: "#A9C413",
            lighter: "#D7EE53"
        }, {
            color: "#2A778D",
            lighter: "#3EA7C6"
        }, {
            color: "#668D1C",
            lighter: "#97D129"
        },
        {
            color: "#BEA413",
            lighter: "#E9CA1D"
        }, {
            color: "#0C5922",
            lighter: "#149638"
        }, {
            color: "#743411",
            lighter: "#C5571D"
        }
    ],
    gvjs_JE = {
        color: "#EEEEEE",
        lighter: "#FEFEFE"
    },
    gvjs_9ea = {
        milliseconds: {
            format: ["ss.SSS", "SSS"],
            interval: [1, 2, 5, 10, 20, 50, 100, 200, 500]
        },
        seconds: {
            format: [gvjs_Ka, "ss.SSS"],
            interval: [1, 2, 5, 10, 15, 30]
        },
        minutes: {
            format: [gvjs_Ja, "mm"],
            interval: [1, 2, 5, 10, 15, 30]
        },
        hours: {
            format: [gvjs_Ja, "HH"],
            interval: [1, 2, 3, 4, 6, 12]
        },
        days: {
            format: ["d"],
            interval: [1, 2, 7]
        },
        months: {
            format: ["MM"],
            interval: [1, 2, 3, 4, 6]
        },
        years: {
            format: ["y"],
            interval: [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1E3]
        }
    },
    gvjs_$ea = {
        milliseconds: {
            format: [".SSS"],
            interval: [50, 100, 200, 500]
        },
        seconds: {
            format: [":ss"],
            interval: [5, 10, 15, 30]
        },
        minutes: {
            format: [":mm"],
            interval: [5, 10, 15, 30]
        },
        hours: {
            format: ["HH"],
            interval: [1, 2, 3, 4, 6, 12]
        },
        days: {
            format: ["d"],
            interval: [1, 2, 7]
        },
        months: {
            format: ["MM"],
            interval: [1, 2, 3, 4, 6, 12]
        },
        years: {
            format: ["y"],
            interval: [1, 2, 5, 10, 20, 50, 100, 200, 500, 1E3]
        }
    },
    gvjs_KE = {
        titleTextStyle: {
            color: gvjs_$p,
            italic: !0
        },
        viewWindow: {
            maxPadding: "50%"
        },
        minTextSpacing: 10,
        gridlines: {
            baseline: gvjs_Gb,
            minorTextOpacity: .7,
            minorGridlineOpacity: .4,
            allowMinor: !0,
            minStrongLineDistance: 40,
            minWeakLineDistance: 20,
            minStrongToWeakLineDistance: 0,
            minNotchDistance: 5,
            minMajorTextDistance: 20,
            minMinorTextDistance: 20,
            unitThreshold: 2.2,
            units: {
                milliseconds: {
                    format: [gvjs_La],
                    interval: [1, 2, 5, 10, 20, 50, 100, 200, 500]
                },
                seconds: {
                    format: [5, 6],
                    interval: [1, 2, 5, 10, 15, 30]
                },
                minutes: {
                    format: [7],
                    interval: [1, 2, 5, 10, 15, 30]
                },
                hours: {
                    format: [7],
                    interval: [1, 2, 3, 4, 6, 12]
                },
                days: {
                    format: [1, 2, 3, gvjs_bj.aaa, gvjs_bj.Y$,
                        gvjs_bj.Z$, gvjs_bj.GZ, gvjs_bj.FZ, gvjs_bj.w$
                    ],
                    interval: [1, 2, 7]
                },
                months: {
                    format: [gvjs_bj.Haa, gvjs_bj.EO, "MMM"],
                    interval: [1, 2, 3, 4, 6]
                },
                years: {
                    format: [gvjs_bj.DO],
                    interval: [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1E3]
                }
            }
        },
        minorGridlines: {
            count: 1,
            units: {
                milliseconds: {
                    format: [".SSS"],
                    interval: [50, 100, 200, 250, 500]
                },
                seconds: {
                    format: [":ss"],
                    interval: [5, 10, 15, 30]
                },
                minutes: {
                    format: [":mm"],
                    interval: [5, 10, 15, 30]
                },
                hours: {
                    format: [7],
                    interval: [1, 2, 3, 4, 6, 12]
                },
                days: {
                    format: ["d"],
                    interval: [1, 2, 7]
                },
                months: {
                    format: ["MMMMM", "MMM",
                        "MM"
                    ],
                    interval: [1, 2, 3, 4, 6, 12]
                },
                years: {
                    format: ["y"],
                    interval: [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1E3]
                }
            }
        }
    },
    gvjs_LE = {
        histogram: {
            bar: {
                gap: 1,
                group: {
                    gap: 2
                }
            },
            histogram: {
                lastBucketPercentile: 0,
                hideBucketItems: !1,
                bucketSize: null,
                numBucketsRule: "rice",
                minSpacing: 1
            },
            domainAxis: {
                baselineColor: gvjs_e,
                gridlines: {
                    color: gvjs_e
                },
                showTextEvery: 0,
                maxAlternation: 2
            },
            targetAxis: {
                format: "#",
                gridlines: {
                    multiple: 1
                }
            }
        }
    },
    gvjs_ME = {
        vAxis: gvjs_KE,
        hAxis: gvjs_KE,
        domainAxis: {
            maxPadding: "5%"
        },
        sizeAxis: {
            minSize: 5,
            maxSize: 30
        },
        fontName: gvjs_Jq,
        titleTextStyle: {
            color: gvjs_ea,
            bold: !0
        },
        bubble: {
            textStyle: {
                color: gvjs_ea
            }
        },
        candlestick: {
            hollowIsRising: !1
        },
        annotations: {
            datum: {
                textStyle: {
                    color: gvjs_jv
                },
                stemColor: gvjs_eq
            },
            domain: {
                textStyle: {
                    color: gvjs_$p
                },
                stemColor: gvjs_eq
            }
        },
        majorAxisTextColor: gvjs_$p,
        minorAxisTextColor: "#444444",
        backgroundColor: {
            fill: gvjs_lq,
            stroke: gvjs_bq,
            strokeWidth: 0
        },
        chartArea: {
            backgroundColor: {
                fill: gvjs_e
            }
        },
        baselineColor: gvjs_aq,
        gridlineColor: gvjs_jq,
        pieSliceBorderColor: gvjs_ga,
        pieResidueSliceColor: gvjs_jq,
        pieSliceTextStyle: {
            color: gvjs_ga
        },
        areaOpacity: .3,
        intervals: {
            style: gvjs_Hr,
            color: gvjs_kv,
            lineWidth: 1,
            fillOpacity: .3,
            barWidth: .25,
            shortBarWidth: .1,
            boxWidth: .25,
            dataOpacity: 1,
            pointSize: 6
        },
        actionsMenu: {
            textStyle: {
                color: gvjs_ea
            },
            disabledTextStyle: {
                color: "#c0c0c0"
            }
        },
        legend: {
            newLegend: !0,
            textStyle: {
                color: gvjs_$p
            },
            pagingTextStyle: {
                color: "#0011cc"
            },
            scrollArrows: {
                activeColor: "#0011cc",
                inactiveColor: gvjs_jq
            }
        },
        tooltip: {
            textStyle: {
                color: gvjs_ea
            },
            boxStyle: {
                stroke: gvjs_jq,
                strokeOpacity: 1,
                strokeWidth: 1,
                fill: gvjs_jw,
                fillOpacity: 1,
                shadow: {
                    radius: 2,
                    opacity: .1,
                    xOffset: 1,
                    yOffset: 1
                }
            }
        },
        aggregationTarget: gvjs_Gb,
        colorAxis: {
            legend: {
                textStyle: {
                    color: gvjs_ea
                }
            }
        }
    };

function gvjs_NE(a, b, c, d) {
    var e = gvjs_Pw(a, gvjs_Zv, {
        fontName: b.fontName,
        fontSize: b.fontSize
    });
    this.showColorCode = gvjs_D(a, gvjs_Yv, c.has(gvjs_3r));
    this.Dla = gvjs_D(a, gvjs_Yv, !0);
    this.Ela = gvjs_D(a, "tooltip.showEmpty", !0);
    this.Ea = e;
    this.OB = gvjs_Pw(a, gvjs_Zv, {
        fontName: b.fontName,
        fontSize: b.fontSize,
        bold: !0
    });
    this.Tc = d || null;
    this.U1 = gvjs_C(a, "diff.newData.tooltip.prefix", "Current: ");
    this.V1 = gvjs_C(a, "diff.oldData.tooltip.prefix", "Previous: ")
}
gvjs_NE.prototype.kr = function() {};

function gvjs_OE(a) {
    this.ca = a
}
gvjs_OE.prototype.aggregate = function(a) {
    var b = this,
        c = {
            index: {},
            order: [],
            Ds: {}
        };
    gvjs_v(a, function(d) {
        var e = b.getKey(d);
        if (null != e) {
            e = e.toString();
            if (!c.Ds.hasOwnProperty(e)) {
                var f = b.getTitle(d);
                f && (c.Ds[e] = f)
            }
            c.index.hasOwnProperty(e) || (c.index[e] = [], c.order.push(e));
            c.index[e].push(d)
        }
    });
    return c
};

function gvjs_PE() {
    this.NK = this.cv = null;
    this.rz = [];
    this.c3 = this.Js = this.kz = null;
    this.On = !0
}

function gvjs_QE(a, b) {
    a.NK = b;
    a.On = !0
}
gvjs_PE.prototype.unit = function(a) {
    this.Js = a;
    this.On = !0;
    return this
};
gvjs_PE.prototype.gna = function(a) {
    a = gvjs_fy(0, typeof a === gvjs_f ? a : 3);
    this.rz = [new gvjs_kz(a, Math.pow(10, 15), "Quadrillion", "Quadrillion"), new gvjs_kz(a, Math.pow(10, 12), "Trillion", "Trillion"), new gvjs_kz(a, Math.pow(10, 9), "Billion", "Billion"), new gvjs_kz(a, Math.pow(10, 6), "Million", "Million")];
    return this
};
gvjs_PE.prototype.hna = function(a) {
    var b = gvjs_fy(0, typeof a === gvjs_f ? a : 3);
    a = new gvjs_kz(b, Math.pow(10, 15), "Q", "Q");
    var c = new gvjs_kz(b, Math.pow(10, 12), "T", "T");
    var d = new gvjs_kz(b, Math.pow(10, 9), "B", "B");
    b = new gvjs_kz(b, Math.pow(10, 6), "M", "M");
    this.rz = [a, c, d, b];
    return this
};
gvjs_PE.prototype.Sd = function() {
    var a = gvjs_z(this.c3);
    if (this.On && null == a.pattern)
        if (typeof this.cv === gvjs_f || typeof this.NK === gvjs_f) {
            var b = typeof this.cv === gvjs_f ? this.cv : 0;
            a.pattern = gvjs_fy(b, typeof this.NK === gvjs_f ? this.NK : typeof this.cv === gvjs_f ? b : 15)
        } else a.pattern = gvjs_3b, null == a.significantDigits && (a.significantDigits = this.kz);
    return new gvjs_RE(new gvjs_Aj(a), this.rz, this.kz, this.Js)
};

function gvjs_RE(a, b, c, d) {
    this.R1 = a;
    this.rz = b || [];
    this.kz = c || null;
    this.Js = d || null
}
gvjs_RE.prototype.format = function(a) {
    var b = 0 > a;
    a = Math.abs(a);
    a = gvjs_uy(this.kz || 15, a);
    for (var c = null, d = 0; d < this.rz.length; d++) {
        var e = this.rz[d];
        if (a >= e.magnitude) {
            c = e.format(a);
            break
        }
    }
    null == c && (c = this.R1.formatValue(a));
    this.Js && (a = this.Js.symbol, d = this.Js.uta ? " " : "", c = this.Js.position === gvjs_i ? c + d + a : a + d + c);
    return b ? "-" + c : c
};
gvjs_RE.prototype.formatValue = function(a) {
    return this.format(a)
};
gvjs_RE.prototype.parse = function(a) {
    return this.R1.parse(a)
};

function gvjs_SE(a, b, c, d) {
    this.value = a;
    this.position = b;
    this.Jha = c;
    this.label = this.label = d
}
gvjs_SE.prototype.getPosition = function() {
    return Math.round(this.position)
};
gvjs_SE.prototype.getValue = function() {
    return this.value
};
gvjs_SE.prototype.Xe = function() {
    return this.label
};
gvjs_SE.prototype.mj = gvjs_p(94);

function gvjs_TE() {};

function gvjs_UE(a, b) {
    this.spacing = a;
    this.offset = void 0 === b ? 0 : b;
    this.position = 0
}
gvjs_r(gvjs_UE, gvjs_TE);
gvjs_ = gvjs_UE.prototype;
gvjs_.next = function() {
    this.position++;
    return this.getValue()
};
gvjs_.ff = function() {
    this.position--;
    return this.getValue()
};
gvjs_.getValue = function() {
    return gvjs_uy(15, this.position * this.spacing + this.offset)
};
gvjs_.floor = function(a) {
    this.position = Math.floor((a - this.offset) / this.spacing);
    return this.getValue()
};
gvjs_.ceil = function(a) {
    this.position = Math.ceil((a - this.offset) / this.spacing);
    return this.getValue()
};
gvjs_.round = function(a) {
    this.position = Math.round((a - this.offset) / this.spacing);
    return this.getValue()
};

function gvjs_VE(a) {
    this.position = 0;
    this.Pia = a.concat();
    this.pE = a.length
}
gvjs_r(gvjs_VE, gvjs_TE);
gvjs_ = gvjs_VE.prototype;
gvjs_.next = function() {
    this.position++;
    return this.getValue()
};
gvjs_.ff = function() {
    this.position--;
    return this.getValue()
};
gvjs_.getValue = function() {
    var a = Math.floor(this.position / this.pE);
    return gvjs_4D(this.Pia[this.position - a * this.pE], a)
};
gvjs_.floor = function(a) {
    this.position = this.pE * gvjs_6D(a);
    if (this.getValue() !== a)
        for (; this.ff() > a;);
    return this.getValue()
};
gvjs_.ceil = function(a) {
    this.position = this.pE * gvjs_5D(a);
    if (this.getValue() !== a)
        for (; this.next() < a;);
    return this.getValue()
};
gvjs_.round = function(a) {
    this.position = this.pE * gvjs_6D(a);
    if (this.getValue() !== a) {
        for (; this.ff() > a;);
        if (a - this.getValue() < this.next() - a) return this.ff()
    }
    return this.getValue()
};

function gvjs_WE(a) {
    var b = 0;
    a = gvjs_q(a);
    for (var c = a.next(); !c.done; c = a.next()) b = Math.max(b, gvjs_ty(c.value));
    return b
};

function gvjs_XE(a, b, c, d) {
    this.Ra = a;
    this.EW = b;
    this.orientation = c;
    this.Fm = d;
    this.Gp = this.Za = null
}

function gvjs_YE(a) {
    if (a.Fm) {
        var b = a.Fm;
        b.kz = 15;
        b.On = !0;
        a.Za = a.Fm.Sd()
    }
}

function gvjs_afa(a, b) {
    if (a.Fm) {
        b = gvjs_WE(b);
        var c = a.Fm;
        c.cv = b;
        c.On = !0;
        gvjs_QE(a.Fm, b)
    }
}

function gvjs_ZE(a, b, c) {
    var d;
    return gvjs_sf(b, function(e, f) {
        f = 0 === f ? !0 : Math.abs(a.Ra.ld(e) - a.Ra.ld(d)) >= c;
        d = e;
        return f
    })
}

function gvjs__E(a, b, c) {
    if (null == c) return !0;
    a.Gp && a.Gp.multiple === c || (a.Gp = {}, a.Gp.multiple = c, a.Gp.v6 = Math.pow(10, gvjs_ty(c || 1)), a.Gp.Hia = Math.round(c * a.Gp.v6));
    return 1E-15 > Math.abs(gvjs_uy(15, b * a.Gp.v6) % a.Gp.Hia)
}

function gvjs_0E(a, b) {
    if (!a.Za) return !0;
    var c = {};
    return gvjs_sf(b, function(d) {
        var e = a.Za.formatValue(d);
        return null == c[e] ? (c[e] = d, !0) : !1
    })
}

function gvjs_1E(a, b) {
    if (!a.Za) return !0;
    var c = b.length;
    if (0 < c) {
        if (gvjs_2E(a, b[0], b[1])) return !1;
        for (; 1 < --c;)
            if (gvjs_2E(a, b[c - 1], b[c])) return !1
    }
    return !0
}

function gvjs_2E(a, b, c) {
    var d = gvjs_3E(a, b),
        e = gvjs_3E(a, c);
    return Math.abs(a.Ra.ld(b) - a.Ra.ld(c)) < (d + e) / 2
}

function gvjs_3E(a, b) {
    b = a.Za.formatValue(b);
    var c = a.EW;
    return a.orientation === gvjs_R ? c.pb(b) : c.getHeight(b)
}

function gvjs_4E(a, b, c) {
    return Math.abs(a.Ra.Hg(c) - a.Ra.Hg(b))
}

function gvjs_5E(a, b) {
    return gvjs_w(b, function(c) {
        c = gvjs_uy(15, c);
        var d = a.Za ? a.Za.formatValue(c) : "";
        return new gvjs_SE(c, a.Ra.ld(c), !0, d)
    })
}

function gvjs_6E(a, b) {
    for (var c = [], d = 0; d < b.length; d++) {
        var e = b[d];
        c.push(new gvjs_SE(e, a.Ra.ld(e), !1, null))
    }
    return c
}

function gvjs_7E(a, b, c, d, e, f) {
    f = void 0 === f ? null : f;
    if (c === d) return [c];
    if (!isFinite(c)) return [d];
    var g = [],
        h = b.floor(c);
    c = null;
    do(null == e || gvjs__E(a, h, e)) && (0 === h || null == f || Math.abs(h) >= f) && (g.push(h), c = h), h = b.next(); while (null == c || c < d);
    return g
};

function gvjs_8E(a, b, c, d, e, f) {
    var g = this;
    this.Ra = a;
    this.options = f;
    this.PF = {};
    this.Ep = gvjs_E(this.options, gvjs_st);
    this.PT = gvjs_E(this.options, gvjs_mu, this.Ep / 2);
    this.nc = new gvjs_XE(a, c, e, b);
    this.Yv = d;
    a = this.options.R(gvjs_rt, gvjs_bfa);
    a = typeof a === gvjs_f ? [a] : Array.isArray(a) ? a : [];
    b = this.options.R(gvjs_lu, gvjs_cfa);
    var h = typeof b === gvjs_f ? [b] : Array.isArray(b) ? b : [];
    this.multiple = this.options.ha(gvjs_tt);
    this.hz = this.options.ha(gvjs_nu);
    this.Sv = new gvjs_VE(a);
    gvjs_v(a, function(k) {
        var l = [];
        gvjs_v(h, function(m) {
            Number.isInteger(10 *
                k / m) && l.push(m)
        });
        g.PF[k.toString()] = l
    })
}
gvjs_8E.prototype.p3 = function(a, b) {
    function c(n) {
        return null != d.Yv ? (n = gvjs_5E(d.nc, n), d.Yv(n)) : gvjs_1E(d.nc, n)
    }
    var d = this;
    a = void 0 === a ? null : a;
    b = void 0 === b ? null : b;
    a = null != a ? a : this.Ra.Ae;
    b = null != b ? b : this.Ra.Jf;
    var e = b - a,
        f = Math.min(e, gvjs_dfa(this));
    if (0 === f) return {
        li: [],
        minorGridlines: []
    };
    this.Sv.floor(f);
    var g = !1,
        h = null,
        k = null,
        l = null;
    do {
        var m = new gvjs_UE(f);
        h = [];
        gvjs__E(this.nc, f, this.multiple) && (h = gvjs_7E(this.nc, m, a, b, this.multiple, null));
        if (h.length)
            if (gvjs_afa(this.nc, h), gvjs_YE(this.nc), gvjs_ZE(this.nc,
                    h, this.Ep) && gvjs_0E(this.nc, h) && c(h)) {
                g = !0;
                break
            } else if (g) break;
        f = this.Sv.next()
    } while (f <= e);
    return function() {
        k || (k = h, l = f);
        var n = gvjs_5E(d.nc, k),
            p = d.WR(l);
        return {
            li: n,
            minorGridlines: p
        }
    }()
};
gvjs_8E.prototype.WR = function(a) {
    var b = this.Ra.Ae,
        c = this.Ra.Jf,
        d = [],
        e = gvjs_uy(15, a / Math.pow(10, Math.floor(Math.log10(a))));
    e = this.PF[e.toString()] || [];
    if (0 === e.length) return d;
    var f = new gvjs_VE(e);
    f.floor(a / 20);
    e = f.getValue();
    do {
        if (Number.isInteger(a / e)) {
            var g = new gvjs_UE(e),
                h = [];
            gvjs__E(this.nc, e, this.hz) && (h = gvjs_7E(this.nc, g, b, c, this.hz, null));
            if (h.length && gvjs_ZE(this.nc, h, this.PT)) {
                d = gvjs_6E(this.nc, h);
                break
            }
        }
        e = f.next()
    } while (e < a);
    return d
};

function gvjs_dfa(a) {
    var b = a.Ra.DJ(),
        c = a.Ra.CJ(),
        d = Math.max(gvjs_4E(a.nc, b, b + a.Ep), gvjs_4E(a.nc, c, c - a.Ep)),
        e = a.Ra.ld(0);
    b <= e === e <= c && (d = Math.max(d, a.Ra.Hg(e + a.Ep)));
    return 0 === d ? 0 : a.Sv.ceil(d)
}
var gvjs_bfa = [1, 2, 2.5, 5],
    gvjs_cfa = [1, 1.5, 2, 2.5, 5];

function gvjs_9E(a, b) {
    this.fL = a;
    this.position = this.location = 0;
    this.PE = Math.floor(a / 10);
    this.co = a - this.PE;
    this.SK = gvjs_5D(Math.abs(b));
    this.rw = this.co * this.SK
}
gvjs_r(gvjs_9E, gvjs_TE);

function gvjs_$E(a) {
    var b = Math.floor(a.position / a.co);
    a = 10 * (a.position + a.PE - b * a.co) / a.fL;
    0 === a && (a = 1);
    return gvjs_4D(a, b)
}
gvjs_ = gvjs_9E.prototype;
gvjs_.getValue = function() {
    this.position = Math.abs(this.location) + this.rw;
    return 0 < this.location ? gvjs_$E(this) : 0 > this.location ? -gvjs_$E(this) : 0
};
gvjs_.next = function() {
    this.location++;
    return this.getValue()
};
gvjs_.ff = function() {
    this.location--;
    return this.getValue()
};
gvjs_.floor = function(a) {
    var b = this.PE,
        c = gvjs_5D(Math.abs(a));
    if (Math.abs(a) <= Math.pow(10, this.SK)) return this.location = 0 > a ? -1 : 0, this.getValue();
    0 < a ? this.location = this.co * c - this.rw : 0 > a && (this.location = this.rw - this.co * c, b = -b);
    this.getValue() !== a && (c = this.fL * a / gvjs_4D(1, gvjs_6D(Math.abs(a))), this.location += Math.floor(c) - b);
    return this.getValue()
};
gvjs_.ceil = function(a) {
    var b = this.PE,
        c = gvjs_5D(Math.abs(a));
    if (Math.abs(a) <= Math.pow(10, this.SK)) return this.location = 0 < a ? 1 : 0, this.getValue();
    0 < a ? this.location = this.co * c - this.rw : 0 > a && (this.location = this.rw - this.co * c, b = -b);
    this.getValue() !== a && (c = this.fL * a / gvjs_4D(1, gvjs_6D(Math.abs(a))), this.location += Math.ceil(c) - b);
    return this.getValue()
};
gvjs_.round = function(a) {
    var b = gvjs_5D(Math.abs(a));
    if (Math.abs(a) <= Math.pow(10, this.SK)) return this.location = 0;
    if (0 < a) {
        this.location = this.co * b - this.rw;
        if (this.next() > a) return a - this.getValue() >= this.ff() - a ? this.next() : this.getValue();
        this.ff()
    } else if (0 > a) {
        this.location = this.rw - this.co * b;
        if (this.ff() < a) return a - this.getValue() < this.next() - a ? this.ff() : this.getValue();
        this.next()
    }
    this.getValue() !== a && (b = this.fL * a / gvjs_4D(1, gvjs_6D(Math.abs(a))), this.location += Math.round(b) - this.PE);
    return this.getValue()
};

function gvjs_aF(a, b, c, d, e, f, g) {
    var h = this;
    this.Ra = a;
    this.options = f;
    this.PF = {};
    this.Qj = Math.abs(g) || 1;
    this.Ep = gvjs_E(this.options, gvjs_st);
    this.PT = gvjs_E(this.options, gvjs_mu, this.Ep / 5);
    this.nc = new gvjs_XE(a, c, e, b);
    this.Yv = d;
    a = this.options.R(gvjs_rt, gvjs_efa);
    a = typeof a === gvjs_f ? [a] : Array.isArray(a) ? a : [];
    b = this.options.R(gvjs_lu, gvjs_ffa);
    var k = typeof b === gvjs_f ? [b] : Array.isArray(b) ? b : [];
    this.Sv = new gvjs_VE(a);
    b = gvjs_w(a, function(l) {
        for (l = 10 / l; 10 <= l;) l /= 10;
        return l
    }).sort(function(l, m) {
        return l > m ?
            1 : l < m ? -1 : 0
    });
    this.dA = new gvjs_VE(b);
    gvjs_v(a, function(l) {
        var m = [];
        gvjs_v(k, function(n) {
            Number.isInteger(10 * l / n) && m.push(n)
        });
        h.PF[l.toString()] = m
    });
    this.multiple = this.options.ha(gvjs_tt);
    this.hz = this.options.ha(gvjs_nu)
}
gvjs_aF.prototype.p3 = function(a, b) {
    function c(q) {
        return 0 < q.length && (q[0] > a || q[q.length - 1] < b) || !gvjs_ZE(e.nc, q, e.Ep) || !gvjs_0E(e.nc, q) ? !1 : null != e.Yv ? (q = gvjs_5E(e.nc, q), e.Yv(q)) : gvjs_1E(e.nc, q)
    }

    function d(q, r) {
        var t = e.nc,
            u = [],
            v = q.length,
            w = t.Ra.ld(0);
        if (w !== t.Ra.ld(q[0]) && w !== t.Ra.ld(q[v - 1])) {
            for (var x = 0; x < v; x++) 0 !== q[x] && w === t.Ra.ld(q[x]) || u.push(q[x]);
            q = u
        }
        t = gvjs_5E(e.nc, q);
        r = e.WR(r);
        return {
            li: t,
            minorGridlines: r
        }
    }
    var e = this,
        f;
    a = null != (f = a) ? f : this.Ra.Ae;
    var g;
    b = null != (g = b) ? g : this.Ra.Jf;
    f = b - a;
    g = this.Qj;
    var h = gvjs_gfa(this),
        k = gvjs_7E(this.nc, new gvjs_9E(h, g), a, b, null, this.Qj),
        l = Math.min(f, 10 / h),
        m = k,
        n = l;
    gvjs_YE(this.nc);
    if (2 > k.length) return d(k, l);
    var p = !1;
    if (c(k)) p = !0;
    else {
        l = k[0] || g;
        k = k[1];
        l === k && (l /= 10);
        this.dA.ceil(Math.max(1, gvjs_4D(1, gvjs_6D(Math.abs(l))) / Math.abs(k - l)));
        h = this.dA.getValue();
        this.Sv.floor(10 / h);
        l = this.Sv.getValue();
        do {
            h = 10 / l;
            h = new gvjs_9E(h, g);
            k = [];
            gvjs__E(this.nc, l, this.hz) && (k = gvjs_7E(this.nc, h, a, b, this.multiple, this.Qj));
            if (c(k)) {
                p = !0;
                break
            }
            l = this.Sv.next()
        } while (l < f);
        p ||
            (k = m, l = n)
    }
    return d(k, l)
};
gvjs_aF.prototype.WR = function(a) {
    var b = this.Ra.Ae,
        c = this.Ra.Jf,
        d = [],
        e = gvjs_uy(15, a / Math.pow(10, Math.floor(Math.log10(a))));
    e = this.PF[e.toString()] || [];
    if (0 === e.length) return d;
    var f = new gvjs_VE(e);
    f.floor(a / 20);
    e = f.getValue();
    do {
        if (Number.isInteger(a / e)) {
            var g = new gvjs_9E(gvjs_uy(15, 10 / e), this.Qj),
                h = [];
            gvjs__E(this.nc, e, this.hz) && (h = gvjs_7E(this.nc, g, b, c, this.hz, this.Qj));
            if (h.length && gvjs_ZE(this.nc, h, this.PT)) {
                d = gvjs_6E(this.nc, h);
                break
            }
        }
        e = f.next()
    } while (e < a);
    return d
};

function gvjs_gfa(a) {
    var b = a.Ra.ld(10 * a.Qj);
    a.dA.floor(1);
    do {
        var c = a.dA.next();
        c = a.Ra.ld(10 * a.Qj * (c - 1) / c)
    } while (Math.abs(b - c) >= a.Ep);
    c = a.dA.ff();
    1 > c && (c = a.dA.next());
    return c
}
var gvjs_efa = [1, 2, 5],
    gvjs_ffa = [1, 2, 5];

function gvjs_hfa() {};

function gvjs_bF(a, b, c, d) {
    this.Ae = a;
    this.Jf = b;
    this.xV = c;
    this.i8 = d;
    this.Tt = (this.i8 - this.xV) / (this.Jf - this.Ae);
    this.vF = this.Tt * this.Ae - this.xV
}
gvjs_bF.prototype.Hg = function(a) {
    return (a + this.vF) / this.Tt
};
gvjs_bF.prototype.ld = function(a) {
    return a * this.Tt - this.vF
};
gvjs_bF.prototype.DJ = function() {
    return this.xV
};
gvjs_bF.prototype.CJ = function() {
    return this.i8
};

function gvjs_cF(a, b, c, d, e, f, g, h, k, l, m, n, p) {
    if (e) {
        var q = c;
        c = d;
        d = q
    }
    this.Ae = a;
    this.Jf = b;
    this.sn = c;
    this.Rp = d;
    this.Je = e;
    this.cT = f;
    this.Qj = g;
    this.orientation = h;
    this.options = k;
    this.EW = l;
    this.Fm = m;
    this.Yv = n;
    this.T5 = p;
    this.Ra = gvjs_dF(this)
}

function gvjs_dF(a) {
    a.Ra = 1 === a.cT ? new gvjs_bF(a.Ae, a.Jf, a.sn, a.Rp) : new gvjs_7D(a.Ae, a.Jf, a.sn, a.Rp, a.cT, a.Qj);
    a.T5 && a.T5(a.Ra);
    return a.Ra
}

function gvjs_eF(a, b, c, d, e) {
    var f = 100;
    do {
        if (0 > f--) break;
        a.Ae = b;
        a.Jf = c;
        gvjs_dF(a);
        var g = b;
        var h = c;
        var k = a;
        var l = b,
            m = c;
        if (k.Ae === k.Jf) {
            var n = k.sn + (k.Rp - k.sn) / 2,
                p = "";
            k.Fm && (p = k.Fm.Sd().format(k.Ae));
            k = {
                li: [new gvjs_SE(k.Ae, n, !1, p)],
                minorGridlines: void 0
            }
        } else {
            n = k.Ra;
            p = k.options;
            var q = k.Qj,
                r = k.orientation,
                t = k.EW,
                u = k.Fm,
                v = k.Yv;
            if (n.Ae === n.Jf) var w = 1;
            else {
                var x = Math.min(n.DJ(), n.CJ()),
                    y = Math.max(n.DJ(), n.CJ()),
                    z = n.ld(0),
                    A = Math.abs(n.Hg(x)),
                    B = Math.abs(n.Hg(y)),
                    D = Math.max(A, B);
                w = 0;
                if (x > z || z > y) w = Math.min(A,
                    B);
                x = n.ld(D);
                w = n.ld(w);
                w = Math.abs(n.Hg(w + 10) - n.Hg(w)) / Math.abs(n.Hg(x + 10) - n.Hg(x))
            }
            k = (.65 < w && .5 < k.cT ? new gvjs_8E(n, u, t, v, r, p) : new gvjs_aF(n, u, t, v, r, p, q)).p3(l, m)
        }
        n = k.li;
        1 < n.length && (null != d && (b = n[0].getValue()), null != e && (c = n[n.length - 1].getValue()));
        g = b !== g || c !== h;
        if (isNaN(b) || isNaN(c)) g = !1, b = null != d ? d : b, c = null != e ? e : c
    } while (g);
    if (!k) throw Error("Failed creating decorations");
    k.min = b;
    k.max = c;
    return k
}

function gvjs_ifa(a, b, c, d, e) {
    var f = a,
        g = b,
        h = .005 * (b - a);
    b += h;
    a -= h;
    return gvjs_eF(new gvjs_cF(a, b, c, d, !1, 1, 0, gvjs_R, e, null, null, null, null), f, g, null, null).li
};

function gvjs_fF() {
    this.ai = this.Zg = null
}
gvjs_ = gvjs_fF.prototype;
gvjs_.adoptText = function(a) {
    this.Zg = a
};
gvjs_.first = function() {
    return this.ai = 0
};
gvjs_.current = function() {
    return this.ai || 0
};
gvjs_.next = function(a) {
    a = this.peek(a);
    return null == a ? a : this.ai = a
};

function gvjs_gF(a, b) {
    b.lastIndex = a.ai;
    b = b.exec(a.Zg);
    return !b || 0 > b.index ? a.Zg.length : b.index + b[0].length
}
gvjs_.peek = function(a) {
    if (0 === a) a = gvjs_gF(this, /(\r\n|\n|\r)/g);
    else if (1 === a) a = gvjs_gF(this, /([`~!@#$%^&*()_+\-=\[\]\\{}|;':",\.\/<>?]|[ \t\u2009\u200b]+)/g);
    else if (2 === a) a = gvjs_gF(this, /[\u00ad]/g);
    else if (3 === a) a: {
        a = this.Zg.length;
        for (var b = this.ai + 1; b < a; b++)
            if (gvjs_dea(this.Zg.charCodeAt(b - 1), this.Zg.charCodeAt(b))) {
                a = b;
                break a
            }
        a = this.Zg.length
    }
    else a = this.Zg.length;
    return a
};

function gvjs_hF() {
    this.zp = {}
}
gvjs_hF.prototype.add = function(a, b, c, d) {
    null == b ? this.zp[a] = d ? {
        Et: d,
        levels: c
    } : c : (a in this.zp || (this.zp[a] = {}), this.zp[a][b] = d ? {
        Et: d,
        levels: c
    } : c)
};

function gvjs_iF(a, b) {
    if (null == b) return Object.keys(a.zp);
    var c = [],
        d;
    for (d in a.zp) {
        var e = a.zp[d];
        if (typeof e === gvjs_f) e === b && c.push(d);
        else if (e.Et) 0 <= e.levels.indexOf(b) && c.push(d);
        else
            for (var f in e) {
                var g = e[f];
                if (typeof g === gvjs_f) g === b && c.push(d);
                else if (g.Et) 0 <= g.levels.indexOf(b) && c.push(d);
                else throw Error("Unknown type");
            }
    }
    return c
}
gvjs_hF.prototype.YB = function(a, b, c) {
    if (!(a in this.zp)) throw Error("Error: unknown iterator type " + a);
    a = this.zp[a];
    if (typeof a === gvjs_f) return a;
    if (a.Et) return a.Et(c);
    if (b in a) {
        a = a[b];
        if (typeof a === gvjs_f) return a;
        if (a.Et) return a.Et(c)
    }
    return null
};

function gvjs_jF(a) {
    var b = this;
    this.jia = a;
    this.eE = {};
    this.aI = new gvjs_hF;
    this.Jp = {};
    this.Zg = this.ai = null;
    this.YB(gvjs_d, gvjs_f, 0);
    this.YB(gvjs_d, gvjs_e, [1, 2], function(c) {
        return "\u00ad" === b.Zg[c - 1] ? 2 : 1
    });
    this.YB("character", null, 3)
}
gvjs_ = gvjs_jF.prototype;
gvjs_.adoptText = function(a) {
    this.Zg = a;
    for (var b in this.eE) this.eE[b].adoptText(a)
};

function gvjs_kF(a, b) {
    var c = a.eE[b];
    c || (c = a.eE[b] = new window.Intl.v8BreakIterator(a.jia, {
        type: b
    }), null != a.Zg && c.adoptText(a.Zg), null != a.ai && c.first());
    return c
}
gvjs_.YB = function(a, b, c, d) {
    this.aI.add(a, b, c, d)
};

function gvjs_lF(a, b, c) {
    c.next();
    if (c.current() >= a.Zg.length) return !0;
    if (c.current() > a.ai) {
        var d = c.breakType();
        c = c.current();
        var e = a.aI.YB(b, d, c);
        if (null == e) throw Error("Break type " + d + " in " + b + " iterator was classified as null.");
        e in a.Jp || (a.Jp[e] = []);
        a.Jp[e].push(c)
    }
    return !1
}

function gvjs_mF(a, b) {
    for (var c = a.Jp[b]; c && 0 < c.length && c[0] <= a.ai;) c.shift();
    c = gvjs_iF(a.aI, b);
    for (var d = {}, e = !1; !(e || a.Jp[b] && 0 !== a.Jp[b].length);) {
        e = !0;
        for (var f = c.length, g = 0; g < f; g++) {
            var h = c[g],
                k = gvjs_kF(a, h);
            d[h] || (e = !1, gvjs_lF(a, h, k) && (d[h] = !0))
        }
    }
}
gvjs_.first = function() {
    for (var a = gvjs_iF(this.aI), b = a.length, c = 0; c < b; c++) gvjs_kF(this, a[c]).first();
    this.Jp = {};
    return this.ai = 0
};
gvjs_.current = function() {
    return this.ai || 0
};
gvjs_.next = function(a) {
    gvjs_mF(this, a);
    a = this.Jp[a];
    if (null != a && 0 < a.length) {
        a = this.ai = a.shift();
        for (var b in this.eE)
            for (var c = gvjs_kF(this, b); c.current() <= a;) gvjs_lF(this, b, c);
        return this.ai
    }
    return this.Zg.length
};
gvjs_.peek = function(a) {
    gvjs_mF(this, a);
    a = this.Jp[a];
    return null != a && 0 < a.length ? a[0] : this.Zg.length
};

function gvjs_nF(a) {
    var b = "Fu";
    if (a.Fu && a.hasOwnProperty(b)) return a.Fu;
    b = new a;
    return a.Fu = b
};

function gvjs_jfa() {
    this.jna = window.Intl && !!window.Intl.v8BreakIterator
}

function gvjs_oF() {
    var a = ["en"];
    return gvjs_nF(gvjs_jfa).jna ? new gvjs_jF(a) : new gvjs_fF
};

function gvjs_kfa(a, b, c, d, e, f) {
    var g = null;
    f = f ? 2 : 3;
    for (var h = 0; h <= f; h++) {
        var k = c.peek(h);
        if (null == g || k < g.position) g = {
            position: k,
            level: h
        };
        if (a(b(d, k)) <= e) return h
    }
    return g && g.level || f
}

function gvjs_lfa(a) {
    return function(b, c) {
        b = gvjs_2e(a.slice(b, c));
        "\u00ad" === b[b.length - 1] && (b = b.slice(0, b.length - 1) + "-");
        return b
    }
}

function gvjs_pF(a, b) {
    b = null == b ? a.length : b;
    return 0 <= b ? gvjs_2e(a.slice(0, b)) + "\u2026" : gvjs_uq.slice(0, b)
}

function gvjs_mfa(a, b, c, d) {
    if (a(gvjs_pF(b)) <= c) return gvjs_pF(b);
    var e = gvjs_oF();
    e.adoptText(b);
    e.first();
    var f = e.next(3),
        g = a(b.slice(0, f)) <= c;
    if (d && !g || !d && a(gvjs_pF(b, f)) > c)
        for (d = 0; - 3 <= d && !(b = gvjs_pF(b, d), a(b) <= c); d--);
    else {
        for (; a(gvjs_pF(b, e.peek(3))) <= c;) f = e.next(3);
        if (d && a(gvjs_pF(b, f)) > c)
            for (d = b.slice(0, f), e = 0; - 3 <= e && !(b = d + gvjs_pF(b, e), a(b) <= c); e--);
        else b = gvjs_pF(b, f)
    }
    return b
}
var gvjs_qF = gvjs_mx(function(a, b, c, d, e, f) {
    if ("" === b) return {
        lines: [],
        Is: !1
    };
    var g = null == f || null == f.truncate ? !0 : f.truncate,
        h = null == f || null == f.O7 ? !1 : f.O7;
    f = null == f || null == f.Z1 ? !1 : f.Z1;
    var k = a;
    a = function(w) {
        return k(w, c).width
    };
    var l = gvjs_oF();
    l.adoptText(b);
    l.first();
    for (var m = !1, n = gvjs_lfa(b), p = !1, q = [], r = 0;;) {
        var t = gvjs_kfa(a, n, l, r, d, f),
            u = l.next(t);
        if (0 !== t)
            for (; u < b.length && a(n(r, l.peek(t))) <= d;) u = l.next(t);
        q.push(n(r, u));
        var v = a(q[q.length - 1]) <= d;
        if (u >= b.length || q.length >= e || !v) {
            (u < b.length || !v) &&
            g ? (0 !== t && (q[q.length - 1] = n(r, l.peek(t))), p = !0) : u < b.length && (m = !0);
            break
        }
        r = u
    }
    p && (q[q.length - 1] = gvjs_mfa(a, q[q.length - 1], d, h && 1 === q.length), m = !0);
    1 === q.length && "" === q[0] && (q = []);
    return {
        lines: q,
        Is: m
    }
}, {
    wM: function(a, b) {
        a = [a];
        for (var c = b.length, d = 1; d < c; d++) a.push(b[d]);
        return gvjs_Fg(a)
    }
});

function gvjs_rF(a, b, c, d, e, f) {
    function g(h) {
        return a(h, c)
    }
    e = null != e ? Math.floor(e) : 1;
    if (0 >= d) return {
        lines: [],
        tc: 0 < b.length,
        Bp: 0
    };
    if (0 == e) return {
        lines: [],
        tc: !1,
        Bp: 0
    };
    b = gvjs_qF(g, b, c, d, e, {
        truncate: !0,
        O7: null != f ? f : !1,
        Z1: !0
    });
    return {
        lines: b.lines,
        tc: b.Is,
        Bp: 0 < b.lines.length ? Math.max.apply(null, b.lines.map(g).map(function(h) {
            return h.width
        })) : 0
    }
}

function gvjs_nfa(a) {
    var b = {
        background: gvjs_Mt,
        padding: "1px",
        border: gvjs_zq
    };
    null != a.fontSize && (b.fontSize = a.fontSize + gvjs_Z, b.margin = a.fontSize + gvjs_Z);
    null != a.fontName && (b.fontFamily = a.fontName);
    return b
};

function gvjs_sF(a, b, c) {
    for (var d = 0; d < a.length; ++d) b.bb(a[d].Af.left, a[d].Af.top, a[d].Af.width, a[d].Af.height, a[d].brush, c)
}

function gvjs_tF(a, b, c) {
    for (var d = 0; d < a.length; ++d) {
        var e = new gvjs_uz;
        e.move(a[d].path[0], a[d].path[1]);
        e.na(a[d].path[2], a[d].path[3]);
        e.na(a[d].path[4], a[d].path[5]);
        e.close();
        b.Ba(e, a[d].brush, c)
    }
}

function gvjs_uF(a, b, c) {
    for (var d = 0; d < a.length; ++d) b.Oc(a[d].text, a[d].x, a[d].y, 1, gvjs_l, gvjs_l, a[d].style, c)
};

function gvjs_vF(a, b) {
    this.x = void 0 === a ? 0 : a;
    this.y = void 0 === b ? 0 : b
}
gvjs_vF.prototype.clone = function() {
    return new gvjs_vF(this.x, this.y)
};

function gvjs_wF(a, b) {
    var c = a.html,
        d = gvjs_ii(b);
    c = gvjs_Sda(d, c);
    b.appendChild(c);
    var e = a.anchor;
    b = a.pivot;
    d = a.ut;
    var f = a.spacing;
    a = a.margin;
    var g = new gvjs_B(c.clientWidth, c.clientHeight),
        h = d.right - e.x >= g.width + a,
        k = e.x - d.left >= g.width + a,
        l = d.bottom - e.y >= g.height + a,
        m = e.y - d.top >= g.height + a,
        n = gvjs_Sx(e.x - b.x),
        p = gvjs_Sx(e.y - b.y);
    0 === n && n === p && (n = !k || h || l || m ? 1 : -1, p = m || h ? -1 : 1);
    h = e.x + (f + g.width / 2) * n;
    e = e.y + (f + g.height / 2) * p;
    e = {
        box: new gvjs_H(e - g.height / 2, h + g.width / 2, e + g.height / 2, h - g.width / 2),
        Kg: null
    };
    gvjs_zD(e,
        d, b, a, 0);
    gvjs_AD(e, d, b, a);
    b = new gvjs_A(e.box.left, e.box.top);
    c.style.width = c.clientWidth + 1 + gvjs_Z;
    c.style.height = c.clientHeight + gvjs_Z;
    c.style.left = b.x + gvjs_Z;
    c.style.top = b.y + gvjs_Z;
    return c
};

function gvjs_xF(a, b, c) {
    a = gvjs_yF(a, b);
    b.appendChild(c, a);
    return a
}

function gvjs_yF(a, b) {
    var c = b.ta();
    c.j().setAttribute(gvjs_Qb, gvjs_jt);
    var d = a.outline,
        e = new gvjs_uz,
        f = new gvjs_H(d.box.top + .5, d.box.right + .5, d.box.bottom + .5, d.box.left + .5),
        g = d.Kg;
    e.move(f.left + 1, f.bottom);
    e.ke(f.left + 1, f.bottom - 1, 1, 1, 180, 270, !0);
    e.na(f.left, f.top + 1);
    e.ke(f.left + 1, f.top + 1, 1, 1, 270, 0, !0);
    if (null != g && g[0].y == d.box.top)
        for (var h = 0; 3 > h; ++h) e.na(g[h].x + .5, g[h].y + .5);
    e.na(f.right - 1, f.top);
    e.ke(f.right - 1, f.top + 1, 1, 1, 0, 90, !0);
    e.na(f.right, f.bottom - 1);
    e.ke(f.right - 1, f.bottom - 1, 1, 1, 90, 180, !0);
    if (null != g && g[0].y == d.box.bottom)
        for (d = 0; 3 > d; ++d) e.na(g[d].x + .5, g[d].y + .5);
    e.close();
    b.Ba(e, a.boxStyle, c);
    a = a.NB;
    for (e = 0; e < a.entries.length; e++) switch (f = a.entries[e], d = f.Ob, g = b.ta(), b.appendChild(c, g), d.type) {
        case gvjs_d:
            d = d.data;
            f = f.data;
            f.background && b.bb(f.background.box.left, f.background.box.top, f.background.box.right - f.background.box.left, f.background.box.bottom - f.background.box.top, d.background.brush, g);
            for (h = 0; h < f.items.length; h++) {
                var k = d.items[h],
                    l = f.items[h];
                switch (k.type) {
                    case gvjs_n:
                        b.Oc(k.data.text,
                            a.Y7 ? l.box.right : l.box.left, l.box.top, 1, gvjs_l, gvjs_l, k.data.style, g, a.Y7);
                        break;
                    case gvjs_uv:
                        b.bb(l.box.left, l.box.top, l.box.right - l.box.left, l.box.bottom - l.box.top, k.data.brush, g)
                }
            }
            null != d.id && (d = gvjs_rD([gvjs_ir, d.id]), b.Cl(g, d));
            break;
        case gvjs_hv:
            d = d.data, f = f.data, h = new gvjs_uz, h.move(f.line.x0, f.line.y0), h.na(f.line.x1, f.line.y1), b.Ba(h, d.brush, g)
    }
    return c
};

function gvjs_zF(a, b) {
    this.renderer = b;
    this.fj = a;
    this.Po = null;
    this.ae = {};
    this.pu = {};
    this.Xc = this.xp = this.OW = this.ca = null
}
gvjs_ = gvjs_zF.prototype;
gvjs_.drawChart = function(a, b) {
    this.ae = {};
    this.pu = {};
    this.renderer.clear();
    this.fj.clear();
    gvjs_AF(this, a, b);
    a = this.ca;
    a = this.renderer.Rk(a.width, a.height);
    gvjs_BF(this, b, a)
};

function gvjs_AF(a, b, c) {
    var d = new gvjs_tD(2);
    d.ed(0, b);
    d.ed(1, c);
    a.ca = d.compact()
}

function gvjs_BF(a, b, c) {
    a.registerElement(c.j(), gvjs_Ob);
    var d = a.ca,
        e = a.renderer,
        f = d.HB;
    !gvjs_Ew(f) && !gvjs_Cw(f) || e.bb(0, 0, d.width, d.height, f, c);
    d.titlePosition == gvjs_Nu && (f = a.jr(d.title, c, !0), a.registerElement(f, gvjs_ce));
    a.xp = e.ta(!0);
    f = d.legend;
    a.GC(f);
    f && (e.appendChild(c, a.xp), a.registerElement(a.xp.j(), gvjs__t));
    a.Xc = e.ta(!0);
    f = d.Ag;
    a.FC(f);
    f && f.position != gvjs_Kt && (e.appendChild(c, a.Xc), a.ae.colorbar = a.Xc.j());
    a.OW = e.ta(!1);
    a.d2(d, c) || a.UQ(d, c);
    e.appendChild(c, a.OW);
    a.Po = b
}
gvjs_.UQ = function(a, b) {
    var c = {
        color: gvjs_Or,
        fontName: a.Kf,
        fontSize: a.rh,
        bold: !1,
        italic: !1,
        zd: !1
    };
    this.vh(gvjs_Vq, c, a.chartArea.width);
    var d = a.chartArea.top + Math.round(a.chartArea.height / 2);
    this.renderer.Mj(gvjs_Vq, a.chartArea.left, d, a.chartArea.left + a.chartArea.width, d, gvjs_X, gvjs_X, c, b)
};
gvjs_.GC = function(a) {
    if (a) {
        var b = a.Zq;
        if (b) {
            var c = a.Dg || 0,
                d = a.nd.length;
            if (a.wF) var e = a.area;
            else e = b.map(function(f) {
                return gvjs_CF(f)
            }, this), e = gvjs_FA(e);
            e && (e = gvjs_Oy(e), this.renderer.bb(e.left, e.top, e.width, e.height, new gvjs__(gvjs_Hw), this.xp));
            for (e = 0; e < b.length; e++) gvjs_ofa(this, b[e]);
            gvjs_pfa(this, a.wF, c, d)
        }
    }
};

function gvjs_CF(a) {
    var b = [];
    if (a.ka) {
        var c = gvjs_JD(a.ka);
        c && b.push(c)
    }
    a.square && b.push(gvjs_Ny(a.square.coordinates));
    return gvjs_FA(b)
}

function gvjs_DF(a, b, c, d, e, f, g) {
    var h = a.renderer.zC(),
        k = f.type,
        l = Number(f.sides);
    null != l && isFinite(l) || (l = 5);
    var m = Number(f.rotation);
    null != m && isFinite(m) || (m = 0);
    m = m / 180 * Math.PI - Math.PI / 2;
    "triangle" === k ? (k = gvjs_Yu, l = 3) : k === gvjs_uv ? (k = gvjs_Yu, l = 4, m += Math.PI / 4) : "diamond" === k && (k = gvjs_Yu, l = 4);
    var n = k === gvjs_wv;
    500 < l && (k === gvjs_Yu || k === gvjs_wv) && (k = gvjs_es);
    if (k === gvjs_Yu || k === gvjs_wv) {
        f = Number(f.dent);
        null != f && isFinite(f) || (5 <= l ? (f = Math.cos(Math.PI / l), f -= Math.pow(Math.sin(Math.PI / l), 2) / Math.sin(Math.PI /
            2 - Math.PI / l)) : f = .3);
        f *= d;
        k === gvjs_wv && (l *= 2);
        k = new gvjs_uz;
        for (var p = 0; p < l; p++) {
            var q = d;
            n && p % 2 && (q = f);
            var r = 2 * Math.PI / l * p + m,
                t = Math.cos(r) * q + b;
            q = Math.sin(r) * q + c;
            0 < p ? k.na(t, q) : k.move(t, q)
        }
        k.close();
        b = a.renderer.Jb(k, e)
    } else b = a.renderer.Ex(b, c, d, e);
    b && g && a.renderer.appendChild(g, b);
    a.renderer.Kx(h);
    return b
}
gvjs_.VQ = function(a, b) {
    var c = this.ca.series[a.index];
    if (this.ca.eX && c && !c.Uk && c.pointShape) {
        var d = a.square.coordinates.left,
            e = a.square.coordinates.width,
            f = a.square.coordinates.height,
            g = d + e / 2;
        a = a.square.coordinates.top + f / 2;
        c.jo && this.renderer.bb(d, a, e, f / 2, c.jo, b);
        var h = .5 * f,
            k = c.Lb;
        k && (k.strokeWidth > h && (k = k.clone(), k.vi(h)), this.renderer.WQ(d, a, d + e, a, k, b));
        c.df && c.CG && ((d = c.pointShape) || (d = {
            type: gvjs_es
        }), gvjs_DF(this, g, a, Math.min(c.pointRadius, f / 2, e / 2), c.df, d, b))
    } else this.renderer.bb(a.square.coordinates.left,
        a.square.coordinates.top, a.square.coordinates.width, a.square.coordinates.height, a.square.brush, b)
};

function gvjs_ofa(a, b) {
    if (b.isVisible) {
        var c = a.renderer.ta(!1),
            d = c.j();
        b.id && d.setAttribute("column-id", b.id);
        var e = gvjs_rD([gvjs_5t, b.index]);
        a.registerElement(d, e, gvjs_5t);
        if (d = gvjs_CF(b)) d = gvjs_Oy(d), a.renderer.bb(d.left, d.top, d.width, d.height, new gvjs__(gvjs_Hw), c);
        b.ka && a.jr(b.ka, c);
        b.square && a.VQ(b, c);
        if (b.Ie && b.Ie.isVisible && b.Ie.brush) {
            var f = b.Ie.coordinates.x,
                g = b.Ie.coordinates.y,
                h = b.Ie.brush;
            d = a.renderer;
            e = d.ta();
            d.bb(f, g, 12, 12, h, e);
            d.appendChild(c, e);
            h = new gvjs_uz;
            h.move(f + 2, g + 2);
            h.na(f +
                12 - 2, g + 12 - 2);
            h.move(f + 12 - 2, g + 2);
            h.na(f + 2, g + 12 - 2);
            f = new gvjs__;
            f.Jc(gvjs_ga);
            f.vi(2);
            d.Ba(h, f, e);
            d = e.j();
            b = gvjs_rD([gvjs_3u, b.index]);
            a.registerElement(d, b)
        }
        a.renderer.appendChild(a.xp, c)
    }
}

function gvjs_pfa(a, b, c, d) {
    b && (gvjs_EF(a, b.WU, c, d, -1), b.FU && a.jr(b.FU, a.xp), gvjs_EF(a, b.cU, c, d, 1))
}

function gvjs_EF(a, b, c, d, e) {
    if (b) {
        var f = gvjs_wz(b.path);
        f = a.renderer.Ba(f, b.brush, a.xp);
        b.active && (b = gvjs_rD([gvjs_6t, e, c, d]), a.registerElement(f, b))
    }
}
gvjs_.FC = function(a) {
    if (a) {
        var b = a.definition,
            c = this.renderer,
            d = this.Xc;
        gvjs_sF(b.WP, c, d);
        gvjs_tF(b.yT, c, d);
        gvjs_uF(b.BW, c, d);
        a = this.renderer.bb(a.IC.left, a.IC.top, a.IC.width, a.IC.height, new gvjs__(gvjs_Hw), this.Xc);
        this.registerElement(a, "colorbar")
    }
};
gvjs_.vh = function(a, b, c) {
    var d = b.fontSize;
    a = this.renderer.el(a, b);
    a > c && (d = Math.max(1, Math.floor(d * c / a)));
    return d
};

function gvjs_FF(a, b) {
    var c = a.ae[b];
    c && (a.renderer.gf(c), delete a.ae[b])
}
gvjs_.VE = function(a, b) {
    a = a.html ? gvjs_wF(a, this.fj.getContainer()) : gvjs_xF(a, this.renderer, this.OW).j();
    this.registerElement(a, b)
};
gvjs_.jr = function(a, b, c) {
    (a = gvjs_GF(this, a, c)) && this.renderer.appendChild(b, a);
    return a
};

function gvjs_GF(a, b, c) {
    var d = b.lines;
    if (!d || 0 == d.length) return null;
    a = a.renderer;
    var e = b.textStyle,
        f = b.boxStyle,
        g = null != b.angle ? b.angle : 0,
        h = b.anchor ? b.anchor : {
            x: 0,
            y: 0
        },
        k = b.tooltip;
    c = !!k || c || !1;
    var l = a.ta();
    if (0 === g && f) {
        var m = gvjs_JD(b);
        if (m) {
            var n = Math.ceil(m.left - 3) + .5,
                p = Math.floor(m.top - 1) + .5;
            a.bb(n, p, Math.floor(m.right + 3) + .5 - n, Math.floor(m.bottom + 1) + .5 - p, f, l)
        }
    }
    for (f = 0; f < d.length; f++) m = d[f], 0 === g ? a.Oc(m.text, m.x + h.x, m.y + h.y, m.length, b.Yb, b.Mb, e, l) : gvjs_aea(a, m.text, m.x + h.x, m.y + h.y, m.length, g, b.Yb,
        b.Mb, e, l);
    if (c) {
        c = null;
        if (0 === g)(d = gvjs_JD(b)) && (c = a.bb(d.left, d.top, d.right - d.left, d.bottom - d.top, new gvjs__(gvjs_Hw), l));
        else {
            var q = gvjs_Ox(g);
            b = gvjs_Bx(b);
            b.angle = 0;
            h = (new gvjs_Ij(h.x, h.y)).rotate(-q);
            b.anchor = new gvjs_vF(h.x, h.y);
            for (h = 0; h < d.length; h++) g = (new gvjs_Ij(d[h].x, d[h].y)).rotate(-q), b.lines[h].x = g.x, b.lines[h].y = g.y;
            if (d = gvjs_JD(b)) d = [new gvjs_Ij(d.left, d.top), new gvjs_Ij(d.right, d.top), new gvjs_Ij(d.right, d.bottom), new gvjs_Ij(d.left, d.bottom)], d.forEach(function(r) {
                    r.rotate(q)
                }),
                d = gvjs_wz(d, !1), c = a.Ba(d, new gvjs__(gvjs_Hw), l)
        }
        k && c && gvjs_cea(a, c, k, gvjs_nfa(e))
    }
    return l.j()
}
gvjs_.Ed = function(a, b, c) {
    var d = this.ae[b];
    null == d ? this.renderer.appendChild(a, c) : this.renderer.replaceChild(a, c, d);
    this.registerElement(c, b)
};
gvjs_.registerElement = function(a, b, c) {
    a && (this.renderer.Cl(a, b), this.ae[b] = a, c && (this.pu[c] || (this.pu[c] = []), gvjs_tf(this.pu[c], b) || this.pu[c].push(b)))
};

function gvjs_HF(a, b) {
    var c = a.ae[b];
    c && (a.renderer.gf(c), delete a.ae[b])
}
gvjs_.getBoundingBox = function(a) {
    var b = [];
    if (this.ae[a]) {
        var c = this.renderer.getBoundingBox(this.ae[a]);
        c && b.push(c)
    }
    a = this.pu[a] || [];
    for (c = 0; c < a.length; ++c) {
        var d = this.renderer.getBoundingBox(this.ae[a[c]]);
        d && b.push(d)
    }
    return gvjs_FA(b)
};

function gvjs_IF() {
    this.Cb = []
}
gvjs_ = gvjs_IF.prototype;
gvjs_.kh = function(a, b) {
    this.Cb.push({
        brush: a,
        BV: b
    })
};
gvjs_.move = function(a, b) {
    this.kh(null, gvjs_tz(a, b))
};
gvjs_.na = function(a, b, c) {
    this.kh(a, {
        type: gvjs_d,
        data: {
            x: b,
            y: c
        }
    })
};
gvjs_.am = function(a, b, c, d, e, f, g) {
    this.kh(a, {
        type: gvjs_qs,
        data: {
            x1: b,
            y1: c,
            x2: d,
            y2: e,
            x: f,
            y: g
        }
    })
};
gvjs_.ke = function(a, b, c, d, e, f, g) {
    this.kh(a, {
        type: "arc",
        data: {
            cx: b,
            cy: c,
            rx: d,
            ry: e,
            gu: f,
            nq: g,
            Z4: void 0
        }
    })
};
gvjs_.close = function(a) {
    var b = this.Cb[0].BV.data;
    this.na(a, b.x, b.y)
};

function gvjs_JF(a) {
    switch (a.type) {
        case gvjs_vu:
        case gvjs_d:
        case gvjs_qs:
            return a = a.data, new gvjs_A(a.x, a.y);
        case "arc":
            a = a.data;
            var b = gvjs_Mx(a.nq, 360);
            return new gvjs_A(a.cx + gvjs_Qx(b - 90, a.rx), a.cy + gvjs_Rx(b - 90, a.ry));
        default:
            return new gvjs_A(0, 0)
    }
}
gvjs_.Jb = function(a) {
    for (var b = [], c = null, d = 0; d < this.Cb.length; d++) {
        var e = this.Cb[d],
            f = e.BV;
        if (f.type === gvjs_vu) c = gvjs_JF(f);
        else {
            a: {
                e = e.brush;
                for (var g = 0; g < b.length; g++) {
                    var h = b[g];
                    if (gvjs_ey(e, h.brush)) {
                        e = h;
                        break a
                    }
                }
                e = {
                    brush: e,
                    Cb: new gvjs_uz,
                    Gd: null
                };b.push(e)
            }
            gvjs_hi(e.Gd, c) || e.Cb.move(c.x, c.y);e.Cb.kh(f);c = e.Gd = gvjs_JF(f)
        }
    }
    if (0 === b.length) a = null;
    else if (1 === b.length) a = a.Jb(b[0].Cb, b[0].brush);
    else {
        c = a.ta();
        for (d = 0; d < b.length; d++) f = b[d], f = a.Jb(f.Cb, f.brush), a.appendChild(c, f);
        a = c.j()
    }
    return a
};

function gvjs_KF(a) {
    for (var b = new gvjs_uz, c = 0; c < a.Cb.length; c++) b.kh(a.Cb[c].BV);
    return b
};

function gvjs_LF(a, b) {
    return a.W && a.W.brush || a.brush || b.df
}

function gvjs_MF(a) {
    return !a || a.Zi
}

function gvjs_NF(a) {
    return a.type == gvjs_d || a.type == gvjs_Ar || a.type == gvjs_j
}

function gvjs_OF(a, b) {
    return null != a.visible ? a.visible : b.CG
}

function gvjs_PF(a, b) {
    var c = a.points[b],
        d = a.points[b - 1];
    a = a.points[b + 1];
    d = !d || !d.W || d.Zi;
    a = !a || !a.W || a.Zi;
    return !(!c || !c.W || c.Zi) && d && a
}

function gvjs_QF(a, b) {
    return a.W && null != a.W.radius ? a.W.radius : null != a.radius ? a.radius : b.pointRadius
}

function gvjs_RF(a, b) {
    return gvjs_QF(a, b) + gvjs_Dw(gvjs_LF(a, b)) / 2
}

function gvjs_SF(a) {
    return a.Jl !== gvjs_e && a.chartType == gvjs_c && a.orientation == gvjs_R
}

function gvjs_TF(a, b) {
    for (var c = new gvjs_IF, d = !0, e = !0, f = null, g = null, h = 0; h < a.points.length; h++) {
        var k = a.points[h];
        if (k && k.W && null != k.W.x && null != k.W.y) {
            d && (f = h, d = !1);
            var l = k.W,
                m = k && k.kp || a.Lb;
            if (e || null === m) c.move(l.x, l.y), e = !1;
            else {
                var n = a.points[g];
                a.MS && n.mn ? c.am(m, a.points[g].mn.x, a.points[g].mn.y, k.wp.x, k.wp.y, l.x, l.y) : c.na(m, l.x, l.y)
            }
            g = h
        } else e = !b || d
    }!d && a.sha && (d = b ? g : a.points.length - 1, f = b ? f : 0, b = a.points[f], null != d && null != f && a.points[d] && !gvjs_MF(b) && (f = b && b.kp || a.Lb, a.MS ? c.am(f, a.points[d].mn.x,
        a.points[d].mn.y, b.wp.x, b.wp.y, b.W.x, b.W.y) : c.close(f)));
    return c
}

function gvjs_UF(a) {
    for (var b = new gvjs_IF, c = !0, d = 0; d < a.points.length; d++) {
        var e = a.points[d],
            f = e && e.W;
        gvjs_MF(e) || !f || null == f.x || null == f.y ? c = !0 : (c || b.na(e && e.kp || a.Lb, f.mI, f.nI), (c || f.mI != f.kI || f.nI != f.lI) && b.move(f.kI, f.lI), c = !1)
    }
    return b
}

function gvjs_qfa(a, b, c) {
    return (c = (a = a.hAxes) && a[c || 0]) && c.position.Ld(b)
}

function gvjs_rfa(a, b, c) {
    return (c = (a = a.vAxes) && a[c || 0]) && c.position.Ld(b)
}

function gvjs_sfa(a, b, c) {
    return (c = (a = a.hAxes) && a[c || 0]) && c.position.Ai(b)
}

function gvjs_tfa(a, b, c) {
    return (c = (a = a.vAxes) && a[c || 0]) && c.position.Ai(b)
}

function gvjs_ufa(a, b, c, d) {
    for (var e = a.series, f = null, g = Infinity, h, k = new gvjs_A(b, c), l = 0, m = e.length; l < m; l++) {
        var n = e[l];
        if (!n.Fe) {
            var p = n;
            if (a.chartType === gvjs_Ru) {
                n = p.Hy.x - b;
                var q = p.Hy.y - c;
                h = 0 < -n * (p.Hy.y - p.Kd.y) + q * (p.Hy.x - p.Kd.x);
                if (0 < -(p.Jr.x - p.dg.x) * q + (p.Jr.y - p.dg.y) * n && h && Math.sqrt(Math.pow(p.Jr.x - b, 2) + Math.pow(p.Jr.y - c, 2)) < Math.sqrt(Math.pow(p.Jr.x - p.dg.x, 2) + Math.pow(p.Jr.y - p.dg.y, 2)) + d) return {
                    row: l,
                    col: void 0
                }
            } else {
                p = 0;
                for (q = n.points.length; p < q; p++)
                    if ((h = n.points[p]) && null != h.W) switch (h = h.W,
                        n.type) {
                        case gvjs_d:
                        case gvjs_Yr:
                        case gvjs_j:
                            h = gvjs_1x(k, h);
                            h < d && h < g && (f = {
                                col: p,
                                row: l
                            }, g = h);
                            break;
                        case gvjs_2r:
                        case gvjs_Hr:
                            var r = null;
                            if (n.type === gvjs_Hr) r = new gvjs_0(h.left, h.top, h.width, h.height);
                            else if (n.type === gvjs_2r) {
                                r = h.line;
                                var t = Math.min(h.rect.top, r.top);
                                r = new gvjs_0(h.rect.left, t, h.rect.width, Math.max(h.rect.top + h.rect.height, r.top + r.height) - t)
                            }
                            h = d;
                            r = r.distance(k);
                            (h = r > h ? null : r) && h < g && (f = {
                                col: p,
                                row: l
                            }, g = h);
                            break;
                        default:
                            throw Error("Unknown chart type for getPointDatum.");
                    }
                if (0 === g) break
            }
        }
    }
    return f
}

function gvjs_VF(a, b) {
    b = b || {};
    switch (a) {
        case gvjs_kv:
            return b.dark;
        case gvjs_lv:
            return b.light;
        case gvjs_jv:
            return b.color;
        default:
            return a
    }
};

function gvjs_WF(a, b) {
    gvjs_zF.call(this, a, b);
    this.Fd = null;
    this.QW = []
}
gvjs_r(gvjs_WF, gvjs_zF);

function gvjs_XF(a, b, c) {
    a.QW.push({
        definition: b,
        id: c
    })
}

function gvjs_YF(a) {
    var b = a.renderer.zC();
    gvjs_v(a.QW, function(c) {
        a.VE(c.definition, c.id)
    });
    a.renderer.Kx(b);
    a.QW = []
}
gvjs_ = gvjs_WF.prototype;
gvjs_.d2 = function(a, b) {
    function c(m) {
        m = a.series[m];
        return !a.Xb || m.type !== gvjs_j || m.CG
    }
    var d = this;
    gvjs_vfa(this, a);
    var e = this.renderer.ta(!1);
    this.renderer.appendChild(b, e);
    this.registerElement(e.j(), gvjs_cs);
    gvjs_y(this.Fd, function(m) {
        m.Kb || (m.Kb = d.renderer.ta(!(void 0 !== m.O_ && !m.O_)))
    });
    this.renderer.bb(a.chartArea.left, a.chartArea.top, a.chartArea.width, a.chartArea.height, a.N0, e);
    a.titlePosition == gvjs_Kt && this.jr(a.title, this.Fd.title.Kb, !0);
    a.OD && this.jr(a.OD, this.Fd.axistitle.Kb, !0);
    gvjs_v(a.Fa,
        function(m, n) {
            m.Ib && gvjs_ZF(d, m.Ib, null, n)
        });
    gvjs_y(a.hAxes, function(m) {
        gvjs_wfa(d, a, m)
    });
    gvjs_y(a.vAxes, function(m) {
        gvjs_xfa(d, a, m)
    });
    var f = new gvjs_0(a.chartArea.left, a.chartArea.top, a.chartArea.width, a.chartArea.height);
    this.renderer.Kx(f);
    for (var g = [], h = 0; h < a.series.length; h++) c(h) && g.push({
        HG: a.series[h].HG,
        index: h
    });
    gvjs_Cf(g, function(m, n) {
        return gvjs_Bf(m.HG, n.HG)
    });
    for (h = 0; h < g.length; h++) {
        var k = g[h].index;
        gvjs__F(this, a.series[k], k)
    }
    a.Xb && a.series[0].type === gvjs_j && gvjs_yfa(this, a, b);
    for (g =
        0; g < a.Fa.length; g++) a.Fa[g].tooltip && (h = gvjs_rD([gvjs_de, g]), gvjs_XF(this, a.Fa[g].tooltip, h));
    g = this.renderer.zC();
    gvjs_y(a.hAxes, function(m) {
        gvjs_0F(d, m)
    });
    gvjs_y(a.vAxes, function(m) {
        gvjs_0F(d, m)
    });
    this.renderer.Kx(g);
    gvjs_YF(this);
    var l = this.renderer.ta(!1);
    f = this.renderer.aC(l, f);
    this.renderer.appendChild(e, f);
    gvjs_v(gvjs_sD, function(m) {
        var n = d.Fd[m].Kb;
        if (n) {
            switch (d.Fd[m].position) {
                case gvjs_hs:
                    var p = l;
                    break;
                case gvjs_Pt:
                    p = e;
                    break;
                case gvjs_Ou:
                    p = b
            }
            d.renderer.appendChild(p, n)
        }
    });
    return !0
};

function gvjs_vfa(a, b) {
    a.Fd = {};
    var c = a.Fd;
    c.action = {
        position: gvjs_Ou
    };
    c.annotation = {
        position: gvjs_hs
    };
    c.annotationtext = {
        position: gvjs_Pt
    };
    c.area = {
        position: gvjs_hs
    };
    c.bar = {
        position: gvjs_hs
    };
    c.baseline = {
        position: gvjs_hs
    };
    c.bubble = {
        position: gvjs_hs
    };
    c.categorysensitivityarea = {
        position: gvjs_hs
    };
    c.candlestick = {
        position: gvjs_hs
    };
    c.histogram = {
        position: gvjs_hs
    };
    c.gridline = {
        position: gvjs_hs
    };
    c.interval = {
        position: gvjs_hs
    };
    c.line = {
        position: gvjs_hs
    };
    c.minorgridline = {
        position: gvjs_hs
    };
    c.overlaybox = {
        position: gvjs_hs
    };
    c.pathinterval = {
        position: gvjs_hs
    };
    c.point = {
        position: gvjs_Pt,
        O_: !1
    };
    c.pointsensitivityarea = {
        position: gvjs_Pt
    };
    c.steppedareabar = {
        position: gvjs_hs
    };
    c.tooltip = {
        position: gvjs_Ou
    };
    c.title = {
        position: b.titlePosition == gvjs_Kt ? gvjs_Pt : gvjs_Ou
    };
    c.axistick = {
        position: gvjs_Pt
    };
    c.axistitle = {
        position: b.axisTitlesPosition == gvjs_Kt ? gvjs_Pt : gvjs_Ou
    };
    var d = b.legend && b.legend.position == gvjs_Kt,
        e = d ? a.xp : null;
    d = d ? gvjs_Pt : gvjs_Ou;
    c.legend = {
        Kb: e,
        position: d
    };
    c.legendscrollbutton = {
        Kb: e,
        position: d
    };
    c.legendentry = {
        Kb: e,
        position: d
    };
    b = b.Ag && b.Ag.position == gvjs_Kt;
    c.colorbar = {
        Kb: b ? a.Xc : null,
        position: b ? gvjs_Pt : gvjs_Ou
    }
}

function gvjs__F(a, b, c) {
    if (b.type == gvjs_Yr) gvjs_zfa(a, b, c);
    else if (b.type == gvjs_Hr) gvjs_1F(a, b, c);
    else if (b.type == gvjs_xv) gvjs_1F(a, b, c);
    else if (b.type == gvjs_2r)
        for (var d = 0; d < b.points.length; d++) gvjs_2F(a, c, b.points[d], d);
    else if (b.type == gvjs_Ar) {
        d = a.ca.Jl !== gvjs_e;
        var e = a.ca.interpolateNulls;
        if (0 != b.points.length) {
            e = e && !d;
            for (var f = [], g = {
                    start: null,
                    end: null,
                    brush: null
                }, h = 0; h <= b.points.length; h++) {
                var k = b.points[h];
                gvjs_MF(k) ? e && h !== b.points.length || (null !== g.start && null !== g.end && f.push(g), h < b.points.length &&
                    (g = {
                        start: null,
                        end: null,
                        brush: null
                    })) : null === g.start ? g.start = h : (k = k && k.hK || b.jo, null === g.brush || gvjs_ey(g.brush, k) ? (g.end = h, g.brush = k) : (f.push(g), g = {
                    start: h - 1,
                    end: h,
                    brush: k
                }))
            }
            h = a.renderer.ta();
            for (k = 0; k < f.length; k++) {
                g = f[k];
                var l = g.brush,
                    m = new gvjs_uz,
                    n = m,
                    p = b,
                    q = d,
                    r = g.start;
                g = g.end;
                var t = !0,
                    u = null;
                n.move(p.points[r].W.oP, p.points[r].W.pP);
                for (var v = r; v <= g; v++) {
                    var w = p.points[v];
                    gvjs_MF(w) || (w = w.W, n.na(w.mI, w.nI), w.kI == w.mI && w.lI == w.nI || n.na(w.kI, w.lI), null != w.x && null != w.y && (t = !1, u = v))
                }
                if (!t)
                    if (q)
                        for (q =
                            g; q >= r; q--) g = p.points[q].W, n.na(g.qP, g.rP), g.oP == g.qP && g.pP == g.rP || n.na(g.oP, g.pP);
                    else null != u && (p = p.points[u].W, n.na(p.qP, p.rP), n.close());
                a.renderer.Ba(m, l, h)
            }
            f = gvjs_rD([gvjs_Ar, c]);
            a.Ed(a.Fd.area.Kb, f, h.j());
            if (d) {
                e = gvjs_UF(b);
                d = gvjs_rD([gvjs_d, c]);
                e = e.Jb(a.renderer);
                f = gvjs_3F(a, b);
                if (e) {
                    h = b.Mm;
                    k = b.Fh;
                    if (h || k) {
                        f = f || a.renderer.ta();
                        if (h)
                            for (l = 0; l < h.levels.length; l++) a.renderer.Ba(h.levels[l].path, h.levels[l].brush, f);
                        k && a.renderer.Ba(k.path, k.brush, f)
                    }
                    f && a.renderer.appendChild(f, e)
                }
                e = f ? f.j() : e;
                null != e && a.Ed(a.Fd.line.Kb, d, e);
                gvjs_4F(a, b, c)
            } else gvjs_5F(a, b, c, e)
        }
    } else gvjs_5F(a, b, c, a.ca.interpolateNulls);
    if (b.intervals && b.intervals.paths)
        for (b = b.intervals.paths, d = 0; e = b[d]; ++d) 0 != e.line.length && (f = new gvjs_uz, gvjs_vz(f, e.line, e.gQ), e.bottom && gvjs_vz(f, e.bottom, e.tba || void 0), h = a.renderer.ta(), a.renderer.Ba(f, e.brush, h), e = h.j(), f = gvjs_rD(["pathinterval", c, d]), a.Ed(a.Fd.pathinterval.Kb, f, e))
}

function gvjs_6F(a, b, c, d, e) {
    b.type == gvjs_Hr || b.type == gvjs_xv ? a.Wd(b, c, d, e) : b.type == gvjs_2r ? gvjs_2F(a, c, d, e) : b.type == gvjs_Yr ? gvjs_7F(a, b, c, d, e, a.Fd.bubble.Kb) : gvjs_7F(a, b, c, d, e, a.Fd.point.Kb)
}

function gvjs_zfa(a, b, c) {
    var d = a.Fd.bubble.Kb,
        e = gvjs_py(b.points.length, function(m) {
            return m
        });
    b.Sla && gvjs_Af(e, function(m, n) {
        m = b.points[m];
        n = b.points[n];
        return (n ? n.W.radius || 0 : 0) - (m ? m.W.radius || 0 : 0)
    });
    for (var f = 0; f < e.length; f++) {
        var g = e[f],
            h = b.points[g];
        if (h) {
            gvjs_7F(a, b, c, h, g, a.Fd.bubble.Kb);
            var k = a.renderer.ud(h.text, h.textStyle),
                l = h.W.radius || 0;
            if (k.width < 2 * l || k.height < 2 * l) h = a.renderer.Oc(h.text, h.W.x, h.W.y, h.textLength, gvjs_X, gvjs_X, h.textStyle, d), g = gvjs_rD([gvjs_Wr, c, g]), a.renderer.Cl(h, g)
        }
    }
}

function gvjs_1F(a, b, c) {
    for (var d = 0; d < b.points.length; d++) a.Wd(b, c, b.points[d], d)
}
gvjs_.Wd = function(a, b, c, d) {
    if (!gvjs_MF(c) && c.W) {
        var e = c.hx || gvjs_LF(c, a),
            f = a.type == gvjs_Hr ? gvjs_Ib : gvjs_yv,
            g = gvjs_rD([f, b, d]),
            h = c.W.bar || c.W;
        e = this.renderer.Ii(h.left, h.top, h.width, h.height, e);
        h = null;
        var k = c.W.outline,
            l = c.Mm,
            m = c.Fh;
        if (k || l || m) {
            h = this.renderer.ta();
            this.renderer.appendChild(h, e);
            if (k) {
                var n = c.Lb || a.Lb;
                k = gvjs_wz(k, !0);
                this.renderer.Ba(k, n, h)
            }
            if (l)
                for (n = 0; n < l.levels.length; n++) k = l.levels[n].rect, this.renderer.bb(k.left, k.top, k.width, k.height, l.levels[n].brush, h);
            m && this.renderer.bb(m.rect.left,
                m.rect.top, m.rect.width, m.rect.height, m.brush, h)
        }
        e = h ? h.j() : e;
        this.Ed(this.Fd[f].Kb, g, e);
        c.tooltip && (f = gvjs_rD([gvjs_de, b, d]), gvjs_XF(this, c.tooltip, f));
        c.Ib && gvjs_ZF(this, c.Ib, b, d);
        c.W.qp && gvjs_8F(this, a, b, d, c.W.qp)
    }
};

function gvjs_3F(a, b) {
    var c = null,
        d = null;
    gvjs_v(b.points, function(e, f) {
        gvjs_PF(b, f) && (c || (c = a.renderer.ta()), d || (d = gvjs_cy(b.Lb.stroke, b.Lb.strokeOpacity)), e && !gvjs_OF(e, b) && a.renderer.ei(e.W.x, e.W.y, b.lineWidth, d, c))
    }, a);
    return c
}

function gvjs_5F(a, b, c, d) {
    var e = gvjs_rD([gvjs_d, c]);
    if (0 >= b.lineWidth) gvjs_HF(a, e), gvjs_4F(a, b, c);
    else {
        var f = gvjs_TF(b, d);
        if (0 != f.Cb.length) {
            d = (f = f.Jb(a.renderer)) && d ? null : gvjs_3F(a, b);
            if (f) {
                var g = b.Mm,
                    h = b.Fh;
                if (g || h) {
                    d || (d = a.renderer.ta());
                    if (g)
                        for (var k = 0; k < g.levels.length; k++) a.renderer.Ba(g.levels[k].path, g.levels[k].brush, d);
                    h && a.renderer.Ba(h.path, h.brush, d)
                }
                d && a.renderer.appendChild(d, f)
            }
            f = d ? d.j() : f;
            null != f && a.Ed(a.Fd.line.Kb, e, f);
            gvjs_4F(a, b, c)
        }
    }
}

function gvjs_yfa(a, b, c) {
    for (var d = 0, e = b.series.length; d < e; d += 2) {
        var f = b.series[d],
            g = b.series[d + 1],
            h = f.points.length;
        if (0 != h)
            for (var k = new gvjs__({
                    stroke: f.df.fill,
                    strokeOpacity: f.df.fillOpacity,
                    strokeWidth: 1
                }), l = 0; l < h; l++) {
                var m = f.points[l],
                    n = g.points[l];
                !gvjs_MF(m) && m.W && a.renderer.WQ(m.W.x, m.W.y, n.W.x, n.W.y, k, c)
            }
    }
}

function gvjs_4F(a, b, c) {
    for (var d = 0; d < b.points.length; d++) gvjs_7F(a, b, c, b.points[d], d, a.Fd.point.Kb)
}

function gvjs_7F(a, b, c, d, e, f) {
    if (!gvjs_MF(d) && d.W) {
        var g = gvjs_RF(d, b);
        a: {
            var h = d.W,
                k = a.ca.chartArea;
            if (h.x - g >= k.right || h.x + g <= k.left || h.y - g >= k.bottom || h.y + g <= k.top) g = !1;
            else {
                if ((h.x >= k.right || h.x <= k.left) && (h.y >= k.bottom || h.y <= k.top)) {
                    g *= g;
                    var l = h.x - k.right,
                        m = h.x - k.left,
                        n = h.y - k.bottom;
                    h = h.y - k.top;
                    k = l * l;
                    m *= m;
                    n *= n;
                    h *= h;
                    if (k + n >= g && k + h >= g && m + h >= g && m + n >= g) {
                        g = !1;
                        break a
                    }
                }
                g = !0
            }
        }
        if (g) {
            g = gvjs_rD([b.type == gvjs_Yr ? gvjs_Wr : gvjs_xp, c, e]);
            if (gvjs_OF(d, b)) {
                n = a.Ed;
                h = gvjs_QF(d, b);
                k = gvjs_LF(d, b);
                m = null;
                var p = d.Fh;
                l = d.Mm;
                var q = d.crosshair;
                if (p || l || q) m = a.renderer.ta();
                q && a.renderer.Ba(q.path, q.brush, m);
                (q = d.shape) && q.type || (q = {
                    type: gvjs_es
                });
                p && gvjs_DF(a, p.x, p.y, p.radius + .5, p.brush, q, m);
                if (l)
                    for (p = 0; p < l.levels.length; p++) gvjs_DF(a, l.x, l.y, l.levels[p].radius || 0, l.levels[p].brush, q, m);
                h = gvjs_DF(a, d.W.x, d.W.y, h, k, q);
                m && a.renderer.appendChild(m, h);
                m = m ? m.j() : h;
                n.call(a, f, g, m)
            } else gvjs_HF(a, g);
            d.tooltip && (f = gvjs_rD([gvjs_de, c, e]), gvjs_XF(a, d.tooltip, f));
            d.Ib && gvjs_ZF(a, d.Ib, c, e);
            d.W.qp && gvjs_8F(a, b, c, e, d.W.qp)
        }
    }
}

function gvjs_2F(a, b, c, d) {
    if (c && c.W) {
        var e = a.renderer.Ii(c.W.line.left, c.W.line.top, c.W.line.width, c.W.line.height, c.Lb),
            f = a.renderer.Ii(c.W.rect.left, c.W.rect.top, c.W.rect.width, c.W.rect.height, c.hx),
            g = a.renderer.ta();
        a.renderer.appendChild(g, e);
        a.renderer.appendChild(g, f);
        if (e = c.Mm)
            for (f = 0; f < e.levels.length; f++) {
                var h = e.levels[f].rect;
                a.renderer.bb(h.left, h.top, h.width, h.height, e.levels[f].brush, g)
            }(e = c.Fh) && a.renderer.bb(e.rect.left, e.rect.top, e.rect.width, e.rect.height, e.brush, g);
        e = gvjs_rD([gvjs__r,
            b, d
        ]);
        a.Ed(a.Fd.candlestick.Kb, e, g.j());
        c.tooltip && (b = gvjs_rD([gvjs_de, b, d]), gvjs_XF(a, c.tooltip, b))
    }
}

function gvjs_ZF(a, b, c, d) {
    if (b) {
        var e = b.stem,
            f = a.ca.chartArea;
        if (!(!e || e.x < f.left || e.x > f.right) && (f = b.labels) && 0 != f.length) {
            var g = [gvjs_nr, d];
            gvjs_bx(g, c, 1);
            g = gvjs_rD(g);
            var h = e.x,
                k = e.y,
                l = e.length;
            l = e.orientation == gvjs_R ? [l, 1] : [1, l];
            e = a.renderer.Ii(Math.min(h, h + l[0]), Math.min(k, k + l[1]), Math.abs(l[0]), Math.abs(l[1]), new gvjs__({
                fill: e.color
            }));
            a.Ed(a.Fd.annotation.Kb, g, e);
            e = a.renderer.ta();
            g = [gvjs_zr, d];
            gvjs_bx(g, c, 1);
            h = null;
            b.jm && !b.jm.c5 && (f = [b.jm.label], h = -1);
            b = a.renderer.zC();
            for (k = 0; k < f.length; k++) {
                var m =
                    f[k];
                if (l = gvjs_GF(a, m, !0)) {
                    if (m.iG) {
                        var n = gvjs_rD([gvjs_de, c, d, k]);
                        gvjs_XF(a, m.iG, n)
                    }
                    a.renderer.appendChild(e, l);
                    m = gvjs_wf(g);
                    m.push(h || k);
                    m = gvjs_rD(m);
                    a.registerElement(l, m)
                }
            }
            a.renderer.Kx(b);
            c = gvjs_rD(g);
            a.Ed(a.Fd.annotationtext.Kb, c, e.j())
        }
    }
}

function gvjs_8F(a, b, c, d, e) {
    if (null != b.intervals) {
        var f = a.renderer.ta();
        b = b.intervals.eq;
        for (var g = 0; g < e.length; g++) {
            var h = e[g].rect,
                k = b[e[g].eC];
            if (k && k.style != gvjs_Ar && k.style != gvjs_d) {
                var l = e[g].brush;
                0 == h.width && 0 == h.height ? (k = k.pointSize / 2, 0 < k && (h = a.renderer.Ex(h.left, h.top, k, l), a.renderer.appendChild(f, h))) : 0 == h.width || 0 == h.height ? (k = new gvjs_uz, k.move(h.left, h.top), k.na(h.left + h.width, h.top + h.height), a.renderer.Ba(k, l, f)) : a.renderer.appendChild(f, a.renderer.Ii(h.left, h.top, h.width, h.height,
                    l))
            }
        }
        f.element && (c = gvjs_rD([gvjs_Rt, c, d]), f = f.j(), a.Ed(a.Fd.interval.Kb, c, f))
    }
}

function gvjs_wfa(a, b, c) {
    gvjs_9F(a, c, function(d, e) {
        var f = null != d.length ? d.length : b.chartArea.height,
            g = c.Nl.oa;
        return a.renderer.bb(Math.floor(d.oa), Math.min(g, g + c.Nl.direction * f), 1, f, d.brush, e)
    })
}

function gvjs_xfa(a, b, c) {
    gvjs_9F(a, c, function(d, e) {
        var f = null != d.length ? d.length : b.chartArea.width,
            g = c.Nl.oa;
        return a.renderer.bb(Math.min(g, g + c.Nl.direction * f), Math.floor(d.oa), f, 1, d.brush, e)
    })
}

function gvjs_9F(a, b, c) {
    (function(f, g, h) {
        if (f) {
            var k = a.Fd[g].Kb,
                l = gvjs_rD([b.name, g]);
            gvjs_v(f, function(m, n) {
                n = gvjs_rD([b.name, g, n]);
                gvjs_$F(a, m, h, k, n, l)
            })
        }
    })(b.gridlines, "gridline", c);
    var d = a.Fd.baseline.Kb,
        e = gvjs_rD([b.name, gvjs_Ir]);
    b.baseline && b.baseline.isVisible && null != b.baseline.Oa && Infinity != b.baseline.oa && gvjs_$F(a, b.baseline, c, d, e)
}

function gvjs_$F(a, b, c, d, e, f) {
    var g;
    if (g = b && b.isVisible) g = b.brush, g = !(!gvjs_Ew(g) && !gvjs_Cw(g));
    g && (b = c(b, d), a.registerElement(b, e, f))
}

function gvjs_0F(a, b) {
    var c = a.Fd;
    if (b.title) {
        var d = a.jr(b.title, c.axistitle.Kb, !0),
            e = gvjs_rD([b.name, gvjs_ce]);
        a.registerElement(d, e);
        if (b.text) {
            var f = c.axistick.Kb,
                g = gvjs_rD([b.name, gvjs_qd]);
            gvjs_v(b.text, function(h, k) {
                h.isVisible && (h = a.jr(h.ka, f), k = gvjs_rD([b.name, gvjs_qd, k]), a.registerElement(h, k, g))
            })
        }
    }
}
gvjs_.G7 = function(a, b) {
    this.bM(a);
    this.XO(a, b)
};
gvjs_.bM = function(a) {
    var b = this.Po;
    if (b) {
        for (var c in b.series) {
            var d = Number(c),
                e = a.series[d];
            if (gvjs_xy(b.series[d], gvjs_Tg({
                    points: null
                }))) {
                var f = b.series[d].points,
                    g;
                for (g in f) {
                    var h = Number(g),
                        k = f[h];
                    if (k.tooltip) {
                        var l = gvjs_rD([gvjs_de, Number(d), Number(h)]);
                        gvjs_FF(this, l)
                    }
                    if (k = k.Ib)
                        for (var m in k.labels) k.labels[Number(m)].iG && (l = gvjs_rD([gvjs_de, Number(d), Number(h), m]), gvjs_FF(this, l));
                    gvjs_6F(this, e, Number(d), e.points[h], Number(h))
                }
            } else {
                for (var n in b.series[d].points) b.series[d].points[Number(n)].tooltip &&
                    (f = gvjs_rD([gvjs_de, Number(d), Number(n)]), gvjs_FF(this, f));
                gvjs__F(this, e, Number(d))
            }
        }
        for (var p in b.Fa)
            if (c = Number(p), d = b.Fa[c], d.tooltip && (e = gvjs_rD([gvjs_de, Number(c)]), gvjs_FF(this, e)), d = d.Ib) {
                for (var q in d.labels) d.labels[Number(q)].iG && (e = gvjs_rD([gvjs_de, null, Number(c), Number(q)]), gvjs_FF(this, e));
                gvjs_ZF(this, a.Fa[c].Ib, null, Number(c))
            }
        gvjs_YF(this)
    }
};
gvjs_.XO = function(a, b) {
    for (var c in b.series) {
        var d = Number(c),
            e = a.series[d];
        if (gvjs_xy(b.series[d], gvjs_Tg({
                points: null
            })))
            for (var f in b.series[d].points) {
                var g = Number(f),
                    h = new gvjs_tD(2);
                h.ed(0, e.points[g]);
                h.ed(1, b.series[d].points[g]);
                h = h.compact();
                gvjs_6F(this, e, Number(d), h, Number(g))
            } else g = new gvjs_tD(2), g.ed(0, e), g.ed(1, b.series[d]), e = g.compact(), gvjs__F(this, e, Number(d))
    }
    for (var k in b.Fa) {
        c = Number(k);
        if (d = b.Fa[c].tooltip) f = gvjs_rD([gvjs_de, Number(c)]), gvjs_XF(this, d, f);
        b.Fa[c].Ib && (d = new gvjs_tD(2),
            d.ed(0, a.Fa[c].Ib), d.ed(1, b.Fa[c].Ib), d = d.compact(), gvjs_ZF(this, d, null, Number(c)))
    }
    gvjs_YF(this)
};

function gvjs_Afa(a, b) {
    if (a) {
        if (b.length != a.length) throw Error("colorsScale and valuesScale must be of the same length");
    } else if (1 !== b.length) throw Error("colorsScale must contain exactly one element when no valueScale is provided");
    this.Bi = a;
    this.Uq = b.map(function(c) {
        return gvjs_$h(c).hex
    })
}

function gvjs_aG(a, b) {
    if (!a.Bi) return a.Uq[0];
    if (b >= a.Bi[a.Bi.length - 1]) return a.Uq[a.Uq.length - 1];
    if (b <= a.Bi[0]) return a.Uq[0];
    var c = gvjs_dx(a.Bi, b);
    if (0 <= c) return a.Uq[c];
    var d = -c - 2;
    c = -c - 1;
    return gvjs_by(a.Uq[c], a.Uq[d], (b - a.Bi[d]) / (a.Bi[c] - a.Bi[d]))
}

function gvjs_Bfa(a, b) {
    b && 0 !== b.length ? 1 === b.length && (b = [gvjs_bG[0], b[0]]) : b = a && 3 === a.length ? gvjs_cG : gvjs_bG;
    if (!a || 2 > a.length) return {
        values: null,
        colors: [gvjs_nf(b)]
    };
    var c = a[0],
        d = a[a.length - 1],
        e = d - c;
    if (0 === e) return {
        values: [d],
        colors: [gvjs_nf(b)]
    };
    if (2 === a.length)
        for (a = [], d = e / (b.length - 1), e = 0; e < b.length; e++) a.push(c + d * e);
    return {
        values: a,
        colors: b
    }
}

function gvjs_dG(a, b) {
    a || (a = new gvjs_Si([]));
    var c = c || "colorAxis";
    var d = a.view(c),
        e = null,
        f = d.LD("values");
    if (f && 0 < f.length) {
        1 === f.length && (f = [f[0], f[0]]);
        b && (null == f[0] && (f[0] = b.start), null == f[f.length - 1] && (f[f.length - 1] = b.end));
        if (null == f[0]) throw Error(c + gvjs_vq);
        for (e = 1; e < f.length; e++) {
            if (null == f[e]) throw Error(c + gvjs_vq);
            if (f[e] < f[e - 1]) throw Error(c + ".values must be a monotonically increasing series");
        }
        e = f
    } else {
        f = d.ha(gvjs_Ad);
        var g = d.ha(gvjs_xd);
        if (null != f && null != g && f > g) throw Error(c + ".minValue (" +
            f + ") must be at most " + (c + ".maxValue (") + g + ")");
        (c = gvjs_EA(b, f, g)) && (e = [c.start, c.end])
    }
    a = gvjs_Xi(a, gvjs__i, [], gvjs_ls);
    a = gvjs_Xi(d, gvjs__i, [], gvjs_ls, a);
    c = d.R("one-sided-colors", gvjs_bG);
    d = d.R("two-sided-colors", gvjs_cG);
    a && 0 !== a.length ? 1 === a.length && (a = [c[0], a[0]]) : a = e && 3 === e.length ? d : c;
    d = gvjs_Bfa(e, a);
    return new gvjs_Afa(d.values, d.colors)
}
var gvjs_bG = ["#EFE6DC", gvjs_9p],
    gvjs_cG = [gvjs_fq, "#EFE6DC", gvjs_9p];

function gvjs_eG(a, b, c, d) {
    var e = {},
        f = b.numberFormat || gvjs_Gj;
    if (b.orientation == gvjs_R) {
        e = b.textStyle;
        var g = a.Bi[0];
        var h = a.Bi[a.Bi.length - 1];
        f = new gvjs_Aj({
            pattern: f
        });
        g = f.formatValue(g);
        h = f.formatValue(h);
        e = {
            minValue: {
                text: g,
                width: d ? d(g, e).width : 0,
                height: e.fontSize
            },
            maxValue: {
                text: h,
                width: d ? d(h, e).width : 0,
                height: e.fontSize
            }
        };
        d = e.minValue.height / 4;
        g = new gvjs_0(e.minValue.width + d, 0, b.width - (e.minValue.width + e.maxValue.width + 2 * d), b.height)
    } else g = new gvjs_0(0, 0, b.width, b.height);
    d = .33 * g.height;
    h = d /
        Math.sqrt(3) * 2;
    f = new gvjs_0(g.left + h / 2, g.top + d + 1, g.width - h, g.height - d - 1);
    var k = a.Uq,
        l = a.Bi,
        m = l[l.length - 1] - l[0];
    if (0 == m) var n = [{
        Af: new gvjs_0(f.left, f.top, f.width, f.height),
        brush: new gvjs__({
            fill: k[0]
        })
    }];
    else {
        n = [];
        m = f.width / m;
        for (var p = f.left, q, r = 0; r < l.length - 1; ++r) q = p + (l[r + 1] - l[r]) * m, n[r] = {
            Af: new gvjs_0(p, f.top, q - p, f.height),
            brush: new gvjs__({
                gradient: {
                    x1: p,
                    y1: 0,
                    x2: q,
                    y2: 0,
                    color1: k[r],
                    color2: k[r + 1]
                }
            })
        }, p = q
    }
    f = n;
    if (null != f && 0 < f.length && (0 > f[0].Af.width || 0 > f[0].Af.height)) return null;
    k = g;
    l = b.V5;
    g = [];
    for (n = 0; n < c.length; ++n) m = c[n].value, p = a.Bi, m < p[0] ? m = 0 : (q = k.width - h, m > p[p.length - 1] ? m = q : (r = p[p.length - 1] - p[0], m = 0 == r ? .5 * q : (m - p[0]) / r * q)), m = k.left + m + h / 2, m = [m - h / 2, k.top, m + h / 2, k.top, m, k.top + d], p = new gvjs__({
        fill: l,
        stroke: l
    }), g[n] = {
        path: m,
        brush: p
    };
    a = [];
    b.orientation == gvjs_R && (a = e, c = [], c[0] = {
        x: 0,
        y: b.height - a.minValue.height,
        text: a.minValue.text,
        style: b.textStyle
    }, c[1] = {
        x: b.width - a.maxValue.width,
        y: b.height - a.maxValue.height,
        text: a.maxValue.text,
        style: b.textStyle
    }, a = c);
    a = {
        WP: f,
        yT: g,
        BW: a
    };
    c = a.WP;
    for (e = 0; e <
        c.length; ++e) d = c[e], b.orientation == gvjs_S && (h = d.Af.left, d.Af.left = d.Af.top, d.Af.top = h, h = d.Af.width, d.Af.width = d.Af.height, d.Af.height = h), d.Af.left += b.left, d.Af.top += b.top, h = d.brush.clone(), d.brush = h, d = h.gradient, b.orientation == gvjs_S && (d.y1 = d.x1, d.x1 = 0, d.y2 = d.x2, d.x2 = 0), null != d && (d.x1 += b.left, d.y1 += b.top, d.x2 += b.left, d.y2 += b.top);
    c = a.yT;
    for (e = 0; e < c.length; ++e)
        for (d = 0; 3 > d; ++d) b.orientation == gvjs_S && (h = c[e].path[2 * d], c[e].path[2 * d] = c[e].path[2 * d + 1], c[e].path[2 * d + 1] = h), c[e].path[2 * d] += b.left, c[e].path[2 *
            d + 1] += b.top;
    c = a.BW;
    for (e = 0; e < c.length; ++e) c[e].x += b.left, c[e].y += b.top;
    return a
};

function gvjs_fG(a, b, c) {
    this.Gi = a;
    this.ef = c ? gvjs_C(b, "colorAxis.legend.position", c, gvjs_pea) : gvjs_e;
    this.Ea = gvjs_Pw(b, "colorAxis.legend.textStyle", {
        fontName: a.Kf,
        fontSize: a.rh,
        auraColor: this.ef == gvjs_Kt ? a.Eu : gvjs_e
    });
    this.ija = b.Ca("colorAxis.legend.numberFormat");
    this.Tg = this.mb = null
}
gvjs_ = gvjs_fG.prototype;
gvjs_.getPosition = function() {
    return this.ef
};
gvjs_.getHeight = function() {
    return 1.5 * this.Ea.fontSize
};
gvjs_.getArea = function() {
    return this.mb
};
gvjs_.wn = function(a) {
    this.mb = a
};
gvjs_.setScale = function(a) {
    this.Tg = a
};
gvjs_.define = function() {
    if (!this.mb || !this.Tg) return null;
    var a = {
            top: this.mb.top,
            left: this.mb.left,
            width: this.mb.right - this.mb.left,
            height: this.mb.bottom - this.mb.top,
            orientation: gvjs_R,
            textStyle: this.Ea,
            V5: gvjs_Or,
            numberFormat: this.ija
        },
        b = gvjs_eG(this.Tg, a, [], this.Gi.Va);
    return null == b ? null : {
        position: this.ef,
        scale: this.Tg,
        IC: a,
        definition: b
    }
};

function gvjs_gG(a, b, c, d, e) {
    this.X7 = gvjs_Cfa;
    this.j2 = 3;
    this.m = a;
    var f = a.R(gvjs_dt);
    this.Ce = null == f ? null : typeof f === gvjs_m ? {
        pattern: f
    } : {
        pattern: f.pattern,
        formatType: f.formatType,
        timeZone: f.timeZone
    };
    this.Cia = gvjs_5i(a, [gvjs_st, "gridlines.minStrongLineDistance"]);
    this.Fia = gvjs_5i(a, [gvjs_mu, "gridlines.minWeakLineDistance"]);
    this.Dia = gvjs_5i(a, "gridlines.minStrongToWeakLineDistance");
    this.Bia = gvjs_5i(a, "gridlines.minNotchDistance");
    this.zia = gvjs_5i(a, "gridlines.minMajorTextDistance");
    this.Aia = gvjs_5i(a,
        "gridlines.minMinorTextDistance");
    this.Xma = gvjs_5i(a, "gridlines.unitThreshold");
    this.P_ = gvjs_D(a, "gridlines.allowMinor");
    0 === a.ha(gvjs_ku) && (this.P_ = !1);
    this.be = b;
    this.Zv = c;
    this.hL = d;
    this.uia = e;
    this.p6 = this.O5 = null
}

function gvjs_hG(a, b, c, d, e) {
    return new gvjs_gG(a, b, c, d, e)
}
gvjs_gG.prototype.generate = function gvjs_Dfa(a, b, c, d) {
    var f = this,
        g, h, k, l, m, n, p, q, r, t, u, v, w, x, y, z, A, B, D, F, G, H, I, P, K, N;
    return gvjs_3w(gvjs_Dfa, function(Q) {
        switch (Q.og) {
            case 1:
                g = gvjs_Efa(f, a, b), h = f.m.La("gridlines.units." + g.unit), k = gvjs_Mj[g.unit], l = gvjs_Jy[k], m = [], n = {
                    minValue: g.minValue,
                    maxValue: g.maxValue,
                    unitName: g.unit,
                    I9: k,
                    G9: l,
                    H9: h.format,
                    ZW: h.interval,
                    k6: f.Cia,
                    gp: d.gp,
                    ec: d.ec,
                    Eia: f.zia,
                    aS: m,
                    j6: 0
                }, f.O5 = n, p = gvjs_iG(f, n), q = null;
            case 2:
                if (!(q = p.next().value)) {
                    Q.uf(3);
                    break
                }
                if (0 == q.gridlines.length) {
                    Q.uf(2);
                    break
                }
                r = d.alignment;
                if (!(f.P_ && 1 == q.multiple && 0 < k)) return I = 1 != q.multiple ? 0 : r, P = gvjs_jG(d.ec, I, q.gridlines, q.ZF), K = void 0, 1 < q.multiple ? (N = gvjs_Ffa(f, g, q, l, d), K = gvjs_vf(q.gridlines, N)) : K = q.gridlines, gvjs_Zw(Q, {
                    gridlines: K,
                    lb: P
                }, 2);
                t = k - 1;
                u = gvjs_Lj[t];
                v = f.m.La("minorGridlines.units." + u);
                w = gvjs_Jy[t];
                x = {
                    minValue: g.minValue,
                    maxValue: g.maxValue,
                    unitName: u,
                    I9: t,
                    G9: w,
                    H9: v.format,
                    ZW: v.interval,
                    k6: f.Fia,
                    gp: d.WK,
                    ec: d.CE,
                    Eia: f.Aia,
                    aS: q.gridlines,
                    j6: f.Dia
                };
                f.p6 = x;
                y = gvjs_iG(f, x);
                z = null;
                A = !1;
            case 6:
                if (A) {
                    Q.uf(2);
                    break
                }
                z = y.next().value;
                A = null == z;
                if (null == z || !z.gridlines.length) return H = gvjs_jG(d.ec, 2, q.gridlines, q.ZF), gvjs_Zw(Q, {
                    gridlines: q.gridlines,
                    lb: H
                }, 6);
                B = gvjs_jG(d.ec, r, q.gridlines, q.ZF);
                D = gvjs_jG(d.CE, r, z.gridlines, z.ZF);
                gvjs_v(D, function(U) {
                    U.optional = !0
                });
                F = gvjs_vf(z.gridlines, q.gridlines);
                G = gvjs_vf(B, D);
                return gvjs_Zw(Q, {
                    gridlines: F,
                    lb: G
                }, 6);
            case 3:
                return Q.return({
                    gridlines: [],
                    lb: []
                })
        }
    })
};

function gvjs_Efa(a, b, c) {
    a = gvjs_4da((c - b) / a.Xma, a.X7, a.j2);
    var d = gvjs_Gfa(a);
    a = gvjs_7w(gvjs_Jy, function(e) {
        return gvjs_ex(e, d)
    });
    return {
        minValue: b,
        maxValue: c,
        unit: gvjs_Lj[a]
    }
}
var gvjs_iG = function gvjs_Hfa(a, b) {
        var d, e, f, g, h, k, l, m, n, p, q, r, t, u, v, w, x, y, z, A, B;
        return gvjs_3w(gvjs_Hfa, function(D) {
            switch (D.og) {
                case 1:
                    d = b.ZW.length, e = 0;
                case 2:
                    if (!(e < d)) {
                        D.uf(4);
                        break
                    }
                    f = b.ZW[e];
                    g = 0;
                    h = gvjs_5da(b.G9, f);
                    k = gvjs_By(new Date(b.minValue + a.Zv), h);
                    if ("days" === b.unitName) {
                        var F = k;
                        F = gvjs_By(F, [0, 0, 0, 0, 1]);
                        k = F = gvjs_Cy(F, [0, 0, 0, 0, (7 + F.getDay() - 1) % 7])
                    }
                    l = new gvjs_Dy(k, new Date(b.maxValue + a.Zv), b.I9, f);
                    m = [];
                    n = !0;
                    p = a.hL(b.minValue);
                    for (q = -1; l.gv <= l.eR;)
                        if (r = l.next(), t = a.hL(r.getTime() - a.Zv), !(t <
                                p)) {
                            -1 == q && t >= p && (q = m.length);
                            u = l.peek();
                            if (null != u && (v = a.hL(u.getTime() - a.Zv), Math.abs(v - t) < b.k6)) {
                                n = !1;
                                break
                            }
                            for (w = !1; g < b.aS.length;) {
                                x = b.aS[g];
                                if (Math.abs(x.oa - t) < b.j6) {
                                    w = !0;
                                    break
                                }
                                if (x.oa > t) {
                                    g = Math.max(0, g - 1);
                                    break
                                }
                                g++
                            }
                            w || m.push({
                                Oa: r,
                                oa: t,
                                isVisible: !0,
                                brush: b.gp,
                                length: null,
                                QS: !1
                            })
                        }
                    if (!n) {
                        D.uf(3);
                        break
                    }
                    y = gvjs_kG(a, m, b);
                    z = null;
                case 5:
                    if (!(z = y.next().value)) {
                        D.uf(6);
                        break
                    }
                    if (null == z) {
                        D.uf(5);
                        break
                    }
                    A = Infinity;
                    for (B = 0; B < m.length - 1; ++B) A = Math.min(A, m[B + 1].oa - m[B].oa);
                    return gvjs_Zw(D, {
                        gridlines: m,
                        ZF: z,
                        multiple: f,
                        o6: A
                    }, 5);
                case 6:
                    m = [];
                case 3:
                    ++e;
                    D.uf(2);
                    break;
                case 4:
                    return D.return({
                        gridlines: [],
                        ZF: [],
                        multiple: 1,
                        o6: Infinity
                    })
            }
        })
    },
    gvjs_kG = function gvjs_Ifa(a, b, c) {
        var e, f, g, h, k, l, m, n, p, q, r;
        return gvjs_3w(gvjs_Ifa, function(t) {
            1 == t.og && (e = c.H9, Array.isArray(e) || (e = [e]), f = [], null != a.Ce && null != a.Ce.pattern ? f = [new gvjs_$i(a.Ce)] : (g = a.Ce || {}, f = gvjs_w(e, function(u) {
                g.pattern = u;
                return new gvjs_$i(g)
            })), h = 0);
            if (3 != t.og) {
                if (!(h < f.length)) return t.uf(0);
                k = f[h];
                l = [];
                for (m = 0; m < b.length; ++m) n = b[m], p = n.qe ||
                    k.formatValue(n.Oa), q = a.uia(p, c.ec), r = a.be ? q.height : q.width, l.push({
                        text: p,
                        size: r
                    });
                return gvjs_Zw(t, l, 3)
            }++h;
            return t.uf(2)
        })
    };

function gvjs_Ffa(a, b, c, d, e) {
    if (c.o6 / c.multiple < a.Bia) return [];
    e = e.gp;
    var f = [],
        g = new Date(b.maxValue + a.Zv);
    d = gvjs_By(new Date(b.minValue + a.Zv), d);
    b = new gvjs_Dy(d, g, gvjs_Mj[b.unit], 1);
    for (d = 0; b.gv <= b.eR;) {
        if (0 != d % c.multiple) {
            g = b.next();
            var h = a.hL(g.getTime() - a.Zv);
            f.push({
                Oa: g,
                oa: h,
                isVisible: !0,
                brush: e,
                length: 5,
                QS: !0
            })
        }
        d++
    }
    return f
}

function gvjs_jG(a, b, c, d) {
    for (var e = [], f = 1 == b ? gvjs_l : 3 == b ? gvjs_Y : gvjs_X, g = 0, h = [], k = 1 < c.length ? c[1].oa - c[0].oa : 0, l = 0; l < c.length; ++l) {
        var m = c[l],
            n = Math.round(b == k),
            p = d[l].size,
            q = void 0;
        q = void 0 !== q ? q : 0;
        if (f == gvjs_l) {
            var r = n;
            var t = n + p
        } else f == gvjs_Y ? (r = n - p, t = n) : (r = Math.round(n - p / 2), t = Math.round(n + p / 2));
        for (t = new gvjs_Lk(r - q, t + q); g < e.length;) e[g].start > t.end && (g = Math.max(0, g - 1)), g++;
        h.push({
            Oa: m.Oa,
            isVisible: !0,
            oa: n,
            ka: {
                text: d[l].text,
                textStyle: a,
                lines: [{
                    x: n,
                    y: 0,
                    text: d[l].text,
                    length: p
                }],
                Yb: f,
                Mb: gvjs_Y,
                sta: d[l].text,
                anchor: null,
                angle: 0
            }
        })
    }
    return h
}

function gvjs_Gfa(a) {
    return gvjs_w(a, function(b) {
        return 0 < b ? 1 : 0
    })
}
var gvjs_Cfa = [
    [1],
    [2],
    [5],
    [10],
    [20],
    [50],
    [100],
    [200],
    [500],
    [0, 1],
    [0, 2],
    [0, 5],
    [0, 10],
    [0, 15],
    [0, 30],
    [0, 0, 1],
    [0, 0, 2],
    [0, 0, 5],
    [0, 0, 10],
    [0, 0, 15],
    [0, 0, 30],
    [0, 0, 0, 1],
    [0, 0, 0, 2],
    [0, 0, 0, 3],
    [0, 0, 0, 4],
    [0, 0, 0, 6],
    [0, 0, 0, 12],
    [0, 0, 0, 0, 1],
    [0, 0, 0, 0, 2],
    [0, 0, 0, 0, 7],
    [0, 0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 3],
    [0, 0, 0, 0, 0, 6],
    [0, 0, 0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 0, 10],
    [0, 0, 0, 0, 0, 0, 50],
    [0, 0, 0, 0, 0, 0, 100]
];

function gvjs_lG(a) {
    switch (a) {
        case gvjs_1b:
        case gvjs_2b:
            return {
                toNumber: gvjs_mG,
                hu: gvjs_nG
            };
        case gvjs_be:
            return {
                toNumber: gvjs_Jfa,
                hu: gvjs_Kfa
            };
        case gvjs_f:
        case gvjs_m:
            return {
                toNumber: gvjs_oG,
                hu: gvjs_pG
            };
        default:
            return {
                toNumber: gvjs_oG,
                hu: gvjs_pG
            }
    }
}

function gvjs_oG(a) {
    return Number(a)
}

function gvjs_pG(a) {
    return a
}

function gvjs_mG(a) {
    return a.getTime()
}

function gvjs_nG(a) {
    return new Date(a)
}

function gvjs_Jfa(a) {
    return gvjs_Iy(a)
}

function gvjs_Kfa(a) {
    return gvjs_Gy(a).reverse()
};

function gvjs_qG() {
    this.ticks = [];
    this.Za = null
}
gvjs_ = gvjs_qG.prototype;
gvjs_.init = function(a) {
    this.options = a;
    this.ticks = [];
    this.hk = Infinity;
    this.gk = -Infinity;
    this.M6 = null;
    this.Ce = a.Ca(gvjs_dt);
    a.R("valueFormatter", function(b, c) {
        return c
    });
    this.Za = this.lv = null
};
gvjs_.Fy = function(a, b, c) {
    if (0 !== c.length && a != gvjs_Su) throw Error("Non-linear scale with gaps is not supported.");
    for (var d = [], e = 0; e < c.length; e++) {
        a: {
            var f = c[e];
            var g = this.IR(f.jea);
            var h = this.zG(f.dc);f = this.zG(f.pe);
            if (0 < g)
                if (h + g < f) h += g;
                else {
                    g = null;
                    break a
                }
            g = {
                iea: 0,
                start: h,
                end: f
            }
        }
        g && d.push(g)
    }
    this.lv = gvjs_aE(a, gvjs_4D(1, gvjs_5D(b)), d)
};
gvjs_.Wz = gvjs_p(97);

function gvjs_rG(a, b) {
    a.Ce || (a.Ce = b)
}

function gvjs_sG(a) {
    a.Za || a.Xq();
    return a.Za
}
gvjs_.Db = function(a) {
    a = gvjs_tG(this, a);
    if (null == a) return null;
    a = gvjs_uG(this, a);
    return isFinite(a) ? a : null
};

function gvjs_tG(a, b) {
    return null == b ? null : a.zG(b)
}
gvjs_.en = function(a) {
    return this.gL(this.lv.inverse(a))
};

function gvjs_uG(a, b) {
    return a.lv.transform(b)
}
gvjs_.compareValues = function(a, b) {
    return a < b ? -1 : a > b ? 1 : 0
};
gvjs_.ub = function(a) {
    null != a && (a < this.hk && null != a && (this.hk = a), a > this.gk && null != a && (this.gk = a))
};

function gvjs_vG(a, b, c) {
    gvjs_qG.call(this);
    this.X7 = a;
    this.j2 = b;
    this.AQ = c
}
gvjs_r(gvjs_vG, gvjs_qG);
gvjs_ = gvjs_vG.prototype;
gvjs_.PR = function() {
    return null
};
gvjs_.init = function(a, b) {
    gvjs_qG.prototype.init.call(this, a, b);
    a = a.La("formatOptions");
    b = [];
    b.push(a.millisecond);
    b.push(a.second);
    b.push(a.minute);
    b.push(a.hour);
    b.push(a.day);
    b.push(a.month);
    b.push(a.year);
    this.AQ = gvjs_Lfa([b, gvjs_gx(this.Ce, b.length), this.AQ])
};

function gvjs_Lfa(a) {
    a = gvjs_ix.apply(null, a);
    return gvjs_w(a, function(b) {
        return gvjs_8w(b, function(c) {
            return c
        })
    })
}
gvjs_.R = function(a, b) {
    return a.R(b)
};
gvjs_.zG = function(a) {
    return gvjs_mG(a)
};
gvjs_.gL = function(a) {
    return gvjs_nG(a)
};
gvjs_.IR = function(a) {
    return a
};
gvjs_.Xq = function() {
    var a = gvjs_Ey(this.qta);
    a = this.AQ[a];
    this.Za = typeof a === gvjs_g ? new gvjs_$i(a) : new gvjs_$i({
        pattern: a
    })
};
var gvjs_Mfa = [
        [0, 0, 0, 0, 1],
        [0, 0, 0, 0, 2],
        [0, 0, 0, 0, 7],
        [0, 0, 0, 0, 0, 1],
        [0, 0, 0, 0, 0, 3],
        [0, 0, 0, 0, 0, 6],
        [0, 0, 0, 0, 0, 12],
        [0, 0, 0, 0, 0, 0, 1],
        [0, 0, 0, 0, 0, 0, 5],
        [0, 0, 0, 0, 0, 0, 10],
        [0, 0, 0, 0, 0, 0, 25],
        [0, 0, 0, 0, 0, 0, 50],
        [0, 0, 0, 0, 0, 0, 100]
    ],
    gvjs_Nfa = [2, 2, 2, 2, 2, gvjs_bj.EO, "y"],
    gvjs_Ofa = [
        [1],
        [2],
        [5],
        [10],
        [20],
        [50],
        [100],
        [200],
        [500],
        [0, 1],
        [0, 2],
        [0, 5],
        [0, 10],
        [0, 15],
        [0, 30],
        [0, 0, 1],
        [0, 0, 2],
        [0, 0, 5],
        [0, 0, 10],
        [0, 0, 15],
        [0, 0, 30],
        [0, 0, 0, 1],
        [0, 0, 0, 2],
        [0, 0, 0, 3],
        [0, 0, 0, 4],
        [0, 0, 0, 6],
        [0, 0, 0, 12],
        [0, 0, 0, 0, 1],
        [0, 0, 0, 0, 2],
        [0, 0, 0, 0, 7],
        [0, 0, 0, 0, 0, 1],
        [0, 0, 0, 0, 0, 3],
        [0, 0, 0, 0, 0, 6],
        [0, 0, 0, 0, 0, 12],
        [0, 0, 0, 0, 0, 0, 1],
        [0, 0, 0, 0, 0, 0, 5],
        [0, 0, 0, 0, 0, 0, 10],
        [0, 0, 0, 0, 0, 0, 25],
        [0, 0, 0, 0, 0, 0, 50],
        [0, 0, 0, 0, 0, 0, 100]
    ],
    gvjs_Pfa = [6, 6, 7, {
        pattern: 7,
        clearMinutes: !0
    }, 2, gvjs_bj.EO, "y"];

function gvjs_wG(a, b, c) {
    this.xQ = a;
    this.Ka = b;
    this.yK = a - b / 2;
    this.Qha = c;
    this.index = 0
}
gvjs_wG.prototype.wr = function() {
    return this.yK
};
gvjs_wG.prototype.vk = function(a) {
    this.yK = a
};
gvjs_wG.prototype.getCenter = function() {
    return this.yK + this.Ka / 2
};
gvjs_wG.prototype.getHeight = function() {
    return this.Ka
};

function gvjs_Qfa(a, b) {
    this.RW = a;
    this.Nu = b;
    a = 0;
    for (var c = b.length; a < c; a++) b[a].index = a
}

function gvjs_Rfa(a) {
    for (var b = 0, c = 0, d = a.Nu.length; c < d; c++) b += a.Nu[c].getHeight();
    if (b > a.RW) throw Error("Not enough space for labels. Need: " + b + " got: " + a.RW);
    a.Nu.sort(function(f, g) {
        var h = f.xQ,
            k = g.xQ;
        return h == k ? f.index > g.index ? 1 : 0 : h > k ? 1 : -1
    });
    b = 0;
    for (c = a.Nu.length; b < c; b++) {
        d = a.Nu[b];
        var e = gvjs_xG(a, d.wr(), d.getHeight());
        d.vk(e)
    }
    b = [];
    c = 0;
    for (d = a.Nu.length; c < d; c++) b.push([a.Nu[c]]);
    for (; gvjs_Sfa(a, b););
}

function gvjs_Sfa(a, b) {
    for (var c = 0; c < b.length - 1; c++) {
        var d = b[c],
            e = b[c + 1],
            f = d[d.length - 1];
        if (f.yK + f.Ka > e[0].wr()) {
            for (f = 0; f < e.length; f++) d.push(e[f]);
            for (var g = e = f = 0; g < d.length; g++) f += d[g].xQ, e += d[g].getHeight();
            f = f / d.length - e / 2;
            f = gvjs_xG(a, f, e);
            for (a = 0; a < d.length; a++) e = d[a], e.vk(f), f += e.getHeight();
            b.splice(c + 1, 1);
            return !0
        }
    }
    return !1
}

function gvjs_xG(a, b, c) {
    return gvjs_7h(b, 0, a.RW - c)
};

function gvjs_yG(a, b, c, d) {
    this.Gi = a;
    this.ef = c ? gvjs_C(b, gvjs_2t, c, gvjs_oea) : gvjs_e;
    this.yH = gvjs_C(b, gvjs_0t, this.ef == gvjs_Tr ? gvjs_X : gvjs_l, gvjs_qea);
    c = gvjs_R;
    if (this.ef == gvjs_sd || this.ef == gvjs_i || this.ef == gvjs_Yt || this.ef == gvjs_Vr) c = gvjs_S;
    this.Bb = c;
    this.Ea = gvjs_Pw(b, gvjs_3t, {
        fontName: a.Kf,
        fontSize: a.rh,
        auraColor: this.ef == gvjs_Kt ? a.Eu : gvjs_e
    });
    this.fq = !1;
    this.i7 = gvjs_Pw(b, "legend.pagingTextStyle", this.Ea);
    this.Me = gvjs_mx(a.Va, {
        size: 1E4
    });
    this.cK = this.Ea.fontSize;
    d = d ? gvjs_7h(d, 1, 4) : 1;
    this.zu = this.cK *
        d;
    this.ju = Math.round(this.Ea.fontSize / (1.618 * 1.618));
    this.uB = this.mb = null;
    this.bW = gvjs_D(b, "legend.showPageIndex", !0);
    this.Xka = gvjs_C(b, "legend.scrollArrows.orientation", this.Bb, gvjs_QA);
    this.Vka = gvjs_Ow(b, "legend.scrollArrows.activeColor");
    this.Wka = gvjs_Ow(b, "legend.scrollArrows.inactiveColor");
    this.Dg = gvjs_5i(b, "legend.pageIndex", 0);
    this.nd = null;
    this.aD = this.ju;
    this.Fv = this.Gv = this.AV = 0;
    this.d6 = this.ef == gvjs_1v ? gvjs_5i(b, gvjs_1t, 1) : 1;
    this.pB = 0
}
gvjs_yG.prototype.getPosition = function() {
    return this.ef
};
gvjs_yG.prototype.getArea = function() {
    return this.mb
};
gvjs_yG.prototype.wn = function(a) {
    this.mb = a
};

function gvjs_Tfa(a) {
    a.uB = a.Gi.pl.filter(function(b) {
        return b.isVisible
    })
}
gvjs_yG.prototype.define = function() {
    if (!this.mb) return null;
    if (this.ef != gvjs_e)
        if (this.Bb == gvjs_S) gvjs_Ufa(this);
        else {
            for (var a = [1, 9, 99, 0], b = 0; b < a.length; ++b) {
                a: {
                    var c = a[b];
                    var d = this.mb.right - this.mb.left,
                        e = !1,
                        f = Math.round(1.618 * this.Ea.fontSize);1 != c && (d -= f + this.aD + 2 * this.Ea.fontSize, e = !0, 0 != c && (d -= gvjs_zG(this, c) + this.ju));f = gvjs_AG(this, this.uB, d);
                    if (0 == f.length) this.fq = !1;
                    else {
                        this.nd = [];
                        for (var g = this.uB; 0 < g.length;) {
                            if (0 < c && this.nd.length == c) {
                                c = !1;
                                break a
                            }
                            for (var h = [gvjs_BG(this, f, g, e)], k =
                                    1; k < this.pB && g.length != f.length; k++) g = g.slice(f.length), f = gvjs_AG(this, g, d), h.push(gvjs_BG(this, f, g, e));
                            h = gvjs_Vfa(this, h);
                            this.nd.push(h);
                            g = g.slice(f.length);
                            f = gvjs_AG(this, g, d)
                        }
                        this.fq = 1 < this.nd.length
                    }
                    c = !0
                }
                if (c) break
            }
            this.fq && (this.AV = Math.round((this.mb.top + this.mb.bottom - this.Ea.fontSize) / 2), this.Fv = this.mb.right - this.Ea.fontSize, this.Gv = this.Fv - this.aD - this.Ea.fontSize, this.bW && (a = gvjs_zG(this, this.nd.length), this.Gv -= a + this.aD))
        }
    a = 0;
    c = b = null;
    if (this.nd && 0 < this.nd.length)
        if (1 < this.nd.length &&
            (a = this.Dg < this.nd.length ? this.Dg : this.nd.length - 1), b = this.nd[a], this.fq) {
            c = 0 < a;
            d = a < this.nd.length - 1;
            e = this.AV;
            f = null;
            this.bW && (f = a + 1 + "/" + this.nd.length, g = this.Gv + this.Ea.fontSize, h = this.Fv - g, f = {
                text: f,
                textStyle: this.i7,
                boxStyle: null,
                lines: [{
                    x: g + h / 2,
                    y: e,
                    text: f,
                    length: h
                }],
                Yb: gvjs_X,
                Mb: gvjs_l,
                tooltip: "",
                anchor: null,
                angle: 0
            });
            h = this.Ea.fontSize;
            k = Math.round(h / 2);
            g = this.Gv;
            var l = this.Fv;
            this.Xka == gvjs_S ? (g = [{
                x: g + h,
                y: e + h
            }, {
                x: g + k,
                y: e
            }, {
                x: g,
                y: e + h
            }], e = [{
                x: l,
                y: e
            }, {
                x: l + h,
                y: e
            }, {
                x: l + k,
                y: e + h
            }]) : (g = [{
                x: g + h,
                y: e +
                    h
            }, {
                x: g + h,
                y: e
            }, {
                x: g,
                y: e + k
            }], e = [{
                x: l,
                y: e
            }, {
                x: l + h,
                y: e + k
            }, {
                x: l,
                y: e + h
            }]);
            h = {
                active: this.Vka,
                gK: this.Wka
            };
            c = {
                WU: {
                    path: g,
                    active: c,
                    ab: h,
                    brush: c ? h.active : h.gK
                },
                cU: {
                    path: e,
                    active: d,
                    ab: h,
                    brush: d ? h.active : h.gK
                },
                FU: f
            }
        } else c = null;
    return {
        position: this.ef,
        area: this.mb,
        nd: this.nd,
        Zq: b,
        Dg: a,
        wF: c
    }
};

function gvjs_Ufa(a) {
    var b = Math.max(a.mb.right - a.mb.left - (a.zu + a.ju), 0),
        c = a.mb.bottom - a.mb.top,
        d = Math.max(c - 2 * a.cK, 0),
        e = a.uB,
        f = a.Gi;
    gvjs_SF(f) && e.reverse();
    var g = e.map(function(h) {
        h = gvjs_rF(this.Me, h.text, this.Ea, b, Infinity);
        0 == h.lines.length && (h.lines = [""]);
        return h
    }, a);
    if (a.ef != gvjs_Yt || f.wC != gvjs_d && f.wC != gvjs_Ar)
        if (c = gvjs_CG(a, g, c), a.fq = gvjs_Wfa(e, c), a.fq)
            if (c = gvjs_CG(a, g, d), void 0 === c[0] || 0 == c[0].length) a.fq = !1;
            else {
                for (a.nd = []; 0 < e.length;) {
                    f = gvjs_DG(a, c, e);
                    a.nd.push(f);
                    for (f = 0; void 0 !== c[f] &&
                        0 != c[f].length;) ++f;
                    g = g.slice(f);
                    c = gvjs_CG(a, g, d);
                    e = e.slice(f)
                }
                a.fq && (a.AV = Math.round(a.mb.bottom - a.Ea.fontSize), a.Gv = a.mb.left, a.Fv = a.Gv + a.Ea.fontSize + a.aD, a.bW && (d = gvjs_zG(a, a.nd.length), a.Fv += d + a.aD))
            }
    else a.nd = [gvjs_DG(a, c, e)];
    else a.nd = [gvjs_Xfa(a, g, c, e)]
}

function gvjs_CG(a, b, c) {
    var d = a.Ea.fontSize;
    a = gvjs_Yfa(a, b, d + Math.round(d / 1.618), d + Math.round(d / 3.236));
    return gvjs_sy(a, c)
}

function gvjs_Zfa(a, b) {
    var c = gvjs_ux(a.Gi.hAxes);
    b = a.Gi.series[b];
    a = b.points.map(function(d) {
        return gvjs_MF(d) ? null : new gvjs_A(d.W.x, d.W.y)
    });
    b = gvjs_zy(a, c.Gd, b.interpolateNulls);
    return null !== b ? b : gvjs__fa(a, c.Gd)
}

function gvjs__fa(a, b) {
    a = a.filter(function(c) {
        return null != c
    });
    b = -(gvjs_dx(a, b, function(c, d) {
        return gvjs_Bf(c, d.x)
    }) + 1);
    a = a.slice(0, b);
    return (a = gvjs_9w(a, function(c) {
        return null !== c.y
    })) ? a.y : null
}

function gvjs_Xfa(a, b, c, d) {
    for (var e = a.mb.right - a.mb.left, f = Math.round(a.mb.left), g = [], h = [], k = a.Gi.Jy == gvjs_Fs, l = 0, m = 0; m < d.length; m++) {
        var n = d[m],
            p = gvjs_rF(a.Me, n.text, a.Ea, e, b[m].lines.length),
            q = {};
        q.id = n.id;
        q.brush = n.brush.clone();
        l = gvjs_z(a.Ea);
        l.color = q.brush.fill;
        q.ka = {
            text: n.text,
            textStyle: l,
            boxStyle: null,
            lines: [],
            Yb: gvjs_l,
            Mb: gvjs_l,
            tooltip: p.tc ? n.text : "",
            anchor: null,
            angle: 0
        };
        l.auraColor && q.brush.Jc(l.auraColor, 1);
        q.isVisible = !0;
        for (var r = 0; r < p.lines.length; r++) q.ka.lines.push({
            length: e,
            text: p.lines[r]
        });
        k && (p = a.Me(q.ka.lines[0].text, l).width, q.Ie = {}, q.Ie.coordinates = {
            x: f + p + 5
        }, q.Ie.brush = q.brush, q.Ie.isVisible = !1);
        q.index = n.index;
        n = gvjs_Zfa(a, q.index) || 0;
        l = a.Me(q.ka.lines[0], l).height;
        g.push(new gvjs_wG(n, q.ka.lines.length * l, q));
        h.push(q)
    }
    gvjs_Rfa(new gvjs_Qfa(c, g));
    for (a = 0; a < g.length; a++)
        for (c = g[a], b = c.wr(), c = c.Qha, d = c.ka.lines, e = 0; e < d.length; e++) d[e].y = Math.round(e * l + b), d[e].x = f, k && (c.Ie.coordinates.y = d[e].y);
    return h
}

function gvjs_DG(a, b, c) {
    var d = a.zu + a.ju,
        e = a.mb.right - a.mb.left - d,
        f = a.Ea.fontSize,
        g = Math.round(f / 1.618),
        h = f + g,
        k = f + Math.round(f / 3.236);
    f = [];
    for (var l = 0, m = Math.round(a.mb.left), n = 0; n < c.length; n++) {
        var p = c[n],
            q = b[n].length;
        if (0 != q) {
            q = gvjs_rF(a.Me, p.text, a.Ea, e, q);
            var r = {};
            r.id = p.id;
            r.ka = {
                text: p.text,
                textStyle: a.Ea,
                boxStyle: null,
                lines: [],
                anchor: new gvjs_vF(m, 0),
                Yb: gvjs_l,
                Mb: gvjs_l,
                tooltip: q.tc ? p.text : "",
                angle: 0
            };
            r.square = {};
            r.square.coordinates = new gvjs_0(m, l, a.zu, a.cK);
            r.square.brush = p.brush.clone();
            a.Ea.auraColor && r.square.brush.Jc(a.Ea.auraColor, 1);
            r.isVisible = !0;
            for (var t = 0; t < q.lines.length; t++) 0 < t && (l += k), r.ka.lines.push({
                x: d,
                y: l,
                length: e,
                text: q.lines[t]
            });
            r.index = p.index;
            l += h;
            f.push(r)
        }
    }
    b = Math.round(a.mb.top);
    a.fq || (g = l - g, c = a.mb.bottom - a.mb.top, a.yH == gvjs_Y ? b += c - g : a.yH == gvjs_X && (b += Math.floor((c - g) / 2)));
    for (a = 0; a < f.length; a++) g = f[a], g.square.coordinates.top += b, g.ka.anchor.y += b;
    return f
}

function gvjs_Yfa(a, b, c, d) {
    for (var e = b.reduce(function(h, k) {
            return Math.max(h, k.lines.length)
        }, 0), f = [], g = {
            Qs: 0
        }; g.Qs < e; g = {
            Qs: g.Qs,
            TN: g.TN
        }, g.Qs++) g.TN = 0 == g.Qs ? c : d, b.forEach(function(h) {
        return function(k, l) {
            h.Qs < k.lines.length && f.push({
                key: l,
                min: 0 == h.Qs && 0 == l ? this.Ea.fontSize : h.TN,
                extra: []
            })
        }
    }(g), a);
    return f
}

function gvjs_Wfa(a, b) {
    var c = a.length - 1;
    return 1 < a.length && 1 > b[c].length
}

function gvjs_Vfa(a, b) {
    var c = a.mb.bottom - a.mb.top,
        d = a.Ea.fontSize,
        e = c - a.pB * d,
        f = 1 < a.pB ? e / (a.pB - 1) : 0,
        g = (c - ((d + f) * b.length - f)) / 2,
        h = [];
    b.forEach(function(k) {
        var l = Math.round(g);
        k.forEach(function(m) {
            m.ka.anchor.y += l;
            m.square.coordinates.top += l
        });
        g += d + f;
        gvjs_xf(h, k)
    });
    return h
}

function gvjs_AG(a, b, c) {
    var d = Math.min(a.Gi.width * (2 - 1.618) / 2, c);
    if (d < a.zu + a.ju) return [];
    a = gvjs_0fa(a, d, b);
    return gvjs_ry(a, c)
}

function gvjs_BG(a, b, c, d) {
    for (var e = a.mb.right - a.mb.left, f = a.zu + a.ju, g = Math.round(1.618 * a.Ea.fontSize), h = [], k = 0, l = Math.round(a.mb.top), m = 0; m < b.length; m++) {
        var n = c[m],
            p = gvjs_rF(a.Me, n.text, a.Ea, b[m] - f - (0 < m ? g : 0), 1),
            q = 0 < p.lines.length ? p.lines[0] : "",
            r = a.Me(q, a.Ea).width,
            t = [{
                x: k + f,
                y: 0,
                length: r,
                text: q
            }],
            u = {};
        u.id = n.id;
        u.ka = {
            text: n.text,
            textStyle: a.Ea,
            boxStyle: null,
            lines: q ? t : [],
            anchor: new gvjs_vF(0, l),
            Yb: gvjs_l,
            Mb: gvjs_l,
            tooltip: p.tc ? n.text : "",
            angle: 0
        };
        u.isVisible = !0;
        u.square = {};
        u.square.brush = n.brush.clone();
        a.Ea.auraColor && u.square.brush.Jc(a.Ea.auraColor, 1);
        u.square.coordinates = new gvjs_0(k, l, a.zu, a.cK);
        u.index = n.index;
        h.push(u);
        k += r + f + g
    }
    b = a.mb.left;
    d || (d = k - g, a.yH == gvjs_Y ? b += e - d : a.yH == gvjs_X && (b += Math.floor((e - d) / 2)));
    for (a = 0; a < h.length; a++) e = h[a], e.square.coordinates.left += b, e.ka.anchor.x += b;
    return h
}

function gvjs_0fa(a, b, c) {
    var d = a.zu + a.ju,
        e = Math.round(1.618 * a.Ea.fontSize);
    return c.map(function(f, g) {
        var h = this.Me(f.text, this.Ea).width + d;
        f = Math.min(b, h);
        h -= f;
        0 < g && (f += e);
        return {
            min: f,
            extra: [h]
        }
    }, a)
}

function gvjs_zG(a, b) {
    for (var c = "0"; 10 <= b;) c += "0", b /= 10;
    return a.Me(c + "/" + c, a.i7).width
};
var gvjs_EG = null;

function gvjs_1fa() {
    this.rF = {}
}

function gvjs_FG() {
    return gvjs_EG ? gvjs_EG : gvjs_EG = new gvjs_1fa
};

function gvjs_GG() {
    gvjs_qG.call(this);
    this.z3 = 1;
    this.tickSize = 0
}
gvjs_r(gvjs_GG, gvjs_qG);
gvjs_ = gvjs_GG.prototype;
gvjs_.PR = function() {
    return [0, 0, 0, 0]
};
gvjs_.R = function(a, b) {
    return a.R(b)
};
gvjs_.compareValues = function(a, b) {
    a = gvjs_Iy(a);
    b = gvjs_Iy(b);
    return a < b ? -1 : a > b ? 1 : 0
};
gvjs_.zG = function(a) {
    return gvjs_Iy(a)
};
gvjs_.gL = function(a) {
    return gvjs_Gy(a).reverse()
};
gvjs_.IR = function(a) {
    return a
};
gvjs_.Xq = function() {
    var a = new gvjs_$i({
        pattern: this.Ce || (1 < this.z3 ? gvjs_Ja : 1 === this.z3 ? gvjs_Ka : gvjs_La),
        timeZone: 0
    });
    this.Za = {
        formatValue: function(b) {
            b = gvjs_Kj(b);
            return a.formatValue(b)
        }
    }
};

function gvjs_HG(a, b) {
    this.h9 = a;
    this.textStyle = b
}
gvjs_r(gvjs_HG, gvjs_hfa);
gvjs_HG.prototype.pb = function(a) {
    return this.h9(a, this.textStyle).width
};
gvjs_HG.prototype.getHeight = function(a) {
    return this.h9(a, this.textStyle).height
};

function gvjs_IG(a, b, c, d, e, f) {
    this.L = a;
    this.mba = c[0];
    this.options = b.view(c);
    this.index = d;
    this.type = gvjs_C(this.options, gvjs_ge, e, gvjs_mea);
    this.maxValue = this.minValue = null;
    this.tB = [];
    this.BI = this.mw = null;
    this.Vaa = 0 < a.Df.bars;
    b = gvjs_C(this.options, gvjs_ce);
    c = a.axisTitlesPosition === gvjs_Kt ? a.Eu : gvjs_e;
    c = gvjs_Pw(this.options, gvjs_Tv, {
        fontName: a.Kf,
        fontSize: a.rh,
        auraColor: c
    });
    this.title = {
        text: b,
        textStyle: c,
        boxStyle: null,
        lines: [],
        Yb: gvjs_X,
        Mb: gvjs_l,
        tooltip: "",
        anchor: null,
        angle: 0
    };
    this.ticks = [];
    this.lb =
        this.Oe = null;
    this.bh = gvjs_C(this.options, "textPosition", gvjs_Nu, gvjs_RA);
    b = this.type != gvjs_o || a.chartType == gvjs_j ? gvjs_Mw(this.options, "majorAxisTextColor", gvjs_ME.majorAxisTextColor) : gvjs_Mw(this.options, "minorAxisTextColor", gvjs_ME.minorAxisTextColor);
    c = this.bh === gvjs_Kt ? a.Eu : gvjs_e;
    b = {
        color: b,
        fontName: a.Kf,
        fontSize: a.rh,
        auraColor: c
    };
    this.ec = gvjs_Pw(this.options, gvjs_Pv, b);
    c = gvjs_5i(this.options, "gridlines.minorTextOpacity");
    c = gvjs_by(this.ec.color, a.vH || gvjs_lq, c);
    this.CE = gvjs_Pw(this.options,
        gvjs_Pv, b);
    this.CE.color = c;
    this.qma = gvjs_C(this.options, "outTextPosition", "unbound", gvjs_rea);
    this.k9 = gvjs_C(this.options, "inTextPosition", "low", gvjs_sea);
    b = gvjs_Mw(this.options, gvjs_Jr, a.baselineColor);
    this.oba = new gvjs__({
        fill: b
    });
    b = gvjs_Mw(this.options, gvjs_pt, a.E3);
    this.gp = new gvjs__({
        fill: b
    });
    this.yr = this.options.ha(gvjs_qt);
    this.G3 = this.options.ha(gvjs_st);
    this.Gia = this.options.ha(gvjs_ku);
    c = gvjs_5i(this.options, "gridlines.minorGridlineOpacity");
    a = b == gvjs_e ? gvjs_e : gvjs_by(b, a.vH || gvjs_lq, c);
    a = gvjs_Mw(this.options, gvjs_ju, a);
    this.WK = new gvjs__({
        fill: a
    });
    this.sl = 2;
    this.h3 = Math.max(this.sl, Math.round(this.title.textStyle.fontSize / 3.236));
    this.FB = 0;
    this.direction = this.Sk = gvjs_E(this.options, gvjs_Cs, 1);
    this.Gd = this.je = null;
    this.yG = this.ks = 0;
    this.Ja = {
        min: -Infinity,
        max: Infinity
    };
    this.viewWindowMode = this.Pca = f;
    this.wV = gvjs_$D(this.options, gvjs_$t, gvjs_bv);
    this.b9 = (this.Tr = (this.q6 = this.wV === gvjs_ou) || "log" === this.wV) && !this.q6;
    this.type == gvjs_o && (this.baseline = this.ga = null, this.QN = Infinity,
        this.w5 = this.lT = null)
}

function gvjs_JG(a, b) {
    typeof b !== gvjs_f || 0 === b || isNaN(b) || (b = Math.abs(b), a.QN = Math.min(b - b / 10, a.QN))
}
gvjs_ = gvjs_IG.prototype;
gvjs_.Fy = function(a) {
    this.Oe && gvjs_v(this.Oe, function(b) {
        gvjs_JG(this, b.v)
    }, this);
    a = a || [];
    this.ga.Fy(this.wV, this.QN, a)
};
gvjs_.initScale = function(a) {
    var b;
    this.ga = b = (b = gvjs_FG().rF[a]) ? b.apply(null, []) : null;
    this.dataType = a;
    gvjs_KG(this) && (a = {}, gvjs_Dp(a, [gvjs_du], 1), gvjs_Dp(a, ["slantedText"], !1), gvjs_Ep(this.options, 1, a), this.EL());
    a = this.Ig();
    if (this.options.R(gvjs_Os) && (!this.options.R("explorer.axis") || this.options.Ca("explorer.axis." + a)) || null != this.yr && 0 > this.yr) this.yr = -1;
    b.init(this.options, this.yr);
    this.minValue = b.R(this.options, gvjs_Ad);
    this.maxValue = b.R(this.options, gvjs_xd);
    this.mw = this.options.R(gvjs_Ir,
        gvjs_ME.vAxis.gridlines.baseline);
    this.BI = void 0 !== this.mw && this.mw !== gvjs_Gb ? this.mw : this.BI || b.PR();
    gvjs_2fa(this)
};

function gvjs_2fa(a) {
    var b = a.options.R(gvjs_Rv);
    Array.isArray(b) && (a.Oe = b);
    a.Oe && (a.Oe = gvjs_w(a.Oe, function(c) {
        var d = {};
        d.v = void 0 !== c.v ? c.v : c;
        typeof c.f === gvjs_m && (d.f = c.f);
        return d
    }), 0 < a.Oe.length && (gvjs_Af(a.Oe, function(c, d) {
        return a.ga.compareValues(c.v, d.v)
    }), null == a.minValue && (a.minValue = a.Oe[0].v), null == a.maxValue && (a.maxValue = gvjs_nf(a.Oe).v)))
}

function gvjs_LG(a) {
    a.viewWindowMode = gvjs_C(a.options, gvjs_gw, a.viewWindowMode, gvjs_nea);
    var b = a.ga;
    if (a.type == gvjs_o) {
        var c = b.R(a.options, "viewWindow.numericMin");
        typeof c !== gvjs_f && (c = b.Db(b.R(a.options, gvjs_fw)));
        var d = b.R(a.options, "viewWindow.numericMax");
        typeof d !== gvjs_f && (d = b.Db(b.R(a.options, gvjs_ew)));
        null != c && (a.Ja.min = c);
        null != d && (a.Ja.max = d)
    } else a.Ja.min = gvjs_E(a.options, gvjs_fw, a.Ja.min), a.Ja.max = gvjs_E(a.options, gvjs_ew, a.Ja.max), a.Ja.max = Math.max(a.Ja.min + 1, a.Ja.max);
    a.Ja.min > a.Ja.max &&
        (c = a.Ja.min, a.Ja.min = a.Ja.max, a.Ja.max = c);
    a.type == gvjs_o && (-Infinity != a.Ja.min && (c = a.Ja.min, null != c && (b.hk = c)), Infinity != a.Ja.max && (c = a.Ja.max, null != c && (b.gk = c)), gvjs_MG(a))
}

function gvjs_NG(a) {
    if (a.type == gvjs_o && !a.ga) throw Error("Axis type/data type mismatch for " + a.mba);
}

function gvjs_OG(a, b, c, d, e) {
    a.je = c + (1 == a.direction ? .5 : -.5);
    a.FB = b - 1;
    a.Gd = c + b * a.direction;
    b = a.F0();
    a.Pc = d;
    a.Se = e;
    a.type != gvjs_o ? d = gvjs_3fa(a, a.FB + 1) : (null != a.mw && a.mw !== gvjs_Gb && a.ub(a.ga.Db(a.mw)), null != a.minValue && a.ub(a.ga.Db(a.minValue)), null != a.maxValue && a.ub(a.ga.Db(a.maxValue)), gvjs_4fa(a), d = gvjs_KG(a) ? gvjs_5fa(a) : gvjs_6fa(a));
    return {
        title: a.title,
        name: a.m3(),
        type: a.type,
        logScale: a.Tr,
        dataType: a.dataType,
        Sk: a.Sk,
        je: a.je,
        Gd: a.Gd,
        number: {
            Ld: a.I6.bind(a),
            Ai: a.en.bind(a)
        },
        position: {
            Ld: a.BP.bind(a),
            Ai: a.C0.bind(a)
        },
        Nl: b,
        baseline: d.baseline,
        gridlines: d.gridlines,
        text: d.lb,
        viewWindow: a.ga ? {
            min: a.ga.hk,
            max: a.ga.gk
        } : {
            min: a.Ja.min,
            max: a.Ja.max
        }
    }
}

function gvjs_3fa(a, b) {
    var c = a.L.Fa; - Infinity == a.Ja.min && (a.Ja.min = Math.min(0, a.Ja.max - 1));
    Infinity == a.Ja.max && (a.Ja.max = Math.max(c.length, a.Ja.min + 1));
    a.Ja.max = Math.max(a.Ja.min + 1, a.Ja.max);
    var d = a.Ja.max - a.Ja.min;
    a.Vaa && (d = Math.min(d, Math.floor((b + 1) / 2)));
    a.type == gvjs_4r && (d = Math.max(1, d - 1));
    a.yG = gvjs_PG(a);
    a.ks = a.FB / d;
    var e = gvjs_7fa(a);
    b = gvjs_py(c.length, function(f) {
        var g = e.formatValue(c[f].Ds[0]),
            h = f - a.yG;
        return {
            Oa: c[f].data,
            oa: a.ne(f),
            text: g,
            isVisible: 0 <= h && h <= d,
            optional: !0
        }
    });
    return {
        gridlines: [],
        baseline: null,
        lb: a.qx(b, null),
        ticks: []
    }
}

function gvjs_7fa(a) {
    if (a.ga) {
        if (gvjs_KG(a)) {
            var b = gvjs_hG(a.options, !1, 0, function(d) {
                return a.ne(d)
            }, a.L.Va);
            gvjs_QG(a, b, 0);
            return new gvjs_$i({
                pattern: 8
            })
        }
        b = gvjs_w(a.Oe, function(d) {
            return d.v
        });
        b = gvjs_WE(b);
        var c = gvjs_RG(a);
        gvjs_QE(c, b);
        return c.Sd()
    }
    return {
        formatValue: function(d) {
            return d
        }
    }
}

function gvjs_5fa(a) {
    function b(F) {
        F = c(F);
        var G = a.qx(F, null);
        if (null == G) return !1;
        gvjs_6w(G, function(H) {
            var I = H.ka.anchor.x;
            u && (I = H.ka.anchor.y);
            H.isVisible && gvjs_SG(a, I) || gvjs_uf(G, H)
        });
        return G
    }

    function c(F) {
        a.Oe ? F = gvjs_QG(a, w, v) : (F = F || [], F = gvjs_w(F, function(G) {
            var H = G.Oa;
            H = (Array.isArray(H) ? d.Db(H) : H.getTime()) - v;
            if (null != H && (H = a.ne(H), null != H && !isNaN(H))) return {
                Oa: G.Oa,
                oa: H,
                text: G.ka.text,
                isVisible: G.isVisible,
                optional: G.optional
            }
        }));
        return F
    }
    var d = a.ga,
        e = !0,
        f = !0;
    a.viewWindowMode != gvjs_gu && (e =
        isFinite(a.Ja.min), f = isFinite(a.Ja.max));
    var g = gvjs_TG(a),
        h = g,
        k = h.min;
    h = h.max;
    gvjs_UG(a, g);
    gvjs_MG(a);
    var l = k,
        m = h;
    g = Math.abs(h - k);
    var n = a.LR(),
        p = a.baseline.Oa,
        q = null == p ? null : d.Db(p);
    p = Math.abs(a.Gd - a.je);
    var r = a.options.Ze("viewWindow.maxPadding", p) / p;
    r *= g;
    e || (k = null != q && q <= k && k - g < q ? q : k - r);
    f || (h = null != q && q >= h && h + g > q ? q : h + r);
    g = {
        min: k,
        max: h
    };
    gvjs_UG(a, g);
    gvjs_MG(a);
    gvjs_Af(a.tB);
    var t = Infinity;
    for (g = 1; g < a.tB.length; ++g)(q = Math.abs(a.tB[g] - a.tB[g - 1])) && (t = Math.min(t, q));
    Infinity === t && (t = 0);
    var u = n.orientation ===
        gvjs_S;
    n = {};
    var v = 0;
    d instanceof gvjs_GG && (v = (new Date(1970, 0, 1)).getTime(), n = {
        gridlines: {
            units: gvjs_9ea
        },
        minorGridlines: {
            units: gvjs_$ea
        }
    });
    g = null != a.yr && 0 <= a.yr ? a.yr : -1;
    q = a.G3;
    0 <= g && (q = p / (g + 1));
    null != q && gvjs_Dp(n, [gvjs_ot, "minStrongLineDistance"], q);
    gvjs_Ep(a.options, 1, n);
    var w = gvjs_hG(a.options, u, v, function(F) {
            return a.ne(F)
        }, a.L.Va),
        x = {
            ec: a.ec,
            gp: a.gp,
            CE: a.CE,
            WK: a.WK,
            alignment: 1 == a.direction ? 1 : 0
        },
        y = a.direction;
    p = function I(G, H) {
        var P, K, N, Q;
        return gvjs_3w(I, function(U) {
            1 == U.og && (P = w.generate(G,
                H, t, x), K = null, N = function() {
                a.direction = 1;
                return K = P.next().value
            }, Q = {});
            if (4 != U.og) {
                if (!N()) return U.uf(0);
                K.gridlines = gvjs_wf(K.gridlines);
                K.lb = gvjs_wf(K.lb);
                Q.NA = function(O) {
                    return Math.round(100 * O) / 100
                }; - 1 === y && (a.direction = y, gvjs_v(K.gridlines, function(O) {
                    return function(J, C) {
                        J = gvjs_z(J);
                        K.gridlines[C] = J;
                        J.oa = O.NA(gvjs_VG(a, J.oa))
                    }
                }(Q)), gvjs_v(K.lb, function(O) {
                    return function(J, C) {
                        J = gvjs_z(J);
                        K.lb[C] = J;
                        J.oa = O.NA(gvjs_VG(a, J.oa));
                        J.ka = gvjs_z(J.ka);
                        J.ka.lines[0] = gvjs_z(J.ka.lines[0]);
                        J.ka.lines[0].x =
                            O.NA(gvjs_VG(a, J.ka.lines[0].x))
                    }
                }(Q)));
                gvjs_6w(K.lb, function(O) {
                    O.Oa = d.en(O.Oa.getTime());
                    O.ka = gvjs_z(O.ka);
                    var J = gvjs_z(O.ka.lines[0]);
                    O.ka.lines[0] = J;
                    u && (O = gvjs_q([J.y, J.x]), J.x = O.next().value, J.y = O.next().value)
                });
                gvjs_6w(K.gridlines, function(O, J) {
                    O = gvjs_z(O);
                    K.gridlines[J] = O;
                    gvjs_SG(a, O.oa) ? O.Oa = d.en(O.Oa.getTime() - v) : (O.isVisible = !1, gvjs_uf(K.gridlines, O))
                });
                gvjs_Cf(K.gridlines, function(O, J) {
                    return d.compareValues(O.Oa, J.Oa)
                });
                return gvjs_Zw(U, K, 4)
            }
            Q = {
                NA: Q.NA
            };
            return U.uf(2)
        })
    };
    q = !0;
    n = null;
    for (var z, A; q;) {
        g = k;
        q = h;
        var B = p(k, h);
        r = null;
        for (var D = !1; !D && (r = B.next().value);)
            if (n = r.gridlines, D = b(r.lb)) A = a.lT, z = a.w5;
        D && 1 < n.length && (e || (z = gvjs_qf(r.gridlines, function(G, H) {
            var I = d.Db(H.Oa);
            return H.QS || I > l ? G : Math.max(G, I)
        }, -Infinity), k = Math.max(k, z)), f || (r = gvjs_qf(r.gridlines, function(G, H) {
            var I = d.Db(H.Oa);
            return H.QS || I < m ? G : Math.min(G, I)
        }, Infinity), h = Math.min(h, r)));
        q = k != g || h != q;
        g = {
            min: k,
            max: h
        };
        gvjs_UG(a, g);
        gvjs_MG(a)
    }
    a.Oe = null;
    A = A || [];
    z = c(A);
    return {
        gridlines: n,
        baseline: gvjs_WG(a),
        lb: A,
        ticks: z
    }
}

function gvjs_QG(a, b, c) {
    var d = [],
        e = gvjs_w(a.Oe, function(g) {
            var h = a.ga.Db(g.v);
            return {
                Oa: new Date(h + c),
                qe: g.f,
                brush: a.gp
            }
        }),
        f = null;
    if (f = gvjs_kG(b, e, b.p6 || b.O5).next().value)
        if (null == f || 0 === f.length) return [];
    gvjs_v(e, function(g, h) {
        var k = g.Oa,
            l = k.getTime() - c;
        null != l && (l = a.ne(l), null == l || isNaN(l) || (g.oa = l, g.isVisible = !0, d.push({
            Oa: k,
            oa: l,
            text: f[h].text,
            isVisible: !0
        })))
    });
    return d
}

function gvjs_6fa(a) {
    function b(z) {
        z = c({
            li: z
        });
        return a.qx(z, null)
    }

    function c(z) {
        return a.Oe ? gvjs_8fa(a, v) : gvjs_9fa(a, z.li)
    }
    var d = a.ga,
        e = !0,
        f = !0;
    a.viewWindowMode != gvjs_gu && (e = isFinite(a.Ja.min), f = isFinite(a.Ja.max));
    var g = gvjs_TG(a),
        h = g,
        k = h.min;
    h = h.max;
    gvjs_UG(a, g);
    gvjs_MG(a);
    var l = k,
        m = h,
        n = Math.abs(h - k);
    isFinite(n) || (n = 1);
    var p = a.baseline.Oa;
    g = null == p ? null : d.Db(p);
    var q = a.LR();
    p = d.lv.inverse(d.hk);
    var r = d.lv.inverse(d.gk);
    gvjs_JG(a, p);
    gvjs_JG(a, r);
    r = Math.abs(a.Gd - a.je);
    var t = a.Tr ? 0 : 1,
        u = new gvjs_HG(a.L.Va,
            a.ec);
    gvjs_Ep(a.options, 1, {
        format: d.Ce
    });
    var v = gvjs_RG(a);
    p = a.yr; - 1 === p && (p = null);
    var w = a.G3;
    null != p && 2 < p && (a.Tr && (p *= 2), w = r / Math.max(1, p + 1));
    null == w && (w = 40, a.Ig() === gvjs_R && (w *= 2));
    a.Tr && (w /= 2);
    e || (null != g && g <= k && k - n < g && (k = g, e = !0), a.b9 && 0 >= k && (k = .1 * l));
    !f && null != g && g >= h && h + n < g && (h = g, f = !0);
    gvjs_Ep(a.options, 0, {
        gridlines: {
            minSpacing: w
        }
    });
    n = function(z, A) {
        function B(I) {
            return gvjs_uy(13, d.lv.inverse(I))
        }
        var D = B(z),
            F = B(A),
            G = e ? null : B(l),
            H = f ? null : B(m);
        if (isNaN(D) || isNaN(F)) return {
            li: [],
            minorGridlines: [],
            min: z,
            max: A
        };
        z = q.sn + .5;
        A = q.Rp - .5;
        a.Tr && (A -= .5);
        return gvjs_eF(new gvjs_cF(D, F, z, A, q.Je, t, a.QN || 1, q.orientation, a.options, u, v, b, function(I) {
            a.ne = function(P) {
                if (null == P) return null;
                P = B(P);
                return I.ld(P)
            };
            a.QH = function(P) {
                if (null == P) return null;
                P = I.Hg(P);
                return gvjs_uG(d, P)
            }
        }), D, F, G, H)
    }(k, h);
    k = gvjs_uG(d, n.min);
    h = gvjs_uG(d, n.max);
    g = {
        min: k,
        max: h
    };
    gvjs_UG(a, g);
    gvjs_MG(a);
    k = a.lT || [];
    if (0 === p || 1 === p) n.li = gvjs_yf(n.li, 0, p);
    2 === p && (n.li = [n.li[0], n.li[n.li.length - 1]]);
    h = c(n);
    var x = [];
    if (!a.Oe) {
        var y = {};
        gvjs_v(h,
            function(z) {
                y[(Math.round(1E4 * z.oa) / 1E4).toString()] = !0
            });
        a.Gia && (null == p || 2 <= p) && gvjs_v(n.minorGridlines || [], function(z) {
            z = z.getValue();
            z = gvjs_uG(d, z);
            z = gvjs_XG(a, z);
            z = Math.round(1E4 * z) / 1E4;
            y[z.toString()] || x.push(z)
        })
    }
    p = gvjs_w(h, function(z) {
        return {
            tick: z,
            Oa: z.Oa,
            oa: z.oa,
            isVisible: gvjs_SG(this, z.oa),
            length: null,
            brush: this.gp
        }
    }, a);
    0 < x.length && (n = gvjs_w(x, function(z) {
        return {
            Oa: this.C0(z),
            oa: z,
            isVisible: !0,
            length: null,
            brush: this.WK
        }
    }, a), gvjs_xf(p, n));
    if (n = gvjs_WG(a)) n.isVisible = gvjs_SG(a, n.oa);
    return {
        gridlines: p,
        baseline: n,
        lb: k,
        ticks: h
    }
}

function gvjs_9fa(a, b) {
    var c = [];
    gvjs_v(b, function(d) {
        var e = d.Xe(),
            f = d.getValue(),
            g = null == f ? null : a.ga.gL(f);
        f = gvjs_uG(a.ga, f);
        f = a.ne(f);
        if (!isNaN(f)) {
            f = Math.round(1E4 * f) / 1E4;
            var h = gvjs_SG(a, f);
            d.Jha && h && c.push({
                Oa: g,
                oa: f,
                text: e || "",
                isVisible: h
            })
        }
    });
    return c
}

function gvjs_8fa(a, b) {
    var c = gvjs_w(a.Oe, function(f) {
        return f.v
    });
    c = gvjs_WE(c);
    gvjs_QE(b, c);
    var d = b.Sd(),
        e = [];
    gvjs_v(a.Oe, function(f) {
        var g = f.v,
            h = a.ga.Db(g);
        null != h && (h = a.ne(h), null != h && !isNaN(h) && gvjs_SG(a, h) && (f = f.f, typeof f !== gvjs_m && (f = d.formatValue(g)), e.push({
            Oa: g,
            oa: h,
            text: f,
            isVisible: !0
        })))
    });
    return e
}

function gvjs_RG(a) {
    var b = a.options;
    a = new gvjs_PE;
    var c = {
        pattern: b.Ca([gvjs_dt, "format.pattern"]),
        fractionDigits: b.ha(["format.fractionDigits", "formatOptions.fractionDigits"]),
        significantDigits: b.ha(["format.significantDigits"]),
        scaleFactor: b.ha(["format.scaleFactor", gvjs_ft, "formatter.scaleFactor"]),
        prefix: b.Ca(["format.prefix", gvjs_et, "formatter.prefix"]),
        suffix: b.Ca(["format.suffix", gvjs_gt, "formatter.suffix"]),
        decimalSymbol: b.Ca(["format.decimalSymbol"]),
        groupingSymbol: b.Ca(["format.groupingSymbol"]),
        negativeColor: b.Ca(["format.negativeColor"]),
        negativeParens: b.Ca(["format.negativeParens"])
    };
    a.c3 = c;
    a.On = !1;
    c = b.ha(["format.numDecimals", "formatter.numDecimals", "formatOptions.numDecimals"]);
    typeof c === gvjs_f && (a.cv = c, a.On = !0, gvjs_QE(a, c));
    c = b.ha(["format.maxNumDecimals", "formatter.maxNumDecimals", "formatOptions.maxNumDecimals"]);
    typeof c === gvjs_f && gvjs_QE(a, c);
    var d = b.ha(["format.minNumDecimals", "formatter.minNumDecimals", "formatOptions.minNumDecimals"]);
    typeof d === gvjs_f && (a.cv = d, a.On = !0);
    d = b.ha(["format.numSignificantDigits",
        "formatter.numSignificantDigits", "formatOptions.numSignificantDigits"
    ]);
    typeof d === gvjs_f && (a.kz = d, a.On = !0);
    if (d = b.R(["format.unit", "formatter.unit", "formatOptions.unit"])) a.Js = {
        symbol: d.symbol,
        position: d.position,
        usePadding: d.usePadding
    }, a.On = !0;
    b = b.R(["format.useMagnitudes", "formatter.useMagnitudes", "formatOptions.useMagnitudes"]);
    null != b && (d = a.hna.bind(a), "long" === b && (d = a.gna.bind(a)), d(typeof c === gvjs_f ? c : 5));
    return a
}

function gvjs_WG(a) {
    var b = null;
    a.type == gvjs_o && a.baseline && (b = {
        Oa: a.baseline.Oa,
        oa: a.baseline.oa,
        isVisible: !0,
        length: null,
        brush: a.oba
    });
    return b
}

function gvjs_4fa(a) {
    if (a.Oe) {
        var b = Infinity,
            c = -Infinity;
        gvjs_v(a.Oe, function(e) {
            e = this.ga.Db(e.v);
            b = Math.min(b, e);
            c = Math.max(c, e);
            this.ub(e)
        }, a);
        if (1 < a.Oe.length) {
            var d = a.ga.gk;
            b <= a.ga.hk && !isFinite(a.Ja.min) && (a.Ja.min = b);
            c >= d && !isFinite(a.Ja.max) && (a.Ja.max = c)
        }
    }
}

function gvjs_TG(a) {
    var b = isFinite(a.Ja.min) ? a.Ja.min : a.ga.hk;
    isFinite(b) || (b = 0);
    var c = isFinite(a.Ja.max) ? a.Ja.max : a.ga.gk;
    isFinite(c) || (c = 1);
    if (b === c) {
        if (gvjs_KG(a)) {
            a = new Date(b);
            a = gvjs_Ey([a.getMilliseconds(), a.getSeconds(), a.getMinutes(), a.getHours(), a.getDate() - 1, a.getMonth(), a.getFullYear()]);
            var d = [1, 1E3, 6E4, 36E5, 864E5, 26784E5];
            a = a < d.length ? d[a] : 316224E5
        } else a = 1;
        b -= a;
        c += a
    }
    b > c && (c = gvjs_q([c, b]), b = c.next().value, c = c.next().value);
    return {
        min: b,
        max: c
    }
}

function gvjs_UG(a, b) {
    var c = b.min;
    null != c && (a.ga.hk = c);
    c = b.max;
    null != c && (a.ga.gk = c);
    a.Ja = b;
    a.ks = a.FB / Math.max(1, b.max - b.min);
    Infinity !== b.min && (a.yG = b.min)
}

function gvjs_MG(a) {
    var b = null == a.BI ? null : a.ga.Db(a.BI);
    a.ga.M6 = b;
    if (null != b) {
        var c = a.ne(b);
        isNaN(c) && (c = Infinity);
        a.baseline = {
            Oa: a.ga.en(b),
            oa: c,
            isVisible: !0
        }
    } else a.baseline = {
        Oa: null,
        oa: Infinity,
        isVisible: !1
    }
}
gvjs_.ub = function(a) {
    this.type == gvjs_o && null != a && (!this.b9 || 0 <= a) && (this.ga.ub(a), this.tB.push(a))
};

function gvjs_YG(a) {
    if (a.type == gvjs_o) {
        var b = a.ga,
            c = b.hk,
            d = b.gk,
            e = .01 * (d - c);
        0 < c && -Infinity == a.Ja.min && (c = Math.max(c - e, 0), null != c && (b.hk = c));
        0 > d && Infinity == a.Ja.max && (a = Math.min(d + e, 0), null != a && (b.gk = a))
    }
}
gvjs_.ne = function(a) {
    return null == a || 0 === this.ks ? null : this.je + (a - this.yG) * this.direction * this.ks
};

function gvjs_XG(a, b) {
    a = a.ne(b);
    if (null == a) throw Error(gvjs_Bu + b + "'");
    return a
}
gvjs_.QH = function(a) {
    return null == a || 0 === this.ks ? null : (a - this.je) * this.direction / this.ks + this.yG
};
gvjs_.C0 = function(a) {
    a = this.QH(a);
    return null == a ? null : this.en(a)
};
gvjs_.BP = function(a) {
    a = this.I6(a);
    return null == a ? null : this.ne(a)
};

function gvjs_ZG(a, b) {
    a = a.BP(b);
    if (null == a) throw Error(gvjs_Bu + b + "'");
    return a
}

function gvjs_VG(a, b) {
    return null == b ? null : 2 * a.je - b
}

function gvjs__G(a, b) {
    return isNaN(b) ? !0 : b * a.direction > a.Gd * a.direction
}

function gvjs_SG(a, b) {
    return !isNaN(b) && Infinity != b && !(isNaN(b) || b * a.direction < a.je * a.direction) && !gvjs__G(a, b)
}
gvjs_.I6 = function(a) {
    return this.type == gvjs_o ? this.ga.Db(a) : a
};
gvjs_.en = function(a) {
    return null == a ? null : this.type == gvjs_o ? this.ga.en(a) : a
};

function gvjs_PG(a) {
    switch (a.type) {
        case gvjs_3r:
            return a.Ja.min - .5
    }
    return a.Ja.min
}

function gvjs_0G(a, b) {
    return null == b ? !1 : a.type == gvjs_o ? b >= a.Ja.min && b <= a.Ja.max : b >= Math.floor(a.Ja.min) && b < Math.ceil(a.Ja.max)
}

function gvjs_KG(a) {
    return null != a.ga && (a.ga instanceof gvjs_vG || a.ga instanceof gvjs_GG)
}
gvjs_.qx = function(a, b) {
    this.ticks = a;
    this.lb = b;
    a = this.bh;
    a === gvjs_e && (this.bh = gvjs_Kt);
    this.E0();
    this.D0();
    b = null;
    a === gvjs_e && (this.lb = []);
    this.lb && this.X_() && (this.lT = this.lb, this.w5 = this.ticks, b = this.lb);
    this.bh = a;
    return b
};

function gvjs_$fa(a, b, c, d) {
    this.sia = b;
    this.L6 = d;
    this.NT = Math.pow(a, 2);
    this.BT = Math.pow(b, 2);
    this.gV = (this.Bk = c ? new gvjs_Lk(d.transform(c.start), d.transform(c.end)) : null) ? this.Bk.end - this.Bk.start : null
}

function gvjs_1G(a, b) {
    var c = null;
    null != b && null != a.L6 && (b = a.L6.transform(b));
    if (null != b && null != a.Bk) 0 === a.gV && b === a.Bk.start ? c = (a.BT + a.NT) / 2 : b <= a.Bk.start ? c = a.NT : b >= a.Bk.end && (c = a.BT);
    else if (!a.gV || null == b) return a.sia;
    null == c && (b = gvjs_7h(b, a.Bk.start, a.Bk.end), c = gvjs_Nx(a.NT, a.BT, (b - a.Bk.start) / a.gV));
    return Math.round(Math.sqrt(c))
}

function gvjs_2G(a, b) {
    var c = gvjs_5i(a, "sizeAxis.minSize"),
        d = gvjs_5i(a, "sizeAxis.maxSize");
    if (c > d) throw Error("sizeAxis.minSize (" + c + ") must be at most sizeAxis.maxSize (" + d + ")");
    var e = a.ha("sizeAxis.minValue"),
        f = a.ha("sizeAxis.maxValue");
    if (null != e && null != f && e > f) throw Error("sizeAxis.minValue (" + e + ") must be at most sizeAxis.maxValue (" + f + ")");
    b = gvjs_EA(b, e, f);
    a = gvjs_$D(a, "sizeAxis.logScale", "sizeAxis.scaleType");
    a = gvjs_aE(a, 1, []);
    return new gvjs_$fa(c, d, b, a)
};

function gvjs_3G(a, b, c, d) {
    this.Ji = a;
    this.m = b;
    this.Gi = d;
    this.Me = c;
    this.Ea = gvjs_Pw(this.m, "bubble.textStyle", {
        fontName: d.Kf,
        fontSize: d.rh,
        auraColor: d.Eu
    });
    this.ena = gvjs_D(this.m, "bubble.highContrast", !1);
    this.Xla = gvjs_Mw(this.m, "bubble.stroke", gvjs_iq);
    this.Hja = gvjs_Lw(this.m, gvjs_Xr, .8);
    this.Iba = [
        [255, 255, 255],
        [97, 97, 97]
    ];
    this.ZT = 0;
    this.EG = 1;
    this.GG = 2;
    this.xo = 3;
    this.gq = 4;
    this.rm = this.M8 = this.X0 = this.f$ = this.e$ = "";
    this.MQ = this.m.R(gvjs_ls, gvjs_IE);
    this.Mca = gvjs_ZD(this.MQ[0]).color;
    this.O8 = this.ZP =
        this.kW = this.YP = this.sz = this.Ax = null;
    this.mp()
}
gvjs_3G.prototype.mp = function() {
    function a(k, l, m) {
        if (c.getNumberOfColumns() <= k) return "";
        var n = c.getColumnType(k);
        if (l && !gvjs_tf(m, n)) throw Error(gvjs_xa + k + " must be of type " + m.join("/"));
        if (!l && gvjs_tf(m, n)) throw Error(gvjs_xa + k + " cannot be of type " + m.join("/"));
        return n
    }
    var b = this.Gi,
        c = this.Ji,
        d = c.getNumberOfColumns();
    if (3 > d) throw Error("Data table should have at least 3 columns");
    a(this.ZT, !0, [gvjs_m]);
    var e = a(this.EG, !1, [gvjs_m]),
        f = a(this.GG, !1, [gvjs_m]);
    this.e$ = c.getColumnLabel(this.EG);
    this.f$ =
        c.getColumnLabel(this.GG);
    typeof this.xo === gvjs_f && this.xo < d ? (this.rm = a(this.xo, !0, [gvjs_f, gvjs_m]), this.rm == gvjs_m && (this.Ax = {}, this.sz = []), this.X0 = c.getColumnLabel(this.xo)) : this.xo = null;
    var g = !1;
    typeof this.gq === gvjs_f && this.gq < d ? (a(this.gq, !0, [gvjs_f]), this.M8 = c.getColumnLabel(this.gq), g = gvjs_D(this.m, "sortBubblesBySize", !0)) : this.gq = null;
    b.Fa = [];
    b.Go = {};
    for (d = 0; d < c.getNumberOfRows(); d++) {
        var h = c.getTableRowIndex(d);
        b.Go[h] = d
    }
    b.series = [{
        type: gvjs_Yr,
        enableInteractivity: gvjs_D(this.m, ["series.0.enableInteractivity",
            gvjs_Ms
        ], !0),
        CG: !0,
        showTooltip: !0,
        Sla: g,
        points: [],
        vqa: this.Ax,
        Jsa: this.sz
    }];
    b.dr = e;
    b.XF = [f];
    b.Df = {};
    b.Df.bubbles = 1;
    b.pl = []
};

function gvjs_aga(a, b, c) {
    for (var d = a.Ji, e = 0; e < d.getNumberOfRows(); e++) {
        var f = d.getValue(e, a.EG),
            g = d.getValue(e, a.GG);
        f = gvjs_tG(b.ga, f);
        g = gvjs_tG(c.ga, g);
        null != f && gvjs_JG(b, f);
        null != g && gvjs_JG(c, g)
    }
}
gvjs_3G.prototype.Paa = function(a) {
    if (a) {
        var b = gvjs_ei(gvjs_4G(this, a.fe)),
            c = gvjs_z(a.textStyle);
        b = gvjs_di(gvjs_0x(b, this.Iba));
        c.color = b;
        a.textStyle = c
    }
};
gvjs_3G.prototype.CP = function(a, b) {
    var c = this.Ji,
        d = c.getFormattedValue(a, this.EG),
        e = c.getFormattedValue(a, this.GG);
    d = [{
        title: this.e$ || "X",
        value: d
    }, {
        title: this.f$ || "Y",
        value: e
    }];
    null != this.xo && (e = c.getFormattedValue(a, this.xo), d.push({
        title: this.X0 || gvjs_Kq,
        value: e
    }));
    null != this.gq && (a = c.getFormattedValue(a, this.gq), d.push({
        title: this.M8 || "Size",
        value: a
    }));
    return {
        title: b,
        lines: d
    }
};

function gvjs_4G(a, b) {
    return a.rm == gvjs_f ? gvjs_aG(a.ZP, b.color) : a.rm == gvjs_m ? a.Ax[b.color].color : a.Mca
};

function gvjs_5G(a, b, c, d, e) {
    this.Ia = this.dataTable = a;
    this.options = b;
    this.Va = c;
    this.Se = this.Pc = null;
    a = this.L = this.c1();
    a.Va = c;
    a.width = d;
    a.height = e;
    a.chartType = gvjs_C(b, gvjs_ge, gvjs_e, gvjs_MA);
    a.Kf = gvjs_C(b, gvjs_at);
    a.rh = gvjs_5i(b, gvjs_bt, Math.round(Math.pow(2 * (a.width + a.height), 1 / 3)));
    a.wC = gvjs_C(b, "seriesType", gvjs_d, gvjs_NA);
    a.enableInteractivity = gvjs_D(b, gvjs_Ms, !0);
    a.md = gvjs_D(b, gvjs_Xv);
    a.Es = gvjs_Ow(b, "tooltip.boxStyle");
    a.selectionMode = gvjs_C(b, gvjs_gv, gvjs_rv, gvjs_SA);
    a.eX = gvjs_D(b, "legend.newLegend");
    a.HB = gvjs_Ow(b, gvjs_Dr);
    a.N0 = gvjs_Ow(b, gvjs_8r);
    c = a.N0;
    d = a.HB;
    c = gvjs_Fw(c) ? c.fill : gvjs_Fw(d) ? gvjs_Ew(c) ? gvjs_by(c.fill, d.fill, c.fillOpacity) : d.fill : null;
    a.vH = c;
    a.baselineColor = gvjs_Mw(b, gvjs_Jr, "");
    a.E3 = gvjs_Mw(b, gvjs_nt, "");
    a.Eu = a.vH || "";
    c = gvjs_C(b, gvjs_ce);
    a.titlePosition = gvjs_C(b, "titlePosition", gvjs_Nu, gvjs_RA);
    d = gvjs_Pw(b, gvjs_Tv, {
        fontName: a.Kf,
        fontSize: a.rh,
        auraColor: a.titlePosition == gvjs_Kt ? a.Eu : gvjs_e
    });
    a.title = {
        text: c,
        textStyle: d,
        boxStyle: null,
        lines: [],
        Yb: gvjs_l,
        Mb: gvjs_Y,
        tooltip: "",
        anchor: null,
        angle: 0
    };
    a.axisTitlesPosition = gvjs_C(b, "axisTitlesPosition", gvjs_Nu, gvjs_RA);
    a.is3D = gvjs_D(b, "is3D");
    a.Pr = gvjs_D(b, "isRtl", !1);
    a.B8 = gvjs_D(b, "shouldHighlightSelection", !0);
    a.interpolateNulls = gvjs_D(b, gvjs_Qt);
    a.Jy = gvjs_C(b, "interactivityModel", gvjs_xs, gvjs_uea);
    this.q1()
}
gvjs_ = gvjs_5G.prototype;
gvjs_.Of = function() {
    return this.L
};
gvjs_.c1 = function() {
    return new gvjs__D
};
gvjs_.Si = function() {
    return this.L
};
gvjs_.init = function(a, b) {
    var c = this,
        d = Infinity;
    if (null != b) {
        var e = this.options.R(gvjs_Eb, null);
        d = typeof e === gvjs_f ? e : (e = gvjs_D(this.options, gvjs_Eb, !1)) ? 100 : Infinity
    }
    var f = gvjs_vf([this.Dba.bind(this)], this.Cu()),
        g = a(function() {
            for (var h = Date.now(), k = 0; 0 < f.length && k <= d;)(k = f.shift()()) && (f = gvjs_vf(k, f)), k = Date.now() - h;
            if (0 === f.length) {
                if (c.L.Jy == gvjs_Fs && (!c.L.Df || c.L.Df.line != c.L.series.length)) throw Error("DIVE interactivity model is only supported when all series are of type line.");
                b && b(c)
            } else setTimeout(g,
                0)
        });
    g()
};
gvjs_.Cu = function() {
    var a = this,
        b;
    return [function() {
        b = a.Si()
    }, function() {
        var c = a.r3(),
            d = a.q3(),
            e = null,
            f = b.chartType;
        !b.Xb || f !== gvjs_Ru && f !== gvjs_j ? b.eX && f !== gvjs_Ru && f !== gvjs_Wr && (e = 2) : e = 2;
        e = a.options.ha("legend.iconAspectRatio") || e;
        a.Pc = new gvjs_yG(b, a.options, c, e);
        a.Se = new gvjs_fG(b, a.options, d)
    }, this.PH.bind(this), function() {
        gvjs_Tfa(a.Pc);
        var c = a.L,
            d = c.title.textStyle.fontSize,
            e = a.Pc.Ea.fontSize,
            f = a.Pc.getPosition(),
            g = a.Se.Ea.fontSize,
            h = a.Se.getPosition(),
            k = c.titlePosition == gvjs_Nu ? c.title.text : "",
            l = gvjs_rF(a.Va, k, c.title.textStyle, c.chartArea.width, Infinity),
            m = Math.max(2, Math.round(d / 3.236)),
            n = Math.max(2, Math.round(e / 1.618)),
            p = Math.max(2, Math.round(g / 1.618));
        g = [];
        g.push({
            key: gvjs_Ur,
            min: 2,
            extra: [Math.max(2, Math.round(1.618 * c.rh)) - 2]
        });
        g.push({
            key: gvjs_2v,
            min: 0,
            extra: [Infinity]
        });
        0 < l.lines.length && g.push({
            key: gvjs_ce,
            min: d + 2,
            extra: []
        });
        if (f == gvjs_1v) {
            f = a.Pc;
            for (var q = c.chartArea.width, r = f.uB, t = gvjs_AG(f, r, q), u = 1;
                (0 == f.d6 || f.d6 > u) && t.length < r.length;) ++u, r = r.slice(t.length), t = gvjs_AG(f, r, q);
            f = u;
            for (q = 0; q < f; ++q) g.push({
                key: gvjs__t,
                min: e + 2,
                extra: [n - 2]
            })
        }
        h == gvjs_1v && g.push({
            key: gvjs_ks,
            min: a.Se.getHeight() + 2,
            extra: [p - 2]
        });
        for (h = 1; h < l.lines.length; h++) g.push({
            key: gvjs_ce,
            min: d + 2,
            extra: [m - 2]
        });
        l = gvjs_sy(g, c.chartArea.top);
        d = l[gvjs_2v][0] || 0;
        m = l.title || [];
        h = gvjs_rF(a.Va, k, c.title.textStyle, c.chartArea.width, m.length);
        for (n = 0; n < h.lines.length; n++) d += m[n], c.title.lines.push({
            text: h.lines[n],
            x: c.chartArea.left,
            y: d,
            length: c.chartArea.width
        });
        c.title.tooltip = h.tc ? k : "";
        k = l.legend || [];
        0 < k.length &&
            (a.Pc.pB = k.length, e = d + k[0] - e, d += gvjs_Tx.apply(null, k), a.Pc.wn(new gvjs_H(e, c.chartArea.right, d, c.chartArea.left)));
        e = l.colorBar || [];
        0 < e.length && (d += e[0], c = new gvjs_H(d - a.Se.getHeight(), c.chartArea.right, d, c.chartArea.left), a.Se.wn(c));
        b.legend = a.Pc.define();
        b.Ag = a.Se.define()
    }]
};
gvjs_.q1 = function() {
    this.Ia = new gvjs_G(this.dataTable);
    if (2 > this.Ia.getNumberOfColumns()) throw Error("Not enough columns given to draw the requested chart.");
};
gvjs_.s7 = function() {};
gvjs_.Dba = function() {
    var a = this.L,
        b = {
            width: this.options.Ze(gvjs_tp, a.width),
            left: this.options.Ze(gvjs_qp, a.width),
            right: this.options.Ze(gvjs_rp, a.width),
            height: this.options.Ze(gvjs_pp, a.height),
            top: this.options.Ze(gvjs_sp, a.height),
            bottom: this.options.Ze(gvjs_op, a.height)
        };
    a.chartArea = gvjs_0p(a.width, a.height, b)
};

function gvjs_6G(a, b, c, d, e, f, g, h, k, l) {
    this.xN = a;
    this.ticks = b;
    this.kJ = c;
    this.maxLines = d;
    this.Y5 = e;
    this.ap = f;
    this.IF = g;
    this.UT = h;
    this.Uaa = k;
    this.qx = l
}

function gvjs_7G(a, b, c, d) {
    switch (d) {
        case "attachToEnd":
            return (b - 1 - a) % c;
        default:
            return a
    }
}

function gvjs_8G(a, b, c) {
    b = Math.ceil((a.ticks.length - 0) / (b * c));
    return 2 > a.ticks.length || 2 > b
}

function gvjs_bga(a, b, c, d, e) {
    b = gvjs_7G(b, a.ticks.length, d, a.IF);
    for (var f = 1 >= a.ticks.length ? a.xN : Math.max(0, Math.abs(a.ticks[1].oa - a.ticks[0].oa) * d - a.UT), g = []; b < a.ticks.length; b += d) {
        var h = a.ticks[b],
            k = h.isVisible && !a.Uaa && null != h.oa ? Math.min(f, 2 * h.oa, 2 * (a.xN - h.oa)) : f,
            l = a.qx(h.text, k, e),
            m = l.tc;
        k < f && (m = a.qx(h.text, f, e).tc);
        g.push({
            Oa: h.Oa,
            isVisible: h.isVisible,
            optional: h.optional,
            oa: h.oa,
            G5: c,
            text: h.text,
            width: l.Bp,
            layout: l,
            tc: m
        })
    }
    return g
}

function gvjs_9G(a, b, c, d) {
    var e = b * c;
    d = 1 < b ? 1 : d;
    for (var f = [], g = 0; g < b; g++) {
        var h = gvjs_bga(a, a.kJ + g * c, g * d, e, d);
        gvjs_xf(f, h)
    }
    f.sort(function(k, l) {
        return (k.oa || 0) - (l.oa || 0)
    });
    return f
}

function gvjs_$G(a, b, c) {
    return gvjs_9G(a, b, c, a.maxLines).map(function(d) {
        return {
            Hp: 0,
            tc: d.tc || !1,
            Wha: d.layout.lines.length
        }
    }).reduce(function(d, e) {
        return {
            Hp: Math.max(d.Hp, e.Wha),
            tc: d.tc || e.tc
        }
    }, {
        Hp: 0,
        tc: !1
    })
}

function gvjs_aH(a) {
    for (var b = 1, c = a.ap || 1, d = gvjs_$G(a, b, c), e = b; d.tc && b < a.Y5;) {
        b++;
        if (gvjs_8G(a, b, c)) break;
        e = b;
        d = gvjs_$G(a, e, c)
    }
    b = c;
    if (!a.ap) {
        c = a.ticks.length / e * a.UT / a.xN;
        if (isNaN(c) || !isFinite(c) || 1 > c) c = 1;
        var f = new gvjs_VE(gvjs_bH);
        f.floor(c);
        for (c = f.next(); d.tc && c < a.ticks.length && !gvjs_8G(a, e, c);) b = c, d = gvjs_$G(a, e, b), c = f.next()
    }
    return {
        TO: e,
        skip: b,
        Hp: d.Hp * e
    }
}

function gvjs_cH(a, b, c, d, e) {
    a = gvjs_9G(a, b, c, d);
    e = a.reduce(function(f, g) {
        var h = g.tc ? 1 : 0;
        delete g.tc;
        return f + h
    }, 0) <= a.length * e;
    return {
        oN: a,
        G_: e
    }
}

function gvjs_dH(a, b, c, d, e) {
    var f = Math.min(a.Y5, d),
        g = Math.min(b, f),
        h = a.ap || c;
    c = gvjs_cH(a, g, h, d, e);
    for (b = g; !c.G_ && g < f;) {
        g++;
        if (gvjs_8G(a, g, h)) break;
        b = g;
        c = gvjs_cH(a, b, h, d, e)
    }
    f = h;
    if (!a.ap) {
        h = a.ticks.length / b * a.UT / a.xN;
        if (isNaN(h) || !isFinite(h) || 1 > h) h = 1;
        g = new gvjs_VE(gvjs_bH);
        g.floor(h);
        for (h = g.next(); !c.G_ && h < a.ticks.length && !gvjs_8G(a, b, h);) f = h, c = gvjs_cH(a, b, f, d, e), h = g.next()
    }
    return {
        TO: b,
        skip: f,
        oN: c.oN
    }
}
var gvjs_bH = [1, 2, 3, 4, 5];

function gvjs_eH(a, b, c, d, e, f) {
    gvjs_IG.call(this, a, b, gvjs_vf(["hAxes." + d, gvjs_ut], c), d, e, f);
    this.allowContainerBoundaryTextCutoff = !1;
    this.EL()
}
gvjs_r(gvjs_eH, gvjs_IG);
gvjs_ = gvjs_eH.prototype;
gvjs_.EL = function() {
    var a = this.options;
    this.lW = a.Pm("slantedText");
    var b = gvjs_E(a, "slantedTextAngle", 30);
    this.P8 = b = gvjs_Mx(b, 360);
    this.YM = gvjs_Ox(b);
    this.lba = gvjs_5i(a, gvjs_au, .5 * this.ec.fontSize);
    this.kJ = gvjs_5i(a, "firstVisibleText");
    this.maxTextLines = gvjs_5i(a, "maxTextLines", Infinity);
    this.maxAlternation = gvjs_5i(a, gvjs_du, 2);
    this.ap = gvjs_5i(a, "showTextEvery", 0);
    this.IF = gvjs_C(a, "showTextEveryMode", "attachToStart", gvjs_xea);
    this.minTextSpacing = gvjs_5i(a, "minTextSpacing", this.ec.fontSize);
    gvjs_D(a, ["allowContainerBoundaryTextCutoff", "allowContainerBoundaryTextCufoff"], !1)
};
gvjs_.m3 = function() {
    return "hAxis#" + this.index
};
gvjs_.xP = function(a, b) {
    var c = this.L.chartArea;
    return gvjs_OG(this, c.width, 1 == this.direction ? c.left : c.right, a, b)
};
gvjs_.E0 = function() {
    var a = this,
        b = null != this.lb;
    if (0 == this.index) {
        var c = this.L.Va,
            d = this.ec.fontSize,
            e = this.title.textStyle.fontSize,
            f = this.L.axisTitlesPosition == gvjs_Nu ? this.title.text : "",
            g = new gvjs_6G(this.L.width, this.ticks, this.kJ, this.maxTextLines, this.maxAlternation, this.ap, this.IF, this.minTextSpacing, this.allowContainerBoundaryTextCutoff, function(y, z, A) {
                return gvjs_rF(c, y, a.ec, z, A)
            }),
            h = this.ap || 1;
        if (this.bh == gvjs_Nu)
            if (null == this.lW)
                if (this.ticks.length * d / (this.maxAlternation * h) <= this.L.width) {
                    var k =
                        gvjs_aH(g);
                    if (k.skip > h || 0 == k.Hp) {
                        var l = gvjs_fH(this, c);
                        k = null
                    }
                } else l = gvjs_fH(this, c);
        else this.lW ? l = gvjs_fH(this, c) : k = gvjs_aH(g);
        var m = gvjs_rF(c, f, this.title.textStyle, this.L.chartArea.width, Infinity),
            n = this.sl,
            p = Math.max(n, Math.round(d / 1.618)),
            q = Math.max(n, Math.round(d / 3.236));
        f = function() {
            return {
                key: gvjs_Rv,
                min: l.minHeight + n,
                max: l.maxHeight + n,
                extra: [p - n]
            }
        };
        var r = [];
        r.push({
            key: gvjs_Ur,
            min: n,
            extra: [Infinity]
        });
        0 < m.lines.length && r.push({
            key: gvjs_ce,
            min: e + n,
            extra: [Infinity]
        });
        var t = this.Pc.Ea.fontSize;
        this.Pc.getPosition() == gvjs_Tr && r.push({
            key: gvjs__t,
            min: t + this.sl,
            extra: [Infinity]
        });
        this.Se.getPosition() == gvjs_Tr && r.push({
            key: gvjs_ks,
            min: this.Se.getHeight() + n,
            extra: [Infinity]
        });
        t = r.length;
        k && 0 < k.Hp ? r.push({
            key: gvjs_Rv,
            min: d + n,
            extra: [p - n]
        }) : l && r.push(f());
        var u = r.length;
        if (k)
            for (var v = 1; v < k.Hp; v++) r.push({
                key: gvjs_Rv,
                min: d + n,
                extra: [q - n]
            });
        d = r.length;
        for (q = 1; q < m.lines.length; q++) r.push({
            key: gvjs_ce,
            min: e + n,
            extra: [this.h3 - n]
        });
        this.PO = e = gvjs_sy(r, this.L.height - this.L.chartArea.bottom);
        var w = e.ticks || [];
        if (k) {
            var x = gvjs_dH(g, k.TO, k.skip, w.length, 0);
            null == this.lW && x.skip > h && (x = k = null, l = gvjs_fH(this, c), r[t] = f(), r = gvjs_Yda(r, 0, u, d, void 0), e = gvjs_sy(r, this.L.height - this.L.chartArea.bottom))
        }
        this.Lg = this.L.chartArea.bottom;
        w = e.ticks || [];
        if (0 < w.length) {
            for (g = 1; g < w.length; g++) w[g] += w[g - 1];
            if (b && 1 == w.length)
                for (b = this.Lg + w[0], g = 0; g < this.lb.length; g++) h = this.lb[g].ka, h.anchor = h.anchor || new gvjs_vF(0, 0), h.anchor.y = b;
            k ? this.lb = gvjs_w(x.oN, function(y, z) {
                var A = gvjs_w(y.layout.lines, function(B, D) {
                    return {
                        x: 0,
                        y: w[y.G5 + D],
                        length: y.width,
                        text: B
                    }
                });
                z = a.lb && a.lb[z] && a.lb[z].ka;
                return {
                    Oa: y.Oa,
                    isVisible: y.isVisible,
                    optional: y.optional,
                    ka: {
                        text: y.text,
                        textStyle: a.ec,
                        lines: A,
                        Yb: z ? z.Yb : gvjs_X,
                        Mb: z ? z.Mb : gvjs_Y,
                        tooltip: y.layout.tc ? y.text : "",
                        anchor: new gvjs_vF(y.oa, a.Lg),
                        angle: 0
                    }
                }
            }) : l && (k = w[0], x = Math.min(k - n, l.maxHeight), this.lb = gvjs_cga(this, c, this.Lg + k - x, x, l.skip));
            this.Lg += gvjs_nf(w)
        }
        gvjs_dga(this);
        gvjs_ega(this);
        gvjs_fga(this)
    }
};

function gvjs_dga(a) {
    var b = a.L.Va,
        c = a.L.axisTitlesPosition == gvjs_Nu ? a.title.text : "",
        d = a.PO.title || [];
    if (0 < d.length)
        for (b = gvjs_rF(b, c, a.title.textStyle, a.L.chartArea.width, d.length), a.title.tooltip = b.tc ? c : "", a.title.lines = [], c = 0; c < d.length; c++) a.Lg += d[c], a.title.Mb = gvjs_Y, a.title.lines.push({
            x: a.L.chartArea.left + a.L.chartArea.width / 2,
            y: a.Lg,
            length: a.L.chartArea.width,
            text: b.lines[c]
        })
}

function gvjs_ega(a) {
    var b = a.Pc.Ea.fontSize,
        c = a.PO.legend || [];
    0 < c.length && (a.Lg += c[0], a.Pc.wn(new gvjs_H(a.Lg - b, a.L.chartArea.right, a.Lg, a.L.chartArea.left)))
}

function gvjs_fga(a) {
    var b = a.PO.colorBar || [];
    0 < b.length && (a.Lg += b[0], b = new gvjs_H(a.Lg - a.Se.getHeight(), a.L.chartArea.right, a.Lg, a.L.chartArea.left), a.Se.wn(b))
}

function gvjs_fH(a, b) {
    function c(m) {
        m = b(m.text, d).width;
        return Math.ceil(Math.abs(m * f) + Math.abs(e * g))
    }
    var d = a.ec,
        e = d.fontSize,
        f = Math.sin(a.YM % Math.PI),
        g = Math.cos(a.YM % Math.PI),
        h = a.ap;
    h || (h = 2 > a.ticks.length ? 1 : Math.ceil((e + a.sl) / f / Math.abs(a.ticks[1].oa - a.ticks[0].oa)));
    for (var k = 0, l = 0; l < a.ticks.length; l += h) k = Math.max(c(a.ticks[l]), k);
    a = c({
        text: gvjs_uq
    });
    return {
        minHeight: Math.min(k, a),
        maxHeight: k,
        skip: h
    }
}

function gvjs_cga(a, b, c, d, e) {
    var f = gvjs_7G(0, a.ticks.length, e, a.IF);
    d = Math.floor((d - a.ec.fontSize * Math.cos(a.YM % Math.PI)) / Math.sin(a.YM % Math.PI));
    var g = [];
    for (c += a.lba; f < a.ticks.length; f += e) {
        var h = a.ticks[f],
            k = gvjs_rF(b, h.text, a.ec, d, 1),
            l = {
                text: h.text,
                textStyle: a.ec,
                lines: [],
                angle: -a.P8,
                Yb: 180 < a.P8 ? gvjs_l : gvjs_Y,
                Mb: gvjs_X,
                tooltip: k.tc ? h.text : "",
                anchor: new gvjs_vF(h.oa, c)
            };
        0 < k.lines.length && l.lines.push({
            x: 0,
            y: 0,
            length: d,
            text: k.lines[0]
        });
        g.push({
            Oa: h.Oa,
            isVisible: h.isVisible,
            optional: h.optional,
            ka: l
        })
    }
    return g
}
gvjs_.D0 = function() {
    var a = this;
    if (0 == this.index) {
        var b = this.L.Va,
            c = this.ec.fontSize,
            d = new gvjs_6G(this.L.width, this.ticks, this.kJ, this.maxTextLines, this.maxAlternation, this.ap, this.IF, this.minTextSpacing, this.allowContainerBoundaryTextCutoff, function(q, r, t) {
                return gvjs_rF(b, q, a.ec, r, t)
            }),
            e, f = this.k9;
        this.bh == gvjs_Kt && (e = gvjs_aH(d));
        var g = this.sl,
            h = Math.max(this.sl, Math.round(c / 3.236)),
            k = Math.max(this.sl, Math.round(c / 1.618));
        k = this.type == gvjs_o ? h : k;
        var l = Math.max(g, Math.round(c / 3.236));
        if (this.type ==
            gvjs_o)
            if ("high" === f) {
                var m = gvjs_l;
                var n = h
            } else m = gvjs_Y, n = -h;
        else m = gvjs_X, n = 0;
        f = [];
        f.push({
            key: gvjs_2v,
            min: g,
            extra: [Infinity]
        });
        if (e)
            for (h = 0; h < e.Hp; h++) f.push({
                key: gvjs_Rv,
                min: c + g,
                extra: [(0 == h ? k : l) - g]
            });
        var p = gvjs_sy(f, Math.floor(this.L.chartArea.height / 2)).ticks || [];
        if (0 < p.length) {
            for (c = 1; c < p.length; c++) p[c] += p[c - 1];
            d = gvjs_dH(d, e.TO, e.skip, p.length, .5);
            this.lb = gvjs_w(d.oN, function(q) {
                var r = q.layout.lines;
                r.reverse();
                r = gvjs_w(r, function(t, u) {
                    return {
                        x: 0,
                        y: -p[q.G5 + u],
                        length: q.width,
                        text: t
                    }
                }, a);
                return {
                    Oa: q.Oa,
                    isVisible: q.isVisible,
                    optional: q.optional,
                    ka: {
                        text: q.text,
                        textStyle: a.ec,
                        lines: r,
                        Yb: m,
                        Mb: gvjs_l,
                        tooltip: q.layout.tc ? q.text : "",
                        anchor: new gvjs_vF(n + q.oa, a.L.chartArea.bottom),
                        angle: 0
                    }
                }
            })
        }
    }
};
gvjs_.X_ = function() {
    function a(h, k) {
        var l = h[0].anchor;
        gvjs_v(h, function(m) {
            var n = m.anchor,
                p = n.x;
            n = n.y;
            var q = l.x,
                r = l.y,
                t = k;
            t = t * Math.PI / 180;
            p -= q;
            n -= r;
            var u = Math.sin(t);
            t = Math.cos(t);
            m.anchor = new gvjs_vF(t * p - u * n + q, u * p + t * n + r);
            m.angle = 0
        })
    }
    var b = this;
    if (this.bh == gvjs_e) return !0;
    var c = this.options.R(gvjs_Rv, null),
        d = null != c && Array.isArray(c);
    gvjs_Cf(this.lb, function(h, k) {
        return h.optional && !k.optional ? 1 : k.optional && !h.optional ? -1 : 0
    });
    c = gvjs_w(this.lb, function(h) {
        return gvjs_z(h.ka)
    });
    var e = 0 < c.length ? c[0].angle :
        0;
    e && (0 < e ? a(c, 360 - e) : a(c, -e));
    var f = [],
        g = [];
    return gvjs_sf(c, function(h, k) {
        function l(n) {
            return gvjs_Ky(m, n)
        }
        var m = gvjs_JD(h);
        if (!m) return !0;
        h = Math.round(h.textStyle.fontSize / 4);
        m.expand(new gvjs_H(0, h, 0, h));
        if (gvjs_8w(f, l)) return d || b.lb[k].optional ? (b.lb[k].isVisible = !1, !0) : !1;
        if (d || b.lb[k].optional) {
            if (gvjs_8w(g, l)) return b.lb[k].isVisible = !1, 0 === f.length;
            g.push(m)
        } else f.push(m);
        return !0
    })
};
gvjs_.LR = function() {
    var a = {};
    a.Je = -1 == this.direction;
    a.sn = this.L.chartArea.left;
    a.Rp = this.L.chartArea.right;
    a.orientation = this.Ig();
    return a
};
gvjs_.Ig = function() {
    return gvjs_R
};
gvjs_.F0 = function() {
    return 0 == this.index ? {
        oa: this.L.chartArea.bottom,
        direction: -1
    } : {
        oa: this.L.chartArea.top,
        direction: 1
    }
};

function gvjs_gH() {
    gvjs_qG.call(this);
    this.L1 = 0
}
gvjs_r(gvjs_gH, gvjs_qG);
gvjs_ = gvjs_gH.prototype;
gvjs_.PR = function() {
    return 0
};
gvjs_.init = function(a, b) {
    gvjs_qG.prototype.init.call(this, a, b);
    this.Za = null;
    this.e8 = gvjs_E(a, gvjs_ft, 1)
};
gvjs_.Wz = gvjs_p(96);
gvjs_.Xq = function() {
    var a = this.Ce;
    a = {
        pattern: a,
        fractionDigits: a ? null : this.L1,
        scaleFactor: this.e8,
        prefix: this.options.Ca(gvjs_et),
        suffix: this.options.Ca(gvjs_gt),
        significantDigits: this.options.Dy("formatOptions.significantDigits")
    };
    this.Za = new gvjs_Aj(a)
};
gvjs_.R = function(a, b) {
    return a.ha(b)
};
gvjs_.zG = function(a) {
    return Number(a)
};
gvjs_.gL = function(a) {
    return a
};
gvjs_.IR = function(a) {
    return a
};
gvjs_FG().rF.timeofday = function() {
    return new gvjs_GG
};
gvjs_FG().rF.date = function() {
    return new gvjs_vG(gvjs_Mfa, 3, gvjs_Nfa)
};
gvjs_FG().rF.datetime = function() {
    return new gvjs_vG(gvjs_Ofa, 3, gvjs_Pfa)
};
gvjs_FG().rF.number = function() {
    return new gvjs_gH
};

function gvjs_hH(a, b, c) {
    return new gvjs_Ij(Math.cos(a) * b, Math.sin(a) * c)
}

function gvjs_iH(a, b, c, d) {
    return new gvjs_0(Math.min(a, c), Math.min(b, d), Math.abs(c - a), Math.abs(d - b))
};

function gvjs_jH(a, b, c, d, e, f) {
    gvjs_IG.call(this, a, b, gvjs_vf(["vAxes." + d, gvjs_ie], c), d, e, f);
    this.type == gvjs_o && (this.direction = -this.direction);
    this.EL()
}
gvjs_r(gvjs_jH, gvjs_IG);
gvjs_ = gvjs_jH.prototype;
gvjs_.EL = function() {
    this.maxTextLines = gvjs_5i(this.options, "maxTextLines", 3)
};
gvjs_.m3 = function() {
    return "vAxis#" + this.index
};
gvjs_.xP = function(a, b) {
    var c = this.L.chartArea;
    return gvjs_OG(this, c.height, 1 == this.direction ? c.top : c.bottom, a, b)
};

function gvjs_kH(a) {
    var b = a.L.Va;
    return gvjs_qf(a.ticks, function(c, d) {
        return Math.max(c, b(d.text, this.ec).width)
    }, 0, a)
}

function gvjs_gga(a) {
    var b = a.L.Va,
        c = gvjs_kH(a);
    a = b(gvjs_uq, a.ec).width;
    return Math.min(a, c)
}
gvjs_.E0 = function() {
    var a = this,
        b = this.L.Va,
        c = this.ec.fontSize,
        d = this.title.textStyle.fontSize,
        e = this.L.axisTitlesPosition == gvjs_Nu ? this.title.text : "",
        f = gvjs_rF(b, e, this.title.textStyle, this.L.chartArea.height, Infinity),
        g = this.sl,
        h = gvjs_kH(this),
        k = gvjs_gga(this),
        l = [];
    this.bh == gvjs_Nu ? l.push({
        key: gvjs_8u,
        min: g,
        extra: [c - g]
    }) : l.push({
        key: gvjs_8u,
        min: 0,
        extra: [Infinity]
    });
    0 < f.lines.length && l.push({
        key: gvjs_ce,
        min: d + g,
        extra: [Infinity]
    });
    this.bh == gvjs_Nu && l.push({
        key: gvjs_Rv,
        min: k + g,
        max: h + g,
        extra: [Infinity]
    });
    for (c = 1; c < f.lines.length; c++) l.push({
        key: gvjs_ce,
        min: d + g,
        extra: [this.h3 - g]
    });
    d = this.L.chartArea;
    l = gvjs_sy(l, 0 == this.index ? d.left : this.L.width - d.right);
    var m = 0 == this.index ? 0 : this.L.width;
    f = l.title || [];
    if (0 < f.length)
        for (b = gvjs_rF(b, e, this.title.textStyle, d.height, f.length), 1 === this.index && b.lines.reverse(), this.title.tooltip = b.tc ? e : "", this.title.lines = [], e = 0; e < f.length; e++) m += f[e] * (0 == this.index ? 1 : -1), this.title.angle = -90, this.title.Mb = 0 == this.index ? gvjs_Y : gvjs_l, this.title.lines.push({
            x: m,
            y: d.top +
                d.height / 2,
            length: d.height,
            text: b.lines[e]
        });
    if (this.bh == gvjs_Nu) {
        e = l.ticks[0] || 0;
        m += e * (0 == this.index ? 1 : -1);
        var n = Math.min(h, e - g);
        this.lb = n < k ? [] : gvjs_w(this.ticks, function(p, q) {
            var r = 0 == a.index ? gvjs_Y : gvjs_l,
                t = gvjs_X;
            "bound" == a.qma && (0 == q && (t = 1 == a.direction ? gvjs_l : gvjs_Y), q == a.ticks.length - 1 && (t = 1 == a.direction ? gvjs_Y : gvjs_l));
            return gvjs_lH(a, p, m, n, r, t, 0)
        })
    }
};
gvjs_.X_ = function() {
    var a = this;
    if (this.bh == gvjs_e) return !0;
    var b = gvjs_w(this.lb, function(g) {
            return g.ka
        }),
        c = this.options.R(gvjs_Rv, null),
        d = null != c && Array.isArray(c),
        e = [],
        f = [];
    return gvjs_sf(b, function(g, h) {
        var k = gvjs_JD(g),
            l = g.textStyle.fontSize / 8;
        if (!k) return !0;
        if (gvjs_8w(e, function(m) {
                return gvjs_Ly(k, m, l)
            })) return d || a.lb[h].optional ? (a.lb[h].isVisible = !1, !0) : !1;
        if (d || a.lb[h].optional) {
            if (gvjs_8w(f, function(m) {
                    return gvjs_Ly(k, m, l)
                })) return a.lb[h].isVisible = !1, 0 === e.length;
            f.push(k)
        } else e.push(k);
        return !0
    })
};
gvjs_.D0 = function() {
    var a = this.L.Va,
        b = this.ec.fontSize,
        c = this.sl,
        d = Math.max(this.sl, Math.round(b / 3.236));
    b = Math.max(this.sl, Math.round(b / 1.618));
    b = this.type == gvjs_o ? d : b;
    if (this.type == gvjs_o)
        if ("high" == this.k9) {
            var e = gvjs_Y;
            var f = d
        } else e = gvjs_l, f = -d;
    else e = gvjs_X, f = 0;
    d = gvjs_qf(this.ticks, function(m, n) {
        return Math.max(m, a(n.text, this.ec).width)
    }, 0, this);
    var g = a(gvjs_uq, this.ec).width;
    g = Math.min(g, d);
    var h = [];
    h.push({
        key: gvjs_8u,
        min: c,
        extra: [Infinity]
    });
    this.bh == gvjs_Kt && h.push({
        key: gvjs_Rv,
        min: g + c,
        max: d + b,
        extra: []
    });
    b = gvjs_sy(h, this.L.chartArea.width);
    var k = 0 == this.index ? this.L.chartArea.left : this.L.chartArea.right;
    if (this.bh == gvjs_Kt) {
        b = b.ticks[0] || 0;
        var l = Math.min(d, b - c);
        k += (b - l) * (0 == this.index ? 1 : -1);
        this.lb = gvjs_w(this.ticks, function(m) {
            return gvjs_lH(this, m, k, l, 0 == this.index ? gvjs_l : gvjs_Y, e, f)
        }, this)
    }
};

function gvjs_lH(a, b, c, d, e, f, g) {
    var h = gvjs_rF(a.L.Va, b.text, a.ec, d, a.maxTextLines),
        k = a.ec.fontSize,
        l = Math.max(2, Math.round(k / 3.236)),
        m = h.lines.length,
        n = gvjs_w(h.lines, function(p, q) {
            return {
                x: 0,
                y: (k + l) * (q - (m - 1) / 2),
                length: d,
                text: p
            }
        });
    return {
        Oa: b.Oa,
        isVisible: b.isVisible,
        optional: b.optional,
        text: b.text,
        ka: {
            text: b.text,
            textStyle: a.ec,
            boxStyle: null,
            lines: n,
            Yb: e,
            Mb: f,
            tooltip: h.tc ? b.text : "",
            anchor: new gvjs_vF(c, b.oa - g),
            angle: 0
        }
    }
}
gvjs_.LR = function() {
    var a = {};
    a.Je = -1 == this.direction;
    a.sn = this.L.chartArea.top;
    a.Rp = this.L.chartArea.bottom;
    a.orientation = this.Ig();
    return a
};
gvjs_.Ig = function() {
    return gvjs_S
};
gvjs_.F0 = function() {
    return 0 == this.index ? {
        oa: this.L.chartArea.left,
        direction: 1
    } : {
        oa: this.L.chartArea.right,
        direction: -1
    }
};

function gvjs_mH(a) {
    this.Za = a = void 0 === a ? String : a;
    this.Fz = gvjs_hga()
}

function gvjs_hga() {
    var a = new Map;
    a.set(gvjs_f, function(b, c) {
        return c.Za(b.value)
    });
    a.set("identifier", function(b) {
        return b.name
    });
    a.set("+", function() {
        return " + "
    });
    a.set("-", function() {
        return gvjs_1p
    });
    a.set("--", function() {
        return "-"
    });
    a.set("=", function() {
        return " = "
    });
    a.set("*", function() {
        return " * "
    });
    a.set("(", function() {
        return "("
    });
    a.set(")", function() {
        return ")"
    });
    a.set(",", function() {
        return gvjs_ja
    });
    a.set("^", function() {
        return "^"
    });
    return a
}
gvjs_mH.prototype.K = function(a) {
    var b = this;
    return a.map(function(c) {
        return b.Fz.get(c.Lm())(c, b)
    }, this).join("")
};

function gvjs_nH(a) {
    a = gvjs_pf(a.split("}"), function(g) {
        return null != g && "" !== gvjs_2e(g)
    });
    for (var b = {}, c = {}, d = 0; d < a.length; c = {
            PG: c.PG
        }, d++) {
        var e = a[d].split("{"),
            f = gvjs_w(e[0].split(","), gvjs_2e);
        c.PG = gvjs_8y(gvjs_2e(e[1]));
        0 === f.length ? Object.assign(b, c.PG) : gvjs_v(f, function(g) {
            return function(h) {
                b[h] = b[h] || {};
                Object.assign(b[h], g.PG)
            }
        }(c))
    }
    return b
}
var gvjs_iga = [{
    input: gvjs_Sb,
    te: [gvjs_Vs, gvjs_Gv]
}, {
    input: gvjs_Ju,
    te: [gvjs_Ws, gvjs_Hv]
}, {
    input: gvjs_Xs,
    te: [gvjs_Vs]
}, {
    input: gvjs_Ys,
    te: [gvjs_Ws]
}, {
    input: gvjs_Jv,
    te: [gvjs_Gv]
}, {
    input: gvjs_Kv,
    te: [gvjs_Hv]
}, {
    input: gvjs_Bp,
    te: [gvjs_Iv]
}];

function gvjs_oH(a, b) {
    var c = {
        fill: {},
        stroke: {}
    };
    a = new gvjs_Si([a]);
    for (var d = 0; d < b.length; d++) {
        var e = b[d],
            f = e.te;
        e = a.R(e.input);
        if (null != e)
            for (var g = 0; g < f.length; g++) gvjs_t(f[g], e, c)
    }
    return c
}

function gvjs_jga(a) {
    return gvjs_oH(a, gvjs_iga)
}

function gvjs_pH(a, b) {
    b = void 0 === b ? gvjs_jga : b;
    if (null == a) return {};
    a = gvjs_2e(a);
    if (gvjs_Xx(a)) var c = b({
        color: a
    });
    else if ("{" === a.charAt(0)) try {
        var d = gvjs_Eg(a);
        null != d && (c = d)
    } catch (e) {}
    null == c && (gvjs_4e(a, "{") ? (c = gvjs_tx(gvjs_nH(a), b), gvjs_vx(c, "") && (Object.assign(c, c[""]), gvjs_xx(c, "")), gvjs_vx(c, "*") && (Object.assign(c, c["*"]), gvjs_xx(c, "*"))) : c = b(gvjs_8y(a)));
    return c
};

function gvjs_qH(a) {
    this.x = a.x || 0;
    this.y = a.y || 0;
    this.length = a.length;
    this.text = a.text
};

function gvjs_rH(a) {
    this.text = a.text;
    this.textStyle = a.textStyle;
    this.boxStyle = a.boxStyle;
    this.lines = a.lines;
    this.Yb = a.Yb;
    this.Mb = a.Mb;
    this.tooltip = void 0 !== a.tooltip ? a.tooltip : "";
    this.hc = a.hc;
    this.angle = null != a.angle ? a.angle : 0;
    this.anchor = void 0 !== a.anchor ? a.anchor : null;
    this.Is = !!a.Is
}
gvjs_rH.prototype.yP = gvjs_p(98);

function gvjs_sH(a, b, c, d, e) {
    gvjs_5G.call(this, a, b, c, d, e);
    this.qo = this.yW = this.lN = this.Lc = this.Ub = this.Mc = this.Yd = this.wc = null;
    this.jv = 1;
    this.JH = this.CC = null;
    this.Rn = !1
}
gvjs_r(gvjs_sH, gvjs_5G);
gvjs_ = gvjs_sH.prototype;
gvjs_.Lu = function() {
    return this.Kha
};
gvjs_.Cu = function() {
    var a = this,
        b;
    return [function() {
        var c = a.options;
        b = a.L;
        b.Xb = gvjs_D(c, "isDiff");
        b.Xb || b.chartType !== gvjs_j || (b.chartType = gvjs_c, gvjs_Ep(c, 1, {
            pointSize: 7,
            trendlines: {
                pointsVisible: !1,
                lineWidth: 2
            },
            lineWidth: 0,
            orientation: gvjs_R,
            domainAxis: {
                viewWindowMode: gvjs__u
            }
        }));
        var d = c.Ca(gvjs__v, gvjs_TA);
        a.Kha = d != gvjs_e;
        d = b;
        var e = Set;
        var f = gvjs_Xi(c, gvjs__i, [], gvjs_2s, [gvjs_vp], gvjs_vea);
        d.focusTarget = new e(f);
        if (b.focusTarget.has(gvjs_3r) && b.chartType != gvjs_c) throw Error("Focus target category is not supported for the chosen chart type, " +
            b.chartType);
        b.chartType == gvjs_Wr ? a.qo = new gvjs_3G(a.Ia, a.options, a.Va, b) : (a.wc = c.R(gvjs_ls, gvjs_IE), gvjs_tH(a));
        c = 0 < b.Df.bars || 0 < b.Df.area || 0 < b.Df.steppedArea;
        d = a.options.Ca(gvjs_St, gvjs_Sea);
        null == d && (d = gvjs_D(a.options, gvjs_St) ? gvjs_xb : gvjs_e);
        b.Jl = c && d || gvjs_e;
        b.C8 = gvjs_D(a.options, "showRemoveSeriesButton", !1)
    }, this.rca.bind(this), this.s7.bind(this), function() {
        b.chartType === gvjs_Bt && gvjs_tH(a)
    }, this.fha.bind(this), gvjs_5G.prototype.Cu.bind(this)]
};

function gvjs_tH(a) {
    var b = a.L,
        c = a.Ia,
        d = b.chartType == gvjs_j ? function() {
            return gvjs_j
        } : b.chartType === gvjs_Bt ? function() {
            return gvjs_Hr
        } : function(l) {
            return gvjs_C(a.options, gvjs_mv + l + ".type", b.wC, gvjs_NA)
        };
    d = b.Xb ? gvjs_kga(c, d, b.chartType) : gvjs_lga(c, d);
    a.JH = d.p0;
    b.Fa = [];
    b.Go = {};
    for (var e = d.di, f = {
            Un: 0
        }; f.Un < c.getNumberOfRows(); f = {
            Un: f.Un
        }, f.Un++) {
        var g = c.getTableRowIndex(f.Un),
            h = c.getValue(f.Un, 0),
            k = e.map(function(l) {
                return function(m) {
                    return c.getFormattedValue(l.Un, m.columns.domain[0]) || ""
                }
            }(f));
        h = {
            data: h,
            Ds: k,
            Fo: g
        };
        if (k = e[0].columns.tooltip) h.hc = gvjs_uH(a, k[0], f.Un);
        b.Fa.push(h);
        b.Go[g] = f.Un
    }
    b.series = [];
    for (e = 0; e < d.HV.length; e++) f = gvjs_mga(a, e, d.HV[e]), b.series.push(f), gvjs_wx(c.getColumnProperties(e)) || (b.series[e].properties = c.getColumnProperties(e));
    b.wm = d.b1;
    b.di = d.di;
    b.dr = d.dr;
    b.XF = {};
    b.Df = {};
    a.lN = new Set;
    a.yW = [];
    for (d = 0; d < b.series.length; ++d) {
        e = b.series[d];
        a.lN.add(e.targetAxisIndex);
        f = b.XF[e.targetAxisIndex];
        if (null == f) b.XF[e.targetAxisIndex] = e.dataType;
        else if (f != e.dataType) throw Error("All series on a given axis must be of the same data type");
        b.Df[e.type] = (b.Df[e.type] || 0) + 1;
        f = a.yW[e.targetAxisIndex] || {};
        a.yW[e.targetAxisIndex] = f;
        f[e.type] = (f[e.type] || 0) + 1
    }
}

function gvjs_nga(a) {
    function b(e) {
        var f = d.series[e];
        if (d.Xb && f.type === gvjs_j) {
            var g = [a.options.R(gvjs_Bs, .5), a.options.R(gvjs_As, 1)],
                h = f.color.color;
            d.pl.push({
                id: f.id,
                text: f.labelInLegend,
                brush: new gvjs__({
                    gradient: {
                        color1: h,
                        color2: h,
                        ik: g[0],
                        jk: g[1],
                        x1: gvjs_yq,
                        y1: gvjs_wq,
                        x2: gvjs_wq,
                        y2: gvjs_wq,
                        useObjectBoundingBoxUnits: !0,
                        Hl: !0
                    }
                }),
                index: e,
                isVisible: f.visibleInLegend
            })
        } else g = new gvjs__({
            fill: f.color.color
        }), f.cC ? g.Qd(f.cC) : f.jo && g.Qd(f.jo.fillOpacity), d.pl.push({
            id: f.id,
            text: f.labelInLegend,
            brush: g,
            index: e,
            isVisible: f.visibleInLegend
        });
        c[e] = !0
    }
    var c = {},
        d = a.L;
    d.pl = [];
    d.series.forEach(function(e, f) {
        c[f] || (b(f), null != e.mG && b(e.mG))
    }, a);
    d.Xb && d.series[0].type === gvjs_Hr && d.pl.push({
        id: -1,
        text: "Previous data",
        brush: new gvjs__({
            fill: gvjs_JE.color
        }),
        index: -1,
        isVisible: !0
    })
}

function gvjs_oga(a, b) {
    function c(K) {
        return K = 864E5 * K + e
    }

    function d(K) {
        K -= e;
        return K / 864E5
    }
    for (var e = (new Date(1900, 0, 1, 0, 0, 0)).getTime(), f = new gvjs_ij("0.###E0"), g = new gvjs_ij("#.###"), h = new gvjs_mH(function(K) {
            return 0 !== K && (1E5 < Math.abs(K) || .01 > Math.abs(K)) ? f.format(K) : g.format(K)
        }), k = a.L, l = 0, m = k.orientation === gvjs_S, n = k.series.length, p = {
            wq: 0
        }; p.wq < n; p = {
            wq: p.wq,
            vq: p.vq,
            RA: p.RA,
            Ts: p.Ts,
            SG: p.SG,
            IG: p.IG
        }, p.wq++) {
        var q = k.series[p.wq],
            r = function(K) {
                return function(N, Q) {
                    return [gvjs_4v + K.wq + "." + N, gvjs_4v +
                        N
                    ].concat(Q || [])
                }
            }(p);
        if (null != a.options.R(gvjs_4v + p.wq)) {
            l++;
            var t = gvjs_C(a.options, r(gvjs_ge), gvjs_8t, gvjs_8ea),
                u = a.options.R(r(gvjs_Sb), "<default>"),
                v = "<default>" === u;
            v && (u = q.df.fill);
            v = gvjs_Lw(a.options, r(gvjs_Ju, [gvjs_vs]), v ? .5 : 1);
            var w = gvjs_5i(a.options, r(gvjs_Tu, [gvjs_Tu]), 0),
                x = gvjs_D(a.options, r(gvjs_Wu, [gvjs_Wu]), 0 < w);
            0 >= w && (w = 6);
            w /= 2;
            0 < w && (w += 1);
            var y = {};
            null != q.columns.data && (y.data = q.columns.data);
            var z = gvjs_5i(a.options, r(gvjs_7t, [gvjs_7t]), 2),
                A = gvjs_C(a.options, r(gvjs_rs), gvjs_e, gvjs_VA),
                B = gvjs_D(a.options, r(gvjs_iw), !1);
            u = gvjs_ZD(u);
            t = gvjs_HE[t];
            var D = (m ? a.Mc : a.Yd)[0],
                F = (m ? a.Yd : a.Mc)[q.targetAxisIndex];
            if (D.type === gvjs_o) {
                p.vq = D.ga;
                p.SG = F.ga;
                D = b.getColumnLabel(0);
                p.IG = q.columns.data[0];
                p.Ts = gvjs_pw;
                p.RA = gvjs_pw;
                F = null;
                0 < b.getNumberOfRows() && gvjs_Oe(b.getValue(0, 0)) ? (p.Ts = d, p.RA = c) : F = {
                    transform: function(K) {
                        return function(N) {
                            return gvjs_uG(K.vq, K.RA(N))
                        }
                    }(p),
                    inverse: function(K) {
                        return function(N) {
                            return K.Ts(K.vq.lv.inverse(N))
                        }
                    }(p)
                };
                var G = {
                    min: p.Ts(p.vq.hk),
                    max: p.Ts(p.vq.gk)
                };
                t =
                    t(b.getNumberOfRows(), function(K) {
                        return function(N) {
                            N = b.getValue(N, 0);
                            N = K.vq.Db(N);
                            return K.Ts(N)
                        }
                    }(p), function(K) {
                        return function(N) {
                            return K.SG.Db(b.getValue(N, K.IG))
                        }
                    }(p), {
                        range: G,
                        er: F,
                        degree: gvjs_E(a.options, r("degree"), 3)
                    });
                if (null !== t) {
                    F = gvjs_C(a.options, r(gvjs_qd), b.getColumnLabel(p.IG));
                    D = t.KK ? t.KK(D, F).nj() : t.lr;
                    D = h.K(D.Dj()) || "Trendline " + l;
                    D = gvjs_C(a.options, r(gvjs_ce), D);
                    F = t.data.map(function(K) {
                        return function(N) {
                            var Q = K.RA(N[0]);
                            return [K.vq.en(Q), K.SG.en(N[1])]
                        }
                    }(p));
                    q.mG = k.series.length;
                    G = gvjs_dy(u.color, z);
                    gvjs_yw(G, v);
                    var H = gvjs_cy(u.color);
                    H.Qd(v);
                    var I = gvjs_C(a.options, r(gvjs_Xt), D);
                    gvjs_D(a.options, r("showR2"), !1) && (I += "\n" + h.K((new gvjs_qE([new gvjs_uE([new gvjs_wE("r"), new gvjs_iE(2)]), new gvjs_iE(t.r2)])).Dj()));
                    t = !1 !== a.options.R(r(gvjs_de));
                    var P = a.options.R(r(gvjs_yp), {
                        type: gvjs_es
                    });
                    q = {
                        id: q.id + "_trendline",
                        title: D,
                        Fe: !0,
                        data: F,
                        dataType: q.dataType,
                        enableInteractivity: gvjs_D(a.options, r(gvjs_Ms, [gvjs_Ms]), !0),
                        showTooltip: t,
                        isVisible: !0,
                        Fo: 0,
                        columns: y,
                        e7: p.wq,
                        sd: q.sd,
                        intervals: null,
                        color: u,
                        cC: v,
                        df: H,
                        Lb: G,
                        jo: null,
                        candlestick: null,
                        type: gvjs_d,
                        HG: gvjs_E(a.options, r("zOrder"), 0),
                        lineWidth: z,
                        pointRadius: w,
                        pointShape: P,
                        p7: 12,
                        curveType: A,
                        ZM: gvjs_5i(a.options, r(gvjs_sv, [gvjs_sv]), 1),
                        CG: x,
                        points: [],
                        gQ: [],
                        targetAxisIndex: q.targetAxisIndex,
                        visibleInLegend: B,
                        labelInLegend: I
                    };
                    k.series.push(q)
                }
            }
        }
    }
}

function gvjs_lga(a, b) {
    for (var c = [], d = [], e = null, f = null, g = 0, h = [], k = new Set, l = a.getNumberOfColumns(), m = !1, n, p = 0; p < l; ++p) {
        var q = a.getColumnType(p),
            r = a.getColumnProperty(p, gvjs_Vd) || (0 == p ? gvjs_Gs : gvjs_ts);
        if (0 == p && r !== gvjs_Gs) throw Error('First column has role "' + r + '", but must be "domain".');
        if (r == gvjs_Gs) {
            if (m || 0 < g) throw Error(gvjs_0q + p + ")");
            m = !0;
            e = {
                columns: {},
                dataType: q
            };
            f = {
                yb: null,
                sd: d.length
            };
            d.push(e)
        } else if (r === gvjs_ts) {
            0 === g && (f = c.length, n = b(f), e = {
                    type: n,
                    dataType: q,
                    columns: {}
                }, f = {
                    yb: f,
                    sd: null
                },
                c.push(e), g = n === gvjs_2r ? 4 : 1);
            g--;
            if (q !== e.dataType) throw Error(gvjs_Hq + p + gvjs_5p + q + gvjs_2p + e.dataType);
            n !== gvjs_Hr && n !== gvjs_2r || k.add(p)
        } else if (r === gvjs_de && e.columns[r]) throw Error("Only one column with role 'tooltip' per series is allowed");
        r !== gvjs_Gs && (m = !1);
        e.columns[r] = e.columns[r] || [];
        h.push({
            yb: f.yb,
            sd: f.sd,
            role: r,
            Hz: e.columns[r].length
        });
        e.columns[r].push(p)
    }
    if (0 < g) throw Error(gvjs_Tq + g + ")");
    a = 0;
    b = d[0].dataType;
    for (e = 0; e < c.length; ++e) {
        if (d.length <= a) throw Error("Series #" + e + gvjs_4p);
        l =
            d[a + 1];
        m = c[e].columns.data;
        if (l && l.columns.domain[0] <= m[0] && (++a, b !== d[a].dataType)) throw Error(gvjs_Iq);
        c[e].sd = a
    }
    return {
        HV: c,
        di: d,
        dr: b,
        b1: h,
        p0: k
    }
}

function gvjs_vH(a, b) {
    if (a !== b) throw Error("Column types must be consistent: equal for domain columns and for columns in the same serie.");
}

function gvjs_kga(a, b, c) {
    var d = [],
        e = [],
        f = null,
        g = [],
        h = new Set;
    if (c === gvjs_j) {
        c = a.getNumberOfColumns() - 2;
        var k = function(t) {
                if (t !== gvjs_ts && t !== gvjs_Eu) throw Error("All columns must be either data or old-data columns");
            },
            l = {
                data: null,
                "old-data": null
            };
        f = a.getColumnType(0);
        for (var m = 0; 2 > m; ++m) {
            var n = a.getColumnType(m),
                p = a.getColumnProperty(m, gvjs_Vd);
            k(p);
            gvjs_vH(f, n);
            n = {
                columns: {},
                dataType: n
            };
            n.columns.domain = [m];
            e.push(n);
            l[p] = m;
            g.push({
                sd: m,
                role: gvjs_Gs,
                Hz: 0,
                yb: null
            })
        }
        for (m = 0; m < c; ++m) {
            p = 2 + m;
            var q = a.getColumnType(m);
            n = a.getColumnProperty(m, gvjs_Vd);
            k(n);
            m % 2 && gvjs_vH(d[m - 1].dataType, q);
            var r = l[n];
            q = {
                type: b(m),
                dataType: q,
                sd: r,
                columns: {}
            };
            q.columns[n] = [p];
            d.push(q);
            g.push({
                sd: r,
                role: n,
                Hz: 0,
                yb: m
            })
        }
    } else if (c === gvjs_c) {
        n = f = null;
        r = 0;
        c = a.getNumberOfColumns();
        for (k = 0; k < c; ++k) {
            l = a.getColumnType(k);
            m = a.getColumnProperty(k, gvjs_Vd) || (0 === k ? gvjs_Gs : gvjs_ts);
            if (0 === k && m !== gvjs_Gs) throw Error("First column must be a domain column");
            if (m === gvjs_Gs) {
                if (0 < r) throw Error(gvjs_0q + k + ")");
                f = {
                    columns: {},
                    dataType: l
                };
                n = {
                    yb: null,
                    sd: e.length
                };
                e.push(f)
            }
            0 !== r || m !== gvjs_ts && m !== gvjs_Eu || (n = d.length, p = b(n), f = {
                type: p,
                dataType: l,
                columns: {}
            }, n = {
                yb: n,
                sd: null
            }, d.push(f), r = p === gvjs_2r ? 4 : m === gvjs_Eu ? 2 : 1, p !== gvjs_Hr && p !== gvjs_2r || h.add(k));
            if (m === gvjs_ts || m === gvjs_Eu)
                if (r--, l !== f.dataType) throw Error(gvjs_Hq + k + gvjs_5p + l + gvjs_2p + f.dataType);
            if (m === gvjs_de && f.columns[m]) throw Error("Only one data column with role 'tooltip' per series is allowed");
            f.columns[m] = f.columns[m] || [];
            g.push({
                yb: n.yb,
                sd: n.sd,
                role: m,
                Hz: f.columns[m].length
            });
            f.columns[m].push(k)
        }
        if (0 <
            r) throw Error(gvjs_Tq + r + ")");
        a = 0;
        f = e[0].dataType;
        for (b = 0; b < d.length; ++b) {
            if (e.length <= a) throw Error("Series #" + b + gvjs_4p);
            c = e[a + 1];
            k = d[b].columns[gvjs_Eu] || d[b].columns.data;
            if (c && c.columns.domain[0] <= k[0] && (++a, f !== e[a].dataType)) throw Error(gvjs_Iq);
            d[b].sd = a
        }
    }
    return {
        HV: d,
        di: e,
        dr: f,
        b1: g,
        p0: h
    }
}
gvjs_.yF = function(a) {
    a = a.columns[gvjs_Eu];
    return null != a && 0 < a.length
};

function gvjs_mga(a, b, c) {
    var d = c.type,
        e = c.columns,
        f = c.sd,
        g = a.options,
        h = gvjs_mv + b + ".",
        k = d + ".",
        l = e.data || e[gvjs_Eu],
        m = a.Ia.getColumnIndex(l[0]),
        n = a.Ia.getColumnLabel(l[0]) || "",
        p = d == gvjs_j ? 0 : 2,
        q = gvjs_5i(g, [h + gvjs_Tu, gvjs_Tu], d == gvjs_j ? 7 : 0);
    var r = gvjs_D(g, [h + gvjs_Wu, gvjs_Wu], d == gvjs_d || d == gvjs_Ar || d == gvjs_j ? 0 < q : !0);
    0 == q && (q = d == gvjs_j ? 7 : 6);
    q /= 2;
    0 < q && (q += 1);
    b = g.R(h + gvjs_Sb, a.wc[(a.L.Xb && d == gvjs_j ? Math.floor(b / 2) : b) % a.wc.length]);
    b = gvjs_ZD(b);
    var t = null;
    if (d == gvjs_Ar || d == gvjs_xv) t = gvjs_Lw(g, [h + gvjs_Br, gvjs_Br]),
        t = gvjs_cy(b.color, t);
    var u = null;
    if (d == gvjs_2r) {
        u = new gvjs__({
            stroke: b.color,
            strokeWidth: 2,
            fill: b.color
        });
        var v = new gvjs__({
                stroke: b.color,
                strokeWidth: 2,
                fill: gvjs_lq
            }),
            w = gvjs_D(g, "candlestick.hollowIsRising"),
            x = w ? u : v;
        u = {
            W7: gvjs_Ow(g, [h + gvjs_1r, gvjs_1r], w ? v : u),
            L2: gvjs_Ow(g, [h + gvjs_0r, gvjs_0r], x)
        }
    }
    p = gvjs_5i(g, [h + gvjs_7t, gvjs_7t], p);
    v = gvjs_dy(b.color, p);
    (w = g.LD([h + "lineDashStyle", "lineDashStyle"])) && null != w && (v.tg = w);
    k = gvjs_5i(g, [h + gvjs_vs, k + gvjs_vs, gvjs_vs], 1);
    w = null;
    if (d === gvjs_j || d === gvjs_d || d === gvjs_Ar) w =
        g.R([h + gvjs_yp, gvjs_yp], {
            type: gvjs_es
        }), typeof w === gvjs_m && (w = {
            type: w
        });
    x = null;
    if (a.L.Xb && d === gvjs_j) {
        var y = a.yF(c);
        k = y ? a.options.R(gvjs_Bs, .5) : a.options.R(gvjs_As, 1);
        y && (x = !1)
    }
    y = d == gvjs_xv ? t : gvjs_cy(b.color, k);
    if (a.L.Xb)
        if (d === gvjs_Hr) {
            var z = g.R("diff.oldData.color", gvjs_JE);
            z = gvjs_ZD(z);
            z = {
                background: {
                    df: gvjs_cy(z.color, k)
                }
            }
        } else d === gvjs_j && a.yF(c) && (r = !1);
    else d === gvjs_j && (d = gvjs_d);
    var A = gvjs_pga(a, e, g, h, b),
        B = !1 !== a.options.R(h + gvjs_de);
    return {
        id: a.Ia.getColumnId(l[0]),
        title: n,
        dataType: c.dataType,
        isVisible: !0,
        showTooltip: B,
        Fo: m,
        columns: e,
        sd: f,
        enableInteractivity: gvjs_D(g, [h + gvjs_Ms, gvjs_Ms], !0),
        intervals: A,
        color: b,
        cC: k,
        df: y,
        Lb: v,
        jo: t,
        pointShape: w,
        Uk: z,
        candlestick: u,
        type: d,
        HG: gvjs_E(g, h + "zOrder", 0),
        lineWidth: p,
        pointRadius: q,
        p7: 12,
        curveType: gvjs_C(g, [h + gvjs_rs, gvjs_rs], gvjs_e, gvjs_VA),
        ZM: gvjs_5i(g, [h + gvjs_sv, gvjs_sv], 1),
        CG: r,
        points: [],
        gQ: [],
        targetAxisIndex: gvjs_5i(g, [h + gvjs_Mv, gvjs_Mv], 0),
        visibleInLegend: null != x ? x : gvjs_D(g, h + gvjs_iw, !0),
        labelInLegend: gvjs_C(g, h + gvjs_Xt, n)
    }
}

function gvjs_pga(a, b, c, d, e) {
    function f(v, w) {
        return g(v, w).concat([d + w, w])
    }

    function g(v, w) {
        return [d + "interval." + v + "." + w, d + "intervals." + w, "interval." + v + "." + w, "intervals." + w]
    }
    var h = b.interval;
    if (!h) return null;
    b = {
        Xa: [],
        Tv: [],
        OH: [],
        points: [],
        areas: [],
        lines: [],
        eq: {}
    };
    for (var k = {}, l = 0; l < h.length; l++) {
        var m = h[l],
            n = a.Ia.getColumnId(m) || a.Ia.getColumnLabel(m) || gvjs_xs,
            p = c.Ca(g(n, gvjs_6d), gvjs_OA);
        switch (p) {
            case gvjs_Hr:
                b.Xa.push(m);
                a.JH.add(m);
                break;
            case "sticks":
                b.Tv.push(m);
                break;
            case "boxes":
                b.OH.push(m);
                a.JH.add(m);
                break;
            case gvjs_Vu:
                b.points.push(m);
                break;
            case gvjs_Ar:
                b.areas.push(m);
                break;
            case gvjs_d:
                b.lines.push(m);
                break;
            case gvjs_e:
                break;
            default:
                throw Error("Invalid interval style: " + p);
        }
        n in k ? k[n].push(m) : k[n] = [m]
    }
    1 < b.Xa.length && 0 == b.Tv.length && (b.Tv = [b.Xa[0], b.Xa[b.Xa.length - 1]]);
    if (0 != b.Tv.length % 2) throw Error("Stick-intervals must be defined by an even number of columns");
    if (0 != b.areas.length % 2) throw Error("Area-intervals must be defined by an even number of columns");
    for (var q in k) {
        a =
            gvjs_5i(c, g(q, gvjs_7t));
        h = gvjs_Lw(c, g(q, gvjs_Ys));
        l = gvjs_Mw(c, g(q, gvjs_Sb), "", gvjs_Sg(gvjs_PA));
        l = gvjs_VF(l, e);
        a = new gvjs__({
            stroke: l,
            strokeWidth: a,
            fill: l,
            fillOpacity: h
        });
        h = gvjs_5i(c, g(q, "barWidth"));
        l = gvjs_5i(c, g(q, "shortBarWidth"));
        m = gvjs_5i(c, g(q, "boxWidth"));
        n = gvjs_5i(c, g(q, gvjs_Tu));
        p = c.Ca(g(q, gvjs_6d), gvjs_OA);
        var r = gvjs_D(c, f(q, gvjs_Qt)),
            t = gvjs_C(c, f(q, gvjs_rs), gvjs_e, gvjs_VA),
            u = gvjs_5i(c, f(q, gvjs_sv), 1);
        a = {
            style: p,
            brush: a,
            barWidth: h,
            sla: l,
            boxWidth: m,
            pointSize: n,
            interpolateNulls: r,
            curveType: t,
            ZM: u
        };
        h = k[q];
        for (l = 0; l < h.length; ++l) b.eq[h[l]] = a
    }
    return b
}
gvjs_.rca = function() {
    var a = this.L;
    switch (a.chartType) {
        case gvjs_c:
        case gvjs_Bt:
            a.orientation = gvjs_C(this.options, gvjs_Lu, "", gvjs_QA);
            if (!a.orientation) throw Error("Unspecified orientation.");
            this.Lc = {};
            this.Yd = {};
            this.Mc = {};
            switch (a.orientation) {
                case gvjs_R:
                    var b = gvjs_eH;
                    var c = this.Yd;
                    var d = gvjs_jH;
                    var e = this.Mc;
                    break;
                case gvjs_S:
                    b = gvjs_jH, c = this.Mc, d = gvjs_eH, e = this.Yd
            }
            for (var f = null == this.lN ? [] : gvjs_Cg(this.lN), g = 0; g < f.length; ++g) {
                var h = f[g],
                    k = new d(a, this.options, ["targetAxes." + h, gvjs_$d], h, gvjs_o,
                        gvjs__u);
                if (k.type != gvjs_o) throw Error("Target-axis must be of type value");
                this.Lc[h] = k;
                e[h] = k
            }
            d = b;
            e = this.options;
            if (this.Ia.getColumnType(0) == gvjs_m) b: {
                switch (gvjs_qga(this)) {
                    case gvjs_Ar:
                        b = 1 < this.L.Fa.length ? gvjs_4r : gvjs_3r;
                        break b;
                    case gvjs_d:
                    case gvjs_j:
                    case gvjs_Hr:
                    case gvjs_xv:
                    case gvjs_2r:
                        b = gvjs_3r;
                        break b
                }
                b = null
            }
            else b = gvjs_o;
            this.Ub = new d(a, e, [gvjs_6b], 0, b, gvjs_gu);
            c[0] = this.Ub;
            break;
        case gvjs_j:
        case gvjs_Wr:
            this.Yd = {
                0: new gvjs_eH(a, this.options, [], 0, gvjs_o, gvjs__u)
            }, this.Mc = {
                0: new gvjs_jH(a,
                    this.options, [], 0, gvjs_o, gvjs__u)
            }, a.orientation === gvjs_R ? (this.Ub = this.Yd[0], this.Lc = this.Mc) : (this.Ub = this.Mc[0], this.Lc = this.Yd)
    }
};

function gvjs_qga(a) {
    var b = [gvjs_d, gvjs_j, gvjs_Ar, gvjs_xv, gvjs_Hr, gvjs_2r],
        c = {};
    b.forEach(function(d, e) {
        c[d] = e
    });
    a = a.L.series.reduce(function(d, e) {
        return Math.max(d, c[e.type])
    }, 0);
    return b[a]
}
gvjs_.fha = function() {
    var a = this.L;
    switch (a.chartType) {
        case gvjs_j:
        case gvjs_Wr:
            if (a.dr == gvjs_m) throw Error("X values column cannot be of type string");
            var b = a.XF[0];
            if (b == gvjs_m) throw Error("Data column(s) cannot be of type string");
            var c = this.Yd[0],
                d = this.Mc[0];
            if (c.type != gvjs_o) throw Error("The x-axis must be of type value");
            c.initScale(a.dr);
            if (d.type != gvjs_o) throw Error("The y-axis must be of type value");
            d.initScale(b);
            break;
        case gvjs_c:
        case gvjs_Bt:
            b = this.Ub;
            a.chartType === gvjs_Bt && (c = this.Ia.getColumnProperty(0,
                gvjs_Ft), gvjs_Ep(b.options, 1, {
                ticks: c
            }));
            if (b.type == gvjs_o) {
                if (a.dr == gvjs_m) throw Error("Domain column cannot be of type string, it should be the X values on a continuous domain axis");
                b.initScale(a.dr)
            }
            gvjs_y(this.Lc, function(e, f) {
                var g = a.XF[f];
                if (g == gvjs_m) throw Error("Data column(s) for axis #" + f + " cannot be of type string");
                e.initScale(g)
            }, this)
    }
    gvjs_y(this.Yd, function(e) {
        gvjs_NG(e)
    });
    gvjs_y(this.Mc, function(e) {
        gvjs_NG(e)
    })
};

function gvjs_rga(a) {
    if (null === gvjs_wH(a)) return [];
    for (var b = (a.L.di[0].columns.domain || [])[0], c = [], d = null, e = a.Ia, f = 0; f < e.getNumberOfRows(); f++) {
        var g = e.getValue(f, b),
            h = gvjs_xH(a, f);
        if (null !== d && null != h) {
            if (0 > h) throw Error("Invalid gap value (" + h + ") in data row #" + f + ". Gap value must be non-negative.");
            c.push({
                dc: d,
                pe: g,
                jea: h
            })
        }
        d = g
    }
    return c
}
gvjs_.r3 = function() {
    return this.qo && this.qo.rm == gvjs_f ? null : null != this.Mc[0] && null != this.Mc[1] ? gvjs_1v : null != this.Mc[1] ? gvjs_sd : gvjs_i
};
gvjs_.q3 = function() {
    return this.qo && this.qo.rm == gvjs_f ? gvjs_1v : null
};

function gvjs_yH(a) {
    var b = a.columns.data;
    return b ? b[0] : a.columns[gvjs_Eu][0]
}

function gvjs_sga(a) {
    for (var b = a.L, c = a.Ia, d = a.Ub, e = 0; e < b.Fa.length; e++) {
        for (var f = 0; f < b.series.length; f++) {
            var g = b.series[f],
                h = a.Lc[g.targetAxisIndex];
            g = c.getValue(e, gvjs_yH(g));
            g = gvjs_tG(h.ga, g);
            null != g && gvjs_JG(h, g)
        }
        d.type == gvjs_o && (f = c.getValue(e, 0), f = gvjs_tG(d.ga, f), gvjs_JG(d, f))
    }
}

function gvjs_tga(a) {
    var b = a.L,
        c = a.Ia,
        d = a.Yd[0];
    a = a.Mc[0];
    for (var e = 0; e < c.getNumberOfRows(); e++)
        for (var f = 0; f < b.series.length; f++) {
            var g = b.series[f],
                h = gvjs_yH(g);
            g = c.getValue(e, b.di[g.sd].columns.domain[0]);
            h = c.getValue(e, h);
            g = gvjs_tG(d.ga, g);
            h = gvjs_tG(a.ga, h);
            null != g && gvjs_JG(d, g);
            null != h && gvjs_JG(a, h)
        }
}
gvjs_.PH = function() {
    var a = this,
        b;
    return [function() {
        b = a.Si()
    }, this.Fba.bind(this), function() {
        (b.Jl !== gvjs_e || b.Xb || b.chartType === gvjs_Bt) && gvjs_y(a.Lc, function(c) {
            c.ub(0)
        })
    }, function() {
        if (b.chartType === gvjs_c || b.chartType === gvjs_Bt) gvjs_sga(a), a.Ub.type == gvjs_o && a.Ub.Fy(gvjs_rga(a)), gvjs_LG(a.Ub), gvjs_y(a.Lc, function(e) {
            e.Fy();
            gvjs_LG(e)
        }, a);
        else {
            var c = a.Yd[0],
                d = a.Mc[0];
            b.chartType == gvjs_Wr ? gvjs_aga(a.qo, c, d) : b.chartType == gvjs_j && gvjs_tga(a);
            c.Fy();
            gvjs_LG(c);
            d.Fy();
            gvjs_LG(d)
        }
    }, function() {
        a.Rn = a.Rn ||
            gvjs_D(a.options, "bar.variableWidth");
        b.chartType === gvjs_Bt && (a.Rn = !1)
    }, function() {
        b.Df.bars && gvjs_zH(a, gvjs_Hr);
        b.Df.steppedArea && (a.Ub.type == gvjs_o && (a.Rn = !0), gvjs_zH(a, gvjs_xv));
        b.Df.candlesticks && gvjs_uga(a);
        if (b.Df.line) {
            for (var c = a.L, d = 0; d < c.series.length; d++) gvjs_AH(a, d);
            gvjs_BH(a);
            gvjs_CH(a);
            gvjs_DH(a)
        }
        b.Df.area && gvjs_vga(a);
        if (b.Df.scatter) {
            c = a.L;
            for (d = 0; d < c.series.length; d++) gvjs_EH(a, d);
            gvjs_CH(a);
            gvjs_DH(a)
        }
        if (b.Df.bubbles) {
            c = a.qo;
            d = a.Yd[0];
            for (var e = a.Mc[0], f = a.Se, g = 0; g < c.Ji.getNumberOfRows(); g++) {
                a: {
                    var h =
                        c;
                    var k = d,
                        l = e,
                        m = g,
                        n = h.Ji,
                        p = n.getValue(m, h.ZT),
                        q = n.getFormattedValue(m, h.ZT),
                        r = n.getValue(m, h.EG),
                        t = n.getValue(m, h.GG),
                        u = null;
                    if (null != h.xo && (u = n.getValue(m, h.xo), null == u)) {
                        h = null;
                        break a
                    }
                    var v = null;
                    if (null != h.gq && (v = n.getValue(m, h.gq), null == v)) {
                        h = null;
                        break a
                    }
                    n = h.Me(q, h.Ea).width;
                    if (h.rm == gvjs_f) h.YP = gvjs_DA(h.YP, u);
                    else if (h.rm == gvjs_m) {
                        var w = u,
                            x = h.Ax[w];
                        if (!x) {
                            x = gvjs_mv + w + ".";
                            var y = gvjs_Mw(h.m, x + gvjs_Sb, h.MQ[h.sz.length % h.MQ.length]);
                            y = gvjs_ZD(y);
                            var z = gvjs_D(h.m, x + gvjs_iw, !0);
                            x = gvjs_C(h.m, x + gvjs_Xt,
                                w);
                            x = {
                                color: y.color,
                                visibleInLegend: z,
                                labelInLegend: x
                            };
                            h.Ax[w] = x;
                            h.sz.push(w)
                        }
                    }
                    h.kW = gvjs_DA(h.kW, v);r = k.ga.Db(r);t = l.ga.Db(t);null === r || null === t ? h = null : (gvjs_0G(k, r) && gvjs_0G(l, t) && (k.ub(r), l.ub(t)), k = h.CP(m, q), h = {
                        id: p,
                        text: q,
                        textLength: n,
                        textStyle: h.Ea,
                        hc: k,
                        fe: {
                            x: r,
                            y: t,
                            color: u,
                            size: v
                        }
                    })
                }
                c.Gi.series[0].points.push(h)
            }
            if (c.rm == gvjs_f) c.ZP = gvjs_dG(c.m, c.YP), f.setScale(c.ZP);
            else if (c.rm == gvjs_m)
                for (d = 0; d < c.sz.length; d++) e = c.sz[d], f = c.Ax[e], f.visibleInLegend && c.Gi.pl.push({
                    index: d,
                    id: e,
                    text: f.labelInLegend,
                    brush: new gvjs__({
                        fill: f.color
                    }),
                    isVisible: !0
                });
            c.O8 = gvjs_2G(c.m, c.kW);
            c.ena && gvjs_v(c.Gi.series[0].points, c.Paa, c)
        }
    }, function() {
        var c = b.chartType === gvjs_Bt,
            d = b.Df.bars || b.Df.candlesticks,
            e = null != b.series.find(function(f) {
                return null != f.intervals
            });
        (d && !c && !a.Rn || e) && gvjs_wga(a)
    }, function() {
        b.hAxes = gvjs_tx(a.Yd, function(c) {
            return c.xP(this.Pc, this.Se)
        }, a);
        b.vAxes = gvjs_tx(a.Mc, function(c) {
            return c.xP(this.Pc, this.Se)
        }, a);
        gvjs_xga(a)
    }, this.Cba.bind(this), this.dka.bind(this), function() {
        gvjs_yga(new gvjs_FH(a,
            a.options))
    }, function() {
        var c = a.Pc.getPosition(),
            d = a.Pc.Ea.fontSize,
            e = null;
        c != gvjs_i && c != gvjs_Yt || null != a.Mc[1] || (e = new gvjs_H(b.chartArea.top, b.width - d, b.chartArea.bottom, b.chartArea.right + d));
        c != gvjs_sd || null != a.Mc[0] || (e = new gvjs_H(b.chartArea.top, b.chartArea.left - d, b.chartArea.bottom, d));
        e && e.right >= e.left && a.Pc.wn(e)
    }, this.Bka.bind(this), function() {
        a.qo || (gvjs_oga(a, a.Ia), gvjs_nga(a), gvjs_zga(a))
    }]
};
gvjs_.Fba = function() {
    var a = this.L,
        b = this.Va,
        c = (gvjs_ux(this.Yd) || gvjs_ux(this.Mc)).title.textStyle,
        d = Math.max(a.title.textStyle.fontSize, c.fontSize),
        e = this.Pc.Ea.fontSize,
        f = this.Pc.getPosition(),
        g = this.Se.Ea.fontSize,
        h = this.Se.getPosition(),
        k = a.titlePosition == gvjs_Kt ? a.title.text : "",
        l = "",
        m = "";
    if (a.axisTitlesPosition == gvjs_Kt) {
        var n = function(w) {
            var x = gvjs_Tg(w);
            x.sort(function(y, z) {
                return y > z ? 1 : y < z ? -1 : 0
            });
            return x.map(function(y) {
                return w[y].title.text
            }).filter(function(y) {
                return "" != y
            }).join(gvjs_ja)
        };
        switch (a.chartType) {
            case gvjs_j:
            case gvjs_Wr:
                l = n(this.Yd);
                m = n(this.Mc);
                break;
            case gvjs_c:
                l = n({
                    0: this.Ub
                }), m = n(this.Lc)
        }
    }
    l = l && m ? l + " / " + m : l ? l : m ? m : "";
    m = Math.max(2, Math.round(d / 1.618));
    var p = Math.max(2, Math.round(e / 1.618)),
        q = Math.max(2, Math.round(g / 1.618)),
        r = a.chartArea.width - 2 * m;
    g = gvjs_rF(b, k, a.title.textStyle, r, 1);
    n = 0 < g.lines.length ? g.lines[0] : "";
    var t = b(n, a.title.textStyle).width;
    r = Math.max(r - t - Math.round(Math.max(2, 1.618 * d)), 0);
    b = gvjs_rF(b, l, c, r, 1);
    var u = 0 < b.lines.length ? b.lines[0] : "",
        v = [];
    v.push({
        key: gvjs_Ur,
        min: 2,
        extra: [Infinity]
    });
    (n || u) && v.push({
        key: gvjs_ce,
        min: d + 2,
        extra: [m - 2]
    });
    f == gvjs_Kt && v.push({
        key: gvjs__t,
        min: e + 2,
        extra: [p - 2]
    });
    h == gvjs_Kt && v.push({
        key: gvjs_ks,
        min: this.Se.getHeight() + 2,
        extra: [q - 2]
    });
    f = gvjs_sy(v, Math.floor(a.chartArea.height / 2));
    d = a.chartArea.top;
    h = f.title || [];
    0 < h.length && (d += h[0], n && (a.title.lines.push({
        text: n,
        x: a.chartArea.left + m,
        y: d,
        length: t
    }), a.title.tooltip = g.tc ? k : ""), u && (a.OD = {
            text: l,
            textStyle: c,
            boxStyle: null,
            lines: [],
            Yb: gvjs_Y,
            Mb: gvjs_Y,
            tooltip: b.tc ? l : "",
            anchor: null,
            angle: 0
        },
        a.OD.lines.push({
            text: u,
            x: a.chartArea.right - m,
            y: d,
            length: r
        })));
    c = f.legend || [];
    0 < c.length && (d += c[0], this.Pc.wn(new gvjs_H(d - e, a.chartArea.right, d, a.chartArea.left)));
    e = f.colorBar || [];
    0 < e.length && (d += e[0], a = new gvjs_H(d - this.Se.getHeight(), a.chartArea.right, d, a.chartArea.left), this.Se.wn(a))
};

function gvjs_zH(a, b) {
    var c = a.L;
    c.Xb ? gvjs_Aga(a, b) : gvjs_Bga(a, b, c.Jl)
}

function gvjs_wga(a) {
    var b = a.Ub;
    if (b.ga) {
        var c = a.L.Fa.filter(function(f, g) {
                return 0 != gvjs_xH(a, g)
            }),
            d = Infinity,
            e;
        c.forEach(function(f) {
            f = b.ga.Db(f.data);
            if (null != f && null != e) {
                var g = Math.abs(f - (e || 0));
                0 < g && (d = Math.min(d, g))
            }
            e = f
        }, a);
        isFinite(d) && (c = d / 2, b.ub(b.ga.hk - c), b.ub(b.ga.gk + c))
    }
}

function gvjs_GH(a, b) {
    for (var c = a.L, d = [], e = 0; e < c.Fa.length; e++) {
        var f = {
            positive: 0,
            negative: 0
        };
        d[e] = f;
        for (var g = 0; g < c.series.length; g++) {
            var h = c.series[g];
            if (h.type == b) {
                var k = a.Lc[h.targetAxisIndex];
                h = a.Ia.getValue(e, h.columns.data[0]);
                null != h && (k = k.ga.Db(h), null != k && (0 < k ? f.positive += k : f.negative -= k))
            }
        }
    }
    return d
}

function gvjs_HH(a, b) {
    for (var c = a.L, d = 0; d < c.series.length; d++) {
        var e = c.series[d];
        e.type == b && (a.Lc[e.targetAxisIndex].viewWindowMode = gvjs_gu)
    }
}

function gvjs_Bga(a, b, c) {
    var d = a.L,
        e = a.Ia,
        f = a.Ub,
        g = a.L.chartType === gvjs_Bt,
        h = a.Rn,
        k = c !== gvjs_e,
        l = k && d.Jl !== gvjs_xb;
    c = d.Jl === gvjs_Nd ? "#.##%" : "0.00#";
    if (g) {
        var m = (d.chartArea.height - 1) / gvjs_Cga(a, k);
        a.L.wu = gvjs_IH(m, gvjs_D(a.options, gvjs_Dt))
    }
    m = [];
    l && (m = gvjs_GH(a, b), gvjs_HH(a, b));
    var n = null,
        p = f.ga ? f.ga.M6 : null;
    h && f.ub(p);
    for (h = {
            uj: 0
        }; h.uj < d.Fa.length; h = {
            WN: h.WN,
            uj: h.uj
        }, h.uj++) {
        var q = 0 == gvjs_xH(a, h.uj),
            r = gvjs_tx(a.Lc, function() {
                return {
                    positive: 0,
                    negative: 0
                }
            }),
            t = -1;
        null != p && (n = p);
        p = gvjs_JH(a, h.uj);
        f.ub(p);
        h.WN = gvjs_0G(f, p);
        for (var u = {
                yw: 0
            }; u.yw < d.series.length; u = {
                UN: u.UN,
                uq: u.uq,
                Vn: u.Vn,
                PA: u.PA,
                QG: u.QG,
                Xn: u.Xn,
                Zl: u.Zl,
                Rs: u.Rs,
                yw: u.yw,
                JG: u.JG
            }, u.yw++)
            if (u.Zl = d.series[u.yw], u.Zl.type == b)
                if (t++, k || (r[u.Zl.targetAxisIndex] = {
                        positive: 0,
                        negative: 0
                    }), u.Rs = u.Zl.points, q) u.Rs.push(null);
                else {
                    var v = u.Zl.targetAxisIndex;
                    u.Xn = a.Lc[v];
                    u.QG = u.Xn.Tr;
                    var w = e.getValue(h.uj, u.Zl.columns.data[0]);
                    w = u.QG ? w : u.Xn.ga.Db(w);
                    u.JG = void 0;
                    l && (gvjs_rG(u.Xn.ga, c), u.JG = gvjs_sG(u.Xn.ga));
                    u.Vn = 0 <= Number(w) ? "positive" : "negative";
                    u.uq = r[v];
                    k || (a.jv = Math.max(a.jv, t + 1));
                    u.UN = m[h.uj] && m[h.uj][u.Vn] || 1;
                    u.PA = function(A) {
                        return function(B) {
                            return null == B ? null : B / A.UN
                        }
                    }(u);
                    v = function(A, B) {
                        return function(D, F, G) {
                            var H = null;
                            null == D || isNaN(D) || (H = D + (k || g ? A.uq[A.Vn] : 0));
                            l && (H = A.PA(H), G = A.PA(G));
                            A.QG && (H = A.Xn.ga.Db(H), G = A.Xn.ga.Db(G));
                            B.WN && A.Xn.ub(H);
                            var I;
                            null != D && (I = gvjs_KH(a, A.Zl, B.uj, A.uq[A.Vn], A.PA, !0));
                            F = {
                                fe: {
                                    Ko: B.uj,
                                    eA: F,
                                    from: G,
                                    bw: H,
                                    Ot: n,
                                    d: p,
                                    RD: I
                                }
                            };
                            null == D && (F.Zi = !0);
                            A.Zl.type == gvjs_xv && (I = A.Rs.length, F.fe.y7 = 0 == I || null == A.Rs[I -
                                1] ? null : A.Rs[I - 1].fe.bw);
                            gvjs_LH(a, F, A.Zl, A.yw, B.uj);
                            l && F.hc && (F.hc.content = F.hc.content + " (" + A.JG.formatValue(H - G) + ")");
                            A.Rs.push(F);
                            null == D || isNaN(D) || (A.uq[A.Vn] += D)
                        }
                    }(u, h);
                    var x = k ? 0 : t,
                        y = k || g ? u.uq[u.Vn] : null;
                    if (g && !a.L.wu)
                        for (var z = 0; z < Number(w); z++) y = k || g ? u.uq[u.Vn] : null, v(1, x, y);
                    else v(w, x, y)
                }
    }
    k || gvjs_y(a.Lc, function(A) {
        gvjs_YG(A)
    })
}

function gvjs_Aga(a, b) {
    for (var c = a.L, d = a.Ia, e = a.Ub, f = c.series.filter(function(w) {
            return w.type == b
        }), g = 0; g < c.Fa.length; ++g) {
        var h = 0 == gvjs_xH(a, g),
            k = gvjs_JH(a, g);
        e.ub(k);
        for (var l = gvjs_0G(e, k), m = [gvjs_Eu, gvjs_ts], n = 0; n < f.length; ++n) {
            var p = f[n];
            if (h) {
                p.points.push(null);
                return
            }
            for (var q = a.Lc[p.targetAxisIndex], r = q.ga, t = 0; t < m.length; ++t) {
                var u = m[t],
                    v = d.getValue(g, p.columns[u][0]);
                v = r.Db(v);
                if (null === v) {
                    p.points.push(null);
                    return
                }
                l && q.ub(v);
                a.jv = Math.max(a.jv, n + 1);
                u = {
                    brush: u == gvjs_Eu ? p.Uk.background.df : null,
                    fe: {
                        Ko: g,
                        eA: n,
                        from: null,
                        bw: v,
                        d: k,
                        vha: u == gvjs_ts,
                        RD: gvjs_KH(a, p, g, 0, null, !0)
                    }
                };
                gvjs_LH(a, u, p, n, g);
                p.points.push(u)
            }
        }
    }
    gvjs_y(a.Lc, function(w) {
        gvjs_YG(w)
    })
}

function gvjs_uga(a) {
    var b = a.L,
        c = a.Ia,
        d = a.Ub,
        e = b.series.filter(function(f) {
            return f.type == gvjs_2r
        });
    b.Fa.forEach(function(f, g) {
        var h = 0 == gvjs_xH(a, g);
        e.forEach(function(k, l) {
            if (h) k.points.push(null);
            else {
                var m = k.columns.data,
                    n = a.Lc[k.targetAxisIndex];
                a.jv = Math.max(a.jv, l + 1);
                var p = c.getValue(g, m[0]),
                    q = c.getValue(g, m[1]),
                    r = c.getValue(g, m[2]);
                m = c.getValue(g, m[3]);
                p = n.ga.Db(p);
                q = n.ga.Db(q);
                r = n.ga.Db(r);
                m = n.ga.Db(m);
                if (null === p || null === m || null === q || null === r) k.points.push(null);
                else {
                    var t = gvjs_JH(a, g);
                    d.ub(t);
                    var u = r < q;
                    gvjs_0G(d, t) && (n.ub(p), n.ub(m));
                    n = {
                        hx: u ? k.candlestick.L2 : k.candlestick.W7,
                        Lb: gvjs_cy(k.color.color),
                        fe: {
                            Ko: g,
                            eA: l,
                            eia: p,
                            lineTo: m,
                            rka: u ? r : q,
                            ska: u ? q : r,
                            qha: u,
                            d: t
                        }
                    };
                    gvjs_LH(a, n, k, l, g);
                    k.points.push(n)
                }
            }
        })
    })
}

function gvjs_AH(a, b) {
    var c = a.L,
        d = a.Ia,
        e = a.Ub,
        f = c.series[b];
    if (f.type == gvjs_d) {
        c = f.Fe ? f.data : c.Fa;
        for (var g = 0; g < c.length; g++) {
            var h = a.Lc[f.targetAxisIndex],
                k = f.columns.data[0];
            k = f.Fe ? f.data[g][1] : d.getValue(g, k);
            k = h.ga.Db(k);
            var l;
            if (null != k) {
                var m = gvjs_JH(a, g, f);
                e.ub(m);
                (l = gvjs_0G(e, m) && !f.Fe) && h.ub(k);
                h = f.Fe ? null : gvjs_KH(a, f, g, 0, null, l)
            } else l = !1, h = null;
            h = {
                fe: {
                    Ko: g,
                    eA: 0,
                    d: m,
                    t: k,
                    RD: h
                },
                shape: f.pointShape,
                A8: l
            };
            null == k && (h.Zi = !0);
            gvjs_LH(a, h, f, b, g);
            f.points.push(h)
        }
    }
}

function gvjs_BH(a) {
    for (var b = a.Ub, c = a.L.series, d = 0; d < c.length; d++) {
        var e = c[d];
        if ((e.type == gvjs_d || e.type == gvjs_Ar) && 0 != e.lineWidth) {
            var f = a.Lc[e.targetAxisIndex],
                g = e.points.map(function(l) {
                    return gvjs_MF(l) ? null : new gvjs_A(l.fe.d, l.fe.t)
                }),
                h = a.L.interpolateNulls;
            e = gvjs_zy(g, gvjs_PG(b), h);
            a: {
                switch (b.type) {
                    case gvjs_4r:
                        var k = b.Ja.max - 1;
                        break a;
                    case gvjs_3r:
                        k = b.Ja.max - .5;
                        break a
                }
                k = b.Ja.max
            }
            g = gvjs_zy(g, k, h);
            f.ub(e);
            f.ub(g)
        }
    }
}

function gvjs_vga(a) {
    var b = a.L,
        c = a.Ia,
        d = a.Ub,
        e = b.interpolateNulls,
        f = b.Jl !== gvjs_e,
        g = f && b.Jl !== gvjs_xb,
        h = b.Jl === gvjs_Nd ? "#.##%" : "0.00#",
        k = [];
    g && (k = gvjs_GH(a, gvjs_Ar), gvjs_HH(a, gvjs_Ar));
    for (var l = {}, m = 0; m < b.Fa.length; l = {
            VN: l.VN
        }, m++) {
        var n = gvjs_tx(a.Lc, function() {
            return 0
        });
        l.VN = k[m] && k[m].positive + k[m].negative || 1;
        for (var p = function(I) {
                return function(P) {
                    return null == P ? null : P / I.VN
                }
            }(l), q = null, r = null, t = 0; t < b.series.length; t++) {
            var u = b.series[t];
            if (u.type == gvjs_Ar) {
                var v = u.targetAxisIndex,
                    w = a.Lc[v],
                    x = null,
                    y = null,
                    z = u.columns.data[0],
                    A = c.getValue(m, z),
                    B = gvjs_tG(w.ga, A),
                    D = null == B || isNaN(B);
                D && (B = 0);
                var F = gvjs_JH(a, m);
                if (null != F) {
                    A = void 0;
                    g && (gvjs_rG(w.ga, h), A = gvjs_sG(w.ga));
                    var G = void 0,
                        H = void 0;
                    G = void 0;
                    G = 0 < m ? c.getValue(m - 1, z) : null;
                    H = 0 === m || null === G && !isNaN(G);
                    z = m < c.getNumberOfRows() - 1 ? c.getValue(m + 1, z) : null;
                    z = m === c.getNumberOfRows() - 1 || null === z && !isNaN(z);
                    f ? (G = n[v], D || (G += B), x = r, y = q, D || (z || (r = G), H || (q = G))) : (r = q = G = B, e || (z && (r = null), H && (q = null)));
                    d.ub(F);
                    H = gvjs_0G(d, F);
                    G = p(G);
                    q = p(q);
                    r = p(r);
                    H &&
                        !D && (z = gvjs_uG(w.ga, G), w.ub(z));
                    z = gvjs_KH(a, u, m, n[v], p, H);
                    f && !D && (n[v] += B);
                    G = {
                        d: F,
                        t: gvjs_uG(w.ga, G),
                        Ko: m,
                        eA: 0,
                        nca: F,
                        oca: gvjs_uG(w.ga, q),
                        lca: F,
                        mca: gvjs_uG(w.ga, r),
                        wba: F,
                        xba: gvjs_uG(w.ga, x),
                        uba: F,
                        vba: gvjs_uG(w.ga, y),
                        RD: z
                    };
                    v = {
                        fe: G,
                        shape: u.pointShape,
                        A8: H,
                        Zi: D
                    };
                    D || (gvjs_LH(a, v, u, t, m), g && v.hc && (w = p(B), v.hc.content = v.hc.content + " (" + A.formatValue(w) + ")"));
                    u.points.push(v)
                }
            }
        }
    }
    gvjs_BH(a);
    gvjs_CH(a)
}

function gvjs_zga(a) {
    a.L.series.forEach(function(b, c) {
        b.Fe && (b.type === gvjs_j ? gvjs_EH(a, c) : b.type === gvjs_d && gvjs_AH(a, c), gvjs_MH(a, c))
    })
}

function gvjs_EH(a, b) {
    var c = a.L,
        d = a.Ia,
        e = a.Yd[0],
        f = a.Mc[0],
        g = c.series[b],
        h = g.sd;
    if (g.type === gvjs_j)
        for (var k = g.Fe ? g.data.length : d.getNumberOfRows(), l = 0; l < k; l++) {
            var m = c.di[h].columns.domain[0],
                n = gvjs_yH(g);
            m = g.Fe ? g.data[l][0] : d.getValue(l, m);
            var p = g.Fe ? g.data[l][1] : d.getValue(l, n);
            n = e.ga.Db(m);
            m = f.ga.Db(p);
            null !== n && null !== m ? ((p = gvjs_0G(e, n) && gvjs_0G(f, m)) && !g.Fe && (e.ub(n), f.ub(m)), n = {
                fe: {
                    x: n,
                    y: m
                },
                shape: g.pointShape,
                vla: p
            }, gvjs_LH(a, n, g, b, l), g.points.push(n)) : g.points.push(null)
        }
}

function gvjs_CH(a) {
    function b(q) {
        var r = null != q.fe ? q.fe.Ko : null;
        return {
            Bt: null != q.Bt ? q.Bt : 1,
            Xt: null != q.Xt ? q.Xt : 1,
            scope: null != q.scope ? q.scope : !0,
            hea: null != r ? gvjs_xH(a, r) : null
        }
    }

    function c(q) {
        return !gvjs_MF(q)
    }
    for (var d = null === gvjs_wH(a), e = 0; e < a.L.series.length; e++) {
        var f = a.L.series[e],
            g = f.jo,
            h = f.columns.emphasis || [],
            k = f.columns.scope || [];
        if (0 != (f.columns.certainty || []).length || 0 != h.length || 0 != k.length || !d) {
            h = gvjs_9w(f.points, c);
            k = b(h || {});
            for (var l = 0; l < f.points.length; l++) {
                var m = f.points[l];
                if (!gvjs_MF(m)) {
                    var n =
                        b(m),
                        p = f.Lb;
                    n.scope || k.scope || (f.B3 = f.B3 || p.lD(), p = f.B3, m.kp = p, g && (f.A3 = f.A3 || g.lD(), m.hK = f.A3));
                    if (1 > n.Bt || 1 > k.Bt) p = gvjs_NH(p, !1), m.kp = p;
                    1 != n.Xt && 1 != k.Xt && (p = gvjs_Dga(p, Math.min(k.Xt, n.Xt)), m.kp = p);
                    0 != n.hea || gvjs_MF(h) || (m.kp = null);
                    k = n
                }
                h = m
            }
        }
    }
}

function gvjs_OH(a) {
    var b = {
        fill: {},
        stroke: {},
        shape: {}
    };
    null != a && (null != a.visible && (b.visible = a.visible), null != a.size && (b.size = a.size), null != a.color && (b.fill.color = b.stroke.color = a.color), null != a.opacity && (b.fill.opacity = b.stroke.opacity = a.opacity), null != a.fillColor && (b.fill.color = a.fillColor), null != a.fillOpacity && (b.fill.opacity = a.fillOpacity), null == b.fill.color && null == b.fill.opacity && delete b.fill, null != a.strokeColor && (b.stroke.color = a.strokeColor), null != a.strokeOpacity && (b.stroke.opacity = a.strokeOpacity),
        null != a.strokeWidth && (b.stroke.width = a.strokeWidth), null == b.stroke.color && null == b.stroke.opacity && null == b.stroke.width && delete b.stroke, null != a.shapeType && (b.shape.type = a.shapeType), null != a.shapeSides && (b.shape.sides = a.shapeSides), null != a.shapeRotation && (b.shape.rotation = a.shapeRotation), null != a.shapeDent && (b.shape.dent = a.shapeDent), null != a.shortSize && (b.shortSize = a.shortSize));
    return b
}

function gvjs_PH(a, b, c) {
    var d = void 0;
    b = null != b.columns.style ? b.columns.style[0] : void 0;
    if (null != b && a.Ia.getColumnType(b) === gvjs_m && (a = a.Ia.getValue(c, b), null != a)) {
        d = gvjs_2e(a);
        if (gvjs_Xx(d)) var e = {
            fill: {
                color: d
            },
            stroke: {
                color: d
            }
        };
        else if ("{" === d.charAt(0)) {
            try {
                var f = gvjs_Eg(d)
            } catch (g) {}
            null != f && (e = f)
        }
        null == e && (gvjs_4e(d, "{") ? (e = gvjs_tx(gvjs_nH(d), gvjs_OH), gvjs_vx(e, "") && (Object.assign(e, e[""]), gvjs_xx(e, "")), gvjs_vx(e, "*") && (Object.assign(e, e["*"]), gvjs_xx(e, "*"))) : e = gvjs_OH(gvjs_8y(d)));
        d = e
    }
    if (null !=
        d) return new gvjs_Si([d])
}

function gvjs_QH(a, b, c) {
    c !== gvjs_Bv && (a.ie(gvjs_Mw(b, [gvjs_Vs, gvjs_Ts], a.fill)), a.Qd(gvjs_Lw(b, gvjs_Ws, a.fillOpacity)));
    c !== gvjs_Ts && (a.Jc(gvjs_Mw(b, [gvjs_Gv, gvjs_Bv], a.stroke)), gvjs_yw(a, gvjs_Lw(b, gvjs_Hv, a.strokeOpacity)), a.vi(gvjs_E(b, gvjs_Iv, a.strokeWidth)))
}

function gvjs_LH(a, b, c, d, e) {
    if (a.Lu()) {
        a: {
            d = a.CP(c, d, e);
            var f = c.columns.tooltip;
            if (f && !c.Fe) {
                f = f[0];
                if (a.Ia.getColumnType(f) === gvjs_c) {
                    d.v1 = a.Ia.getValue(e, f);
                    d.Qf = !0;
                    d.ng = !0;
                    break a
                }(f = gvjs_uH(a, f, e)) && f.ng && Object.assign(d, f)
            }
            d.Qf = !!d.Qf
        }
        b.hc = d
    }
    d = gvjs_PH(a, c, e);
    a: {
        f = a.Ia;
        var g = c.columns.certainty || [];
        if (g.length) {
            var h = f.getValue(e, g[0]);
            if (null != h) {
                f = f.getColumnType(g[0]) == gvjs_Lb ? h ? 1 : 0 : h;
                break a
            }
        }
        f = 1
    }
    a: {
        g = a.Ia;h = c.columns.emphasis || [];
        if (h.length) {
            var k = g.getValue(e, h[0]);
            if (null != k) {
                g = g.getColumnType(h[0]) ==
                    gvjs_Lb ? k ? 2 : 1 : k;
                break a
            }
        }
        g = 1
    }
    a: {
        a = a.Ia;h = c.columns.scope || [];
        if (h.length && (e = a.getValue(e, h[0]), null != e)) {
            e = !!e;
            break a
        }
        e = !0
    }
    a = gvjs_RF(b, c);
    h = c.df;
    if (null != d) {
        h = h.clone();
        b.radius = a = gvjs_5i(d, "point.size", a);
        k = d.R("point.shape");
        null != k && (b.shape = k);
        k = d.Pm("point.visible");
        null != k && (b.visible = k);
        gvjs_QH(h, d);
        switch (c.type) {
            case gvjs_d:
            case gvjs_j:
            case gvjs_Ar:
                gvjs_QH(h, d.view(gvjs_xp));
                null != c.Lb && (b.kp = (b.kp || b.Lb || c.Lb).clone(), gvjs_QH(b.kp, d.view([gvjs_d, ""]), gvjs_Bv));
                null != c.jo && (b.hK = (b.hK ||
                    b.Lb || c.jo).clone(), gvjs_QH(b.hK, d.view([gvjs_Ar, ""]), gvjs_Ts));
                break;
            case gvjs_xv:
                gvjs_QH(h, d.view(gvjs_Ar), gvjs_Ts), null != c.Lb && (b.Lb = (b.Lb || c.Lb).clone(), gvjs_QH(b.Lb, d.view([gvjs_d, ""]), gvjs_Bv));
            case gvjs_Hr:
                gvjs_QH(h, d.view(gvjs_Ib));
                break;
            case gvjs_2r:
                b.hx = b.hx.clone(), gvjs_QH(b.hx, d.view([gvjs_Ib, ""])), gvjs_QH(b.Lb, d.view([gvjs_d, ""]))
        }
        b.brush = h
    }
    e || (b.scope = e, c.C3 = c.C3 || h.lD(), h = c.C3, b.brush = h);
    1 != g && (b.Xt = g, c.type == gvjs_d || c.type == gvjs_Ar || c.type == gvjs_j) && (a = Math.round(a * Math.sqrt(g) * 10) /
        10, b.radius = a);
    if (1 > f) switch (b.Bt = f, c.type) {
        case gvjs_d:
        case gvjs_Ar:
        case gvjs_j:
            b.brush = gvjs_NH(h, !0);
            c = a - gvjs_Dw(b.brush) / 2;
            b.radius = Math.max(c, 0);
            break;
        case gvjs_Hr:
        case gvjs_xv:
            b.brush = gvjs_NH(h, !1)
    }
}

function gvjs_uH(a, b, c) {
    var d = a.Ia;
    a = a.L.md && (d.getProperty(c, b, gvjs_It) || d.getColumnProperty(b, gvjs_It));
    b = d.getFormattedValue(c, b);
    return {
        Qf: !!a,
        ng: b ? !0 : !1,
        content: b
    }
}
gvjs_.CP = function(a, b, c) {
    if (this.L.chartType === gvjs_j || a.Fe || 0 === a.lineWidth) {
        var d = this.Ia,
            e = this.L;
        if (a.Fe) {
            var f = a.data[c][0];
            var g = a.data[c][1];
            null != f && (f = gvjs_4j(f, d.getColumnType(a.sd)));
            null != g && (g = gvjs_4j(g, a.dataType));
            var h = e.focusTarget.has(gvjs_3r) ? g : f + gvjs_ja + g;
            var k = f
        } else if (this.L.Xb) {
            var l = this.Yd[0].title.text || "X",
                m = this.Mc[0].title.text || "Y";
            f = b % 2 ? b - 1 : b;
            b = e.series[f];
            h = e.series[f + 1];
            f = e.di[h.sd].columns.domain[0];
            g = gvjs_yH(h);
            f = d.getFormattedValue(c, f);
            g = d.getFormattedValue(c,
                g);
            h = l + ": " + f + gvjs_ja + m + ": " + g;
            f = e.di[b.sd].columns.domain[0];
            g = gvjs_yH(b);
            f = d.getFormattedValue(c, f);
            g = d.getFormattedValue(c, g);
            h += "\n" + l + ": " + f + gvjs_ja + m + ": " + g
        } else l = gvjs_yH(a), f = d.getFormattedValue(c, e.di[a.sd].columns.domain[0]), g = d.getFormattedValue(c, l), h = e.focusTarget.has(gvjs_3r) ? g : f + gvjs_ja + g;
        a = {
            ng: !1,
            content: h,
            sk: a.title,
            At: k
        }
    } else a = gvjs_Ega(this, a, c);
    return a
};

function gvjs_Ega(a, b, c) {
    var d = a.Ia,
        e = a.L.Fa[c];
    e = b.Fe ? b.data[c][0].toString() : e.Ds[b.sd];
    if (b.type == gvjs_2r) a = b.columns.data, a = d.getFormattedValue(c, a[0]) + gvjs_1p + d.getFormattedValue(c, a[3]) + gvjs_ja + d.getFormattedValue(c, a[1]) + gvjs_1p + d.getFormattedValue(c, a[2]);
    else if (a.L.Xb) {
        var f = b.columns[gvjs_Eu],
            g = b.columns.data,
            h = a.Ia.getValue(c, f[0]);
        a = a.Ia.getValue(c, g[0]);
        f = d.getFormattedValue(c, f[0]);
        g = d.getFormattedValue(c, g[0]);
        if (null === h && gvjs_1e(f) && null === a && gvjs_1e(g)) return {
            ng: !1,
            content: null
        };
        a = g + "\n" + f
    } else {
        g = b.columns.data;
        h = b.Fe ? b.data[c][1] : a.Ia.getValue(c, g[0]);
        a = b.Fe ? b.data[c][1].toString() : a.Ia.getFormattedValue(c, g[0]);
        if (null === h && gvjs_1e(a)) return {
            ng: !1,
            content: null
        };
        h = b.columns.interval || [];
        h.length && (h = h.map(function(k) {
            return d.getFormattedValue(c, k)
        }), a += " [" + h.join(gvjs_ja) + "]")
    }
    return {
        ng: !1,
        content: a,
        At: e,
        sk: b.title,
        Qf: !1
    }
}

function gvjs_DH(a) {
    function b(x, y, z) {
        k.ub(z.d);
        y.A8 && a.Lc[x.targetAxisIndex].ub(z.t)
    }

    function c(x) {
        return {
            d: x.x,
            t: x.y
        }
    }

    function d(x) {
        return new gvjs_Ij(x.d, x.t)
    }

    function e(x, y, z) {
        y.vla && (a.Yd[0].ub(z.x), a.Mc[0].ub(z.y))
    }

    function f(x) {
        return {
            x: x.x,
            y: x.y
        }
    }

    function g(x) {
        return new gvjs_Ij(x.x, x.y)
    }
    var h = a.L,
        k = a.Ub;
    switch (h.chartType) {
        case gvjs_j:
            var l = g;
            var m = f;
            var n = e;
            break;
        case gvjs_c:
            l = d, m = c, n = b
    }
    for (var p = 0; p < h.series.length; p++) {
        var q = h.series[p];
        if (q.type == gvjs_j || q.type == gvjs_d)
            if (gvjs_tf([gvjs_c,
                    "phase", gvjs_js
                ], q.curveType)) {
                var r = q.type == gvjs_j && q.curveType == gvjs_js,
                    t = q.curveType == gvjs_c;
                q.MS = !0;
                q.sha = r;
                r = gvjs_ny(q.points.map(function(x) {
                    return gvjs_MF(x) ? null : l(x.fe)
                }), q.ZM, t, r, h.interpolateNulls);
                for (t = 0; t < q.points.length; ++t) {
                    var u = q.points[t];
                    if (r[t]) {
                        var v = m(r[t][0]),
                            w = m(r[t][1]);
                        u.B6 = v;
                        u.C6 = w;
                        n(q, u, v);
                        n(q, u, w)
                    }
                }
            } else q.MS = !1
    }
}
gvjs_.Cba = function() {
    var a = this;
    if (this.L.focusTarget.has(gvjs_3r)) {
        var b = this.L.Fa,
            c = b.map(function(p, q) {
                return gvjs_RH(a, q)
            }),
            d = this.Ub;
        b = gvjs_fx(b.length);
        gvjs_Cf(b, function(p, q) {
            return gvjs_Bf(c[p], c[q])
        });
        var e = d.je,
            f = d.Gd;
        if (e > f) {
            var g = e;
            e = f;
            f = g
        }
        for (g = 0; g < b.length; g++) {
            var h = gvjs_RH(this, b[g]);
            if (null != h) {
                if (gvjs__G(d, h)) return;
                if (!(isNaN(h) || h * d.direction < d.je * d.direction)) {
                    var k = g;
                    break
                }
            }
        }
        if (void 0 !== k) {
            g = e;
            e = null;
            for (var l = k; l < b.length; l++) {
                null != e && l < e && (l = e, e = null);
                var m = b[l];
                k = g;
                if (l ==
                    b.length - 1) {
                    gvjs_SH(this, m, k, f);
                    break
                }
                var n = gvjs_RH(this, b[l + 1]);
                if (null == n) {
                    for (g = l + 2; g < b.length; g++)
                        if (n = gvjs_RH(this, b[g]), null != n) {
                            e = g;
                            break
                        }
                    if (null == n) {
                        gvjs_SH(this, m, k, f);
                        break
                    }
                }
                if (gvjs__G(d, n)) {
                    gvjs_SH(this, m, k, f);
                    break
                }
                g = gvjs_Ux(h, n);
                gvjs_SH(this, m, k, g);
                h = n
            }
        }
    }
};

function gvjs_RH(a, b) {
    var c = a.L.Fa;
    a = a.Ub;
    return a.type == gvjs_o ? null == c[b].data ? null : a.BP(c[b].data) : a.ne(b)
}

function gvjs_SH(a, b, c, d) {
    function e() {
        var m = c;
        c = d;
        d = m
    }
    var f = a.L.chartArea.top,
        g = a.L.chartArea.bottom,
        h = a.L.chartArea.left,
        k = a.L.chartArea.right,
        l = a.Ub.direction;
    b = a.L.Fa[b];
    a.L.orientation == gvjs_R ? 1 == l ? (d < c && e(), b.sM = new gvjs_H(f, d, g, c)) : (d > c && e(), b.sM = new gvjs_H(f, c, g, d)) : 1 == l ? (d < c && e(), b.sM = new gvjs_H(c, k, d, h)) : (d > c && e(), b.sM = new gvjs_H(d, k, c, h))
}
gvjs_.Bka = function() {
    gvjs_Fga(this);
    gvjs_Gga(this)
};

function gvjs_Fga(a) {
    var b = a.L;
    gvjs_y(b.vAxes, function(c, d) {
        gvjs_TH(this, this.Mc[d], b.vAxes[d], this.Mha)
    }, a);
    gvjs_y(b.hAxes, function(c, d) {
        gvjs_TH(this, this.Yd[d], b.hAxes[d], this.yha)
    }, a)
}

function gvjs_Gga(a) {
    var b = a.L;
    gvjs_y(b.vAxes, function(c, d) {
        gvjs_TH(a, a.Mc[d], c, function() {
            return !0
        })
    });
    gvjs_y(b.hAxes, function(c, d) {
        gvjs_TH(a, a.Yd[d], c, function(e, f) {
            return gvjs_Hga(a, f)
        })
    })
}

function gvjs_TH(a, b, c, d) {
    c.text && (c.text = c.text.filter(d.bind(a, b)))
}
gvjs_.yha = function(a, b) {
    var c = this.L;
    b = b.ka;
    return b.angle ? !0 : (b = gvjs_JD(b)) ? a.bh != gvjs_Kt || (new gvjs_H(c.chartArea.top, c.chartArea.right, c.chartArea.bottom, c.chartArea.left)).contains(b) ? !0 : !1 : !0
};

function gvjs_Hga(a, b) {
    var c = a.L,
        d = b.ka;
    if (d.angle) return !0;
    b = gvjs_JD(d);
    if (!b) return !0;
    d = Math.ceil(d.textStyle.fontSize / 8);
    var e = new gvjs_H(b.top, b.right + d, b.bottom, b.left - d),
        f;
    for (f in c.vAxes) {
        var g = Number(f);
        if (a.Mc[g].bh == gvjs_Kt && !(1 > (c.vAxes[g].text ? c.vAxes[g].text.length : 0))) {
            var h = gvjs_JD(c.vAxes[g].text[0].ka),
                k = gvjs_JD(gvjs_nf(c.vAxes[g].text).ka);
            if (h || k) {
                if (h && gvjs_Ky(e, h) || k && gvjs_Ky(e, k)) return !1;
                h ? k ? (g = Math.min(h.left, k.left), h = Math.max(h.right, k.right)) : (g = h.left, h = h.right) : (g = k.left,
                    h = k.right);
                if (Math.abs(b.left - g) < d || Math.abs(b.right - h) < d) return !1
            }
        }
    }
    return !0
}
gvjs_.Mha = function(a, b) {
    var c = this.L,
        d = new gvjs_H(c.chartArea.top, c.chartArea.right, c.chartArea.bottom, c.chartArea.left),
        e = b.ka;
    b = e.textStyle.fontSize / 8;
    e = gvjs_JD(e);
    if (!e) return !0;
    if (a.bh == gvjs_Kt && !d.contains(e)) return !1;
    a = new gvjs_H(e.top, e.right + b, e.bottom, e.left - b);
    return (d = gvjs_JD(c.title)) && gvjs_Ky(a, d) || (c = c.OD ? gvjs_JD(c.OD) : null) && gvjs_Ky(a, c) ? !1 : (c = this.Pc.getArea()) && gvjs_Ky(a, c) ? !1 : !0
};

function gvjs_MH(a, b) {
    b = a.L.series[b];
    var c = gvjs_Iga(a, b);
    b.points && b.points.forEach(function(d) {
        null == d || d.Zi || (d.W = c(d.fe), null != d.B6 && (d.wp = c(d.B6)), null != d.C6 && (d.mn = c(d.C6)))
    });
    b.intervals && (0 < b.intervals.lines.length || 0 < b.intervals.areas.length) && gvjs_Jga(b)
}
gvjs_.dka = function() {
    var a = this;
    this.L.series.forEach(function(b, c) {
        gvjs_MH(a, c)
    })
};

function gvjs_Jga(a) {
    function b(q) {
        var r = e[q];
        delete e[q];
        if (r && 1 < r.line.length) {
            r.bottom && r.bottom.reverse();
            if (f[q].curveType != gvjs_e) {
                var t = f[q].curveType == gvjs_c;
                q = f[q].ZM;
                r.gQ = gvjs_ny(r.line, q, t, !1, !1);
                r.bottom && (r.tba = gvjs_ny(r.bottom, q, t, !1, !1))
            }
            a.intervals.paths.push(r)
        }
    }

    function c(q, r) {
        if (!e[q]) {
            var t = f[q].brush.clone(),
                u = f[q].style,
                v = {};
            v.eC = q;
            v.line = [];
            u == gvjs_Ar ? (t.vi(0), v.bottom = []) : t.Qd(0);
            v.brush = t;
            e[q] = v
        }
        e[q].line.push(new gvjs_Ij(r.left, r.top));
        e[q].bottom && e[q].bottom.push(new gvjs_Ij(r.left +
            r.width, r.top + r.height))
    }

    function d(q) {
        q = f[q].style;
        return q == gvjs_Ar || q == gvjs_d
    }
    var e = {},
        f = a.intervals.eq;
    a.intervals.paths = [];
    for (var g = 0; g < a.points.length; g++) {
        var h = {},
            k = a.points[g];
        if (k && k.W && k.W.qp) {
            k = k.W.qp;
            for (var l = 0; l < k.length; ++l) {
                var m = k[l].eC;
                d(m) && (h[m] = !0, c(m, k[l].rect))
            }
        }
        for (var n in e) k = Number(n), h[k] || f[k].interpolateNulls || b(k)
    }
    for (var p in e) b(Number(p))
}

function gvjs_Iga(a, b) {
    switch (b.type) {
        case gvjs_j:
            return a.Rka.bind(a, b);
        case gvjs_Yr:
            return a.Oka.bind(a, b);
        case gvjs_d:
            return a.Qka.bind(a, b);
        case gvjs_Hr:
            return a.Nka.bind(a, b);
        case gvjs_xv:
            return a.Ska.bind(a, b);
        case gvjs_2r:
            return a.Pka.bind(a, b);
        case gvjs_Ar:
            return a.Mka.bind(a, b)
    }
    return null
}
gvjs_.Rka = function(a, b) {
    a = this.Yd[0].ne(b.x);
    b = this.Mc[0].ne(b.y);
    return {
        x: a,
        y: b
    }
};
gvjs_.Oka = function(a, b) {
    var c = this.qo,
        d = this.Mc[0];
    a = this.Yd[0].ne(b.x);
    d = d.ne(b.y);
    var e = gvjs_4G(c, b);
    e = new gvjs__({
        fill: e,
        fillOpacity: c.Hja,
        stroke: c.Xla
    });
    b = gvjs_1G(c.O8, b.size);
    return {
        x: a,
        y: d,
        brush: e,
        radius: b,
        tM: b
    }
};
gvjs_.Qka = function(a, b) {
    var c = gvjs_UH(this, a.targetAxisIndex, b.d, b.t);
    c.qp = gvjs_VH(this, a, b);
    return c
};
gvjs_.Nka = function(a, b) {
    var c = gvjs_WH(this, a, b, b.from, b.bw);
    return c ? {
        top: c.top,
        left: c.left,
        width: Math.max(.5, c.width),
        height: Math.max(.5, c.height),
        qp: gvjs_VH(this, a, b)
    } : null
};
gvjs_.Pka = function(a, b) {
    var c = gvjs_WH(this, a, b, b.rka, b.ska),
        d = gvjs_WH(this, a, b, b.eia, b.lineTo);
    if (!c || !d) return null;
    var e = gvjs_XH(this, d.left, d.top),
        f = gvjs_XH(this, c.width, c.height),
        g = gvjs_XH(this, d.width, d.height);
    g.domain = 2;
    e.domain += (f.domain - (f.domain % 2 ? 3 : 2)) / 2;
    e = gvjs_YH(this, e.domain, e.target);
    g = gvjs_YH(this, g.domain, g.target);
    d.width = g.x;
    d.height = g.y;
    d.left = e.x;
    d.top = e.y;
    a = b.qha ? a.candlestick.L2 : a.candlestick.W7;
    gvjs_Cw(a) && (a = a.strokeWidth / 2, c.height -= 2 * a, c.width -= 2 * a, c.left += a, c.top += a);
    c.height = Math.max(c.height, 2);
    c.width = Math.max(c.width, 1);
    return {
        rect: c,
        line: d
    }
};
gvjs_.Ska = function(a, b) {
    var c = this.Lc[a.targetAxisIndex];
    null == b.from && (b.from = c.ga.Db(c.baseline.Oa), null == b.from && (b.from = 0));
    var d = this.Ub,
        e = b.Ko;
    if (this.Rn || d.ga) {
        if (null == b.Ot) return null;
        e = Math.floor(gvjs_XG(d, b.Ot));
        var f = Math.floor(gvjs_XG(d, b.d));
        d.ub(b.Ot)
    } else {
        var g = d.ticks[e].oa || 0;
        f = d.ks;
        e = Math.floor(g - d.direction * f / 2);
        f = Math.floor(g + d.direction * f / 2)
    }
    d.ub(b.d);
    d = c.ne(b.from);
    var h = c.ne(b.bw);
    d = gvjs_YH(this, e, d);
    g = gvjs_YH(this, e, h);
    f = gvjs_YH(this, f, h);
    h = [];
    gvjs_D(this.options, "connectSteps", !0) && null != b.y7 && (c = c.ne(b.y7), c = gvjs_YH(this, e, c), h.push(c));
    h.push(g);
    h.push(f);
    return {
        bar: gvjs_iH(d.x, d.y, f.x, f.y),
        outline: h,
        qp: gvjs_VH(this, a, b)
    }
};

function gvjs_WH(a, b, c, d, e) {
    var f = a.Ub,
        g = a.Lc[b.targetAxisIndex];
    b = a.CC;
    var h = g.ga.Db(g.baseline.Oa);
    null == d && (d = h || 0);
    null == e && (e = h || 0);
    h = e;
    h = Math.min(gvjs_XG(g, d), gvjs_XG(g, h));
    d = Math.max(gvjs_XG(g, d), gvjs_XG(g, e));
    g = a.L.chartType === gvjs_Bt ? gvjs_IH(g.ks, gvjs_D(a.options, gvjs_Dt)) ? 0 : 1 : Math.min(1, .2 * (d - h));
    0 === g || Math.floor(h + g) < Math.floor(d) && Math.floor(h + g) > Math.floor(h) ? (h = Math.floor(h + g), d = Math.floor(d)) : h += g;
    g = gvjs_E(a.options, "diff.newData.widthFactor", .3);
    g = c.vha ? g : 1;
    if (a.Rn) {
        if (null == c.Ot) return null;
        g = Math.floor(gvjs_XG(f, c.Ot));
        b = Math.floor(gvjs_XG(f, c.d));
        f.ub(c.Ot)
    } else c = gvjs_ZH(a, c), e = g * b.wW / 2, g = b.vV(c - e), b = b.vV(c + e);
    f.ub(f.QH(g));
    f.ub(f.QH(b));
    f = gvjs_YH(a, g, h);
    a = gvjs_YH(a, b, d);
    return gvjs_iH(f.x, f.y, a.x, a.y)
}
gvjs_.Mka = function(a, b) {
    function c(l) {
        return null != l ? l : e
    }
    var d = this.Lc[a.targetAxisIndex];
    d = d.ga.Db(d.baseline.Oa);
    var e = null != d ? d : 0;
    d = gvjs_UH(this, a.targetAxisIndex, b.d, b.t);
    var f = gvjs_UH(this, a.targetAxisIndex, b.uba, c(b.vba)),
        g = gvjs_UH(this, a.targetAxisIndex, b.wba, c(b.xba)),
        h = gvjs_UH(this, a.targetAxisIndex, b.lca, c(b.mca)),
        k = gvjs_UH(this, a.targetAxisIndex, b.nca, c(b.oca));
    a = gvjs_VH(this, a, b);
    return {
        x: d.x,
        y: d.y,
        oP: f.x,
        pP: f.y,
        qP: g.x,
        rP: g.y,
        kI: h.x,
        lI: h.y,
        mI: k.x,
        nI: k.y,
        qp: a
    }
};

function gvjs_VH(a, b, c) {
    if (!c.RD) return [];
    var d = a.Ub;
    b = a.Lc[b.targetAxisIndex];
    var e = a.CC;
    if (c.eA >= e.gja || d.type != gvjs_o && c.Ko >= d.ticks.length) return [];
    var f = gvjs_ZH(a, c),
        g = e.vV;
    a.Rn ? (d = gvjs_XG(d, c.d) - gvjs_XG(d, c.Ot), f -= d / 2) : d = e.wW + e.e9;
    e = [];
    for (var h = 0, k; k = c.RD[h]; h++) {
        var l = gvjs_XG(b, k.Oga),
            m = gvjs_XG(b, k.kia),
            n = d * k.Tla / 2,
            p = g(f - n);
        n = g(f + n);
        p = gvjs_YH(a, p, Math.min(m, l));
        l = gvjs_YH(a, n, Math.max(m, l));
        e.push({
            rect: gvjs_iH(p.x, p.y, l.x, l.y),
            eC: k.eC,
            brush: k.brush
        })
    }
    return e
}

function gvjs_ZH(a, b) {
    var c = a.Ub,
        d = a.CC;
    c = c.type == gvjs_o ? gvjs_XG(c, b.d) : c.ticks && c.ticks[b.Ko] && c.ticks[b.Ko].oa;
    if (a.Rn) return c;
    a = d.wW;
    return c - d.gda + (a + d.e9) * b.eA + a / 2
}

function gvjs_XH(a, b, c) {
    switch (a.L.orientation) {
        case gvjs_R:
            return {
                domain: b,
                target: c
            };
        case gvjs_S:
            return {
                domain: c,
                target: b
            }
    }
    throw Error(gvjs_Sq);
}

function gvjs_YH(a, b, c) {
    switch (a.L.orientation) {
        case gvjs_R:
            return {
                x: b,
                y: c
            };
        case gvjs_S:
            return {
                x: c,
                y: b
            }
    }
    throw Error(gvjs_Sq);
}

function gvjs_UH(a, b, c, d) {
    b = a.Lc[b];
    c = a.Ub.ne(c);
    d = b.ne(d);
    return gvjs_YH(a, c, d)
}

function gvjs_NH(a, b) {
    a = a.clone();
    gvjs_Ew(a) && a.fill != gvjs_ga ? (gvjs_zw(a, new gvjs_xw(gvjs_0u, a.fill)), !gvjs_Cw(a) && b && (a.Jc(a.fill), a.vi(1))) : gvjs_Cw(a) && (a.tg = gvjs_ss);
    return a
}

function gvjs_Dga(a, b) {
    a = a.clone();
    a.vi(a.strokeWidth * b);
    return a
}

function gvjs_xH(a, b) {
    var c = gvjs_wH(a);
    return null !== c ? a.Ia.getValue(b, c) : null
}

function gvjs_wH(a) {
    if (null === a.Ub || a.Ub.type != gvjs_o) return null;
    a = a.L.di[0].columns.gap || [];
    return 0 === a.length ? null : a[0]
}

function gvjs_KH(a, b, c, d, e, f) {
    function g(u, v, w, x, y) {
        var z = h.eq[u],
            A = p.getValue(c, u);
        A = m ? A : n(A);
        v = p.getValue(c, v);
        v = m ? v : n(v);
        null != A && null != v && (A += d, v += d, e && (A = e(A), v = e(v)), m && (A = n(A), v = n(v)), f && (l.ub(A), l.ub(v)), z = z.brush, null != k && (z = z.clone(), gvjs_QH(z, k.view([x, ""])), y = y || "size", w = gvjs_E(k, [x + "." + y, y], w)), q.push({
            kia: A,
            Oga: v,
            Tla: w,
            eC: u,
            brush: z
        }))
    }
    var h = b.intervals;
    if (!h) return null;
    var k = gvjs_PH(a, b, c),
        l = a.Lc[b.targetAxisIndex],
        m = l.Tr,
        n = l.ga.Db.bind(l.ga),
        p = a.Ia,
        q = [];
    for (a = 0; a < h.Tv.length; a += 2) g(h.Tv[a],
        h.Tv[a + 1], 0, "interval stick");
    a = 0;
    for (b = h.OH.length - 1; a <= b; a++, b--) {
        var r = h.OH[a];
        g(r, h.OH[b], h.eq[r].boxWidth, "interval box")
    }
    for (a = 0; a < h.points.length; a++) b = h.points[a], g(b, b, 0, "interval point");
    for (a = 0; a < h.Xa.length; a++) {
        b = h.Xa[a];
        r = h.eq[b];
        var t = !(0 == a || a == h.Xa.length - 1);
        g(b, b, t ? r.sla : r.barWidth, "interval bar", t ? "shortSize" : void 0)
    }
    a = 0;
    for (b = h.areas.length - 1; a <= b; a++, b--) g(h.areas[a], h.areas[b], 0, "interval area");
    for (a = 0; a < h.lines.length; a++) b = h.lines[a], g(b, b, 0, "interval line");
    return q.length ?
        q : null
}

function gvjs_xga(a) {
    function b() {
        m = h / f;
        7 > m && (m = Math.floor(m));
        m = Math.max(1, m);
        n = a.options.Ze("bar.gap", m);
        p = gvjs_Xi(a.options, gvjs_8i, 0, gvjs_Gr, gvjs_yq, m);
        null == n && (n = Math.max(1 < f ? 1 : 0, m - p));
        p = m - n
    }
    var c = a.L.chartType === gvjs_Bt,
        d = a.Ub,
        e = gvjs_Kga(a),
        f = a.jv,
        g = a.options.Ze("bar.group.gap", e),
        h = a.options.Ze(["bar.group.width", gvjs_Fr], e);
    1 == f && (null == g && (g = a.options.Ze("bar.gap", e)), null == h && (h = a.options.Ze([gvjs_Gr], e)));
    null == g && c && (g = 1);
    if (null == h) {
        var k = a.options.ha("bar.gap") || 1,
            l = a.options.ha(gvjs_Gr);
        null !=
            l ? h = f * (l + k) - k : c || (h = gvjs_8i(100 / 1.618 + "%", e))
    }
    null == g && (g = Math.max(0, e - h));
    h = Math.max(f, e - g);
    g = e - h;
    var m, n = null;
    b();
    n > g && (g = n, h = e - g);
    g -= n;
    h += n;
    b();
    var p = gvjs_uy(10, p);
    n = gvjs_uy(10, n);
    h = gvjs_uy(10, h);
    g = gvjs_uy(10, g);
    d = d.direction;
    e = g + n;
    a.CC = {
        gja: f,
        gda: gvjs_uy(10, c ? (-1 === d ? h + g : 0) + -(g + n) / 2 : (h - n) / 2),
        Jqa: g,
        Kqa: h,
        wW: p,
        e9: n,
        vV: 7 > p && 0 == p % 2 || 7 > e && 0 == e % 2 ? function(q) {
            return Math.floor(q) + .5
        } : function(q) {
            return Math.floor(q + .5)
        }
    }
}

function gvjs_Kga(a) {
    var b = a.Ub,
        c = a.L.Fa;
    c = c.filter(function(h, k) {
        return 0 != gvjs_xH(a, k)
    });
    if (0 === c.length) return 0;
    var d = a.JH;
    if (!d || 0 === d.size) return 0;
    if (b.type == gvjs_o) {
        d = b.FB;
        for (var e = null, f = 0; f < c.length; f++) {
            var g = gvjs_JH(a, f);
            g = null == g ? null : b.ne(g);
            null != g && null != e && (e = Math.abs(g - e), 0 < e && (d = Math.min(d, e)));
            e = g
        }
        return d
    }
    return Math.abs(gvjs_ZG(b, 1) - gvjs_ZG(b, 0))
}

function gvjs_JH(a, b, c) {
    var d = a.Ia;
    a = a.Ub;
    a.type == gvjs_o && (b = c && c.Fe ? c.data[b][0] : d.getValue(b, 0), b = a.ga.Db(b));
    return b
}

function gvjs_FH(a, b) {
    this.zg = a;
    this.m = b
}

function gvjs_yga(a) {
    var b = a.zg.Si(),
        c = a.m,
        d = a.zg.Ub,
        e = b.orientation || gvjs_R;
    if (d) {
        var f = d.direction,
            g = -1;
        e === gvjs_S && (f = 1, g = d.direction);
        var h = a.zg.CC,
            k = h && h.xta;
        h = {
            fontName: b.Kf,
            fontSize: b.rh,
            auraColor: b.Eu
        };
        var l = gvjs_Pw(c, [gvjs_rr, gvjs_yr], h),
            m = gvjs_Ow(c, ["annotations.domain.boxStyle", gvjs_or]),
            n = gvjs_Mw(c, ["annotations.domain.stem.color", gvjs_pr, gvjs_tr, gvjs_vr], ""),
            p = gvjs_E(c, ["annotations.domain.stem.length", "annotations.domain.stemLength", gvjs_ur, gvjs_wr], 5),
            q = 90;
        e === gvjs_S && (q = 0);
        gvjs_E(c, ["annotations.domain.stem.angle", "annotations.stem.angle"], q);
        var r = gvjs_C(c, [gvjs_qr, gvjs_xr], gvjs_xp, gvjs_WA);
        "letter" === r && (r = gvjs_xp);
        b.Fa.forEach(function(B, D) {
            var F = [],
                G = [];
            b.di.forEach(function(K) {
                K = a.fJ(D, K.columns, r);
                gvjs_xf(F, K.point);
                gvjs_xf(G, K.line)
            });
            if (F.length || G.length) {
                var H = gvjs_JH(a.zg, D);
                H = gvjs_XG(d, H);
                var I = null,
                    P = null;
                e === gvjs_S ? (I = b.chartArea.left, P = H) : (I = H, P = b.chartArea.top + b.chartArea.height);
                F.length && (B.Ib = gvjs__H(a, I, P, null, gvjs_e, "", e, f, g, F, l, m, p, n));
                G.length && (b.orientation ===
                    gvjs_S ? I = null : P = null, B.Ib = gvjs_0H(a, I, P, e, G, l, n))
            }
        });
        var t = gvjs_Sg(gvjs_PA),
            u = gvjs_D(c, ["annotations.datum.highContrast", gvjs_sr], !0),
            v = gvjs_D(c, ["annotations.datum.alwaysOutside", "annotations.alwaysOutside"], !1),
            w = gvjs_Pw(c, ["annotations.datum.textStyle", gvjs_yr], h, t),
            x = gvjs_Ow(c, ["annotations.datum.boxStyle", gvjs_or]),
            y = gvjs_Mw(c, ["annotations.datum.stem.color", "annotations.datum.stemColor", gvjs_tr, gvjs_vr], "", t),
            z = gvjs_E(c, ["annotations.datum.stem.length", "annotations.datum.stemLength", gvjs_ur,
                gvjs_wr
            ], 12),
            A = gvjs_C(c, ["annotations.datum.style", gvjs_xr], gvjs_xp, gvjs_WA);
        "letter" === A && (A = gvjs_xp);
        b.series.forEach(function(B, D) {
            if (B.type == gvjs_Ar || B.type == gvjs_Hr || B.type == gvjs_d || B.type == gvjs_j || B.type == gvjs_xv) {
                var F = gvjs_mv + D + ".annotations.";
                D = gvjs_D(c, F + gvjs_zt, u);
                var G = gvjs_D(c, F + "alwaysOutside", v),
                    H = gvjs_Pw(c, F + gvjs_Pv, w, t);
                H.color = gvjs_VF(H.color, B.color);
                var I = gvjs_Ow(c, [F + "boxStyle"], x),
                    P = gvjs_Mw(c, [F + "stemColor", F + "stem.color"], y, t),
                    K = gvjs_E(c, [F + "stemLength", F + "stem.length"], z);
                gvjs_E(c, [F + "stem.angle"], z);
                P = gvjs_VF(P, B.color);
                gvjs_C(c, F + gvjs_6d, A, gvjs_WA);
                F = a.zg.Lc[B.targetAxisIndex];
                for (var N = 0; N < B.points.length; ++N)
                    if (null != B.points[N] && null != B.points[N].W) {
                        var Q = B.points[N],
                            U = a.fJ(N, B.columns, A),
                            O = Q.W,
                            J = gvjs_Ew(B.df) ? B.df.fill : D ? gvjs_lq : gvjs_8p;
                        Q = Q.brush && gvjs_Ew(Q.brush) ? Q.brush.fill : J;
                        if (Q !== J && D) {
                            J = gvjs_z(H);
                            var C = [.1, .2, .3],
                                E = gvjs_ei(Q),
                                L = gvjs_ei(b.HB.fill),
                                M = C.map(gvjs_Te(gvjs_Yx, E));
                            C = C.map(gvjs_Te(gvjs_Zx, E));
                            E = [E].concat(M, C);
                            L = gvjs_di(gvjs_0x(L, E));
                            J.color =
                                L
                        } else J = H;
                        M = E = L = null;
                        C = d;
                        var R = F;
                        e === gvjs_S && (C = F, R = d);
                        if (null != O.x) L = O.x, E = O.y;
                        else if (null != O.bar || null != O.left) M = O.bar, null == M && (M = new gvjs_0(O.left, O.top, O.width, O.height)), L = M.left, E = M.top, k ? (1 == C.direction && (L = M.left + M.width), 1 == R.direction && (E = M.top + M.height)) : e === gvjs_S ? (E = M.top + M.height / 2, 1 == C.direction && (L = M.left + M.width)) : (L = M.left + M.width / 2, 1 == R.direction && (E = M.top + M.height));
                        U.point.length && (B.points[N].Ib = gvjs__H(a, L, E, M, B.type, Q, e, C.direction, R.direction, U.point, J, I, K, P, D, G));
                        U.line.length &&
                            (B.points[N].Ib = gvjs_0H(a, L, E, e, U.line, H, P))
                    }
            }
        })
    }
}
gvjs_FH.prototype.fJ = function(a, b, c) {
    var d = this.zg.Ia,
        e = b.annotation,
        f = {
            line: [],
            point: []
        };
    if (null == e) return f;
    b = b.annotationText || [];
    for (var g = 0; g < e.length; ++g) {
        var h = e[g],
            k = h + 1;
        0 <= gvjs_of(b, k) && d.getFormattedValue(a, k) || (k = null);
        null != d.getValue(a, h) && (k = {
            text: d.getFormattedValue(a, h),
            mA: k,
            rowIndex: a
        }, gvjs_C(this.m, "annotation." + h + ".style", c, gvjs_WA) == gvjs_d ? f.line.push(k) : f.point.push(k))
    }
    return f
};

function gvjs__H(a, b, c, d, e, f, g, h, k, l, m, n, p, q, r, t) {
    var u = a.zg.Si(),
        v = l.length,
        w = [
            [64, 64, 64],
            [128, 128, 128],
            [255, 255, 255]
        ];
    r = null == r ? !0 : r;
    (e = e === gvjs_Hr || e === gvjs_xv) && d && (g === gvjs_S ? c = Math.floor(d.top + d.height / 2) : b = Math.floor(d.left + d.width / 2));
    if (g === gvjs_R && 1 === k || g === gvjs_S && 1 === h) p *= -1;
    var x = g === gvjs_R ? 1 === k ? gvjs_Tr : gvjs_1v : 1 === h ? gvjs_i : gvjs_sd,
        y = b,
        z = c - p;
    g === gvjs_S && (y = b - p, z = c);
    var A = -p,
        B = !1,
        D = p + m.fontSize * v;
    c - D < u.chartArea.top && c + D < u.chartArea.bottom && (z = c + D, A = p);
    u = [];
    for (p = 0; p < v; p++) {
        D = l[p];
        var F =
            (0, a.zg.Va)(D.text, m),
            G = {},
            H = new gvjs_vF(null == y ? void 0 : y, null == z ? void 0 : z),
            I = null;
        G.textStyle = new gvjs_Jw(m);
        if (!e) G.Yb = gvjs_X, G.Mb = gvjs_Y;
        else if (d && !t && 1 === v) {
            I = gvjs_ei(f);
            I = gvjs_di(gvjs_0x(I, w));
            var P = gvjs_Hg(m, gvjs_Ig);
            r && (P.auraColor = gvjs_e, P.color = I);
            a: {
                I = void 0;
                var K = D.text,
                    N = new gvjs_0(d.left, d.top + 0, d.width, d.height),
                    Q = a.zg.Va,
                    U = a.zg.Lu(),
                    O = Q(K, P);
                var J = N.getSize();
                var C = O.width <= J.width && O.height <= J.height;
                var E = {},
                    L = [];E.text = K;E.textStyle = P;
                if (x === gvjs_1v) {
                    var M = Math.floor(N.getCenter().x);
                    J = N.top + 2;
                    E.Yb = gvjs_X;
                    E.Mb = gvjs_l
                } else if (x === gvjs_i) M = N.left + N.width - 4,
                J = Math.floor(N.getCenter().y),
                E.Yb = gvjs_Y,
                E.Mb = gvjs_X;
                else if (x === gvjs_Tr) M = Math.floor(N.getCenter().x),
                J = N.top + N.height - 2,
                E.Yb = gvjs_X,
                E.Mb = gvjs_Y;
                else if (x === gvjs_sd) M = N.left + 4,
                J = Math.floor(N.getCenter().y),
                E.Yb = gvjs_l,
                E.Mb = gvjs_X;
                else throw Error("Invalid text block position.");
                if (!C || O.width > N.width - 4)
                    if (O.height < N.height) P = gvjs_rF(Q, K, P, N.width - 4, N.height / (O.height + 2)), L = P.lines, P.tc && (I = K, E.Is = !0);
                    else if (N.height > P.fontSize /
                    3) I = K,
                L = [gvjs_uq],
                J = Math.floor(N.getCenter().y),
                E.Mb = gvjs_X,
                E.Is = !0;
                else {
                    I = null;
                    break a
                }
                E.lines = [];
                if (L.length)
                    for (P = 0, K = L.length, Q = 0; Q < K; Q++) E.lines.push(new gvjs_qH({
                        x: 0,
                        y: P,
                        length: N.width,
                        text: L[Q]
                    })), P += O.height;
                else E.lines.push(new gvjs_qH({
                    x: 0,
                    y: 0,
                    length: O.width,
                    text: K
                }));E.angle = 0;E.anchor = new gvjs_vF(M, J);U && I && (E.hc = {
                    Qf: !1,
                    ng: !1,
                    content: I
                });I = new gvjs_rH(E)
            }
        }
        if (I && !I.Is && 1 === v) u.push(I), B = !0;
        else {
            switch (g) {
                case gvjs_R:
                    G.Yb = gvjs_X;
                    G.Mb = -1 === k ? gvjs_Y : gvjs_l;
                    break;
                case gvjs_S:
                    G.Yb = 1 === h ? gvjs_l :
                        gvjs_Y, G.Mb = gvjs_X
            }
            G.text = D.text;
            G.textStyle = m;
            G.boxStyle = n;
            G.anchor = H;
            G.Is = !1;
            G.lines = [{
                x: 0,
                y: 0,
                length: F.width,
                text: D.text
            }];
            G.angle = 0;
            F = D.mA;
            a.zg.Lu() && null != F && (G.hc = gvjs_uH(a.zg, F, D.rowIndex));
            u.push(new gvjs_rH(G));
            z += k * m.fontSize * G.lines.length
        }
    }
    p = B ? 0 : A;
    a = gvjs_S;
    g === gvjs_S && (a = gvjs_R);
    return {
        stem: {
            x: b,
            y: c,
            length: p,
            orientation: a,
            color: q
        },
        labels: u,
        jm: null
    }
}

function gvjs_0H(a, b, c, d, e, f, g) {
    for (var h = a.zg.Si(), k = f.fontSize, l = [], m = a.zg.Va, n = 0; n < e.length; n++) {
        var p = gvjs_rF(m, e[n].text, f, h.chartArea.height - k);
        l.push(p)
    }
    m = gvjs_S;
    n = 270;
    var q = c,
        r = h.chartArea.top;
    p = h.chartArea.bottom;
    d === gvjs_S && (m = gvjs_R, n = 0, q = b, r = h.chartArea.left, p = h.chartArea.right);
    if (null != b && null != c) {
        for (var t = h = 0; t < l.length; t++) h = Math.max(h, l[t].Bp);
        h += k;
        k = Math.max(Math.round(q - h / 2), r);
        p = Math.min(k + h, p);
        k = p - h
    } else k = r;
    r = Math.round((k + p) / 2);
    h = b;
    q = k;
    d === gvjs_S && (h = k, q = c);
    d === gvjs_S ? (b = r,
        c += 2) : (b += 2, c = r);
    r = [];
    for (t = 0; t < e.length; t++) {
        var u = e[t],
            v = l[t];
        v = {
            text: u,
            textStyle: f,
            lines: [{
                x: b,
                y: c,
                length: v.Bp,
                text: v.lines[0] || ""
            }],
            Yb: gvjs_X,
            Mb: gvjs_l,
            anchor: null,
            angle: n
        };
        var w = u.mA;
        a.zg.Lu() && null != w && (v.hc = gvjs_uH(a.zg, w, u.rowIndex));
        r.push(v);
        d === gvjs_S ? c += f.fontSize : b += f.fontSize
    }
    return {
        stem: {
            x: h,
            y: q,
            length: p - k,
            orientation: m,
            color: g
        },
        labels: r,
        jm: null
    }
};

function gvjs_1H(a) {
    gvjs_L.call(this);
    this.QD = a;
    this.WT = [];
    this.pK = !1;
    this.Mf = {
        fd: null,
        hq: 0,
        Ll: 0,
        nC: 0,
        oC: 0
    }
}
gvjs_r(gvjs_1H, gvjs_L);
gvjs_ = gvjs_1H.prototype;
gvjs_.Zd = function(a, b, c) {
    this.WT[c] = !0;
    0 === c && a && (this.Mf.fd = b, this.Mf.hq = a.x, this.Mf.Ll = a.y, this.Mf.nC = a.x, this.Mf.oC = a.y)
};
gvjs_.kS = function(a, b, c) {
    this.WT[b] = !1;
    0 === b && a && this.pK && (this.pK = !1, this.Mf.nC = a.x, this.Mf.oC = a.y, this.dispatchEvent("chartDragEnd", {
        fd: this.Mf.fd,
        Pa: {
            x: this.Mf.nC,
            y: this.Mf.oC
        },
        shiftKey: c
    }))
};
gvjs_.jS = function(a, b) {
    this.WT[0] && a && (this.Mf.nC = a.x, this.Mf.oC = a.y, this.pK || this.dispatchEvent(gvjs_9r, {
        fd: this.Mf.fd,
        Pa: {
            x: this.Mf.hq,
            y: this.Mf.Ll
        },
        shiftKey: b
    }), this.pK = !0, this.dispatchEvent("chartDrag", {
        fd: this.Mf.fd,
        Pa: {
            x: this.Mf.nC,
            y: this.Mf.oC
        },
        shiftKey: b
    }))
};
gvjs_.dispatchEvent = function(a, b) {
    this.QD.dispatchEvent({
        type: a,
        data: b
    })
};
gvjs_.J = function() {
    this.QD = null;
    gvjs_L.prototype.J.call(this)
};

function gvjs_2H(a, b, c, d) {
    gvjs_L.call(this);
    this.renderer = b;
    this.fj = c;
    this.chartType = d;
    this.jM = this.xu = null;
    this.Lr = a;
    this.qJ = new gvjs_1H(a);
    gvjs_Rw(this, this.qJ)
}
gvjs_r(gvjs_2H, gvjs_L);
gvjs_ = gvjs_2H.prototype;
gvjs_.J = function() {
    this.Lr = null;
    gvjs_K(this.jM);
    gvjs_L.prototype.J.call(this)
};

function gvjs_Lga(a) {
    var b = a.renderer.Xr;
    gvjs_3H(a, function(c, d) {
        a.renderer.qb(b, c, d)
    });
    gvjs_K(a.jM);
    a.jM = new gvjs_fD(a.renderer.getContainer());
    gvjs_M(a.jM, gvjs_uu, a.uga.bind(a))
}

function gvjs_Mga(a) {
    var b = a.fj.getContainer();
    gvjs_3H(a, function(c, d) {
        a.fj.qb(b, c, d)
    })
}

function gvjs_Nga(a) {
    var b = gvjs_gk();
    gvjs_Oga(a, function(c, d) {
        a.fj.qb(b, c, d)
    })
}

function gvjs_Oga(a, b) {
    b(gvjs_su, a.jS.bind(a));
    b(gvjs_tu, a.kS.bind(a))
}

function gvjs_3H(a, b) {
    b(gvjs_Dd, a.a4.bind(a));
    b(gvjs_Cd, a.Zfa.bind(a));
    b(gvjs_su, a.a4.bind(a));
    b(gvjs_tu, a.Yfa.bind(a));
    b(gvjs_pu, a.Tfa.bind(a));
    b(gvjs_fs, a.hfa.bind(a));
    b(gvjs_ms, a.nga.bind(a));
    b(gvjs_ws, a.pfa.bind(a))
}
gvjs_.jS = function(a) {
    var b = gvjs_Yy(this.renderer.getContainer()),
        c = gvjs_Yy(a);
    c.x -= b.x;
    c.y -= b.y;
    this.qJ.jS(c, a.shiftKey)
};
gvjs_.kS = function(a) {
    var b = gvjs_Yy(this.renderer.getContainer()),
        c = gvjs_Yy(a);
    c.x -= b.x;
    c.y -= b.y;
    this.qJ.kS(c, a.button, a.shiftKey)
};
gvjs_.a4 = function(a) {
    var b = this.Vj(a);
    try {
        this.Vj(a)
    } catch (d) {
        return
    }
    if (b) {
        var c = this.Io(a);
        a.type === gvjs_su && this.dispatchEvent(gvjs_as, {
            Pa: b,
            fd: c
        });
        c !== this.xu && (null != this.xu && gvjs_4H(this, this.xu), this.dispatchEvent("chartHoverIn", {
            Pa: b
        }), gvjs_5H(this, "HoverIn", c), this.xu = c)
    }
};
gvjs_.Vj = function(a) {
    return this.renderer.Vj(a)
};
gvjs_.Zfa = function(a) {
    a = this.Io(a);
    a === this.xu && (gvjs_4H(this, a), this.xu = null)
};

function gvjs_4H(a, b) {
    a.dispatchEvent("chartHoverOut", null);
    gvjs_5H(a, "HoverOut", b)
}
gvjs_.Yfa = function(a) {
    var b = this.Vj(a);
    b && (a = this.Io(a), this.dispatchEvent("chartMouseUp", {
        Pa: b,
        fd: a
    }), gvjs_5H(this, "MouseUp", a))
};
gvjs_.Tfa = function(a) {
    var b = this.Vj(a),
        c = this.Io(a);
    this.dispatchEvent(gvjs_$r, {
        Pa: b,
        fd: c,
        preventDefault: a.preventDefault.bind(a),
        shiftKey: a.shiftKey
    });
    gvjs_5H(this, "MouseDown", c);
    this.qJ.Zd(b, c, a.button)
};
gvjs_.hfa = function(a) {
    var b = this.Vj(a);
    a = this.Io(a);
    this.dispatchEvent("chartClick", {
        Pa: b,
        fd: a
    });
    gvjs_5H(this, "Click", a)
};
gvjs_.nga = function(a) {
    var b = this.Vj(a),
        c = this.Io(a);
    this.dispatchEvent(gvjs_bs, {
        Pa: b,
        fd: c
    });
    gvjs_5H(this, "RightClick", c);
    a.preventDefault()
};
gvjs_.pfa = function(a) {
    var b = this.Vj(a);
    a = this.Io(a);
    this.dispatchEvent("chartDblClick", {
        Pa: b,
        fd: a
    });
    gvjs_5H(this, "DblClick", a)
};
gvjs_.uga = function(a) {
    var b = this.Vj(a),
        c = this.Io(a);
    this.dispatchEvent("chartScroll", {
        Pa: b,
        fd: c,
        wheelDelta: a.deltaY,
        preventDefault: a.preventDefault.bind(a)
    });
    gvjs_5H(this, "Scroll", c)
};

function gvjs_5H(a, b, c) {
    var d = c.split("#");
    switch (d[0]) {
        case gvjs_de:
            var e = c = null,
                f = null;
            a.chartType === gvjs_Ru ? c = gvjs_ly(d[1]) : 4 === d.length ? (c = gvjs_ly(d[1]), e = gvjs_ly(d[2]), f = gvjs_ly(d[3])) : 3 === d.length ? (c = gvjs_ly(d[1]), e = gvjs_ly(d[2])) : e = gvjs_ly(d[1]);
            d = {
                yb: c,
                bi: e,
                wB: f
            };
            a.dispatchEvent(gvjs_de + b, d);
            break;
        case gvjs_ir:
            d = {
                Zt: d[1]
            };
            a.dispatchEvent("actionsMenuEntry" + b, d);
            break;
        case gvjs_5t:
            d = gvjs_ly(d[1]);
            if (null != d && 0 > d) break;
            d = {
                GK: d
            };
            a.dispatchEvent("legendEntry" + b, d);
            break;
        case gvjs_6t:
            d = {
                Yka: gvjs_ly(d[1]),
                Dg: gvjs_ly(d[2]),
                sA: gvjs_ly(d[3])
            };
            a.dispatchEvent("legendScrollButton" + b, d);
            break;
        case gvjs_3u:
            d = gvjs_ly(d[1]);
            d = {
                GK: d
            };
            a.dispatchEvent("removeSerieButton" + b, d);
            break;
        default:
            a.Y1(b, c)
    }
}
gvjs_.dispatchEvent = function(a, b) {
    this.Lr && this.Lr.dispatchEvent({
        type: a,
        data: b
    })
};

function gvjs_6H(a, b, c, d) {
    gvjs_2H.call(this, a, b, c, d.chartType);
    this.ca = d;
    this.zL = gvjs_7H(this)
}
gvjs_r(gvjs_6H, gvjs_2H);

function gvjs_7H(a) {
    var b = a.ca;
    if (b.chartType !== gvjs_c && b.chartType !== gvjs_j) return {};
    a = {};
    b = b.series;
    for (var c = 0; c < b.length; c++) {
        var d = b[c];
        if (gvjs_NF(d))
            for (var e = d.points, f = 0; f < e.length; f++) {
                var g = e[f];
                if (g && g.W && !g.Zi) {
                    var h = gvjs_rD([gvjs_xp, c, f]);
                    a[h] = {
                        center: g.W,
                        radius: g.W && null != g.W.tM ? g.W.tM : null != g.tM ? g.tM : d.p7,
                        yb: c,
                        bi: f
                    }
                }
            }
    }
    return a
}
gvjs_6H.prototype.Io = function(a) {
    var b = this.renderer.sr(a.target),
        c = this.Vj(a);
    if (!c) return gvjs_Ob;
    if ((new gvjs_0(Number(this.ca.chartArea.left) + 1, Number(this.ca.chartArea.top) + 1, this.ca.chartArea.width - 2, this.ca.chartArea.height - 2)).contains(c)) {
        var d = this.ca.focusTarget,
            e = null;
        if (d.has(gvjs_vp)) {
            e = c.x;
            var f = c.y,
                g = null,
                h = Infinity,
                k;
            for (k in this.zL)
                if (this.zL.hasOwnProperty(k)) {
                    var l = this.zL[k],
                        m = l.center.x,
                        n = l.center.y,
                        p = l.radius;
                    m - e <= p && m - e >= -p && n - f <= p && n - f >= -p && (m = (m - e) * (m - e) + (n - f) * (n - f), m <=
                        p * p && m <= h && (g = gvjs_rD([gvjs_Xu, l.yb, l.bi]), h = m))
                }
            e = g
        }
        if (null == e && d.has(gvjs_3r)) b: {
            d = this.ca.Fa;
            for (k = 0; k < d.length; k++)
                if ((e = d[k].sM) && e.contains(c)) {
                    e = gvjs_rD([gvjs_5r, k]);
                    break b
                }
            e = null
        }
        c = e
    } else c = null;
    if (a.type === gvjs_Cd) {
        a = this.xu;
        if (null == a) return b;
        c = c === a ? null : a
    }
    null != c && (gvjs_8H(this, b) ? (a = gvjs_of(gvjs_sD, b.split("#")[0]), d = gvjs_of(gvjs_sD, c.split("#")[0]), b = a > d ? b : c) : b = c);
    return gvjs_8H(this, b) ? b : gvjs_Ob
};

function gvjs_8H(a, b) {
    a = a.ca.focusTarget;
    return a.has(gvjs_3r) && !a.has(gvjs_vp) ? (b = b.split("#")[0], b !== gvjs_Ib && b !== gvjs_Wr && b !== gvjs__r && b !== gvjs_xp && b !== gvjs_Xu && b !== gvjs_yv) : !0
}
gvjs_6H.prototype.Y1 = function(a, b) {
    b = b.split("#");
    switch (b[0]) {
        case gvjs_Ib:
        case gvjs_Wr:
        case gvjs__r:
        case gvjs_xp:
        case gvjs_Xu:
        case gvjs_yv:
            var c = gvjs_ly(b[1]);
            b = {
                yb: c,
                bi: gvjs_ly(b[2])
            };
            this.dispatchEvent(gvjs_vp + a, b);
            break;
        case gvjs_5r:
            b = {
                yb: null,
                bi: gvjs_ly(b[1])
            };
            this.dispatchEvent(gvjs_3r + a, b);
            break;
        case gvjs_zr:
            c = gvjs_ly(gvjs_nf(b));
            this.dispatchEvent(gvjs_nr + a, 3 === b.length ? {
                yb: null,
                bi: gvjs_ly(b[1]),
                wB: c
            } : {
                yb: gvjs_ly(b[1]),
                bi: gvjs_ly(b[2]),
                wB: c
            });
            break;
        case gvjs_d:
        case gvjs_Ar:
            c = gvjs_ly(b[1]),
                b = {
                    yb: c,
                    bi: null
                }, this.dispatchEvent("serie" + a, b)
    }
};

function gvjs_9H(a) {
    this.ca = a
}
gvjs_r(gvjs_9H, gvjs_OE);
gvjs_9H.prototype.getKey = function(a) {
    return this.ca.MR(a)
};
gvjs_9H.prototype.getTitle = function(a) {
    return this.ca.rJ(a)
};
gvjs_9H.prototype.getContent = function(a, b, c) {
    var d = gvjs_1D(this.ca, c);
    return gvjs_$H(a, d, b.content || "", !0, a.Dla, this.ca.series[c.Ua])
};

function gvjs_aI(a) {
    this.ca = a
}
gvjs_r(gvjs_aI, gvjs_OE);
gvjs_aI.prototype.getKey = function(a) {
    return a.Ua
};
gvjs_aI.prototype.getTitle = function(a) {
    return gvjs_1D(this.ca, a)
};
gvjs_aI.prototype.getContent = function(a, b, c) {
    c = this.ca.rJ(c) || "";
    return [c ? gvjs_BD(b.content || "", a.OB, c, a.Ea) : null]
};

function gvjs_bI(a, b, c, d) {
    gvjs_NE.call(this, a, b, c, d)
}
gvjs_r(gvjs_bI, gvjs_NE);
gvjs_bI.prototype.s1 = function(a, b, c) {
    var d = a.ca,
        e = d.series[b];
    c = d.kD(b, c);
    var f = !1,
        g = null,
        h = null,
        k = null != d.Xb && d.Xb;
    if (d.Xb)
        if (f = !0, h = [this.U1, this.V1], g = e.type, g === gvjs_Hr) g = [{
            color: e.df.fill,
            alpha: e.df.fillOpacity
        }, {
            color: e.Uk.background.df.fill,
            alpha: e.Uk.background.df.fillOpacity
        }];
        else if (g === gvjs_j) g = b % 2 ? b - 1 : b, b = d.series[g], d = d.series[g + 1], g = [{
        color: d.df.fill,
        alpha: d.df.fillOpacity
    }, {
        color: b.df.fill,
        alpha: b.df.fillOpacity
    }];
    else throw Error("Diff chart not supported for the chosen chart type.");
    d = {
        entries: []
    };
    if (c.lines)
        for (c.title && gvjs_cI(this, d, c.title), e = 0; e < c.lines.length; e++) f = c.lines[e], f = (h = f.title) ? gvjs_BD(f.value, this.OB, h, this.Ea) : null, null != f && d.entries.push(f);
    else c.At && !c.ng ? (gvjs_cI(this, d, c.At), gvjs_dI(this, d, c.sk, c.content, !0, this.showColorCode, e, f, g, h, k)) : c.sk && !c.ng ? gvjs_dI(this, d, c.sk, c.content, !0, this.showColorCode, e, !0, g, h, k) : null != c.content && gvjs_dI(this, d, null, c.content, !1, this.showColorCode, e);
    this.kr(d, a.Rh);
    return d
};

function gvjs_eI(a, b, c, d) {
    var e = b.ca,
        f = new gvjs_9H(e),
        g = new gvjs_aI(e),
        h = null;
    d == gvjs_3r ? h = f : d == gvjs_iv && (h = g);
    if (h) var k = h.aggregate(c);
    else {
        d = f.aggregate(c);
        var l = g.aggregate(c);
        h = g;
        k = l;
        1 == d.order.length && 1 < l.order.length && (h = f, k = d)
    }
    var m = {
        entries: []
    };
    gvjs_v(k.order, function(n) {
        gvjs_cI(this, m, (k.Ds[n] || "").toString());
        gvjs_v(k.index[n], function(p) {
            var q = e.kD(p.Ua, p.category);
            q.ng ? gvjs_dI(this, m, null, q.content, !1, this.showColorCode, e.series[p.Ua]) : m.entries.push.apply(m.entries, h.getContent(this,
                q, p))
        }, this)
    }, a);
    a.kr(m, b.Rh, 0 < c.length);
    return m
}
gvjs_bI.prototype.t1 = function(a, b) {
    var c = a.ca,
        d = c.series[b],
        e = d.hc,
        f = null,
        g = null,
        h = null != c.Xb && c.Xb;
    c.Xb && (f = c.series.length, f = (b + f / c.pie.cc.length) % f, g = c.series[f], c = {
        color: d.brush.fill,
        alpha: d.brush.fillOpacity
    }, g = {
        color: g.brush.fill,
        alpha: g.brush.fillOpacity
    }, f = b > f ? [c, g] : [g, c], g = [this.U1, this.V1]);
    b = {
        entries: []
    };
    e.sk ? gvjs_dI(this, b, e.sk, e.content, !0, this.showColorCode, d, !0, f, g, h) : gvjs_dI(this, b, null, e.content, !1, this.showColorCode, d);
    this.kr(b, a.Rh);
    return b
};
gvjs_bI.prototype.p1 = function(a, b) {
    var c = a.ca,
        d = c.Fa[b].hc,
        e = !1,
        f = {
            entries: []
        };
    if (d && d.content) gvjs_dI(this, f, null, d.content, !1, !1);
    else {
        var g = 0,
            h = 1,
            k = c.series.length;
        gvjs_SF(c) && (g = c.series.length - 1, k = h = -1);
        for (var l = null; g != k; g += h) {
            var m = c.series[g];
            if (m.showTooltip) {
                d = gvjs_0D(c, g, b);
                if (l != m.sd) {
                    l = m.sd;
                    var n = c.Fa[b].Ds[l];
                    gvjs_1e(gvjs_Lh(n)) || gvjs_cI(this, f, n)
                }
                m.points[d] && m.points[d].hc && m.points[d].hc.content && (d = m.points[d].hc, gvjs_dI(this, f, d.sk, d.content, !0, this.showColorCode, m, void 0, void 0,
                    void 0, void 0, d.ng && d.Qf), e = !0)
            }
        }
    }
    null != a.Rh && 0 < a.Rh.length && (e = !0);
    this.kr(f, a.Rh);
    return e || this.Ela ? f : null
};

function gvjs_cI(a, b, c) {
    a = gvjs_BD(c, a.OB);
    b.entries.push(a)
}

function gvjs_$H(a, b, c, d, e, f, g, h, k, l, m) {
    g = void 0 === g ? !1 : g;
    d = d ? a.OB : a.Ea;
    c = c.split("\n");
    var n = e ? f.color.color : null;
    b = g && null != b ? gvjs_BD(b, a.Ea, null, null, n, f && f.cC) : gvjs_BD(c[0], d, b, a.Ea, n, f && f.cC, null, m);
    a = [b];
    for (g = g ? 0 : 1; g < c.length; g++) n = null != h ? h[g].color : e ? gvjs_e : null, b = gvjs_BD(c[g], d, null, null, n, null != h ? h[g].alpha : null, null != k ? k[g] : null, m), b.sB = l, a.push(b);
    return a
}

function gvjs_dI(a, b, c, d, e, f, g, h, k, l, m, n) {
    b.entries.push.apply(b.entries, gvjs_$H(a, c, d, e, f, g, h, k, l, m, n))
}
gvjs_bI.prototype.kr = function(a, b, c) {
    b && 0 !== b.length && ((void 0 == c || c) && a.entries.push(gvjs_DD()), gvjs_xf(a.entries, b))
};

function gvjs_fI(a, b, c) {
    gvjs_NE.call(this, a, b, c, void 0);
    this.U9 = this.OB;
    this.pN = gvjs_z(this.Ea);
    this.pN.color = gvjs_bq;
    this.pN.fontSize -= 2
}
gvjs_r(gvjs_fI, gvjs_bI);
gvjs_fI.prototype.s1 = function(a, b, c) {
    b = a.ca.series[b];
    a = b.points[c].hc;
    c = [];
    b.visibleInLegend || (b = gvjs_BD(b.title || "", this.U9), c.push(b));
    b = gvjs_BD(a.content, this.U9);
    c.push(b);
    a = gvjs_BD(a.At, this.pN);
    c.push(a);
    return {
        entries: c
    }
};
gvjs_fI.prototype.t1 = function() {
    return {
        entries: []
    }
};
gvjs_fI.prototype.p1 = function() {
    return {
        entries: []
    }
};

function gvjs_Pga(a, b, c) {
    this.oo = b;
    this.le = new gvjs_H(0, c.width, c.height, 0);
    gvjs_D(a, ["tooltip.ignoreBounds.left", gvjs_Wv], !1) ? this.le.left = -Infinity : this.le.left -= gvjs_E(a, ["tooltip.bounds.left", gvjs_Vv], 0);
    gvjs_D(a, ["tooltip.ignoreBounds.top", gvjs_Wv], !1) ? this.le.top = -Infinity : this.le.top -= gvjs_E(a, ["tooltip.bounds.top", gvjs_Vv], 0);
    gvjs_D(a, ["tooltip.ignoreBounds.right", gvjs_Wv], !1) ? this.le.right = Infinity : this.le.right += gvjs_E(a, ["tooltip.bounds.right", gvjs_Vv], 0);
    gvjs_D(a, ["tooltip.ignoreBounds.bottom",
        gvjs_Wv
    ], !1) ? this.le.bottom = Infinity : this.le.bottom += gvjs_E(a, ["tooltip.bounds.bottom", gvjs_Vv], 0);
    this.Nt = null;
    c = a.ha("tooltip.pivot.x");
    var d = a.ha("tooltip.pivot.y");
    null != c && typeof c === gvjs_f && isFinite(c) && null != d && typeof d === gvjs_f && isFinite(d) && (this.Nt = new gvjs_A(c, d));
    b = null != b.Tc && 0 < b.Tc.getEntries().length ? gvjs_Sr : gvjs_1s;
    this.UW = gvjs_C(a, gvjs__v, b, gvjs_TA)
}

function gvjs_gI(a) {
    if (a.chartType == gvjs_Ru) {
        var b = a.pie.center;
        return new gvjs_A(b.x, b.y)
    }
    b = gvjs_ux(a.hAxes);
    a = gvjs_ux(a.vAxes);
    return new gvjs_A(null != b.baseline ? b.baseline.oa : Math.min(b.je, b.Gd), null != a.baseline ? a.baseline.oa : Math.max(a.je, a.Gd))
}

function gvjs_Qga(a, b) {
    a.le = b
}

function gvjs_hI(a, b, c) {
    var d = b.W;
    b = gvjs_RF(b, c);
    a = gvjs_gI(a);
    b = 1 + Math.ceil(b / Math.sqrt(2));
    return new gvjs_A(d.x + (d.x >= a.x ? b : -b), d.y + (d.y <= a.y ? -b : b))
}

function gvjs_iI(a, b) {
    var c = gvjs_jy(a.pie.center, gvjs_hH(((b.sp ? 45 : (b.Bc + b.fc) / 2) / 180 - .5) * Math.PI, a.pie.radiusX, a.pie.radiusY));
    b = new gvjs_A(c.x + b.offset.x, c.y + b.offset.y);
    b.x = gvjs_7h(b.x, 0, a.width);
    b.y = gvjs_7h(b.y, 0, a.height);
    return b
}

function gvjs_jI(a) {
    var b = a.anchor ? a.anchor : new gvjs_A(0, 0),
        c = a.lines[0],
        d = a.textStyle.fontSize;
    return 270 == a.angle ? new gvjs_A(b.x + c.x + d, b.y + c.y - c.length / 2) : new gvjs_A(b.x + c.x + c.length / 2, b.y + c.y - d)
}

function gvjs_kI(a, b, c) {
    var d = a.series[b],
        e = d.type;
    c = gvjs_0D(a, b, c);
    b = d.points[c];
    if (!b) return new gvjs_A(0, 0);
    switch (a.chartType) {
        case gvjs_c:
        case gvjs_Bt:
            switch (e) {
                case gvjs_Hr:
                case gvjs_xv:
                    return d = b.W.bar || b.W, e = gvjs_gI(a), d = new gvjs_A(d.left + (d.left < e.x ? 0 : d.width), d.top + (d.top < e.y ? 0 : d.height)), gvjs_lI(a, d), d;
                case gvjs_d:
                case gvjs_Ar:
                case gvjs_j:
                    return gvjs_hI(a, b, d);
                case gvjs_2r:
                    return d = b.W.rect, e = gvjs_gI(a), d = new gvjs_A(d.left + d.width > e.x ? d.left + d.width : d.left, d.top < e.y ? d.top : d.top + d.height),
                        gvjs_lI(a, d), d
            }
        case gvjs_j:
            return gvjs_hI(a, b, d);
        case gvjs_Wr:
            e = b.W;
            d = gvjs_hI(a, b, d);
            if (d.x < a.chartArea.left || d.x > a.chartArea.right) d.x += 2 * (e.x - d.x);
            if (d.y < a.chartArea.top || d.y > a.chartArea.bottom) d.y += 2 * (e.y - d.y);
            return d
    }
    return new gvjs_A(0, 0)
}

function gvjs_lI(a, b) {
    a = a.chartArea;
    b.x = gvjs_7h(b.x, a.left, a.right);
    b.y = gvjs_7h(b.y, a.top, a.bottom)
}

function gvjs_mI(a, b, c, d) {
    var e = null,
        f = null,
        g = gvjs_ux(b.hAxes),
        h = gvjs_ux(b.vAxes),
        k = g.Sk,
        l = h.Sk,
        m = d;
    b.orientation && b.orientation !== gvjs_R ? (l = -l, h.type === gvjs_o && (m = b.Fa[d].data), f = h.position.Ld(m)) : (g.type === gvjs_o && (m = b.Fa[d].data), e = g.position.Ld(m));
    a = a.oo.Ea.fontSize;
    c.x = null === e ? c.x : e;
    c.y = null === f ? c.y : f;
    e = c.x - k * a;
    f = c.y + l * a;
    return new gvjs_A(e, f)
}

function gvjs_nI(a, b) {
    a = gvjs_jy(a.pie.center, gvjs_hH(((b.sp ? 45 : (b.Bc + b.fc) / 2) / 180 - .5) * Math.PI, a.pie.radiusX - .1, a.pie.radiusY - .1));
    return new gvjs_A(a.x + b.offset.x, a.y + b.offset.y)
}

function gvjs_oI(a) {
    var b = a.anchor ? a.anchor : new gvjs_A(0, 0),
        c = a.lines[0],
        d = a.textStyle.fontSize;
    return 270 == a.angle ? new gvjs_A(b.x + c.x + d / 2, b.y + c.y) : new gvjs_A(b.x + c.x, b.y + c.y - d / 2)
}

function gvjs_pI(a, b, c) {
    c = gvjs_0D(a, b, c);
    var d = a.series[b];
    b = d.type;
    c = d.points[c].W;
    if (b == gvjs_Hr || b == gvjs_xv || b == gvjs_2r) {
        var e = c.bar || c.rect || c;
        c = e.left;
        b = e.width;
        d = e.top;
        e = e.height;
        var f = d + e,
            g = gvjs_gI(a);
        a = a.orientation == gvjs_R ? f > g.y ? new gvjs_A(c + b / 2, f - .1) : new gvjs_A(c + b / 2, d + .1) : c < g.x ? new gvjs_A(c + .1, d + e / 2) : new gvjs_A(c + b - .1, d + e / 2)
    } else a = new gvjs_A(c.x, c.y);
    return a
}

function gvjs_qI(a, b, c, d, e, f) {
    if (null !== c && null !== d && null !== e) {
        var g = b.ca,
            h = g.series[c].points[d].Ib.labels[e],
            k = h.hc;
        k ? (f = gvjs_jI(h), h = gvjs_oI(h), k.Qf && k.ng ? (b = gvjs_gz(k.content || ""), a = gvjs_rI(a, b, f, h)) : (k = a.oo, d = {
            entries: [gvjs_BD(b.ca.series[c].points[d].Ib.labels[e].hc.content, k.Ea)]
        }, k.kr(d, b.Rh), a = gvjs_ED(d, g.Va, !1, f, a.le, h, void 0, g.md, g.Pr, g.Es))) : a = null
    } else if (null !== c && null !== d)
        if (g = b.ca, g.series[c].showTooltip)
            if (e = gvjs_kI(g, c, d), f = a.Nt ? gvjs_3x(e, a.Nt) : gvjs_pI(g, c, d), h = g.series[c].points[d].hc)
                if (typeof h.v1 ===
                    gvjs_c) {
                    b = h.v1(g, c, d);
                    d = null;
                    b instanceof gvjs_vh ? d = b : typeof b === gvjs_m && (d = gvjs_7m.sanitize(b));
                    if (!d) throw Error("Custom calc function for tooltip content should produce string literal or safe HTML.");
                    a = gvjs_rI(a, d, e, f)
                } else h.Qf && h.ng ? (b = gvjs_gz(h.content || ""), a = gvjs_rI(a, b, e, f)) : (b = a.oo.s1(b, c, d), a = gvjs_ED(b, g.Va, !0, e, a.le, f, void 0, g.md, g.Pr, g.Es));
    else a = null;
    else a = null;
    else null !== c && null === d ? (e = b.ca, f = e.series[c], null == f.offset ? a = null : (d = gvjs_iI(e, f), f = gvjs_nI(e, f), g = e.series[c].hc, g.Qf &&
        g.ng ? (b = gvjs_gz(g.content || ""), a = gvjs_rI(a, b, d, f)) : (b = a.oo.t1(b, c), a = gvjs_ED(b, e.Va, !0, d, a.le, f, void 0, e.md, e.Pr, e.Es)))) : null === c && null !== d && null !== e ? (f = b.ca, g = f.Fa[d].Ib.labels[e], (h = g.hc) ? (c = gvjs_jI(g), g = gvjs_oI(g), h.Qf && h.ng ? (b = gvjs_gz(h.content || ""), a = gvjs_rI(a, b, c, g)) : (h = a.oo, d = b.ca.Fa[d], d = {
        entries: [gvjs_BD((d.Ib && d.Ib.labels[e]).hc.content, h.Ea)]
    }, 0 < b.Rh.length && h.kr(d, b.Rh), a = gvjs_ED(d, f.Va, !1, c, a.le, g, void 0, f.md, f.Pr, f.Es))) : a = null) : null === c && null !== d ? (c = b.ca, e = f.clone(), f = gvjs_mI(a, c,
        e, d), e = a.Nt ? gvjs_3x(f, a.Nt) : e, (g = c.Fa[d].hc) && g.Qf && g.ng ? (b = gvjs_gz(g.content), a = gvjs_rI(a, b, f, e)) : (b = a.oo.p1(b, d), a = null === b ? null : gvjs_ED(b, c.Va, !1, f, a.le, e, void 0, c.md, c.Pr, c.Es))) : a = null;
    return a
}

function gvjs_Rga(a, b, c, d, e) {
    var f = b.ca;
    d = d.clone();
    var g = gvjs_mI(a, f, d, c[c.length - 1]);
    d = a.Nt ? gvjs_3x(g, a.Nt) : d;
    var h = [];
    c.forEach(function(k) {
        f.series.forEach(function(l, m) {
            h.push({
                Ua: m,
                category: k
            })
        })
    });
    b = gvjs_eI(a.oo, b, h, e);
    return null === b ? null : gvjs_ED(b, f.Va, !1, g, a.le, d, void 0, f.md, f.Pr, f.Es)
}

function gvjs_rI(a, b, c, d) {
    return {
        html: gvjs_Ah(gvjs_5b, {
            "class": gvjs_jt
        }, b),
        wI: !0,
        pivot: d,
        anchor: c,
        ut: a.le,
        spacing: 20,
        margin: 5
    }
};

function gvjs_sI(a, b, c, d, e, f) {
    this.Tc = f;
    d == gvjs_Fs || this.Tc ? null != this.Tc && this.Tc.updateOptions(a, c) : this.Tc = new gvjs_HD(a, c);
    c = d == gvjs_Fs ? new gvjs_fI(a, c, e) : new gvjs_bI(a, c, e, this.Tc);
    this.Ol = new gvjs_Pga(a, c, b)
}

function gvjs_tI(a, b, c) {
    var d = {};
    if (null != c.legend.Dg) {
        d.legend = d.legend || {};
        var e = b.legend,
            f = c.legend.Dg;
        d.legend.Zq = e.nd[f];
        var g = f + 1 + "/" + e.nd.length,
            h = e.wF.WU,
            k = 0 < f;
        e = e.wF.cU;
        f = f < b.legend.nd.length - 1;
        d.legend.wF = {
            WU: {
                brush: k ? h.ab.active : h.ab.gK,
                active: k
            },
            cU: {
                brush: f ? e.ab.active : e.ab.gK,
                active: f
            },
            FU: {
                text: g,
                lines: {
                    0: {
                        text: g
                    }
                }
            }
        }
    }
    a.Uo(b, c, d);
    return d
}
gvjs_sI.prototype.setAction = function(a) {
    this.Tc && gvjs_ID(this.Tc, a)
};
gvjs_sI.prototype.getAction = function(a) {
    if (this.Tc) return this.Tc.getAction(a)
};
gvjs_sI.prototype.removeAction = function(a) {
    this.Tc && this.Tc.removeEntry(a)
};

function gvjs_uI(a, b, c, d, e, f, g) {
    gvjs_sI.call(this, a, b, c, d, e, g);
    this.tI = a.Ca("crosshair.trigger", gvjs_tea);
    this.zca = gvjs_C(a, ["crosshair.selected.orientation", gvjs_ps], gvjs_Sr, gvjs_UA);
    this.wca = gvjs_C(a, ["crosshair.focused.orientation", gvjs_ps], gvjs_Sr, gvjs_UA);
    this.xca = a.Bu(["crosshair.selected.color", gvjs_ns]);
    this.uca = a.Bu(["crosshair.focused.color", gvjs_ns]);
    this.yca = gvjs_Lw(a, ["crosshair.selected.opacity", gvjs_os], 1);
    this.vca = gvjs_Lw(a, ["crosshair.focused.opacity", gvjs_os], 1);
    this.OO = gvjs_C(a,
        "aggregationTarget", gvjs_e, gvjs_wea);
    this.eK = !0
}
gvjs_r(gvjs_uI, gvjs_sI);
gvjs_uI.prototype.Uo = function(a, b, c) {
    this.eK = !0;
    switch (a.Jy) {
        case gvjs_xs:
            this.HQ(a, b, c);
            break;
        case gvjs_Fs:
            gvjs_Sga(this, a, b, c)
    }
};
gvjs_uI.prototype.z2 = function(a, b) {
    return a.equals(b, this.eK)
};

function gvjs_Tga(a) {
    return a.series.some(function(b) {
        return b.enableInteractivity
    })
}

function gvjs_vI(a, b, c) {
    a.series = a.series || {};
    a = a.series;
    a[b] = a[b] || {};
    b = a[b];
    b.points = b.points || {};
    b = b.points;
    a = b[c] || {};
    return b[c] = a
}

function gvjs_wI(a, b, c) {
    if (null != b) return a = gvjs_vI(a, b, c), a.Ib = a.Ib || {}, a.Ib;
    a = gvjs_xI(a, c);
    a.Ib = a.Ib || {};
    return a.Ib
}

function gvjs_yI(a, b) {
    a.series = a.series || [];
    a = a.series;
    a[b] = a[b] || {};
    return a[b]
}

function gvjs_xI(a, b) {
    a.Fa = a.Fa || {};
    a = a.Fa;
    a[b] = a[b] || {};
    return a[b]
}

function gvjs_zI(a, b) {
    a.legend = a.legend || {};
    a = a.legend;
    a.Zq = a.Zq || {};
    a = a.Zq;
    a[b] = a[b] || {};
    return a[b]
}
gvjs_uI.prototype.HQ = function(a, b, c) {
    var d = {
            ca: a,
            Rh: this.Tc.getEntries(),
            Nr: c,
            Sh: b.fg
        },
        e = b.fg.focused.Zt;
    null != e && (b.fg.focused.action = this.Tc.getAction(e).action);
    e = this.Ol.UW;
    var f = e == gvjs_fv || e == gvjs_Sr;
    e = e == gvjs_1s || e == gvjs_Sr;
    for (var g = this.OO != gvjs_e, h = this.Tc && 0 < d.Rh.length, k = gvjs_Jo(b.selected), l = 1 < k.length && (g || h), m = 0; m < k.length; ++m) {
        var n = k[m],
            p = n.column,
            q = a.wm[p],
            r = q.yb;
        if (n = a.sJ({
                column: p,
                row: n.row
            })) switch (q.role) {
            case gvjs_ts:
                gvjs_AI(this, a, n.Ua, n.category, c);
                f && !l && gvjs_BI(this, d, n.Ua,
                    n.category);
                break;
            case gvjs_nr:
                if (null != r ? a.series[r].enableInteractivity : a.enableInteractivity) q = q.Hz, null != q && (gvjs_Uga(n.Ua, n.category, q, c), f && gvjs_CI(this, d, n.Ua, n.category, q))
        }
    }
    f && l && !a.wu && (k = k.map(function(t) {
        return a.sJ({
            column: t.column,
            row: t.row
        })
    }).filter(function(t) {
        return null != t
    }), 0 < k.length && gvjs_Vga(this, d, g ? k : [], k[k.length - 1]));
    k = gvjs_Ho(b.selected, gvjs_Vb);
    for (l = 0; l < k.length; ++l) m = a.wm[k[l]], null != m && (m = m.yb, null != m && gvjs_DI(this, a, m, c));
    k = a.chartType === gvjs_Wr;
    l = gvjs_Io(b.selected);
    g = 1 < l.length && (g || h);
    for (h = 0; h < l.length; ++h) m = a.Go[l[h]], k ? (gvjs_AI(this, a, 0, m, c), f && !g && gvjs_BI(this, d, 0, m)) : (gvjs_Wga(this, a, m, c), f && !g && gvjs_EI(this, d, b.cursor.RU, m));
    g && (k ? gvjs_BI(this, d, 0, a.Go[l[l.length - 1]]) : f && (f = l.map(function(t) {
        return a.Go[t]
    }), 0 < f.length && gvjs_Xga(this, d, b.cursor.RU, f)));
    f = b.focused.Ua;
    g = b.focused.datum;
    null != g ? a.series[f].enableInteractivity && (gvjs_FI(this, a, f, g, c), e && gvjs_BI(this, d, f, g), gvjs_Yga(a, f, g, c)) : null != f && a.series[f].enableInteractivity && gvjs_GI(this, a, f, c);
    f = b.legend.focused.Ob;
    null != f && a.series[f].enableInteractivity && gvjs_GI(this, a, f, c);
    f = b.focused.category;
    null != f && a.Fa[f] && (gvjs_Zga(this, a, f, c), e && gvjs_Tga(d.ca) && (gvjs_EI(this, d, b.cursor.position, f), this.eK = !1));
    if (f = b.annotations.cJ) f = gvjs_wI(c, f.yb, f.CQ), f.jm = f.jm || {}, f.jm.c5 = !0;
    (f = b.annotations.focused) && e && (g = a.wm[f.column], e = g.yb, f = a.Go[f.row], g = g.Hz, (null != e ? a.series[e].enableInteractivity : a.enableInteractivity) && gvjs_CI(this, d, e, f, g));
    if (b = b.cf) c.cf = b
};

function gvjs_FI(a, b, c, d, e) {
    var f = b.series[c],
        g = f.points[d];
    if (!gvjs_MF(g) && g.W && (!gvjs_NF(f) || 0 != f.lineWidth || gvjs_OF(g, f))) {
        var h = f.type == gvjs_Hr ? gvjs__ga : gvjs_0ga;
        d = gvjs_vI(e, c, d);
        d.Mm = {};
        c = d.Mm;
        c.levels = [];
        for (e = 0; e < h.length; e++) {
            var k = {
                brush: new gvjs__({
                    fill: gvjs_e,
                    stroke: gvjs_Or,
                    strokeOpacity: h[e],
                    strokeWidth: 1
                })
            };
            c.levels.push(k)
        }
        switch (f.type) {
            case gvjs_Hr:
            case gvjs_xv:
            case gvjs_2r:
                a = g.W.bar || g.W.rect || g.W;
                a = new gvjs_0(a.left, a.top, a.width, a.height);
                for (b = 0; b < h.length; b++) f = c.levels[b].brush.strokeWidth,
                    c.levels[b].rect = new gvjs_0(a.left - f / 2, a.top - f / 2, a.width + f, a.height + f), a.left -= f, a.top -= f, a.width += 2 * f, a.height += 2 * f;
                break;
            case gvjs_d:
            case gvjs_Ar:
            case gvjs_j:
            case gvjs_Yr:
                d.visible = !0;
                c.x = g.W.x;
                c.y = g.W.y;
                if (a.tI === gvjs_Sr || a.tI === gvjs_1s) e = gvjs_LF(g, f), e = gvjs_dy(a.uca || e.fill, 1, !1, a.vca), gvjs_HI(b, g, d, e, a.wca);
                d.Fh ? (a = d.Fh, a = a.radius + a.brush.strokeWidth / 2) : a = gvjs_RF(g, f);
                for (b = 0; b < h.length; b++) f = c.levels[b].brush.strokeWidth, c.levels[b].radius = a + f / 2, a += f
        }
    }
}

function gvjs_GI(a, b, c, d) {
    var e = b.series[c];
    if (gvjs_NF(e) && 0 < e.lineWidth) {
        var f = gvjs_yI(d, c);
        f.Mm = {};
        f = f.Mm;
        f.levels = [];
        var g = e.type == gvjs_Ar ? b.Jl !== gvjs_e ? gvjs_UF(e) : gvjs_TF(e, !1) : gvjs_TF(e, b.interpolateNulls);
        g = gvjs_KF(g);
        for (var h = e.Lb.strokeWidth / 2, k = 0; k < gvjs_II.length; k++) {
            var l = new gvjs__({
                    fill: gvjs_e,
                    stroke: gvjs_Or,
                    strokeOpacity: gvjs_II[k],
                    strokeWidth: 1
                }),
                m = gvjs_IA(g, h + l.strokeWidth / 2);
            f.levels.push({
                brush: l,
                path: m
            });
            h += l.strokeWidth
        }
    }
    f = (f = (f = d.series) && f[c]) && f.points;
    for (g = 0; g < e.points.length; ++g) h =
        e.points[g], gvjs_MF(h) || (gvjs_OF(h, e) || f && f[g] && f[g].visible) && gvjs_FI(a, b, c, g, d);
    b.Xb && e.type === gvjs_j && !a.yF(e.columns) && gvjs_GI(a, b, c - 1, d)
}
gvjs_uI.prototype.yF = function(a) {
    a = a[gvjs_Eu];
    return null != a && 0 < a.length
};

function gvjs_Zga(a, b, c, d) {
    for (var e = b.series, f = 0; f < e.length; ++f) {
        var g = gvjs_0D(b, f, c);
        b.series[f].enableInteractivity && null != g && gvjs_FI(a, b, f, g, d)
    }
}

function gvjs_AI(a, b, c, d, e) {
    var f = b.series[c],
        g = f.points[d];
    if (!gvjs_MF(g) && g.W && (!gvjs_NF(f) || 0 != f.lineWidth || gvjs_OF(g, f))) {
        var h = gvjs_LF(g, f);
        c = gvjs_vI(e, c, d);
        c.Fh = {};
        d = c.Fh;
        var k = b.vH;
        e = 1;
        null == k && (k = gvjs_jw, e = 0);
        switch (f.type) {
            case gvjs_Hr:
            case gvjs_xv:
            case gvjs_2r:
                e = 1;
                d.brush = new gvjs__(gvjs_Hw);
                d.brush.Jc(k);
                f.type == gvjs_2r && (a = gvjs_ei(gvjs_$h(h.fill).hex), b = gvjs_ei(gvjs_$h(k).hex), f = gvjs_ei(gvjs_$h(g.hx.fill).hex), d.brush.Jc(gvjs_di(gvjs_0x(f, [a, b]))));
                gvjs_yw(d.brush, e);
                d.brush.vi(1);
                g = g.W.bar ||
                    g.W.rect || g.W;
                h = h.strokeWidth;
                a = d.brush.strokeWidth;
                d.rect = new gvjs_0(g.left + h / 2 + 1.5 + a / 2, g.top + h / 2 + 1.5 + a / 2, g.width - (h + 3 + a), g.height - (h + 3 + a));
                (0 >= d.rect.width || 0 >= d.rect.height) && delete c.Fh;
                break;
            case gvjs_d:
            case gvjs_Ar:
            case gvjs_j:
            case gvjs_Yr:
                c.visible = !0;
                d.x = g.W.x;
                d.y = g.W.y;
                if (a.tI === gvjs_Sr || a.tI === gvjs_fv) {
                    var l = gvjs_dy(a.xca || h.fill, 1, !1, a.yca);
                    gvjs_HI(b, g, c, l, a.zca)
                }
                d.brush = new gvjs__({
                    fill: k,
                    fillOpacity: e,
                    stroke: h.fill,
                    strokeWidth: 1
                });
                d.radius = gvjs_RF(g, f) + 1.5 + d.brush.strokeWidth / 2
        }
    }
}

function gvjs_HI(a, b, c, d, e) {
    c.crosshair = c.crosshair || {};
    c = c.crosshair;
    c.x = b.W.x;
    c.y = b.W.y;
    c.brush = d;
    b = new gvjs_A(a.chartArea.left, c.y);
    d = new gvjs_A(a.chartArea.right, c.y);
    var f = new gvjs_A(c.x, a.chartArea.top);
    a = new gvjs_A(c.x, a.chartArea.bottom);
    c.path = c.path || new gvjs_uz;
    if (e === gvjs_Sr || e === gvjs_S)
        for (a = gvjs_wz([f, a]), f = 0; f < a.Cb.length - 1; f++) c.path.kh(a.Cb[f]);
    if (e === gvjs_Sr || e === gvjs_R)
        for (e = gvjs_wz([b, d]), a = 0; a < e.Cb.length - 1; a++) c.path.kh(e.Cb[a]);
    c.path.close()
}

function gvjs_DI(a, b, c, d) {
    var e = b.series[c];
    if ((e.type == gvjs_d || e.type == gvjs_Ar || e.type == gvjs_j) && 0 < e.lineWidth) {
        var f = gvjs_yI(d, c);
        f.Fh = {};
        f = f.Fh;
        var g = e.type == gvjs_Ar ? b.Jl !== gvjs_e ? gvjs_UF(e) : gvjs_TF(e, !1) : gvjs_TF(e, b.interpolateNulls);
        g = gvjs_KF(g);
        f.brush = new gvjs__({
            stroke: e.Lb.stroke,
            strokeWidth: Math.min(1, e.Lb.strokeWidth / 2)
        });
        f.path = gvjs_IA(g, -(e.Lb.strokeWidth / 2 + 2 + f.brush.strokeWidth / 2))
    }
    for (f = 0; f < e.points.length; ++f) g = e.points[f], gvjs_MF(g) || (gvjs_OF(g, e) || gvjs_PF(e, f) && !b.interpolateNulls) &&
        gvjs_AI(a, b, c, f, d);
    b.Xb && e.type === gvjs_j && !a.yF(e.columns) && gvjs_DI(a, b, c - 1, d)
}

function gvjs_Wga(a, b, c, d) {
    for (var e = b.series, f = 0; f < e.length; ++f) {
        var g = gvjs_0D(b, f, c);
        null != g && gvjs_AI(a, b, f, g, d)
    }
}

function gvjs_JI(a, b, c, d) {
    c = gvjs_vI(b.Nr, c.Ua, c.category);
    var e = null != b.Sh;
    c.tooltip = d;
    e && a.Tc.Uo(d, b.Sh, c.tooltip)
}

function gvjs_BI(a, b, c, d) {
    var e = gvjs_qI(a.Ol, b, c, d, null);
    null != e && gvjs_JI(a, b, {
        Ua: c,
        category: d
    }, e)
}

function gvjs_Vga(a, b, c, d) {
    var e = a.Ol;
    var f = a.OO,
        g = b.ca,
        h = gvjs_kI(g, d.Ua, d.category),
        k = gvjs_pI(g, d.Ua, d.category);
    c = gvjs_eI(e.oo, b, c, f);
    e = gvjs_ED(c, g.Va, !0, h, e.le, k, void 0, g.md, g.Pr, g.Es);
    gvjs_JI(a, b, d, e)
}

function gvjs_Xga(a, b, c, d) {
    if (c) {
        c = gvjs_Rga(a.Ol, b, d, c, a.OO);
        d = gvjs_xI(b.Nr, d[d.length - 1]);
        var e = null != b.Sh;
        d.tooltip = c;
        e && a.Tc.Uo(c, b.Sh, d.tooltip)
    }
}

function gvjs_EI(a, b, c, d) {
    if (c) {
        var e = gvjs_xI(b.Nr, d),
            f = null != b.Sh;
        c = gvjs_qI(a.Ol, b, null, d, null, c);
        null !== c && (e.tooltip = c, f && a.Tc.Uo(c, b.Sh, e.tooltip))
    }
}

function gvjs_CI(a, b, c, d, e) {
    if (null != c && null != e) {
        var f = gvjs_wI(b.Nr, c, d);
        f.labels = f.labels || {};
        f = f.labels;
        f[e] = f[e] || {};
        f = f[e];
        var g = null != b.Sh;
        c = gvjs_qI(a.Ol, b, c, d, e);
        f.iG = c || void 0;
        g && c && a.Tc.Uo(c, b.Sh, f.iG)
    }
}

function gvjs_Yga(a, b, c, d) {
    if (a.Ag) {
        var e = a.Ag;
        a = gvjs_eG(e.scale, e.IC, [{
            value: a.series[b].points[c].fe.color
        }], a.Va);
        d.Ag = {
            definition: a
        }
    }
}

function gvjs_Uga(a, b, c, d) {
    a = gvjs_wI(d, a, b);
    a.labels = a.labels || {};
    a = a.labels;
    a[c] = a[c] || {};
    c = a[c];
    c.textStyle = c.textStyle || {};
    c.textStyle.bold = !0
}

function gvjs_Sga(a, b, c, d) {
    var e = {
            ca: b,
            Rh: [],
            Nr: d,
            Sh: null
        },
        f = c.focused.Ua,
        g = c.focused.datum;
    b.legend && gvjs_Qga(a.Ol, new gvjs_H(0, b.legend.area.left, b.height, 0));
    var h = a.Ol.UW;
    if (null != f && null == g) {
        var k = c.cursor.position.x,
            l = b.series[f].points;
        g = l.filter(function(p) {
            return null != p
        });
        for (var m = 0; m < g.length && g[m].W.x < k;) m++;
        0 == m ? g = 0 : m == g.length ? g = g.length - 1 : (k = k < gvjs_Ux(g[m - 1].W.x, g[m].W.x) ? m - 1 : m, g = l.indexOf(g[k]));
        a.eK = !1
    }
    l = null;
    if (null != g)
        for (l = gvjs_vI(d, f, g), l.visible = !0, h == gvjs_1s && gvjs_BI(a, e, f,
                g), b.legend && (gvjs_zI(d, f).Ie = {
                isVisible: b.C8
            }), l = 0; l < b.series.length; l++) l != f && (b.legend && (gvjs_zI(d, l).ka = {
            textStyle: {
                color: "#CCCCCC"
            }
        }), g = gvjs_yI(d, l), g.Lb = b.series[l].Lb.clone(), gvjs_yw(g.Lb, .3));
    if (f = c.annotations.cJ) f = gvjs_wI(d, f.yb, f.CQ), f.jm = f.jm || {}, f.jm.c5 = !0;
    if (g = c.annotations.focused) l = b.wm[g.column], f = l.yb, g = b.Go[g.row], l = l.Hz, (null != f ? b.series[f].enableInteractivity : b.enableInteractivity) && gvjs_CI(a, e, f, g, l);
    if (b.legend && b.legend.position == gvjs_Yt && null != c.legend.focused.Ob) {
        c = c.legend.focused.Ob;
        gvjs_zI(d, c).Ie = {
            isVisible: b.C8
        };
        f = b.series[c].points;
        for (l = f.length - 1; 0 <= l; l--)
            if (g = f[l], !gvjs_MF(g) && g.W && (new gvjs_H(b.chartArea.top, b.chartArea.right, b.chartArea.bottom, b.chartArea.left)).contains(new gvjs_A(g.W.x, g.W.y))) {
                var n = l;
                break
            }
        null != n && (l = gvjs_vI(d, c, n), l.visible = !0, h == gvjs_1s && gvjs_BI(a, e, c, n));
        for (a = 0; a < b.series.length; a++) a != c && (gvjs_zI(d, a).ka = {
            textStyle: {
                color: "#CCCCCC"
            }
        }, e = gvjs_yI(d, a), e.Lb = b.series[a].Lb.clone(), gvjs_yw(e.Lb, .3))
    }
}
var gvjs_0ga = [.25, .1, .05],
    gvjs_II = [.3, .1, .05],
    gvjs__ga = [.3, .15, .05];

function gvjs_KI(a, b) {
    this.so = a;
    this.Dt = b;
    this.yh = gvjs_z(a);
    var c = a.width != b.width || a.height != b.height;
    !c && a.chartArea && b.chartArea && (c = a.chartArea.width != b.chartArea.width || a.chartArea.height != b.chartArea.height || a.chartArea.left != b.chartArea.left || a.chartArea.top != b.chartArea.top);
    this.yh.title && c && (this.yh.title.textStyle.opacity = 0);
    this.yh.hAxes && (this.yh.hAxes = gvjs_tx(this.yh.hAxes, gvjs_z), this.Gea = gvjs_tx(a.hAxes, function(d, e) {
            return gvjs_LI(a.hAxes[e], b.hAxes[e], this.yh.hAxes[e], !0, !1, c)
        },
        this));
    this.yh.vAxes && (this.yh.vAxes = gvjs_tx(this.yh.vAxes, gvjs_z), this.kna = gvjs_tx(a.vAxes, function(d, e) {
        return gvjs_LI(a.vAxes[e], b.vAxes[e], this.yh.vAxes[e], !1, !0, c)
    }, this));
    this.tk = this.Ug = null;
    gvjs_1ga(this);
    this.D5 = this.C5 = null;
    gvjs_2ga(this)
}

function gvjs_LI(a, b, c, d, e, f) {
    if (!a || !b) return null;
    var g = gvjs_z(a),
        h = gvjs_z(a);
    h.Nl = b.Nl;
    h.je = b.je;
    h.Gd = b.Gd;
    c.title && f && (c.title.textStyle.opacity = 0);
    if (a.type == gvjs_o && b.type == gvjs_o && a.dataType === b.dataType) {
        a.baseline && b.baseline && (h.baseline = b.baseline, c.baseline = gvjs_z(c.baseline));
        h.number = gvjs_z(h.number);
        h.position = gvjs_z(h.position);
        c.number = gvjs_z(c.number);
        c.position = gvjs_z(c.position);
        h.position.Ld = b.position.Ld;
        if (a.gridlines && b.gridlines) {
            h.gridlines = gvjs_wf(h.gridlines);
            c.gridlines =
                gvjs_wf(c.gridlines);
            f = h.gridlines;
            for (var k = c.gridlines, l = 0; l < f.length; l++) {
                f[l] = gvjs_z(f[l]);
                k[l] = gvjs_z(k[l]);
                var m = f[l],
                    n = a.number.Ld(m.Oa);
                n = b.number.Ai(n);
                m.oa = b.position.Ld(n)
            }
        }
        if (a.text && b.text)
            for (h.text = gvjs_wf(h.text), c.text = gvjs_wf(c.text), f = h.text, c = c.text, gvjs_MI(f), gvjs_MI(c), c = 0; c < f.length; c++) gvjs_3ga(a, b, a.text[c], b.text[c], f[c], d, e)
    } else if (a.text && b.text) {
        var p = gvjs_wy(a.text, b.text, function(q, r) {
            return q.Oa == r.Oa
        });
        g.text = a.text.filter(function(q, r) {
            return null != p.R5[r]
        });
        h.text =
            b.text.filter(function(q, r) {
                return null != p.S5[r]
            });
        c.text = gvjs_wf(g.text);
        gvjs_MI(g.text);
        gvjs_MI(h.text);
        gvjs_MI(c.text)
    }
    return [g, h]
}

function gvjs_3ga(a, b, c, d, e, f, g) {
    var h = e.ka,
        k = a.number.Ld(e.Oa);
    k = b.number.Ai(k);
    a = a.position.Ld(e.Oa);
    b = b.position.Ld(k);
    null != a && null != b && (f && (h.anchor.x = b + (c.ka.anchor.x - a), d && (h.anchor.y = d.ka.anchor.y)), g && (h.anchor.y = b + (c.ka.anchor.y - a), d && (h.anchor.x = d.ka.anchor.x)))
}

function gvjs_MI(a) {
    a.forEach(function(b, c) {
        a[c] = gvjs_z(a[c]);
        b = a[c];
        b.ka = gvjs_z(b.ka);
        b = b.ka;
        b.anchor && (c = b.anchor, b.anchor = new gvjs_vF(c.x, c.y))
    })
}

function gvjs_1ga(a) {
    var b = a.so,
        c = a.Dt;
    if (b.series && c.series) {
        var d = gvjs_wy(b.series, c.series, function(e, f) {
            return e.id == f.id
        });
        a.Ug = b.series.filter(function(e, f) {
            return null != d.R5[f]
        });
        a.tk = c.series.filter(function(e, f) {
            return null != d.S5[f]
        });
        b.chartType == gvjs_c || b.chartType == gvjs_j ? (b = null == b.orientation || b.orientation == gvjs_R ? b.hAxes[0] : b.vAxes[0], c = null == c.orientation || c.orientation == gvjs_R ? c.hAxes[0] : c.vAxes[0], b.type == gvjs_o && c.type == gvjs_o && b.dataType === c.dataType ? gvjs_4ga(a, b.number.Ld, b.number.Ai) :
            gvjs_5ga(a)) : b.chartType == gvjs_Wr && gvjs_6ga(a)
    }
}

function gvjs_5ga(a) {
    var b = a.so.Fa,
        c = a.Dt.Fa;
    if (b && c) {
        var d = {},
            e = {},
            f = {},
            g = {};
        b.forEach(function(p, q) {
            null != p.data && (f[p.data] = q)
        });
        c.forEach(function(p, q) {
            null != p.data && (g[p.data] = q)
        });
        b.forEach(function(p, q) {
            null != p.data && (d[q] = g[p.data])
        });
        c.forEach(function(p, q) {
            null != p.data && (p = f[p.data], d[p] !== q && (p = null), e[q] = p)
        });
        b.forEach(function(p, q) {
            null != p.data && e[g[p.data]] !== q && (d[q] = null)
        });
        for (var h = 0, k = 0, l = [], m = []; h < b.length || k < c.length;) h < b.length && null == d[h] ? (m.push({
            wt: {
                idx: h,
                cu: !0
            },
            xt: {
                idx: k,
                cu: !1
            }
        }), l.push({
            data: b[h].data
        }), h++) : (k < c.length && null == e[k] ? (m.push({
            wt: {
                idx: h,
                cu: !1
            },
            xt: {
                idx: k,
                cu: !0
            }
        }), l.push({
            data: c[k].data
        })) : (m.push({
            wt: {
                idx: h,
                cu: !0
            },
            xt: {
                idx: k,
                cu: !0
            }
        }), l.push({
            data: b[h].data
        }), h++), k++);
        a.yh.Fa = l;
        var n = function(p, q) {
            return 0 == q ? p[0] : q >= p.length ? gvjs_nf(p) : gvjs_NI(p[q - 1], p[q], .5)
        };
        a.so.Xb ? gvjs_OI(a, m, function(p, q, r, t) {
            return q.cu ? p[q.idx * r + t] : n(p, q.idx * r + t)
        }) : gvjs_PI(a, m, function(p, q) {
            return q.cu ? p[q.idx] : n(p, q.idx)
        })
    }
}

function gvjs_4ga(a, b, c) {
    var d = a.so.Fa,
        e = a.Dt.Fa;
    if (d && e)
        if (0 == d.length || 0 == e.length) a.yh.Fa = [], gvjs_PI(a, [], function() {
            return null
        });
        else {
            var f = function(l) {
                    return b(l.data)
                },
                g = [],
                h = [];
            if (d.length === e.length)
                for (var k = 0; k < d.length; k++) h.push({
                    wt: k,
                    xt: k
                }), g.push({
                    data: c(gvjs_Ux(f(d[k]), f(e[k])))
                });
            else gvjs__da(d, e, f).forEach(function(l) {
                var m = l.ax;
                l = l.bx;
                var n;
                null != d[m] && null != e[l] && (n = c(gvjs_Ux(f(d[m]), f(e[l]))));
                null != n && (h.push({
                    wt: m,
                    xt: l
                }), g.push({
                    data: n
                }))
            });
            a.yh.Fa = g;
            a.so.Xb ? gvjs_OI(a, h, function(l,
                m, n, p) {
                return l[m * n + p]
            }) : gvjs_PI(a, h, function(l, m) {
                return l[m]
            })
        }
}

function gvjs_6ga(a) {
    function b(l) {
        l = gvjs_z(l);
        l.W = gvjs_z(l.W);
        l.W.brush = l.W.brush.clone();
        l.W.brush.Qd(0);
        gvjs_yw(l.W.brush, 0);
        l.textStyle = gvjs_z(l.textStyle);
        l.textStyle.opacity = 0;
        return l
    }
    var c = a.Ug[0].points,
        d = a.tk[0].points,
        e = [],
        f = [],
        g = [],
        h = {};
    d.forEach(function(l, m) {
        null != l && (void 0 === h[l.id] && (h[l.id] = []), h[l.id].push(m))
    });
    gvjs_y(c, function(l, m) {
        if (null != l) {
            var n = l.id && h[l.id];
            n = n && n.shift();
            void 0 !== n ? g.push({
                wt: m,
                xt: n
            }) : e.push(l)
        }
    });
    gvjs_y(h, function(l) {
        l.forEach(function(m) {
            f.push(d[m])
        })
    });
    gvjs_PI(a, g, function(l, m) {
        return l[m]
    });
    c = e.map(b);
    var k = f.map(b);
    a.Ug[0].Sx = e.concat(k);
    a.tk[0].Sx = c.concat(f)
}

function gvjs_PI(a, b, c) {
    for (var d = 0; d < a.Ug.length; d++) {
        var e = a.Ug[d].points,
            f = a.tk[d].points,
            g = [],
            h = [];
        if (a.Ug[d].Fe) g = gvjs_wf(a.Ug[d].points), h = gvjs_wf(a.tk[d].points);
        else
            for (var k = 0; k < b.length; k++) {
                var l = b[k],
                    m = c(e, l.wt);
                l = c(f, l.xt);
                m && l && (g.push(m), h.push(l))
            }
        a.Ug[d] = gvjs_QI(a.Ug[d], g);
        a.tk[d] = gvjs_QI(a.tk[d], h)
    }
}

function gvjs_OI(a, b, c) {
    for (var d = 0; d < a.Ug.length; d++) {
        var e = a.Ug[d].points,
            f = a.tk[d].points,
            g = [],
            h = [];
        if (0 < b.length)
            for (var k = Math.ceil(e.length / b.length), l = Math.ceil(f.length / b.length), m = 0; m < b.length; m++) {
                for (var n = b[m], p = 0; p < k; p++) {
                    var q = c(e, n.wt, k, p);
                    q && g.push(q)
                }
                for (p = 0; p < l; p++)(q = c(f, n.xt, l, p)) && h.push(q)
            }
        a.Ug[d] = gvjs_QI(a.Ug[d], g);
        a.tk[d] = gvjs_QI(a.tk[d], h)
    }
}

function gvjs_QI(a, b) {
    a = gvjs_z(a);
    a.points = b;
    return a
}

function gvjs_2ga(a) {
    var b = a.so,
        c = a.Dt;
    b.legend && b.legend.nd && c.legend && c.legend.nd && (a.yh.legend = null)
}

function gvjs_RI(a, b, c) {
    if (a === b) return a;
    if (a && a.constructor == gvjs__ && b && b.constructor == gvjs__) return new gvjs__({
        fill: gvjs_by(a.fill, b.fill, 1 - c),
        fillOpacity: gvjs_RI(a.fillOpacity, b.fillOpacity, c),
        stroke: gvjs_by(a.stroke, b.stroke, 1 - c),
        strokeWidth: gvjs_RI(a.strokeWidth, b.strokeWidth, c),
        strokeOpacity: gvjs_RI(a.strokeOpacity, b.strokeOpacity, c),
        tg: a.tg,
        gradient: a.gradient,
        pattern: a.pattern
    });
    if (Array.isArray(a) && Array.isArray(b)) {
        if (a)
            if (b) {
                for (var d = [], e = Math.min(a.length, b.length), f = 0; f < e; f++) d.push(gvjs_RI(a[f],
                    b[f], c));
                c = d
            } else c = a;
        else c = b;
        return c
    }
    return gvjs_Pe(a) || gvjs_Pe(b) ? gvjs_SI(a, b, c) : typeof a === gvjs_m || typeof b === gvjs_m ? a : typeof a === gvjs_f && typeof b === gvjs_f ? (a = isNaN(a) ? 0 : a, b = isNaN(b) ? 0 : b, isFinite(a) && isFinite(b) ? a * (1 - c) + b * c : Infinity) : null
}

function gvjs_SI(a, b, c) {
    if (!a) return b;
    if (!b) return a;
    var d = {};
    gvjs_y(a, function(e, f) {
        void 0 !== b[f] && (d[f] = gvjs_RI(a[f], b[f], c))
    });
    return d
}

function gvjs_TI(a, b, c, d, e) {
    b = !e || (c ? b >= c.top && b <= c.bottom : !1);
    return (!d || (c ? a >= c.left && a <= c.right : !1)) && b
}

function gvjs_UI(a, b, c, d, e) {
    a.position && a.position.Ld && b.position && b.position.Ld && (c.position.Ld = function(f) {
        var g = a.position.Ld(f);
        f = b.position.Ld(f);
        return gvjs_RI(g, f, e)
    });
    a.title && b.title && c.title.lines.forEach(function(f, g) {
        f.x = gvjs_RI(a.title.lines[g].x, b.title.lines[g].x, e);
        f.y = gvjs_RI(a.title.lines[g].y, b.title.lines[g].y, e)
    });
    a.baseline && b.baseline && (c.baseline.oa = gvjs_RI(a.baseline.oa, b.baseline.oa, e));
    a.gridlines && b.gridlines && c.gridlines.forEach(function(f, g) {
        f.oa = gvjs_RI(a.gridlines[g].oa,
            b.gridlines[g].oa, e);
        f.isVisible = d(f.oa, f.oa)
    });
    a.Nl && b.Nl && (c.Nl = gvjs_SI(a.Nl, b.Nl, e));
    null != a.je && null != b.je && (c.je = gvjs_RI(a.je, b.je, e));
    null != a.Gd && null != b.Gd && (c.Gd = gvjs_RI(a.Gd, b.Gd, e));
    a.text && b.text && c.text.forEach(function(f, g) {
        if (f) {
            var h = a.text[g].ka;
            g = b.text[g].ka;
            var k = f.ka;
            k && k.anchor && (k.anchor.x = gvjs_RI(h.anchor.x, g.anchor.x, e), k.anchor.y = gvjs_RI(h.anchor.y, g.anchor.y, e));
            f.ka && (h = 0 < f.ka.lines.length, f.isVisible = d((h ? f.ka.lines[0].x : 0) + f.ka.anchor.x, (h ? f.ka.lines[0].y : 0) + f.ka.anchor.y))
        }
    })
}

function gvjs_NI(a, b, c) {
    if (!a || !b) return null;
    var d = gvjs_z(a);
    if (a.Zi || b.Zi) d.Zi = !0;
    if (void 0 !== a.W || void 0 !== b.W) d.W = gvjs_RI(a.W || {}, b.W || {}, c), d.fe = gvjs_RI(a.fe || {}, b.fe || {}, c);
    void 0 !== a.wp && void 0 !== b.wp && (d.wp = gvjs_RI(a.wp, b.wp, c));
    void 0 !== a.mn && void 0 !== b.mn && (d.mn = gvjs_RI(a.mn, b.mn, c));
    void 0 !== a.textStyle && void 0 !== b.textStyle && a.textStyle !== b.textStyle && (d.textStyle = gvjs_z(a.textStyle), d.textStyle.color = gvjs_by(a.textStyle.color, b.textStyle.color, 1 - c), d.textStyle.opacity = gvjs_RI(void 0 !==
        a.textStyle.opacity ? a.textStyle.opacity : 1, void 0 !== b.textStyle.opacity ? b.textStyle.opacity : 1, c));
    null != a.Ib && null != b.Ib && a.Ib.labels[0].text === b.Ib.labels[0].text ? d.Ib = gvjs_RI(a.Ib, b.Ib, c) : delete d.Ib;
    return d
}
gvjs_KI.prototype.interpolate = function(a) {
    var b = this.yh;
    if (b.hAxes) {
        var c = function(r, t) {
            return gvjs_TI(r, t, b.chartArea, !0, !1)
        };
        gvjs_y(b.hAxes, function(r, t) {
            (t = this.Gea[t]) && gvjs_UI(t[0], t[1], r, c, a)
        }, this)
    }
    if (b.vAxes) {
        var d = function(r, t) {
            return gvjs_TI(r, t, b.chartArea, !1, !0)
        };
        gvjs_y(b.vAxes, function(r, t) {
            (t = this.kna[t]) && gvjs_UI(t[0], t[1], r, d, a)
        }, this)
    }
    if (this.Ug && this.tk) {
        b.series = [];
        for (var e = 0; e < this.Ug.length; ++e) {
            var f = this.Ug[e],
                g = this.tk[e],
                h = gvjs_z(g);
            if (f && g && f.type == g.type) {
                if (f.points &&
                    g.points) {
                    h.points = [];
                    for (var k = 0; k < f.points.length; k++) h.points[k] = gvjs_NI(f.points[k], g.points[k], a);
                    if (f.Sx && g.Sx)
                        for (k = 0; k < f.Sx.length; k++) h.points.push(gvjs_NI(f.Sx[k], g.Sx[k], a))
                }
                f.intervals && f.intervals.paths && g.intervals && g.intervals.paths && (h.intervals = gvjs_z(h.intervals), h.intervals.paths = gvjs_RI(f.intervals.paths, g.intervals.paths, a))
            }
            b.series[e] = h
        }
    }
    b.height && (b.height = gvjs_RI(this.so.height, this.Dt.height, a));
    b.width && (b.width = gvjs_RI(this.so.width, this.Dt.width, a));
    b.chartArea && (b.chartArea =
        gvjs_RI(this.so.chartArea, this.Dt.chartArea, a));
    if (this.C5 && this.D5 && b.legend && b.legend.Zq)
        for (e = 0; e < b.legend.Zq.length; e++) {
            f = b.legend.Zq[e];
            g = this.C5[e];
            h = this.D5[e];
            if (f.ka && f.ka.lines && g.ka && g.ka.lines && 0 !== g.ka.lines.length && h.ka && h.ka.lines) {
                k = f.ka.lines;
                for (var l = g.ka.lines, m = h.ka.lines, n = l.length, p = 0; p < k.length; p++) {
                    var q = p < n ? l[p] : l[n - 1];
                    k[p].x = gvjs_RI(q.x, m[p].x, a);
                    k[p].y = gvjs_RI(q.y, m[p].y, a)
                }
            }
            f.square && f.square.coordinates && g.square && g.square.coordinates && h.square && h.square.coordinates &&
                (k = gvjs_RI(g.square.coordinates, h.square.coordinates, a), f.square.coordinates = new gvjs_0(k.left, k.top, k.width, k.height));
            f.Ie && f.Ie.coordinates && g.Ie && g.Ie.coordinates && h.Ie && h.Ie.coordinates && (f.Ie.coordinates = gvjs_RI(g.Ie.coordinates, h.Ie.coordinates, a))
        }
    return b
};

function gvjs_VI(a) {
    gvjs_L.call(this);
    var b = this;
    this.GP = a;
    this.zo = Infinity;
    this.lE = 0;
    a = new gvjs_az(15);
    gvjs_Rw(this, a);
    gvjs_M(a, gvjs_Qv, function() {
        b.FW()
    });
    this.gd = a
}
gvjs_r(gvjs_VI, gvjs_L);

function gvjs_WI(a, b) {
    var c = a.zo;
    a.zo = Math.min(a.zo, b);
    isFinite(a.zo) ? isFinite(c) || a.gd.start() : a.gd.stop()
}
gvjs_VI.prototype.FW = function() {
    var a = Date.now();
    this.zo -= a - this.lE;
    this.lE = a;
    0 >= this.zo && (this.GP(), this.zo = Infinity, this.gd.stop())
};

function gvjs_XI(a, b, c, d, e, f) {
    gvjs_L.call(this);
    this.ua = a;
    this.ib = b;
    this.QD = c;
    this.Ad = d;
    this.Rc = new gvjs_VI(e);
    gvjs_Rw(this, this.Rc);
    this.al = f;
    this.al.Hc = this.Rc;
    gvjs_7ga(this)
}
gvjs_r(gvjs_XI, gvjs_L);
gvjs_ = gvjs_XI.prototype;
gvjs_.J = function() {
    gvjs_5k(this.QD);
    gvjs_L.prototype.J.call(this)
};
gvjs_.Wea = function(a) {
    this.ib.cursor.position = a.data.Pa || null;
    gvjs_WI(this.Rc, 5)
};
gvjs_.Xea = function() {};
gvjs_.Zea = function(a) {
    this.ib.cursor.position = a.data.Pa || null;
    this.Ad.dispatchEvent(gvjs_Gu, {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y
    })
};
gvjs_.afa = function(a) {
    this.Ad.dispatchEvent("onmouseup", {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y
    })
};
gvjs_.Yea = function(a) {
    var b = {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y,
        shiftKey: a.data.shiftKey
    };
    this.Ad.dispatchEvent(gvjs_Fu, b);
    this.al.pk(gvjs_Fu, b, a.data.preventDefault)
};
gvjs_.Rea = function(a) {
    this.Ad.dispatchEvent(gvjs_fs, {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y
    })
};
gvjs_.efa = function(a) {
    var b = {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y
    };
    this.Ad.dispatchEvent(gvjs_9u, b);
    this.al.pk(gvjs_9u, b, a.data.preventDefault)
};
gvjs_.Sea = function(a) {
    this.Ad.dispatchEvent(gvjs_ws, {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y
    })
};
gvjs_.ffa = function(a) {
    var b = {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y,
        wheelDelta: a.data.wheelDelta
    };
    this.Ad.dispatchEvent(gvjs_dv, b);
    this.al.pk(gvjs_dv, b, a.data.preventDefault)
};
gvjs_.Uea = function(a) {
    a = {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y,
        shiftKey: a.data.shiftKey
    };
    this.Ad.dispatchEvent(gvjs_Js, a);
    this.al.pk(gvjs_Js, a)
};
gvjs_.Vea = function(a) {
    a = {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y,
        shiftKey: a.data.shiftKey
    };
    this.Ad.dispatchEvent(gvjs_Hs, a);
    this.al.pk(gvjs_Hs, a)
};
gvjs_.Tea = function(a) {
    a = {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y,
        shiftKey: a.data.shiftKey
    };
    this.Ad.dispatchEvent(gvjs_Is, a);
    this.al.pk(gvjs_Is, a)
};
gvjs_.cfa = function(a) {
    this.al.pk("pinchstart", {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y,
        gesture: a.data.j3
    }, a.data.preventDefault)
};
gvjs_.dfa = function(a) {
    this.al.pk("pinch", {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y,
        gesture: a.data.j3
    }, a.data.preventDefault)
};
gvjs_.bfa = function(a) {
    this.al.pk("pinchend", {
        targetID: a.data.fd,
        x: a.data.Pa.x,
        y: a.data.Pa.y,
        gesture: a.data.j3
    }, a.data.preventDefault)
};
gvjs_.N3 = function(a) {
    var b;
    this.ib.focused.category = null != (b = a.data.bi) ? b : null;
    gvjs_WI(this.Rc, 50)
};
gvjs_.O3 = function() {
    this.ib.cursor.position = null;
    this.ib.focused.category = null;
    gvjs_WI(this.Rc, 50)
};
gvjs_.M3 = function(a) {
    var b = this,
        c = this.ua;
    this.ib.cursor.RU = this.ib.cursor.position.clone();
    a = a.data.bi;
    if (c.series.some(function(g) {
            return g.enableInteractivity
        })) {
        var d = c.Fa[a].Fo;
        a = c.selectionMode == gvjs_rv;
        if (!a && c.focusTarget.has(gvjs_vp)) {
            var e = new Set,
                f = new Set;
            this.ua.series.forEach(function(g) {
                var h = g.points[d];
                null == h || h.Zi || (g = g.Fo, gvjs_Mo(this.ib.selected, d, g) ? e.add(g) : f.add(g))
            }, this);
            c = f.size;
            0 < e.size && 0 === c ? e.forEach(function(g) {
                b.ib.selected.oF(d, g)
            }) : 0 < c && f.forEach(function(g) {
                gvjs_No(b.ib.selected,
                    d, g)
            })
        } else gvjs_Uw(this.ib.selected, d, a);
        gvjs_WI(this.Rc, 0)
    }
};
gvjs_.W3 = function(a) {
    if (this.ua.chartType != gvjs_Wr) {
        var b;
        this.ib.legend.focused.Ob = null != (b = a.data.GK) ? b : null;
        gvjs_WI(this.Rc, 50)
    }
};
gvjs_.X3 = function() {
    this.ua.chartType != gvjs_Wr && (this.ib.legend.focused.Ob = null, gvjs_WI(this.Rc, 250))
};
gvjs_.Lfa = function(a) {
    this.ua.chartType != gvjs_Wr && (gvjs_YI(this, a.data.GK), gvjs_WI(this.Rc, 0))
};
gvjs_.Mfa = function(a) {
    null == this.ib.legend.Dg && (this.ib.legend.Dg = a.data.Dg || 0, this.ib.legend.sA = a.data.sA || 0);
    this.ib.legend.Dg += a.data.Yka;
    gvjs_WI(this.Rc, 0)
};
gvjs_.e4 = function(a) {
    if (this.ua.chartType != gvjs_Wr) {
        var b = this.ua.Jy;
        if (this.ua.focusTarget.has(gvjs_iv) || b == gvjs_Fs) {
            var c;
            this.ib.focused.Ua = null != (c = a.data.yb) ? c : null;
            gvjs_WI(this.Rc, 50)
        }
    }
};
gvjs_.f4 = function() {
    if (this.ua.chartType != gvjs_Wr) {
        var a = this.ua.Jy;
        if (this.ua.focusTarget.has(gvjs_iv) || a == gvjs_Fs) this.ib.focused.Ua = null, gvjs_WI(this.Rc, 250)
    }
};
gvjs_.d4 = function(a) {
    this.ua.chartType != gvjs_Wr && this.ua.focusTarget.has(gvjs_iv) && (gvjs_YI(this, a.data.yb), gvjs_WI(this.Rc, 0))
};
gvjs_.kga = function(a) {
    this.W3(a)
};
gvjs_.lga = function(a) {
    this.X3(a)
};
gvjs_.jga = function(a) {
    this.Ad.dispatchEvent("removeserie", {
        index: a.data.GK
    })
};
gvjs_.nfa = function(a) {
    var b = this.ua.focusTarget;
    if (b.has(gvjs_vp)) {
        var c;
        this.ib.focused.Ua = null != (c = a.data.yb) ? c : null;
        var d;
        this.ib.focused.datum = null != (d = a.data.bi) ? d : null
    } else {
        if (b.has(gvjs_iv)) {
            this.e4(a);
            return
        }
        if (b.has(gvjs_3r)) {
            this.N3(a);
            return
        }
    }
    gvjs_WI(this.Rc, 50)
};
gvjs_.ofa = function(a) {
    var b = this.ua.focusTarget;
    if (b.has(gvjs_vp)) this.ib.focused.Ua = null, this.ib.focused.datum = null;
    else {
        if (b.has(gvjs_iv)) {
            this.f4(a);
            return
        }
        if (b.has(gvjs_3r)) {
            this.O3(a);
            return
        }
    }
    gvjs_WI(this.Rc, 250)
};
gvjs_.mfa = function(a) {
    var b = this.ua;
    if (b.focusTarget.has(gvjs_vp)) {
        var c = b.selectionMode == gvjs_rv;
        a = {
            category: a.data.bi,
            Ua: a.data.yb
        };
        var d = b.series[a.Ua];
        d.enableInteractivity && (b.chartType == gvjs_Wr ? gvjs_Uw(this.ib.selected, a.category, c) : d.Fe || (b = b.NR(a), a = this.ua.focusTarget, a.has(gvjs_vp) ? gvjs_Ww(this.ib.selected, b.row, b.column, c) : a.has(gvjs_iv) && gvjs_Vw(this.ib.selected, b.column, c)));
        gvjs_WI(this.Rc, 0)
    } else b.focusTarget.has(gvjs_iv) ? this.d4(a) : b.focusTarget.has(gvjs_3r) && this.M3(a)
};
gvjs_.Nea = function(a) {
    var b = a.data.wB;
    if (-1 != b) {
        var c;
        this.ib.annotations.focused = {
            row: a.data.bi,
            column: gvjs_ZI(this, null != (c = a.data.yb) ? c : null, b)
        };
        this.ib.focused.Ua = null;
        this.ib.focused.datum = null;
        gvjs_WI(this.Rc, 50)
    }
};
gvjs_.Oea = function(a) {
    -1 != a.data.wB && (this.ib.annotations.focused = null, gvjs_WI(this.Rc, 250))
};
gvjs_.Mea = function(a) {
    var b = this.ua,
        c = b.selectionMode == gvjs_rv,
        d = a.data.bi,
        e, f = null != (e = a.data.yb) ? e : null;
    a = a.data.wB;
    if (null == f || b.series[f].enableInteractivity) - 1 == a ? this.ib.annotations.cJ = {
        yb: f,
        CQ: d
    } : gvjs_Ww(this.ib.selected, d, gvjs_ZI(this, f, a), c);
    gvjs_WI(this.Rc, 0)
};
gvjs_.Bga = function() {};
gvjs_.Cga = function() {};
gvjs_.Jea = function(a) {
    this.ib.fg.focused.Zt = a.data.Zt || null;
    gvjs_WI(this.Rc, 50)
};
gvjs_.Kea = function() {
    this.ib.fg.focused.Zt = null;
    gvjs_WI(this.Rc, 250)
};
gvjs_.Iea = function() {
    var a = this.ib.fg.focused.action;
    a && a();
    gvjs_WI(this.Rc, 250)
};
gvjs_.hp = function() {
    this.al.pk(gvjs_h)
};

function gvjs_ZI(a, b, c) {
    a = a.ua;
    var d = null;
    if (null != b) d = a.series[b].columns.annotation;
    else
        for (b = 0; b < a.di.length; ++b) d = a.di[b].columns.annotation;
    return d[c]
}

function gvjs_7ga(a) {
    function b(c, d) {
        gvjs_M(a.QD, c, d.bind(a))
    }
    b("chartHoverIn", a.Wea);
    b("chartHoverOut", a.Xea);
    b(gvjs_as, a.Zea);
    b("chartMouseUp", a.afa);
    b(gvjs_$r, a.Yea);
    b("chartClick", a.Rea);
    b(gvjs_bs, a.efa);
    b("chartDblClick", a.Sea);
    b("chartScroll", a.ffa);
    b(gvjs_9r, a.Uea);
    b("chartDrag", a.Vea);
    b("chartDragEnd", a.Tea);
    b("chartPinchStart", a.cfa);
    b("chartPinch", a.dfa);
    b("chartPinchEnd", a.bfa);
    b("categoryHoverIn", a.N3);
    b("categoryHoverOut", a.O3);
    b("categoryClick", a.M3);
    b("legendEntryHoverIn", a.W3);
    b("legendEntryHoverOut",
        a.X3);
    b("legendEntryClick", a.Lfa);
    b("legendScrollButtonClick", a.Mfa);
    b("serieHoverIn", a.e4);
    b("serieHoverOut", a.f4);
    b("serieClick", a.d4);
    b("removeSerieButtonHoverIn", a.kga);
    b("removeSerieButtonHoverOut", a.lga);
    b("removeSerieButtonClick", a.jga);
    b("datumHoverIn", a.nfa);
    b("datumHoverOut", a.ofa);
    b("datumClick", a.mfa);
    b("annotationHoverIn", a.Nea);
    b("annotationHoverOut", a.Oea);
    b("annotationClick", a.Mea);
    b("tooltipHoverIn", a.Bga);
    b("tooltipHoverOut", a.Cga);
    b("actionsMenuEntryHoverIn", a.Jea);
    b("actionsMenuEntryHoverOut",
        a.Kea);
    b("actionsMenuEntryClick", a.Iea)
}

function gvjs_YI(a, b) {
    var c = a.ua;
    if (c.series[b].enableInteractivity) {
        var d = c.selectionMode == gvjs_rv,
            e = c.focusTarget,
            f = c.series[b].Fo;
        if (c.chartType == gvjs_Ru) gvjs_Uw(a.ib.selected, f, d);
        else if (!d && e.has(gvjs_vp)) {
            var g = new Set,
                h = new Set;
            a.ua.series[b].points.forEach(function(k, l) {
                null == k || k.Zi || (gvjs_Mo(this.ib.selected, l, f) ? g.add(l) : h.add(l))
            }, a);
            b = h.size;
            0 < g.size && 0 === b ? g.forEach(function(k) {
                a.ib.selected.oF(k, f)
            }) : 0 < b && h.forEach(function(k) {
                gvjs_No(a.ib.selected, k, f)
            })
        } else gvjs_Vw(a.ib.selected,
            f, d)
    }
};

function gvjs__I() {}
gvjs_r(gvjs__I, gvjs__D);
gvjs_ = gvjs__I.prototype;
gvjs_.rJ = function(a) {
    var b = a.Ua,
        c = a.category;
    return this.wu ? gvjs__D.prototype.rJ.call(this, a) : this.series[b].properties.histogramBucketItems[c].label.At
};
gvjs_.MR = function(a) {
    return this.wu ? gvjs__D.prototype.MR.call(this, a) : this.series[a.Ua].properties.histogramBucketItems[a.category].row
};
gvjs_.NR = function(a) {
    if (this.wu) return gvjs__D.prototype.NR.call(this, a);
    a = this.series[a.Ua].properties.histogramBucketItems[a.category];
    return {
        row: a.row,
        column: a.column
    }
};
gvjs_.sJ = function(a) {
    var b = this.wm[a.column].yb;
    return null == b ? null : this.wu ? gvjs__D.prototype.sJ.call(this, a) : {
        Ua: b,
        category: this.series[b].properties.histogramElementIndexes[a.row]
    }
};
gvjs_.kD = function(a, b) {
    a = this.series[a];
    var c = a.points[b];
    return this.wu ? {
        lines: [{
            title: "Items",
            value: gvjs_uy(15, (this.orientation === gvjs_R ? this.vAxes[a.targetAxisIndex] : this.hAxes[a.targetAxisIndex]).number.Ai(c.fe.bw - c.fe.from))
        }]
    } : a.properties.histogramBucketItems[b].label
};

function gvjs_0I(a, b, c, d, e) {
    gvjs_sH.call(this, a, b, c, d, e)
}
gvjs_r(gvjs_0I, gvjs_sH);
gvjs_0I.prototype.Cu = function() {
    return gvjs_sH.prototype.Cu.call(this)
};
gvjs_0I.prototype.c1 = function() {
    return new gvjs__I
};
gvjs_0I.prototype.q1 = function() {
    var a = this.dataTable,
        b = a.getColumnType(0) === gvjs_m ? 1 : 0,
        c = a.getNumberOfColumns();
    this.YJ = new gvjs_F;
    for (this.YJ.addColumn(gvjs_f, gvjs_qd); b < c; b++) {
        var d = a.getColumnLabel(b) + " (count)";
        this.YJ.addColumn(gvjs_f, d)
    }
    this.Ia = this.YJ
};
gvjs_0I.prototype.s7 = function() {
    var a = this.dataTable,
        b = a.getColumnType(0) === gvjs_m,
        c = b ? 1 : 0,
        d = a.getNumberOfRows(),
        e = a.getNumberOfColumns();
    this.toNumber = [];
    for (var f = c; f < e; f++) this.toNumber[f] = gvjs_lG(a.getColumnType(f)).toNumber;
    a = gvjs_8ga(this);
    var g = gvjs_wf(a),
        h = gvjs_w(a, function(u) {
            return gvjs_Pe(u) ? u.v : u
        }),
        k = h.length,
        l = Number((h[1] - h[0]).toPrecision(15)) - 0,
        m = Number(h[0].toPrecision(15)) - 0,
        n = Number(h[k - 1].toPrecision(15)) - 0;
    a = [];
    for (f = c; f < e; f++) {
        a[f - c] = [];
        for (var p = 0; p < k; p++) a[f - c].push([])
    }
    f =
        this.YJ;
    f.setColumnProperty(0, gvjs_Ft, g);
    for (g = 0; g < k; g++) {
        p = [h[g]];
        for (var q = c; q < e; q++) p.push(0);
        f.addRow(p)
    }
    for (h = 0; h < d; h++)
        for (g = b ? this.dataTable.getValue(h, 0) : "", p = c; p < e; p++)
            if (q = this.dataTable.getValue(h, p), q = null != q ? this.toNumber[p](q) : null, (typeof q !== gvjs_f || isFinite(q)) && (null != q || this.L.interpolateNulls)) {
                q = q || 0;
                q = 0 == l || q < m ? 0 : q >= n ? k - 1 : Math.floor((q - m) / l);
                var r = p + 1 - c;
                f.setValue(q, r, (f.getValue(q, r) || 0) + 1);
                r = this.dataTable.getColumnLabel(p) || "Value";
                r = {
                    row: h,
                    column: p,
                    label: {
                        title: g,
                        At: g,
                        sk: r,
                        content: this.dataTable.getFormattedValue(h, p),
                        lines: [{
                            title: r,
                            value: this.dataTable.getFormattedValue(h, p) || 0
                        }]
                    }
                };
                a[p - c][q].push(r)
            }
    var t = [];
    for (b = c; b < e; b++) t[b] = [];
    b = gvjs_D(this.options, "histogram.sortBucketItems");
    for (d = c; d < e; d++) k = gvjs_hx(a[d - c]), b && k.sort(function(u, v) {
        u = u.label.lines[0].value;
        v = v.label.lines[0].value;
        return u < v ? -1 : u > v ? 1 : 0
    }), f.setColumnProperty(d - c, "histogramBucketItems", k), gvjs_v(k, function(u, v) {
        t[u.column][u.row] = v
    });
    for (a = c; a < e; a++) f.setColumnProperty(a - c, "histogramElementIndexes",
        t[a])
};

function gvjs_8ga(a) {
    var b = a.dataTable,
        c = b.getNumberOfRows(),
        d = b.getNumberOfColumns(),
        e = b.getColumnType(0) === gvjs_m ? 1 : 0,
        f = a.options.LD("histogram.buckets");
    if (f) return f;
    f = [];
    for (var g = 0; g < c; g++)
        for (var h = e; h < d; h++) {
            var k = b.getValue(g, h);
            k = null != k ? a.toNumber[h](k) : null;
            typeof k === gvjs_f && !isFinite(k) || null == k && !a.L.interpolateNulls || (k = k || 0, f.push(k))
        }
    f = f.sort(function(m, n) {
        return m - n
    });
    d = gvjs_E(a.options, gvjs_Et, 0);
    b = f[Math.max(0, Math.ceil(d / 100 * f.length) - 1)];
    f = f[Math.min(f.length - 1, Math.ceil((100 - d) /
        100 * f.length) - 1)];
    d = a.options.ha("histogram.minValue");
    e = a.options.ha("histogram.maxValue");
    null != d && (b = Math.min(d, b));
    null != e && (f = Math.max(e, f));
    d = a.L.chartArea.left;
    e = d + a.L.chartArea.width;
    g = gvjs_E(a.options, "histogram.minSpacing", 1);
    k = gvjs_E(a.options, "histogram.minNumBuckets", 2);
    h = gvjs_E(a.options, "histogram.maxNumBuckets", (e - d) / g);
    var l = a.options.Ca("histogram.numBucketsRule", gvjs_9ga);
    c = (0, gvjs_$ga[l])(c);
    c = Math.max(k, Math.min(h, c));
    c == k && (c = Math.min(2 * c, (k + h) / 2));
    k = Math.max(g, (e - d) / (2 + c));
    l = (f - b) / c;
    a = a.options.ha(gvjs_Ct);
    null != a && (0 >= a ? a = null : l = a, c = Math.min(h, (f - b) / l), k = Math.max(g, (e - d) / (2 * c)));
    b -= Math.min(l, Math.abs(b));
    f += Math.min(l, Math.abs(f));
    a = new gvjs_Si([{
        gridlines: {
            minSpacing: k
        }
    }]);
    a = gvjs_ifa(b, f, d, e, a);
    return f = gvjs_w(a, function(m) {
        return m.getValue()
    })
}

function gvjs_IH(a, b) {
    return 4 > a || b
}

function gvjs_Cga(a, b) {
    var c = a.Ia,
        d = a.L;
    a = [];
    for (var e = 0; e < d.Fa.length; e++) {
        a[e] = [];
        for (var f = 0; f < d.series.length; f++) {
            var g = d.series[f];
            if (g.type == gvjs_Hr) {
                var h = b ? 0 : f;
                a[e][h] = (a[e][h] || 0) + c.getValue(e, g.columns.data[0])
            }
        }
    }
    for (c = b = 0; c < a.length; c++)
        for (d = 0; d < a[c].length; d++) b = Math.max(a[c][d], b);
    return b
}
var gvjs_9ga = {
        SQRT: "sqrt",
        rpa: "sturges",
        fpa: "rice"
    },
    gvjs_$ga = {
        sqrt: function(a) {
            return Math.sqrt(a)
        },
        rice: function(a) {
            return 2 * Math.cbrt(a)
        },
        sturges: function(a) {
            return 1 + Math.log2(a)
        }
    };

function gvjs_aha(a) {
    return Math.pow(a, 3)
}

function gvjs_bha(a) {
    return 1 - Math.pow(1 - a, 3)
}

function gvjs_cha(a) {
    return 3 * a * a - 2 * a * a * a
};
var gvjs_dha = {
    LINEAR: gvjs_8t,
    voa: gvjs_Kt,
    Soa: gvjs_Nu,
    woa: gvjs_Lt
};

function gvjs_eha(a) {
    switch (a) {
        case gvjs_8t:
            return gvjs_pw;
        case gvjs_Kt:
            return gvjs_aha;
        case gvjs_Nu:
            return gvjs_bha;
        case gvjs_Lt:
            return gvjs_cha
    }
}

function gvjs_1I(a, b, c) {
    var d = gvjs_D(a, "animation.startup", !1);
    b = gvjs_5i(a, gvjs_mr, b);
    if (!b) return null;
    var e = gvjs_5i(a, "animation.maxFramesPerSecond", 30);
    a = gvjs_C(a, "animation.easing", c, gvjs_dha);
    return {
        startup: d,
        duration: b,
        easing: gvjs_eha(a),
        ET: e
    }
};

function gvjs_2I(a, b) {
    this.fonts = a || [];
    gvjs_fha(this, b)
}

function gvjs_3I() {
    return function(a, b) {
        return b === gvjs_at && typeof a === gvjs_m && -1 === gvjs_gha.indexOf(a.toLowerCase())
    }
}

function gvjs_fha(a, b) {
    var c = gvjs_s.WebFont;
    0 !== a.fonts.length && c ? c.load({
        google: {
            Tra: a.fonts
        },
        active: function() {
            b.resolve()
        },
        Xra: function() {
            b.reject("One or more fonts could not be loaded")
        }
    }) : b.resolve(null)
}
var gvjs_gha = "arial;comic sans ms;courier new;georgia;impact;times new roman;trebuchet ms;verdana".split(";");

function gvjs_4I(a, b, c, d) {
    var e = this;
    this.Bd = a;
    this.Pj = c;
    this.Ch = d;
    this.viewport = null;
    this.Pf = b;
    this.Ch.subscribe(gvjs_h, function() {
        e.hp()
    })
}
gvjs_ = gvjs_4I.prototype;
gvjs_.RM = function(a) {
    this.viewport = a
};
gvjs_.Pf = function() {
    return this.Pf()
};
gvjs_.getState = function() {
    return this.Bd
};
gvjs_.hp = function() {};
gvjs_.updateOptions = function() {
    var a = {
        hAxis: {
            viewWindowMode: gvjs_Ns,
            viewWindow: {}
        },
        vAxis: {
            viewWindowMode: gvjs_Ns,
            viewWindow: {}
        }
    };
    this.Pj.Fr && (isNaN(this.viewport.Ym) || (a.hAxis.viewWindow.numericMin = this.viewport.Ym), isNaN(this.viewport.Cp) || (a.hAxis.viewWindow.numericMax = this.viewport.Cp));
    this.Pj.vertical && (isNaN(this.viewport.Zm) || (a.vAxis.viewWindow.numericMin = this.viewport.Zm), isNaN(this.viewport.Dp) || (a.vAxis.viewWindow.numericMax = this.viewport.Dp));
    this.Bd.wl = a
};

function gvjs_5I(a, b) {
    return gvjs_7h(a.x, b.left, b.left + b.width) === a.x && gvjs_7h(a.y, b.top, b.top + b.height) === a.y ? !0 : !1
};

function gvjs_6I(a, b, c, d) {
    gvjs_4I.call(this, a, b, c, d);
    this.Su = null
}
gvjs_r(gvjs_6I, gvjs_4I);
gvjs_ = gvjs_6I.prototype;
gvjs_.hp = function() {
    var a = this,
        b = this.Ch;
    b.subscribe(gvjs_Js, function(c) {
        a.fS(c)
    });
    b.subscribe(gvjs_Hs, function(c) {
        a.uy(c)
    });
    b.subscribe(gvjs_Is, function() {
        a.eS()
    });
    b.subscribe(gvjs_Fu, function(c, d) {
        a.Zd(c, d)
    })
};
gvjs_.fS = function(a) {
    var b = this.Pf().getChartAreaBoundingBox();
    gvjs_5I(a, b) && (this.Su = new gvjs_Ij(a.x, a.y))
};
gvjs_.uy = function(a) {
    this.Su && (this.cX(a.x, a.y), this.Su.x = a.x, this.Su.y = a.y)
};
gvjs_.eS = function() {
    this.Su = null
};
gvjs_.Zd = function(a, b) {
    var c = this.Pf().getChartAreaBoundingBox();
    gvjs_5I(a, c) && b()
};
gvjs_.cX = function(a, b) {
    var c = this.viewport;
    if (c) {
        var d = this.Pf();
        c.layout = d;
        d = this.Pj;
        if (d.Fr) {
            a = c.getHAxisValue(a) - c.getHAxisValue(this.Su.x);
            var e = c.Ym - a,
                f = c.Cp - a,
                g = Math.max(e, c.mL),
                h = Math.min(f, c.mL + c.lL);
            if (c.keepInBounds && (g === e || 0 > a) && (h === f || 0 < a) || !c.keepInBounds) c.Ym = e, c.Cp = f
        }
        d.vertical && (b = c.getVAxisValue(b) - c.getVAxisValue(this.Su.y), d = c.Zm - b, a = c.Dp - b, e = Math.max(d, c.nL), f = Math.min(a, c.nL + c.kL), c.keepInBounds && (e === d || 0 > b) && (f === a || 0 < b) || !c.keepInBounds) && (c.Zm = d, c.Dp = a);
        this.updateOptions()
    }
};

function gvjs_7I(a, b, c, d) {
    gvjs_4I.call(this, a, b, c, d);
    this.As = null
}
gvjs_r(gvjs_7I, gvjs_4I);
gvjs_ = gvjs_7I.prototype;
gvjs_.hp = function() {
    var a = this,
        b = this.Ch;
    b.subscribe(gvjs_Js, function(c) {
        a.fS(c)
    });
    b.subscribe(gvjs_Hs, function(c) {
        a.uy(c)
    });
    b.subscribe(gvjs_Is, function() {
        a.eS()
    });
    b.subscribe(gvjs_Fu, function(c, d) {
        a.Zd(c, d)
    })
};
gvjs_.fS = function(a) {
    var b = this.Pf().getChartAreaBoundingBox();
    gvjs_5I(a, b) && (this.As = new gvjs_Ij(a.x, a.y))
};
gvjs_.uy = function(a) {
    if (this.As) {
        var b = this.Pf().getChartAreaBoundingBox(),
            c = this.Pj;
        this.jka(a, b);
        if (c.Fr) {
            var d = Math.min(this.As.x, a.x);
            var e = Math.abs(this.As.x - a.x)
        } else d = b.left, e = b.width;
        c.vertical ? (c = Math.min(this.As.y, a.y), a = Math.abs(this.As.y - a.y)) : (c = b.top, a = b.height);
        this.getState().cf = {
            left: d,
            top: c,
            width: e,
            height: a,
            color: "blue",
            opacity: .2
        }
    }
};
gvjs_.eS = function() {
    this.As && (this.cX(), this.As = null, this.getState().cf = null)
};
gvjs_.Zd = function(a, b) {
    var c = this.Pf().getChartAreaBoundingBox();
    gvjs_5I(a, c) && b()
};
gvjs_.cX = function() {
    var a = this.Pj,
        b = this.viewport,
        c = this.Pf();
    b.layout = c;
    var d = this.getState().cf,
        e = b.getHAxisValue(d.left),
        f = b.getHAxisValue(d.left + d.width);
    c = b.getVAxisValue(d.top);
    d = b.getVAxisValue(d.top + d.height);
    if (e !== f && c !== d) {
        var g = b.lL * b.maxZoomIn;
        if (a.Fr) {
            var h = Math.min(e, f);
            e = Math.max(e, f);
            e - h < g && (e = (h + e) / 2, h = e - g / 2, e += g / 2);
            b.Ym = h;
            b.Cp = e
        }
        g = b.kL * b.maxZoomIn;
        a.vertical && (a = Math.min(c, d), c = Math.max(c, d), c - a < g && (c = (a + c) / 2, a = c - g / 2, c += g / 2), b.Zm = a, b.Dp = c);
        this.updateOptions()
    }
};
gvjs_.jka = function(a, b) {
    a.x = gvjs_7h(a.x, b.left, b.left + b.width);
    a.y = gvjs_7h(a.y, b.top, b.top + b.height)
};

function gvjs_hha(a, b) {
    this.Fr = a;
    this.vertical = b
};

function gvjs_8I(a, b, c, d) {
    gvjs_4I.call(this, a, b, c, d)
}
gvjs_r(gvjs_8I, gvjs_4I);
gvjs_8I.prototype.hp = function() {
    var a = this;
    this.Ch.subscribe(gvjs_9u, function() {
        var b = a.viewport;
        b.scale = 1;
        b.Ym = b.mL;
        b.Cp = b.mL + b.lL;
        b.Zm = b.nL;
        b.Dp = b.nL + b.kL;
        a.updateOptions()
    })
};

function gvjs_9I(a, b, c, d) {
    gvjs_4I.call(this, a, b, c, d)
}
gvjs_r(gvjs_9I, gvjs_4I);
gvjs_9I.prototype.hp = function() {
    var a = this;
    this.Ch.subscribe(gvjs_dv, function(b, c) {
        var d = a.Pj,
            e = a.Pf().getChartAreaBoundingBox();
        gvjs_5I(b, e) && (c(), c = a.viewport, b = 0 > b.wheelDelta ? c.scale * c.zoomDelta : c.scale / c.zoomDelta, b = gvjs_7h(b, c.maxZoomIn, c.maxZoomOut), b !== c.scale && (c.scale = b, d.Fr && (b = (c.Cp + c.Ym) / 2, e = c.lL * c.scale / 2, c.Ym = b - e, c.Cp = b + e), d.vertical && (d = (c.Dp + c.Zm) / 2, b = c.kL * c.scale / 2, c.Zm = d - b, c.Dp = d + b), a.updateOptions()))
    })
};

function gvjs_iha(a, b, c, d, e, f) {
    var g = this;
    this.maxZoomOut = c;
    this.maxZoomIn = d;
    this.zoomDelta = e;
    this.keepInBounds = f;
    this.scale = 1;
    var h = a.hAxes[0] ? 0 : 1,
        k = a.vAxes[0] ? 0 : 1;
    c = a.hAxes[h];
    a = a.vAxes[k];
    var l = c && c.dataType ? gvjs_lG(c.dataType).toNumber : null,
        m = a && a.dataType ? gvjs_lG(a.dataType).toNumber : null;
    this.layout = b;
    this.getHAxisValue = function(n) {
        if (!l) return n;
        var p = g.layout.getHAxisValue;
        return l(p(n, h))
    };
    this.getVAxisValue = function(n) {
        if (!m) return n;
        var p = g.layout.getVAxisValue;
        return m(p(n, k))
    };
    b = this.layout.getChartAreaBoundingBox();
    this.Ym = this.getHAxisValue(b.left);
    this.Zm = this.getVAxisValue(b.top + b.height);
    this.Cp = this.getHAxisValue(b.left + b.width);
    this.Dp = this.getVAxisValue(b.top);
    this.mL = this.Ym;
    this.nL = this.Zm;
    this.lL = this.Cp - this.Ym;
    this.kL = this.Dp - this.Zm
};

function gvjs_$I(a, b, c, d, e) {
    var f = void 0 === f ? !0 : f;
    this.viewport = this.Pj = null;
    this.v2 = [];
    if (c.R(gvjs_ge) === gvjs_Ru) throw Error("Cannot use explorer with a pie chart");
    this.Bd = a;
    this.Pf = b;
    this.options = c;
    this.ca = d;
    this.Ch = e;
    f && this.init()
}
gvjs_$I.prototype.hp = function() {
    var a = this,
        b = gvjs_E(this.options, "explorer.maxZoomOut", 4);
    1 > b && (b = 1 / b);
    var c = gvjs_E(this.options, "explorer.maxZoomIn", .25);
    1 < c && (c = 1 / c);
    var d = gvjs_E(this.options, "explorer.zoomDelta", 1.5),
        e = gvjs_D(this.options, "explorer.keepInBounds", !1);
    this.viewport = new gvjs_iha(this.ca, this.Pf(), b, c, d, e);
    this.v2.forEach(function(f) {
        f.RM(a.viewport)
    })
};
gvjs_$I.prototype.init = function() {
    var a = this,
        b = this.ca.hAxes[0] ? 0 : 1,
        c = this.ca.vAxes[0] ? 0 : 1,
        d = this.ca.hAxes[b],
        e = this.ca.vAxes[c];
    b = !this.ca.hAxes[1 - b] && d && d.type === gvjs_o && !d.logScale;
    c = !this.ca.vAxes[1 - c] && e && e.type === gvjs_o && !e.logScale;
    e = (this.options.R(gvjs_Os) || {}).axis;
    e === gvjs_R ? c = !1 : e === gvjs_S && (b = !1);
    this.Pj = new gvjs_hha(b, c);
    gvjs_jha(this);
    this.Ch.subscribe(gvjs_h, function() {
        a.hp()
    })
};

function gvjs_jha(a) {
    var b = a.v2,
        c = a.options.R(gvjs_Ps);
    (null == c || Array.isArray(c) && gvjs_tf(c, "dragToPan")) && b.push(new gvjs_6I(a.Bd, a.Pf, a.Pj, a.Ch));
    c = a.options.R(gvjs_Ps);
    Array.isArray(c) && gvjs_tf(c, "dragToZoom") && b.push(new gvjs_7I(a.Bd, a.Pf, a.Pj, a.Ch));
    c = a.options.R(gvjs_Ps);
    (null == c || Array.isArray(c) && gvjs_tf(c, "rightClickToReset")) && b.push(new gvjs_8I(a.Bd, a.Pf, a.Pj, a.Ch));
    c = a.options.R(gvjs_Ps);
    Array.isArray(c) && gvjs_tf(c, "pinchToZoom");
    c = a.options.R(gvjs_Ps);
    (null == c || Array.isArray(c) && gvjs_tf(c,
        "scrollToZoom")) && b.push(new gvjs_9I(a.Bd, a.Pf, a.Pj, a.Ch))
};

function gvjs_aJ(a) {
    gvjs_L.call(this);
    this.Mu = 1;
    this.xL = [];
    this.HL = 0;
    this.xi = [];
    this.Kn = {};
    this.iba = !!a
}
gvjs_u(gvjs_aJ, gvjs_L);
gvjs_ = gvjs_aJ.prototype;
gvjs_.subscribe = function(a, b, c) {
    var d = this.Kn[a];
    d || (d = this.Kn[a] = []);
    var e = this.Mu;
    this.xi[e] = a;
    this.xi[e + 1] = b;
    this.xi[e + 2] = c;
    this.Mu = e + 3;
    d.push(e);
    return e
};
gvjs_.unsubscribe = function(a, b, c) {
    if (a = this.Kn[a]) {
        var d = this.xi;
        if (a = a.find(function(e) {
                return d[e + 1] == b && d[e + 2] == c
            })) return this.bX(a)
    }
    return !1
};
gvjs_.bX = function(a) {
    var b = this.xi[a];
    if (b) {
        var c = this.Kn[b];
        0 != this.HL ? (this.xL.push(a), this.xi[a + 1] = function() {}) : (c && gvjs_uf(c, a), delete this.xi[a], delete this.xi[a + 1], delete this.xi[a + 2])
    }
    return !!b
};
gvjs_.pk = function(a, b) {
    var c = this.Kn[a];
    if (c) {
        for (var d = Array(arguments.length - 1), e = 1, f = arguments.length; e < f; e++) d[e - 1] = arguments[e];
        if (this.iba)
            for (e = 0; e < c.length; e++) {
                var g = c[e];
                gvjs_kha(this.xi[g + 1], this.xi[g + 2], d)
            } else {
                this.HL++;
                try {
                    for (e = 0, f = c.length; e < f && !this.Ue; e++) g = c[e], this.xi[g + 1].apply(this.xi[g + 2], d)
                } finally {
                    if (this.HL--, 0 < this.xL.length && 0 == this.HL)
                        for (; c = this.xL.pop();) this.bX(c)
                }
            }
        return 0 != e
    }
    return !1
};

function gvjs_kha(a, b, c) {
    gvjs_gl(function() {
        a.apply(b, c)
    })
}
gvjs_.clear = function(a) {
    if (a) {
        var b = this.Kn[a];
        b && (b.forEach(this.bX, this), delete this.Kn[a])
    } else this.xi.length = 0, this.Kn = {}
};
gvjs_.De = function(a) {
    if (a) {
        var b = this.Kn[a];
        return b ? b.length : 0
    }
    a = 0;
    for (b in this.Kn) a += this.De(b);
    return a
};
gvjs_.J = function() {
    gvjs_aJ.G.J.call(this);
    this.clear();
    this.xL.length = 0
};

function gvjs_bJ(a, b, c, d, e) {
    this.options = a;
    this.state = b;
    this.ca = d;
    this.Hda = [];
    this.Hc = null;
    this.Pf = c;
    this.Ch = new gvjs_aJ;
    (void 0 === e || e) && this.init()
}
gvjs_bJ.prototype.init = function() {
    var a = this.options;
    a.R(gvjs_ge) === gvjs_Ru ? a = !1 : (a = a.R(gvjs_Os), a = null != a && typeof a === gvjs_g);
    a && this.Hda.push(new gvjs_$I(this.state, this.Pf, this.options, this.ca, this.Ch))
};
gvjs_bJ.prototype.pk = function(a, b, c) {
    var d = gvjs_lha[a];
    d && this.Hc && !this.Hc.Ue && gvjs_WI(this.Hc, d);
    this.Ch.pk.apply(this.Ch, [a, b, c])
};
var gvjs_cJ = {},
    gvjs_lha = (gvjs_cJ.dragstart = 15, gvjs_cJ.drag = 5, gvjs_cJ.dragend = 5, gvjs_cJ.scroll = 5, gvjs_cJ.rightclick = 5, gvjs_cJ.pinch = 5, gvjs_cJ.pinchend = 15, gvjs_cJ);

function gvjs_dJ(a) {
    for (var b = gvjs_Ah("thead", {}, gvjs_eJ(a, gvjs_mha)), c = [], d = a.getNumberOfRows(), e = {
            OA: 0
        }; e.OA < d; e = {
            OA: e.OA
        }, ++e.OA) c.push(gvjs_eJ(a, function(f) {
        return function(g, h) {
            g = g.getFormattedValue(f.OA, h);
            return gvjs_Ah("td", {}, g)
        }
    }(e)));
    a = gvjs_Ah("tbody", {}, gvjs_Dh(c));
    return gvjs_Ah(gvjs_8d, {}, gvjs_Dh(b, a))
}

function gvjs_eJ(a, b) {
    for (var c = [], d = a.getNumberOfColumns(), e = 0; e < d; ++e) "" === a.getColumnRole(e) && c.push(b(a, e));
    a = gvjs_Dh(c);
    return gvjs_Ah("tr", {}, a)
}

function gvjs_mha(a, b) {
    a = a.getColumnLabel(b) || a.getColumnId(b);
    return gvjs_Ah("th", {}, a)
};
var gvjs_nha = gvjs_iz.Vpa,
    gvjs_oha = gvjs_iz.Wpa,
    gvjs_pha = gvjs_J.removeAll;

function gvjs_fJ(a) {
    gvjs_cn.call(this, a);
    this.Ee = this.Uh = this.ca = this.theme = this.chartType = null;
    this.uH = [];
    this.Rt = this.nm = this.Pb = this.animation = this.la = this.Qo = this.Bd = null;
    this.height = this.width = 0;
    this.logger = this.options = null;
    this.orientation = gvjs_R;
    this.Lr = new gvjs_7k;
    this.Pq = new gvjs_Zp(this);
    gvjs_Rw(this, this.Pq);
    this.Uda = gvjs_bJ;
    this.Eca = {}
}
gvjs_r(gvjs_fJ, gvjs_cn);
gvjs_ = gvjs_fJ.prototype;
gvjs_.J = function() {
    this.Wc();
    gvjs_K(this.Lr);
    gvjs_K(this.Pb);
    gvjs_K(this.nm);
    gvjs_K(this.Rt);
    gvjs_cn.prototype.J.call(this)
};
gvjs_.iI = function(a, b, c, d, e, f) {
    a = this.chartType === gvjs_Bt ? new gvjs_0I(a, b, c, d, e) : new gvjs_sH(a, b, c, d, e);
    a.init(this.mf, f);
    return a
};
gvjs_.e1 = function(a, b, c, d, e, f, g) {
    return new gvjs_uI(a, b, c, d, e, f, g)
};
gvjs_.d1 = function(a, b, c, d) {
    return new gvjs_6H(a, b, c, d)
};
gvjs_.dQ = function(a, b) {
    return new gvjs_WF(a, b)
};
gvjs_.setChartType = function(a, b, c, d) {
    this.chartType = a;
    null != b && (this.wC = b);
    null != c && (this.orientation = c);
    null != d && (this.theme = d)
};
gvjs_.draw = function(a, b, c) {
    gvjs_cn.prototype.draw.call(this, a, b, c)
};
gvjs_.Nc = function(a, b, c, d) {
    var e = this;
    c = void 0 === c ? {} : c;
    this.mf = a;
    c = gvjs_Jg(gvjs_Gg(c));
    gvjs_qha(this, c);
    gvjs_rha(this, c);
    c.orientation = c.orientation || this.orientation;
    c.theme = c.theme || this.theme;
    this.chartType !== gvjs_e && gvjs_sha(c);
    if (this.chartType !== gvjs_Ru && gvjs_0i(c.reverseCategories)) {
        var f = c.orientation === gvjs_S ? gvjs_ie : gvjs_ut;
        c[f] = c[f] || {};
        c[f].direction = -1;
        delete c.reverseCategories
    }
    gvjs_tha(c);
    f = this.getContainer();
    gvjs_pha(f);
    if (!b) throw Error(gvjs_Oq);
    gvjs_rf(gvjs_fx(b.getNumberOfColumns()),
        function(k) {
            return b.getColumnRole(k) === gvjs_Eu
        }) && (c.isDiff = !0);
    b.getColumnType(0);
    b.getNumberOfRows();
    gvjs_gJ(this);
    c = gvjs_uha(c);
    var g = [],
        h = gvjs_3I();
    gvjs_v(c, function(k) {
        g.push.apply(g, gvjs_we(gvjs_px(k, h)))
    });
    this.d8 = c;
    this.options = new gvjs_Si(gvjs_wf(this.d8));
    this.chartType = gvjs_C(this.options, gvjs_ge, gvjs_e, gvjs_MA);
    this.width = this.pb(this.options);
    this.height = this.getHeight(this.options);
    c = new gvjs_B(this.width, this.height);
    f = gvjs_D(this.options, gvjs_ct);
    if (!this.la || this.la.Ue) try {
        this.la =
            new gvjs_BA(this.container, c, a, f)
    } catch (k) {
        throw Error(gvjs_1q);
    } else this.la.update(c, a);
    this.Bd = new gvjs_vD(d);
    this.dataTable = b;
    g.length && this.wh ? (this.wh.promise.then(function() {
        e.la.Vl(e.gC.bind(e), a)
    }), gvjs_Tw(this, function() {
        e.la.Vl(e.gC.bind(e), a)
    }), new gvjs_2I(g, this.wh)) : this.la.Vl(this.gC.bind(this), a)
};

function gvjs_uha(a) {
    if (a.isStacked && a.vAxis && a.vAxis.baseline) throw Error("Cannot set a non-zero base-line for a stacked chart");
    var b = a.theme || [];
    b && !Array.isArray(b) && (b = [b]);
    for (var c = [a], d = 0; d < b.length; d++) {
        var e = b[d];
        if (typeof e === gvjs_m) e = gvjs_YD(e);
        else if (gvjs_Pe(e)) e instanceof gvjs_Si && (e = gvjs_Gp(e));
        else throw Error("Theme must be a theme name or an options object.");
        e && c.push(e)
    }
    a = a.type.toLowerCase();
    gvjs_LE[a] && c.push(gvjs_LE[a]);
    c.push(gvjs_ME);
    return c
}
gvjs_.gC = function() {
    var a = this,
        b = this.la.ya(),
        c = this.la.nu(),
        d = this.options;
    this.iI(this.dataTable, d, b.ud.bind(b), this.width, this.height, function(e) {
        gvjs_hJ(a);
        e = e.Si();
        var f = new a.Uda(d, a.Bd, a.getChartLayoutInterface.bind(a), e);
        a.Eca = {};
        gvjs_K(a.Pb);
        a.Pb = new gvjs_XI(e, a.Bd, a.Lr, a.Pq, a.refresh.bind(a, !0), f);
        a.Ee = a.e1(a.options, new gvjs_B(a.width, a.height), {
            fontName: e.Kf,
            fontSize: e.rh
        }, e.Jy, e.focusTarget, e.series.length, a.Ee ? a.Ee.Tc : void 0);
        gvjs_vha(a);
        a.Uh = a.dQ(c, b);
        gvjs_wha(a, e) || (a.ca = e, gvjs_iJ(a),
            gvjs_jJ(a));
        a.TQ();
        a.Pq.dispatchEvent(gvjs_h);
        a.Pb.hp()
    })
};
gvjs_.TQ = function() {
    var a = this,
        b = this.la.ya();
    setTimeout(function() {
        if (b && b.Jt) {
            var c = b.Jt();
            if (c && a.dataTable) {
                var d = gvjs_dJ(a.dataTable);
                gvjs_1m(c, d)
            }
        }
    }, 0)
};
gvjs_.computeDiff = function(a, b) {
    if (this.chartType === gvjs_Ru) return gvjs_kJ(a, b);
    throw Error("Cannot compute diff for this chart type.");
};

function gvjs_kJ(a, b) {
    if (!a || !b) throw Error("Old and New DataTables must exist.");
    var c = new gvjs_F,
        d = b.getNumberOfRows(),
        e = b.getNumberOfColumns(),
        f = a.getColumnType(0) !== gvjs_f;
    f && c.addColumn(a.getColumnType(0), a.getColumnLabel(0));
    for (var g = f ? 1 : 0, h = g; h < e; ++h) c.addColumn({
        type: a.getColumnType(h),
        label: a.getColumnLabel(h),
        role: gvjs_Eu
    }), c.addColumn({
        type: b.getColumnType(h),
        label: b.getColumnLabel(h),
        role: gvjs_ts
    });
    c.addRows(d);
    for (h = 0; h < d; ++h) {
        if (f) {
            var k = b.getValue(h, 0);
            c.setCell(h, 0, k)
        }
        for (var l = k =
                g; l < e; ++l) {
            var m = a.getValue(h, l);
            c.setCell(h, k, m);
            k += 1;
            m = b.getValue(h, l);
            c.setCell(h, k, m);
            k += 1
        }
    }
    return c
}

function gvjs_qha(a, b) {
    switch (b.type) {
        case gvjs_lJ.LINE:
            a.setChartType(gvjs_c, gvjs_d, gvjs_R);
            b.type = null;
            break;
        case gvjs_lJ.AREA:
            a.setChartType(gvjs_c, gvjs_Ar, gvjs_R);
            b.type = null;
            break;
        case gvjs_lJ.s$:
            a.setChartType(gvjs_c, gvjs_Hr, gvjs_R);
            b.type = null;
            break;
        case gvjs_lJ.fO:
            a.setChartType(gvjs_c, gvjs_Hr, gvjs_S);
            b.type = null;
            break;
        case gvjs_lJ.tO:
            a.setChartType(gvjs_j);
            b.type = null;
            break;
        case gvjs_lJ.sO:
            a.setChartType(gvjs_Ru), b.type = null
    }
    a = a.chartType;
    a === gvjs_e && (a = null);
    var c = b.type || gvjs_e;
    c === gvjs_e &&
        (c = null);
    if (!a && !c) throw Error("Unspecified chart type.");
    if (a && c && a !== c) throw Error("Incompatible chart types.");
    b.type = a || c
}

function gvjs_rha(a, b) {
    if (b.type === gvjs_c) {
        a = a.wC;
        a === gvjs_e && (a = null);
        var c = b.seriesType || gvjs_e;
        c === gvjs_e && (c = null);
        if (a && c && a !== c) throw Error("Incompatible default series types.");
        b.seriesType = a || c
    }
}

function gvjs_sha(a) {
    a.hAxis = a.hAxis || {};
    a.vAxis = a.vAxis || {};
    var b = a.hAxis,
        c = a.vAxis,
        d = null;
    switch (a.type) {
        case gvjs_j:
            d = c;
            break;
        case gvjs_c:
            a.targetAxis = a.targetAxis || {}, d = a.targetAxis
    }
    d && (gvjs_mJ(a, gvjs_zd, d, gvjs_Ad), gvjs_mJ(a, gvjs_wd, d, gvjs_xd), gvjs_mJ(a, gvjs_$t, d, gvjs_$t));
    b && (gvjs_mJ(a, "logScaleX", b, gvjs_$t), gvjs_mJ(a, "titleX", b, gvjs_ce));
    c && gvjs_mJ(a, "titleY", c, gvjs_ce);
    a.smoothLine && void 0 === a.curveType && (a.curveType = gvjs_c);
    gvjs_mJ(a, "lineSize", a, gvjs_7t);
    gvjs_mJ(a, "reverseAxis", a, gvjs_6u);
    a.chartArea = a.chartArea || {};
    gvjs_mJ(a, "axisBackgroundColor", a.chartArea, gvjs_Dr)
}

function gvjs_tha(a) {
    gvjs_nJ(a, "titleColor", gvjs_Sv, gvjs_Tv);
    gvjs_nJ(a, "legendTextColor", "legendFontSize", gvjs_4t);
    gvjs_oJ(a.hAxis);
    var b = a.hAxes || {},
        c;
    for (c in b) b.hasOwnProperty(c) && gvjs_oJ(b[c]);
    b = a.vAxes || {};
    gvjs_oJ(a.vAxis);
    for (var d in b) b.hasOwnProperty(d) && gvjs_oJ(b[d]);
    d = a.tooltip;
    null == d && (d = {}, a.tooltip = d);
    gvjs_nJ(a, "tooltipTextColor", "tooltipFontSize", gvjs_0v);
    gvjs_mJ(a, gvjs_0v, d, gvjs_Pv);
    gvjs_mJ(a, "tooltipText", d, gvjs_n);
    gvjs_mJ(a, "tooltipTrigger", d, "trigger");
    "hover" === d.trigger && (d.trigger =
        gvjs_1s);
    d = a.legend;
    null == d ? (d = {}, a.legend = d) : typeof d === gvjs_m && (b = d, d = {}, a.legend = d, d.position = b);
    gvjs_mJ(a, gvjs_4t, d, gvjs_Pv);
    d = a.animation;
    null == d ? (d = {}, a.animation = d) : typeof d === gvjs_f && (b = 1E3 * d, d = {}, a.animation = d, d.duration = b);
    gvjs_mJ(a, "animationEasing", d, "easing")
}

function gvjs_oJ(a) {
    if (null != a) {
        gvjs_nJ(a, "textColor", "textFontSize", gvjs_Pv);
        gvjs_nJ(a, "titleColor", gvjs_Sv, gvjs_Tv);
        a.gridlines = a.gridlines || {};
        var b = a.gridlines,
            c = a.numberOfSections;
        void 0 === b.count && void 0 !== c && typeof c === gvjs_f && (b.count = c + 1);
        a = a.gridlineColor;
        void 0 === b.color && void 0 !== a && (b.color = a)
    }
}

function gvjs_nJ(a, b, c, d) {
    a[d] = a[d] || {};
    d = a[d];
    gvjs_mJ(a, b, d, gvjs_Sb);
    gvjs_mJ(a, c, d, gvjs_bt)
}

function gvjs_mJ(a, b, c, d) {
    void 0 !== a[b] && void 0 === c[d] && (c[d] = a[b])
}
gvjs_.Wc = function() {
    gvjs_pJ(this);
    gvjs_gJ(this);
    gvjs_hJ(this);
    gvjs_K(this.la);
    gvjs_5k(this)
};

function gvjs_gJ(a) {
    if (a.Pb && !a.Pb.Ue) {
        var b = a.Pb.Rc;
        b.zo = Infinity;
        b.gd.stop()
    }
    gvjs_K(a.Pb);
    if (a.la && !a.la.Ue) {
        b = a.la.ya();
        var c = a.la.nu();
        a.Rt = b;
        c.clear()
    }
    gvjs_K(a.nm);
    gvjs_5k(a.Lr)
}

function gvjs_hJ(a) {
    var b = a.Rt || a.la && a.la.ya();
    a.Rt = null;
    b && b.clear()
}

function gvjs_vha(a) {
    gvjs_v(a.uH, function(b) {
        typeof b === gvjs_m ? a.removeAction(b) : a.setAction(b)
    });
    a.uH = []
}
gvjs_.setAction = function(a) {
    null != this.Ee ? this.Ee.setAction(a) : this.uH.push(a)
};

function gvjs_xha(a, b) {
    var c = new gvjs_Go;
    c.setSelection(b);
    b = gvjs_Jo(c);
    c = !1;
    for (var d = 0; d < b.length; d++) {
        var e = b[d],
            f = e.column;
        e = e.row;
        f = a.ca.wm && a.ca.wm[f];
        if (!f) return !1;
        var g = f.yb,
            h = void 0,
            k = void 0;
        null != g ? k = a.ca.series[g].points[e] : h = a.ca.Fa[e];
        if (!k && !h) return !1;
        if (f.role === gvjs_nr) {
            if (c) return !1;
            c = !0;
            if (!(k || h).Ib) return !1
        }
    }
    return !0
}
gvjs_.setSelection = function(a) {
    if (gvjs_xha(this, a)) {
        var b = null;
        if (this.ca.chartType !== gvjs_Ru) {
            var c = new gvjs_Go;
            c.setSelection(a);
            c = gvjs_Jo(c);
            for (var d = 0; d < c.length; d++) {
                var e = c[d],
                    f = this.ca.wm[e.column];
                if (f.role === gvjs_nr) {
                    b = {
                        yb: f.yb,
                        CQ: e.row
                    };
                    break
                }
            }
        }
        this.refresh(!0);
        this.Bd.selected.setSelection(a);
        b && (this.Bd.annotations.cJ = b);
        this.refresh(!1)
    }
};
gvjs_.refresh = function(a) {
    if (this.Qo) {
        var b = this.Qo;
        if (!this.Ee.z2(this.Bd, this.Qo)) {
            var c = this.Bd.wl;
            if (c) {
                this.options = new gvjs_Si(gvjs_wf(this.d8));
                gvjs_Ep(this.options, 0, c);
                c = this.la.ya();
                c = this.iI(this.dataTable, this.options, c.ud.bind(c), this.width, this.height).Si();
                this.Pb.ua = c;
                this.Rt && (this.Rt.clear(), this.Rt = null);
                if (this.nm && this.nm instanceof gvjs_6H) {
                    var d = this.nm;
                    d.ca = c;
                    d.zL = gvjs_7H(d)
                }
                d = gvjs_tI(this.Ee, c, this.Bd);
                this.ca = c;
                this.Uh.bM(this.ca);
                c = this.Uh;
                var e = this.ca;
                (null == d ? 0 : d.cf) ||
                !c.ae.overlaybox || gvjs_HF(c, gvjs_Pu);
                c.ae = {};
                c.pu = {};
                gvjs_AF(c, e, d);
                c.renderer.deleteContents(!0);
                gvjs_BF(c, d, c.renderer.Xr);
                c.renderer.flush();
                this.Bd.wl = null;
                this.Qo = this.Bd.clone()
            } else {
                this.Qo = this.Bd.clone();
                d = gvjs_tI(this.Ee, this.ca, this.Bd);
                c = this.Uh;
                e = this.ca;
                var f = gvjs_Tg({
                    series: null,
                    Fa: null,
                    legend: null,
                    Vm: null,
                    Ag: null,
                    cf: null
                });
                gvjs_xy(d, f) && gvjs_xy(c.Po, f) ? (gvjs_ox(d.legend, c.Po.legend) || (c.renderer.xb(c.xp), f = new gvjs_tD(2), f.ed(0, e.legend || {}), f.ed(1, d.legend || {}), f = f.compact(), c.GC(f)),
                    gvjs_ox(d.Ag, c.Po.Ag) || (c.renderer.xb(c.Xc), f = new gvjs_tD(2), f.ed(0, e.Ag || {}), f.ed(1, d.Ag || {}), f = f.compact(), c.FC(f)), c.G7(e, d), null != d && d.cf && !gvjs_ox(d.cf, c.Po.cf) && (gvjs_HF(c, gvjs_Pu), e = d.cf, f = new gvjs__, f.ie(e.color), f.Qd(e.opacity), e = c.renderer.bb(e.left, e.top, e.width, e.height, f, c.renderer.Xr), c.registerElement(e, gvjs_Pu)), c.Po = d) : c.drawChart(e, d)
            }
        }
        a && this.Pq.ar(b, this.Qo, this.ca.chartType, this.ca.series)
    }
};
gvjs_.getSelection = function() {
    return this.Qo ? this.Qo.selected.getSelection() : []
};
gvjs_.getAction = function(a) {
    if (this.Ee) return this.Ee.getAction(a)
};
gvjs_.removeAction = function(a) {
    null != this.Ee ? this.Ee.removeAction(a) : this.uH.push(a)
};
gvjs_.dump = function() {
    var a = this.la.ya();
    return a instanceof gvjs_mA ? a.container.innerHTML : ""
};

function gvjs_iJ(a) {
    var b = gvjs_tI(a.Ee, a.ca, a.Bd);
    a.Uh.drawChart(a.ca, b);
    a.Qo = a.Bd.clone()
}

function gvjs_jJ(a) {
    var b = a.la.ya(),
        c = a.la.nu();
    gvjs_K(a.nm);
    a.nm = a.d1(a.Lr, b, c, a.ca);
    gvjs_Lga(a.nm);
    gvjs_Mga(a.nm);
    gvjs_Nga(a.nm)
}

function gvjs_wha(a, b) {
    var c = gvjs_1I(a.options, 0, gvjs_8t);
    if (a.animation) {
        var d = a.animation.w7;
        gvjs_pJ(a)
    } else d = a.ca;
    if (!c || !(c.startup || d && d.chartType === b.chartType) || b.chartType === gvjs_Bt || b.chartType === gvjs_Ru) return !1;
    if (!d) {
        var e = gvjs_fx(a.dataTable.getNumberOfColumns());
        d = a.dataTable instanceof gvjs_G;
        var f = a.dataTable.Hm();
        if (!d) {
            var g = a.dataTable;
            f = gvjs_w(g.Hm(), function(u) {
                return typeof u === gvjs_g ? u : {
                    sourceColumn: u,
                    properties: g.getColumnProperties(u)
                }
            })
        }
        var h = b.series;
        d = b.wm;
        b.chartType ===
            gvjs_Wr && (d = [{
                role: gvjs_nd
            }, {
                role: gvjs_Gs
            }, {
                role: gvjs_ts,
                yb: 0
            }]);
        var k, l;
        gvjs_v(d, function(u, v) {
            if (u.role === gvjs_ts || u.role === gvjs_Rt) {
                var w = gvjs_z(f[v]);
                if (u.role === gvjs_ts) {
                    u = h[u.yb];
                    if (u.Fe) return;
                    u = u.targetAxisIndex || 0;
                    if (null != u) {
                        var x = b.orientation && b.orientation !== gvjs_R ? b.hAxes[u] : b.vAxes[u];
                        k = function() {
                            return x.baseline.Oa
                        };
                        l = x.dataType
                    }
                } else w.role = gvjs_Rt;
                w.calc = k;
                w.type = l;
                e[v] = w
            }
        });
        d = new gvjs_G(a.dataTable);
        d.setColumns(e);
        var m = {},
            n = b.hAxes;
        if (n) {
            var p = Object.keys(n);
            p = gvjs_q(p);
            for (var q =
                    p.next(); !q.done; q = p.next()) {
                var r = q.value;
                typeof r === gvjs_f && (q = n[r], q.viewWindow && (m[r] = {
                    viewWindow: {
                        numericMin: q.viewWindow.min,
                        numericMax: q.viewWindow.max
                    }
                }))
            }
        }
        p = {};
        if (n = b.vAxes)
            for (r = Object.keys(n), r = gvjs_q(r), q = r.next(); !q.done; q = r.next())
                if (q = q.value, typeof q === gvjs_f) {
                    var t = n[q];
                    t.viewWindow && (p[q] = {
                        viewWindow: {
                            numericMin: t.viewWindow.min,
                            numericMax: t.viewWindow.max
                        }
                    })
                }
        gvjs_Ep(a.options, 0, {
            hAxes: m,
            vAxes: p
        });
        m = a.la.ya();
        d = a.iI(d, a.options, m.ud.bind(m), a.width, a.height).Si()
    }
    a.ca = null;
    m = Date.now();
    n = a.animation && a.animation.VU || 0;
    gvjs_pJ(a);
    a.animation = {
        Hsa: d,
        A6: b,
        interpolator: new gvjs_KI(d, b),
        w7: d,
        startTime: m,
        endTime: m + c.duration,
        VU: n,
        timer: new gvjs_az(10),
        oda: c.easing,
        ET: c.ET,
        done: !1
    };
    a.o4();
    gvjs_M(a.animation.timer, gvjs_Qv, a.o4.bind(a));
    a.animation.timer.start();
    a.ca = b;
    return !0
}
gvjs_.o4 = function() {
    var a = this.animation;
    this.ca = null;
    if (a.done) gvjs_pJ(this), this.ca = a.A6, gvjs_iJ(this), gvjs_jJ(this), this.Pq.dispatchEvent(gvjs_nha);
    else {
        var b = Date.now(),
            c = (b - a.startTime) / (a.endTime - a.startTime);
        if (1 > c) {
            if (b - a.VU < 1E3 / this.animation.ET) return
        } else c = 1, a.done = !0;
        c = a.interpolator.interpolate(a.oda(c));
        a.w7 = c;
        a.VU = b;
        this.Uh.drawChart(c, {});
        this.Pq.dispatchEvent(gvjs_oha)
    }
    this.ca = a.A6
};

function gvjs_pJ(a) {
    a.animation && (gvjs_K(a.animation.timer), a.animation = null)
}
gvjs_.getChartAreaBoundingBox = function() {
    var a = this.ca.chartArea;
    return {
        left: a.left,
        top: a.top,
        width: a.width,
        height: a.height
    }
};
gvjs_.getBoundingBox = function(a) {
    return null == this.Uh ? null : (a = this.Uh.getBoundingBox(a)) ? {
        left: a.left,
        top: a.top,
        width: a.right - a.left,
        height: a.bottom - a.top
    } : null
};
gvjs_.getChartLayoutInterface = function() {
    var a = this.ca;
    if (null == a) throw Error("redundant error checking");
    return {
        getChartAreaBoundingBox: this.getChartAreaBoundingBox.bind(this),
        getBoundingBox: this.getBoundingBox.bind(this),
        getXLocation: gvjs_qfa.bind(null, a),
        getYLocation: gvjs_rfa.bind(null, a),
        getHAxisValue: gvjs_sfa.bind(null, a),
        getVAxisValue: gvjs_tfa.bind(null, a),
        getPointDatum: gvjs_ufa.bind(null, a)
    }
};
gvjs_.Si = function() {
    return this.ca
};
gvjs_.getImageURI = function() {
    if (!this.options || !this.ca || !this.Bd) throw Error("Chart has not finished drawing.");
    var a = new gvjs_B(this.width, this.height),
        b = gvjs_ii(this.container).createElement(gvjs_5b);
    a = gvjs_zA(b, a);
    a = new gvjs_1z(b, a);
    a = this.dQ(new gvjs_pz(b), a);
    var c = gvjs_tI(this.Ee, this.ca, this.Bd);
    a.drawChart(this.ca, c);
    return b.childNodes[0].toDataURL("image/png")
};
var gvjs_lJ = {
    LINE: gvjs_d,
    AREA: gvjs_Ar,
    s$: "columns",
    fO: gvjs_Hr,
    tO: gvjs_j,
    sO: gvjs_Ru
};

function gvjs_qJ(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_c, gvjs_Ar, gvjs_R)
}
gvjs_r(gvjs_qJ, gvjs_fJ);

function gvjs_rJ(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_c, gvjs_d, gvjs_R)
}
gvjs_r(gvjs_rJ, gvjs_fJ);

function gvjs_sJ(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_j)
}
gvjs_r(gvjs_sJ, gvjs_fJ);
gvjs_sJ.prototype.computeDiff = function(a, b) {
    return gvjs_kJ(a, b)
};

function gvjs_tJ(a) {
    gvjs_fJ.call(this, a);
    this.setChartType(gvjs_c, gvjs_e, gvjs_R)
}
gvjs_r(gvjs_tJ, gvjs_fJ);
var gvjs_yha = 1 / Math.sqrt(2 * Math.PI);

function gvjs_2(a, b) {
    this.Ff = a;
    this.Ma = null != b && gvjs_z(b) || {}
}

function gvjs_uJ(a, b) {
    a = gvjs_3(new gvjs_2(gvjs_Wq), gvjs_Xq, a);
    null != b && gvjs_3(a, gvjs_Zq, b);
    return a
}

function gvjs_vJ(a) {
    a = gvjs_Eg(a);
    return new gvjs_2(a.Ff, a.Ma)
}
gvjs_ = gvjs_2.prototype;
gvjs_.clone = function() {
    return gvjs_vJ(this.Ic())
};
gvjs_.equals = function(a) {
    var b = this;
    if (!a || this.Ff != a.Ff) return !1;
    var c = gvjs_Tg(this.Ma);
    return c.length !== gvjs_Tg(a.Ma).length ? !1 : gvjs_sf(gvjs_w(c, function(d) {
        return b.Ma[d] === a.Ma[d]
    }), gvjs_pw)
};

function gvjs_3(a, b, c) {
    a.Ma[b] = c;
    return a
}
gvjs_.VS = function(a) {
    return this.Ff === a.Ff && gvjs_Rg(this.Ma, function(b, c) {
        return a.Ma[c] === b
    })
};
gvjs_.type = function() {
    return this.Ff
};
gvjs_.Ic = function() {
    return gvjs_Fg(this)
};

function gvjs_wJ() {
    this.Lp = this.JO = null
}

function gvjs_xJ(a) {
    var b = new gvjs_wJ;
    b.JO = a;
    return b
}

function gvjs_yJ(a) {
    var b = new gvjs_wJ;
    b.Lp = a;
    return b
}

function gvjs_zJ(a) {
    if (null != a.JO) return a.JO;
    throw Error("AbstractRenderer not set");
}
gvjs_wJ.prototype.kn = gvjs_p(99);

function gvjs_AJ() {};

function gvjs_BJ() {
    this.selected = new gvjs_Go;
    this.Ak = this.Jd = null;
    this.rk = new Set
}
gvjs_BJ.prototype.clone = function() {
    var a = new gvjs_BJ;
    a.selected = this.selected.clone();
    a.Jd = this.Jd ? this.Jd.clone() : null;
    a.Ak = this.Ak ? this.Ak.clone() : null;
    a.rk = new Set(this.rk);
    return a
};
gvjs_BJ.prototype.equals = function(a) {
    return this.selected.equals(a.selected) && (this.Jd ? this.Jd.equals(a.Jd) : !a.Jd) && (this.Ak ? this.Ak.equals(a.Ak) : !a.Ak) && gvjs_rx(this.rk, a.rk)
};

function gvjs_CJ(a, b) {
    this.lR = a;
    this.E2 = b || null;
    this.V = null
}
gvjs_CJ.prototype.setState = function(a) {
    this.V = a.clone()
};
gvjs_CJ.prototype.getState = function() {
    return this.V
};

function gvjs_DJ(a, b) {
    if (!b) return null;
    var c = {};
    c.row = b.Ma.ROW_INDEX;
    c.column = b.Ma.COLUMN_INDEX;
    a.E2 && gvjs_y(a.E2, function(d, e) {
        e = b.Ma[e];
        null != e && (c[d] = e)
    });
    return c
}
gvjs_CJ.prototype.ar = function(a) {
    var b = this.V,
        c = [];
    a.selected.equals(b.selected) && gvjs_rx(a.rk, b.rk) || c.push({
        event: gvjs_k,
        data: null
    });
    var d = a.Jd;
    b = b.Jd;
    if (!d && b || d && !d.equals(b)) {
        var e = !!b && !!d && !b.equals(d);
        !e && d || c.push({
            event: gvjs_Hu,
            data: gvjs_DJ(this, b)
        });
        !e && b || c.push({
            event: gvjs_Iu,
            data: gvjs_DJ(this, d)
        })
    }
    this.V = a.clone();
    c.forEach(function(f) {
        this.dispatchEvent(f.event, f.data)
    }, this)
};
gvjs_CJ.prototype.dispatchEvent = function(a, b) {
    gvjs_N(this.lR, a, b)
};

function gvjs_EJ(a, b) {
    gvjs_L.call(this);
    this.V = null;
    this.Ar = b;
    this.Rc = new gvjs_VI(a);
    gvjs_Rw(this, this.Rc)
}
gvjs_r(gvjs_EJ, gvjs_L);
gvjs_EJ.prototype.setState = function(a) {
    this.V = a
};
gvjs_EJ.prototype.gD = function() {
    var a = this;
    return function(b, c) {
        a.handleEvent(b, c)
    }
};
gvjs_EJ.prototype.handleEvent = function(a, b) {
    if (null != this.Ar) {
        var c = !1;
        this.Ar.forEach(function(d) {
            d.Nda(a, b) && (d = d.VB(a, b, this.V), c = c || d)
        }, this);
        c && gvjs_WI(this.Rc, 50)
    }
};

function gvjs_zha() {
    this.Ro = [];
    this.So = [];
    this.cI = !1
};

function gvjs_FJ(a) {
    this.V = null;
    this.LC = [];
    this.Ar = a
}
gvjs_ = gvjs_FJ.prototype;
gvjs_.SB = function(a) {
    if (this.V.equals(a)) return {
        cI: !1,
        Ro: [],
        So: []
    };
    var b = this.LC;
    a = this.Vh(a);
    return this.bQ(a, b)
};
gvjs_.Vh = function(a) {
    if (null == this.Ar) return [];
    var b = this.Ar.reduce(function(c, d) {
        gvjs_xf(c, d.Vh(a));
        return c
    }, []);
    this.LC = b;
    this.V = a.clone();
    return b
};
gvjs_.bQ = function(a, b) {
    a = this.RB(a);
    var c = this.RB(b);
    b = gvjs_sx(a, c);
    a = gvjs_sx(c, a);
    c = new gvjs_zha;
    c.Ro = this.ZE(b);
    c.So = this.ZE(a);
    return c
};
gvjs_.RB = function(a) {
    a = a.map(function(b) {
        return gvjs_Fg(b)
    });
    return new Set(a)
};
gvjs_.ZE = function(a) {
    return gvjs_Cg(a).map(function(b) {
        b = gvjs_Eg(b);
        b.targets = b.targets.map(function(c) {
            return new gvjs_2(c.Ff, c.Ma)
        });
        return b
    })
};

function gvjs_GJ(a, b, c, d, e, f) {
    gvjs_L.call(this);
    this.du = a;
    this.Li = this.state = null;
    this.G2 = this.du.Jm();
    a = this.du.Ao(e);
    this.Ee = new gvjs_FJ(a);
    e = f(this.Bv.bind(this, !0));
    this.Pb = new gvjs_EJ(e, a);
    gvjs_Rw(this, this.Pb);
    this.Uh = this.du.Qk(b, c, this.Pb.gD(), f);
    this.Rj = new gvjs_CJ(d, this.G2)
}
gvjs_r(gvjs_GJ, gvjs_L);
gvjs_GJ.prototype.draw = function(a, b) {
    this.state = b.clone();
    this.Pb.setState(this.state);
    this.Rj.setState(this.state);
    b = this.Ee.Vh(this.state);
    this.Uh.draw(a, b);
    this.Li = this.state.clone();
    this.Rj.dispatchEvent(gvjs_h, null)
};
gvjs_GJ.prototype.Bv = function(a) {
    var b = this.Ee.SB(this.state);
    this.Uh.refresh(b);
    this.Li = this.state.clone();
    a && this.Rj.ar(this.state)
};
gvjs_GJ.prototype.setSelection = function(a) {
    this.Bv(!0);
    this.state.selected.setSelection(a);
    this.Bv(!1)
};
gvjs_GJ.prototype.getSelection = function() {
    var a = this,
        b = this.Li.selected.getSelection(),
        c = [];
    this.Li.rk.forEach(function(d) {
        var e = gvjs_vJ(d),
            f = {};
        gvjs_y(a.G2, function(g, h) {
            h = e.Ma[h];
            null != h && (f[g] = h)
        });
        c.push(f)
    });
    gvjs_xf(b, c);
    return b
};

function gvjs_HJ(a) {
    gvjs_cn.call(this, a);
    this.Ke = null
}
gvjs_r(gvjs_HJ, gvjs_cn);
gvjs_ = gvjs_HJ.prototype;
gvjs_.Jm = function() {
    return null
};
gvjs_.getDefaultOptions = function() {};
gvjs_.Qk = function() {};
gvjs_.Fj = function() {};
gvjs_.Gj = function() {};
gvjs_.Ao = function() {
    return null
};
gvjs_.Wc = function() {
    gvjs_K(this.Ke);
    this.Ke = null
};
gvjs_.setSelection = function(a) {
    this.Ke && this.Ke.setSelection(a)
};
gvjs_.getSelection = function() {
    return this.Ke ? this.Ke.getSelection() : []
};

function gvjs_IJ(a, b, c, d, e) {
    this.du = a;
    this.renderer = b;
    this.Sc = gvjs_xJ(b);
    this.fj = c;
    this.ki = null;
    this.Uu = gvjs_Aha;
    this.Pb = d;
    this.mf = e;
    this.lm = null
}
gvjs_r(gvjs_IJ, gvjs_AJ);
gvjs_ = gvjs_IJ.prototype;
gvjs_.draw = function(a) {
    this.ki = {};
    var b = this.renderer;
    b.clear();
    this.lm = this.du.Fj(a, this.fj);
    a = this.lm.getSize();
    a = b.Rk(a.width, a.height);
    for (var c = 0; c < this.Uu.length; c++) {
        var d = this.Uu[c],
            e = b.ta();
        b.appendChild(a, e);
        this.ki[d] = e
    }
    this.lm.draw(this);
    this.Rz(a)
};
gvjs_.Yp = gvjs_p(100);
gvjs_.refresh = function(a) {
    this.Xp(a.So, !1);
    this.Xp(a.Ro, !0);
    this.lm.draw(this)
};
gvjs_.Xp = function(a, b) {
    for (var c = 0; c < a.length; c++)
        for (var d = a[c], e = d.targets, f = 0; f < e.length; f++) this.lm.kj(e[f], d.effect, b)
};
gvjs_.Rz = function(a) {
    var b = this.renderer;
    b.qb(a, gvjs_ms, gvjs_$y);
    b.qb(a, gvjs_Dd, this.mf(this.handleEvent.bind(this, gvjs_Gt)));
    b.qb(a, gvjs_Cd, this.mf(this.handleEvent.bind(this, gvjs_Ht)));
    b.qb(a, gvjs_fs, this.mf(this.handleEvent.bind(this, gvjs_fs)))
};
gvjs_.handleEvent = function(a, b) {
    b.stopPropagation && b.stopPropagation();
    b = this.renderer.sr(b.target);
    b != gvjs_2q && (b = gvjs_vJ(b), this.Pb(b, a))
};
gvjs_.ya = function() {
    return this.Sc
};
gvjs_.Ed = function(a, b, c, d) {
    null != b ? this.rV(a, b) : this.Lk(a, c, d)
};
gvjs_.Lk = function(a, b, c) {
    this.renderer.appendChild(this.ki[c], a);
    this.renderer.Cl(a, b.Ic())
};
gvjs_.rV = function(a, b) {
    gvjs_Gi(b).replaceChild(a, b);
    b = this.renderer.sr(b);
    this.renderer.Cl(a, b)
};
gvjs_.gf = function(a) {
    this.renderer.gf(a)
};
var gvjs_Aha = [gvjs_np, gvjs_Xd, gvjs_$u, gvjs_4q, gvjs_3q];

function gvjs_JJ(a) {
    gvjs_HJ.call(this, a);
    this.la = null
}
gvjs_r(gvjs_JJ, gvjs_HJ);
gvjs_ = gvjs_JJ.prototype;
gvjs_.Qk = function(a, b, c, d) {
    if (null == b) throw Error("Internal error: missing overlayArea");
    a = gvjs_zJ(a);
    return new gvjs_IJ(this, a, b, c, d)
};
gvjs_.Nc = function(a, b, c) {
    (0, gvjs_J.removeAll)(this.container);
    c = c || {};
    var d = this.getDefaultOptions() || {};
    c = new gvjs_Si([c, d]);
    d = this.pb(c);
    var e = this.getHeight(c);
    d = new gvjs_B(d, e);
    e = gvjs_D(c, gvjs_ct);
    this.Lt(d, a, e);
    this.la.Vl(this.hC.bind(this, b, c, d, a), a)
};
gvjs_.Lt = function(a, b, c) {
    null == this.la ? this.la = new gvjs_BA(this.container, a, b, c) : this.la.update(a, b)
};
gvjs_.hC = function(a, b, c, d) {
    var e = this.la.ya(),
        f = this.la.nu();
    c = this.Gj(a, b, e.ud.bind(e), c).Of();
    gvjs_K(this.Ke);
    if (e instanceof gvjs_xz) var g = gvjs_xJ(e);
    else if (e instanceof gvjs_LA) g = gvjs_yJ(e);
    else throw Error("Unknown renderer type");
    this.Ke = new gvjs_GJ(this, g, f, this, b, d);
    this.Ke.draw(c, new gvjs_BJ);
    e.Jt && (b = e.Jt()) && a && gvjs_1m(b, gvjs_dJ(a))
};
gvjs_.Wc = function() {
    gvjs_HJ.prototype.Wc.call(this);
    gvjs_K(this.la);
    this.la = null
};
gvjs_t("gviz.fw.FrameworkVisualization.convertOptions", function(a) {
    return a || {}
});

function gvjs_KJ(a, b, c) {
    c = null != c ? c.map(function(l) {
        return [l, 0]
    }) : b ? gvjs_Bha : gvjs_Cha;
    var d = c.length;
    this.Bh = [];
    for (var e = 1 + Math.floor((a - 1) / d), f = Math.ceil(a / e), g = [], h = 0; h < d; h++) c[h][1] < f && g.push(c[h][0]);
    for (h = 0; h < a; h++) {
        var k = Math.pow(b ? .7 : .85, b ? Math.floor(h / f) : h % e);
        this.Bh[h] = gvjs_w(g[b ? h % f : Math.floor(h / e)], function(l) {
            return ~~(k * l + 255 * (1 - k))
        })
    }
}
gvjs_KJ.prototype.getSize = function() {
    return this.Bh.length
};
gvjs_KJ.prototype.Gm = function() {
    return "rgb(" + this.Bh[void 0] + ")"
};

function gvjs_LJ(a, b) {
    function c(d) {
        d = d.toString(16);
        1 == d.length && (d = "0" + d);
        return d
    }
    a = a.Bh[b];
    return "#" + (c(a[0]) + c(a[1]) + c(a[2])).toUpperCase()
}
var gvjs_Cha = [
        [
            [66, 133, 244], 0
        ],
        [
            [219, 68, 55], 0
        ],
        [
            [244, 180, 0], 0
        ],
        [
            [15, 157, 88], 0
        ],
        [
            [171, 71, 188], 0
        ],
        [
            [0, 172, 193], 0
        ],
        [
            [255, 112, 67], 0
        ],
        [
            [158, 157, 36], 0
        ],
        [
            [92, 107, 192], 0
        ],
        [
            [240, 98, 146], 0
        ],
        [
            [0, 121, 107], 0
        ],
        [
            [194, 24, 91], 0
        ]
    ],
    gvjs_Bha = [
        [
            [67, 69, 157], 6
        ],
        [
            [83, 168, 251], 8
        ],
        [
            [95, 150, 84], 10
        ],
        [
            [241, 202, 58], 2
        ],
        [
            [231, 113, 27], 5
        ],
        [
            [135, 27, 71], 4
        ],
        [
            [67, 116, 224], 0
        ],
        [
            [26, 135, 99], 1
        ],
        [
            [185, 194, 70], 9
        ],
        [
            [228, 147, 7], 7
        ],
        [
            [211, 54, 45], 3
        ]
    ];

function gvjs_MJ(a, b) {
    gvjs_L.call(this);
    this.id = a;
    this.name = b;
    this.children = this.parent = null
}
gvjs_r(gvjs_MJ, gvjs_L);
gvjs_ = gvjs_MJ.prototype;
gvjs_.EF = function(a) {
    this.id = a
};
gvjs_.getId = function() {
    return this.id
};
gvjs_.getName = function() {
    return this.name
};
gvjs_.getParent = function() {
    return this.parent
};
gvjs_.Or = function() {
    return !this.Cc()
};
gvjs_.getChildren = function() {
    return this.children || []
};
gvjs_.td = function(a) {
    return this.getChildren()[a] || null
};
gvjs_.Cc = function() {
    return this.getChildren().length
};
gvjs_.getHeight = function() {
    var a = this.getChildren();
    return Number(a.reduce(function(b, c) {
        return Math.max(b, c.getHeight())
    }, -1)) + 1
};
gvjs_.contains = function(a) {
    do a = a.getParent(); while (a && a !== this);
    return !!a
};
gvjs_.Rl = function(a, b) {
    function c(d, e) {
        if (!1 !== a.call(b, d, e)) {
            d = d.getChildren();
            d = gvjs_q(d);
            for (var f = d.next(); !f.done; f = d.next()) c(f.value, e + 1)
        }
    }
    c(this, 0)
};
gvjs_.find = function(a, b) {
    var c = [];
    this.Rl(function(d) {
        a.call(b, d) && c.push(d)
    });
    return c
};
gvjs_.ox = gvjs_p(102);
gvjs_.Kv = function(a) {
    this.parent = a
};
gvjs_.addChild = function(a) {
    a.Kv(this);
    this.children = this.children || [];
    this.children.push(a);
    gvjs_Rw(this, a)
};

function gvjs_NJ(a, b, c) {
    gvjs_MJ.call(this, c, a);
    this.dataTable = b
}
gvjs_r(gvjs_NJ, gvjs_MJ);
gvjs_ = gvjs_NJ.prototype;
gvjs_.getDataTable = function() {
    return this.dataTable
};

function gvjs_OJ(a) {
    return a.getFormattedValue(0) || a.getName()
}
gvjs_.getRowProperty = function(a) {
    return this.UR(this.dataTable.getRowProperty, a)
};
gvjs_.getValue = function(a) {
    return this.UR(this.dataTable.getValue, a)
};
gvjs_.getFormattedValue = function(a) {
    return this.UR(this.dataTable.getFormattedValue, a)
};
gvjs_.UR = function(a) {
    var b = this.getId();
    return null != b ? (b = [b], gvjs_xf(b, Array.prototype.slice.call(arguments, 1)), a.apply(this.dataTable, b)) : null
};

function gvjs_PJ() {
    gvjs_L.call(this);
    this.ij = [];
    this.gs = {}
}
gvjs_r(gvjs_PJ, gvjs_L);
gvjs_ = gvjs_PJ.prototype;
gvjs_.qB = function(a) {
    var b = a.getId();
    null != b && (this.gs[b] = a)
};
gvjs_.getHeight = function() {
    return this.ij.reduce(function(a, b) {
        return Math.max(a, b.getHeight())
    }, -1)
};
gvjs_.Rl = function(a, b) {
    for (var c = this.ij, d = 0; d < c.length; d++) c[d].Rl(a, b)
};
gvjs_.find = function(a, b) {
    for (var c = [], d = this.ij, e = 0; e < d.length; e++) gvjs_xf(c, d[e].find(a, b));
    return c
};
gvjs_.ox = gvjs_p(101);

function gvjs_QJ(a, b) {
    gvjs_PJ.call(this);
    if (2 > a.getNumberOfColumns()) throw Error("Data table should have at least 2 columns");
    if (a.getColumnType(0) !== gvjs_m) throw Error("Column 0 must be of type string");
    if (a.getColumnType(1) !== gvjs_m) throw Error("Column 1 must be of type string");
    b = this.MU(b);
    for (var c = b.A2, d = b.B2, e = b.a3, f = {}, g = [], h = 0; h < a.getNumberOfRows(); h++)
        if (b = a.getValue(h, 0)) {
            var k = f[b];
            k ? null == k.getId() && k.EF(h) : (f[b] = k = new gvjs_NJ(b, a, h), g.push(k));
            var l = k.getValue(1);
            if (l)
                if (b = f[l], b || (f[l] =
                        b = new gvjs_NJ(l, a, null), g.push(b)), k.getParent()) {
                    if (d) throw Error("More than one row with the same id (" + k.getName() + ").");
                } else if (k !== b && !k.contains(b)) b.addChild(k);
            else if (c) {
                a = Error;
                e = gvjs_Dha;
                g = b;
                c = [];
                for (b = b.getParent(); b;) c.push(b), b = b.getParent();
                throw a("Data contains a cycle: " + e(this, gvjs_vf(g, c)) + ".");
            }
        }
    for (b = 0; b < g.length; b++) {
        a = g[b];
        if (e && null === a.getId()) throw Error('Failed to find row with id "' + a.getName() + '".');
        a.getParent() || (this.ij.push(a), gvjs_Rw(this, a));
        this.qB(a)
    }
}
gvjs_r(gvjs_QJ, gvjs_PJ);

function gvjs_Dha(a, b) {
    return b.map(function(c) {
        return c.getName()
    }).toString()
}
gvjs_QJ.prototype.MU = function(a) {
    var b = new gvjs_tD(2);
    b.ed(0, {
        A2: !0,
        B2: !0,
        a3: !0
    });
    null != a && b.ed(1, a);
    return b.compact()
};

function gvjs_RJ(a, b, c, d, e) {
    gvjs_PJ.call(this);
    a = a.ij;
    for (var f = 0; f < a.length; f++) {
        var g = gvjs_SJ(this, a[f], b, c, d, e);
        this.ij.push(g);
        gvjs_Rw(this, g);
        this.qB(g)
    }
}
gvjs_r(gvjs_RJ, gvjs_PJ);

function gvjs_SJ(a, b, c, d, e, f) {
    var g = null,
        h = null != e && null != f;
    e = e || 0;
    f = f || 0;
    if (h) {
        g = (e + f / 2 * b.Cc()) % 360;
        var k = e
    }
    e = c.call(d, b, g);
    b = b.getChildren();
    for (g = 0; g < b.length; g++) {
        var l = b[g];
        h ? (l = gvjs_SJ(a, l, c, d, k, l.Or() ? 0 : f / l.Cc()), k = (k + f) % 360) : l = gvjs_SJ(a, l, c, d);
        a.qB(l);
        e.addChild(l)
    }
    return e
};

function gvjs_Eha(a, b) {
    Array.isArray(b) || (b = [b]);
    b = b.map(function(c) {
        return typeof c === gvjs_m ? c : c.property + " " + c.duration + "s " + c.timing + " " + c.delay + "s"
    });
    gvjs_TJ(a, b.join(","))
}
var gvjs_Fha = gvjs_Pg(function() {
    if (gvjs_x) return !0;
    var a = gvjs_ti(gvjs_b),
        b = gvjs_If ? "-webkit" : gvjs_Hf ? "-moz" : gvjs_x ? "-ms" : null,
        c = {
            transition: gvjs_Ku
        };
    b && (c[b + "-transition"] = gvjs_Ku);
    b = gvjs_Ah(gvjs_5b, {
        style: c
    });
    gvjs_Hh(a, b);
    return "" != gvjs_Py(a.firstChild, "transition")
});

function gvjs_TJ(a, b) {
    gvjs_I(a, "transition", b)
};

function gvjs_UJ(a, b, c, d, e) {
    gvjs_nD.call(this);
    this.O = a;
    this.ZQ = b;
    this.iha = c;
    this.O2 = d;
    this.tA = Array.isArray(e) ? e : [e]
}
gvjs_u(gvjs_UJ, gvjs_nD);
gvjs_ = gvjs_UJ.prototype;
gvjs_.play = function() {
    if (1 == this.V) return !1;
    this.SE();
    this.Lf("play");
    this.startTime = gvjs_Ue();
    this.V = 1;
    if (gvjs_Fha()) return gvjs_I(this.O, this.iha), this.pj = gvjs_yl(this.Zja, void 0, this), !0;
    this.Uv(!1);
    return !1
};
gvjs_.Zja = function() {
    gvjs_1y(this.O);
    gvjs_Eha(this.O, this.tA);
    gvjs_I(this.O, this.O2);
    this.pj = gvjs_yl(gvjs_Se(this.Uv, this, !1), 1E3 * this.ZQ)
};
gvjs_.stop = function() {
    1 == this.V && this.Uv(!0)
};
gvjs_.Uv = function(a) {
    gvjs_TJ(this.O, "");
    gvjs_zl(this.pj);
    gvjs_I(this.O, this.O2);
    this.endTime = gvjs_Ue();
    this.V = 0;
    a ? this.Lf(gvjs_zv) : this.Lf(gvjs__s);
    this.nv()
};
gvjs_.J = function() {
    this.stop();
    gvjs_UJ.G.J.call(this)
};
gvjs_.pause = function() {};

function gvjs_VJ(a, b, c, d, e) {
    return new gvjs_UJ(a, b, {
        opacity: d
    }, {
        opacity: e
    }, {
        property: gvjs_Ju,
        duration: b,
        timing: c,
        delay: 0
    })
}

function gvjs_WJ(a, b) {
    return gvjs_VJ(a, b, "ease-out", 0, 1)
}

function gvjs_XJ(a, b) {
    return gvjs_VJ(a, b, "ease-in", 1, 0)
};